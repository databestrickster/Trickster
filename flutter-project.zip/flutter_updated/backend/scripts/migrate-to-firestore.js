/**
 * Script migrasi sekali jalan: data/*.json (users, deposits, orders, config)
 * -> Firestore (collections: users, deposits, orders, config/app)
 *
 * CARA PAKAI:
 *   1. Pastikan .env sudah ada FIREBASE_SERVICE_ACCOUNT (lihat config/firebase.js)
 *   2. npm install (supaya firebase-admin terpasang)
 *   3. node scripts/migrate-to-firestore.js
 *
 * Script ini aman dijalankan berkali-kali (idempotent) - data lama di
 * data/*.json TIDAK dihapus, cuma dibaca lalu di-push/overwrite ke Firestore.
 */

require('dotenv').config();
const fs   = require('fs');
const path = require('path');
const { db } = require('../config/firebase');

const DATA_DIR      = path.join(__dirname, '..', 'data');
const USERS_FILE    = path.join(DATA_DIR, 'users.json');
const DEPOSITS_FILE = path.join(DATA_DIR, 'deposits.json');
const ORDERS_FILE   = path.join(DATA_DIR, 'orders.json');
const CONFIG_FILE   = path.join(DATA_DIR, 'config.json');

function readJsonSafe(filePath) {
  if (!fs.existsSync(filePath)) {
    console.log(`⚠️  Tidak ditemukan: ${filePath} (dilewati)`);
    return null;
  }
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch (err) {
    console.error(`❌ Gagal parse ${filePath}:`, err.message);
    return null;
  }
}

async function migrateCollection(name, dataObj) {
  if (!dataObj) return 0;
  const entries = Object.entries(dataObj);
  if (entries.length === 0) {
    console.log(`ℹ️  ${name}: kosong, tidak ada yang dimigrasi.`);
    return 0;
  }

  const col = db.collection(name);
  // Firestore batch maksimal 500 operasi, kita chunk per 400 buat aman
  const CHUNK_SIZE = 400;
  let migrated = 0;

  for (let i = 0; i < entries.length; i += CHUNK_SIZE) {
    const chunk = entries.slice(i, i + CHUNK_SIZE);
    const batch = db.batch();
    chunk.forEach(([key, value]) => {
      batch.set(col.doc(key), value);
    });
    await batch.commit();
    migrated += chunk.length;
    console.log(`   ...${migrated}/${entries.length} dokumen ${name} ter-migrasi`);
  }

  console.log(`✅ ${name}: ${migrated} dokumen berhasil dimigrasi ke Firestore`);
  return migrated;
}

async function migrateConfig(configObj) {
  if (!configObj) return;
  await db.collection('config').doc('app').set(configObj, { merge: true });
  console.log('✅ config: 1 dokumen (config/app) berhasil dimigrasi ke Firestore');
}

async function main() {
  console.log('🚀 Mulai migrasi data JSON lokal -> Firestore...\n');

  const users    = readJsonSafe(USERS_FILE);
  const deposits = readJsonSafe(DEPOSITS_FILE);
  const orders   = readJsonSafe(ORDERS_FILE);
  const config   = readJsonSafe(CONFIG_FILE);

  await migrateCollection('users', users);
  await migrateCollection('deposits', deposits);
  await migrateCollection('orders', orders);
  await migrateConfig(config);

  console.log('\n🎉 Migrasi selesai! Cek Firebase Console buat verifikasi datanya.');
  console.log('   Setelah yakin datanya lengkap & benar, file data/*.json lama bisa di-backup lalu dihapus.');
  process.exit(0);
}

main().catch((err) => {
  console.error('\n❌ Migrasi gagal:', err);
  process.exit(1);
});
