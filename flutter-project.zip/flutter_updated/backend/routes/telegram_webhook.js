const express = require('express');
const router  = express.Router();
const bcrypt  = require('bcryptjs');
const {
  readConfig, writeConfig,
  readUsers, writeUsers,
  readDeposits, writeDeposits,
  readWithdrawals, writeWithdrawals,
  findUserKeyByUsername,
  getPasswordReset, updatePasswordReset,
} = require('../config/db');
const { sendMessage, answerCallback, editMessage, tgRequest } = require('../config/telegram');

const ADMIN_ID = process.env.TELEGRAM_ADMIN_ID || '';

function isAdmin(id) { return String(id) === String(ADMIN_ID); }
function fmtDate(iso) {
  return iso ? new Date(iso).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }) : '-';
}

// ─── POST /api/telegram/webhook ──────────────────────────────────────────────
router.post('/webhook', async (req, res) => {
  res.sendStatus(200);
  const body = req.body;

  // ── Callback Query ──────────────────────────────────────────────────────────
  if (body.callback_query) {
    const cb     = body.callback_query;
    const chatId = cb.message.chat.id;
    const msgId  = cb.message.message_id;
    const data   = cb.data || '';

    if (!isAdmin(cb.from.id)) {
      await answerCallback(cb.id, '⛔ Bukan admin!');
      return;
    }

    // ── Toggle maintenance ──────────────────────────────────────────────────
    if (data === 'toggle_maintenance') {
      const cfg = await readConfig();
      cfg.maintenance = !cfg.maintenance;
      await writeConfig(cfg);
      await answerCallback(cb.id, cfg.maintenance ? '🔧 Maintenance ON' : '✅ Maintenance OFF');
      await editMessage(chatId, msgId,
        `🔧 *Maintenance Mode*: ${cfg.maintenance ? 'AKTIF 🔴' : 'NONAKTIF 🟢'}\nPesan: _${cfg.maintenance_msg}_`,
        [[{ text: cfg.maintenance ? '✅ Matikan' : '🔧 Aktifkan', callback_data: 'toggle_maintenance' }]]
      );
      return;
    }

    // ── APPROVE reset password ─────────────────────────────────────────────
    if (data.startsWith('reset_approve_')) {
      const token   = data.replace('reset_approve_', '');
      const pending = await getPasswordReset(token);

      if (!pending) {
        await answerCallback(cb.id, '❌ Request tidak ditemukan / sudah kedaluwarsa');
        return;
      }
      if (pending.status !== 'pending') {
        await answerCallback(cb.id, '⚠️ Sudah diproses sebelumnya');
        return;
      }

      // Update password di database
      try {
        const users = await readUsers();
        const key   = findUserKeyByUsername(users, pending.username);
        if (key) {
          const hashed = await bcrypt.hash(pending.newPassword, 10);
          users[key].password            = hashed;
          users[key].temp_reset_password = pending.newPassword; // untuk verifikasi di reset-password endpoint
          users[key].last_seen           = new Date().toISOString();
          await writeUsers(users);
        }
        await updatePasswordReset(token, { status: 'approved' });
        await answerCallback(cb.id, '✅ Password berhasil direset!');
        await editMessage(chatId, msgId,
          `✅ *APPROVED — Reset Password*\n\n` +
          `👤 Username: \`${pending.username}\`\n` +
          `📧 Email: \`${pending.email}\`\n` +
          `🔐 Password baru: \`${pending.newPassword}\`\n\n` +
          `_User sudah bisa login dengan password baru dan set ulang._`
        );
      } catch (err) {
        console.error('[RESET APPROVE ERROR]', err);
        await answerCallback(cb.id, '❌ Gagal update password di DB');
      }
      return;
    }

    // ── CANCEL reset password ──────────────────────────────────────────────
    if (data.startsWith('reset_cancel_')) {
      const token   = data.replace('reset_cancel_', '');
      const pending = await getPasswordReset(token);

      if (!pending) {
        await answerCallback(cb.id, '❌ Request tidak ditemukan');
        return;
      }
      await updatePasswordReset(token, { status: 'cancelled' });
      await answerCallback(cb.id, '❌ Reset password ditolak');
      await editMessage(chatId, msgId,
        `❌ *CANCELLED — Reset Password*\n\n` +
        `👤 Username: \`${pending.username}\`\n` +
        `📧 Email: \`${pending.email}\`\n\n` +
        `_Request ditolak. User akan diberitahu._`
      );
      return;
    }

    // ── KONFIRMASI deposit (manual transfer) ─────────────────────────────────
    if (data.startsWith('confirm_dep:')) {
      const invoiceId = data.replace('confirm_dep:', '');
      const deposits  = await readDeposits();
      const dep = deposits[invoiceId];

      if (!dep) {
        await answerCallback(cb.id, '❌ Deposit tidak ditemukan');
        return;
      }
      if (dep.status !== 'pending') {
        await answerCallback(cb.id, '⚠️ Sudah diproses sebelumnya');
        return;
      }

      const users = await readUsers();
      const user  = users[dep.user_id];
      if (user) {
        user.saldo = (user.saldo || 0) + dep.amount;
        user.last_activity = new Date().toISOString();
        users[dep.user_id] = user;
        await writeUsers(users);
      }

      dep.status     = 'confirmed';
      dep.updated_at = new Date().toISOString();
      deposits[invoiceId] = dep;
      await writeDeposits(deposits);

      const fmtRp = (n) => `Rp${Number(n).toLocaleString('id-ID')}`;
      await answerCallback(cb.id, '✅ Deposit dikonfirmasi!');
      await editMessage(chatId, msgId,
        `✅ *CONFIRMED — Deposit*\n\n` +
        `👤 User: \`${dep.user_id}\`\n` +
        `🧾 Invoice: \`${invoiceId}\`\n` +
        `💵 Nominal: *${fmtRp(dep.amount)}*\n\n` +
        `_Saldo sudah masuk ke akun user._`
      );
      return;
    }

    // ── TOLAK deposit ─────────────────────────────────────────────────────────
    if (data.startsWith('cancel_dep:')) {
      const invoiceId = data.replace('cancel_dep:', '');
      const deposits  = await readDeposits();
      const dep = deposits[invoiceId];

      if (!dep) {
        await answerCallback(cb.id, '❌ Deposit tidak ditemukan');
        return;
      }
      if (dep.status !== 'pending') {
        await answerCallback(cb.id, '⚠️ Sudah diproses sebelumnya');
        return;
      }

      dep.status     = 'rejected';
      dep.updated_at = new Date().toISOString();
      deposits[invoiceId] = dep;
      await writeDeposits(deposits);

      await answerCallback(cb.id, '❌ Deposit ditolak');
      await editMessage(chatId, msgId,
        `❌ *REJECTED — Deposit*\n\n` +
        `👤 User: \`${dep.user_id}\`\n` +
        `🧾 Invoice: \`${invoiceId}\`\n\n` +
        `_Bukti transfer tidak valid / tidak ditemukan. Saldo TIDAK ditambahkan._`
      );
      return;
    }

    // ── KONFIRMASI withdraw (admin sudah transfer manual) ────────────────────
    if (data.startsWith('confirm_wd:')) {
      const trxId = data.replace('confirm_wd:', '');
      const withdrawals = await readWithdrawals();
      const trx = withdrawals[trxId];

      if (!trx) {
        await answerCallback(cb.id, '❌ Transaksi tidak ditemukan');
        return;
      }
      if (trx.status !== 'pending') {
        await answerCallback(cb.id, '⚠️ Sudah diproses sebelumnya');
        return;
      }

      // Potong saldo user saat admin konfirmasi (bukan saat submit)
      const users = await readUsers();
      const user  = users[trx.user_id];
      let saldoSisa = 0;
      if (user) {
        const saldoSebelum = user.saldo || 0;
        user.saldo = Math.max(0, saldoSebelum - trx.total_potong);
        user.last_activity = new Date().toISOString();
        users[trx.user_id] = user;
        await writeUsers(users);
        saldoSisa = user.saldo;
        trx.saldo_sebelum = saldoSebelum;
        trx.saldo_sesudah = saldoSisa;
      }

      trx.status     = 'completed';
      trx.updated_at = new Date().toISOString();
      withdrawals[trxId] = trx;
      await writeWithdrawals(withdrawals);

      const fmtRp = (n) => `Rp${Number(n).toLocaleString('id-ID')}`;
      await answerCallback(cb.id, '✅ Withdraw selesai! Saldo dipotong.');
      await editMessage(chatId, msgId,
        `✅ *COMPLETED — Withdraw*\n\n` +
        `👤 User: \`${trx.username || trx.user_id}\`\n` +
        `🧾 Trx: \`${trxId}\`\n` +
        `📱 ${trx.ewallet.toUpperCase()}: \`${trx.nomor}\`\n` +
        `👛 Nama Akun: \`${trx.nama_akun || '-'}\`\n` +
        `💵 Nominal: *${fmtRp(trx.nominal)}*\n` +
        `💳 Fee: ${fmtRp(trx.admin_fee)}\n` +
        `📉 Total dipotong: *${fmtRp(trx.total_potong)}*\n` +
        `💰 Sisa saldo user: *${fmtRp(saldoSisa)}*\n\n` +
        `_Withdraw selesai diproses._`
      );
      return;
    }

    // ── TOLAK withdraw (saldo TIDAK dipotong karena belum dipotong saat submit) ──
    if (data.startsWith('cancel_wd:')) {
      const trxId = data.replace('cancel_wd:', '');
      const withdrawals = await readWithdrawals();
      const trx = withdrawals[trxId];

      if (!trx) {
        await answerCallback(cb.id, '❌ Transaksi tidak ditemukan');
        return;
      }
      if (trx.status !== 'pending') {
        await answerCallback(cb.id, '⚠️ Sudah diproses sebelumnya');
        return;
      }

      // Saldo TIDAK pernah dipotong (dipotong baru saat confirm), jadi tidak perlu refund
      trx.status     = 'rejected';
      trx.updated_at = new Date().toISOString();
      withdrawals[trxId] = trx;
      await writeWithdrawals(withdrawals);

      const fmtRp = (n) => `Rp${Number(n).toLocaleString('id-ID')}`;
      await answerCallback(cb.id, '❌ Withdraw ditolak');
      await editMessage(chatId, msgId,
        `❌ *REJECTED — Withdraw*\n\n` +
        `👤 User: \`${trx.username || trx.user_id}\`\n` +
        `🧾 Trx: \`${trxId}\`\n` +
        `💵 Nominal: *${fmtRp(trx.nominal)}*\n\n` +
        `_Withdraw ditolak. Saldo user tidak berubah (belum dipotong)._`
      );
      return;
    }

    await answerCallback(cb.id, '');
    return;
  }

  // ── Text Commands ───────────────────────────────────────────────────────────
  if (body.message) {
    const msg    = body.message;
    const chatId = msg.chat.id;
    const text   = (msg.text || '').trim();
    const fromId = msg.from?.id;

    if (!isAdmin(fromId)) return;

    // /start atau /menu
    if (text === '/start' || text === '/menu') {
      await sendMessage(chatId,
        `🤖 *MIWACHAN BOT — MENU ADMIN*\n\n` +
        `🌐 *Domain*\n• /domain\n• /setdomain [URL]\n\n` +
        `📊 *Markup Withdraw*\n• /markup\n• /setmarkup flat [nominal]\n• /setmarkup percent [%]\n• /setmarkup off\n\n` +
        `💰 *Harga Gojo Crasher*\n• /gojoprice — lihat harga\n• /setgojo [hari] [harga]\n  _Contoh: /setgojo 1 1000_\n• /resetgojo — reset ke default\n\n` +
        `📡 *Harga Panel*\n• /panelprice — lihat harga\n• /setpanel [gb] [harga] [note]\n  _Contoh: /setpanel 5gb 7000 "Panel Cepat"_\n• /resetpanel — reset ke default\n\n` +
        `💳 *Nominal Withdraw*\n• /withdrawlist\n• /setwithdraw [list nominal dipisah koma]\n  _Contoh: /setwithdraw 10000,20000,50000,100000_\n\n` +
        `🔧 *Maintenance*\n• /maintenance\n• /maintenance on/off\n• /maintenance msg [pesan]\n\n` +
        `👥 *Pengguna*\n• /users\n• /stats`
      );
      return;
    }

    // /domain
    if (text === '/domain') {
      const cfg = await readConfig();
      await sendMessage(chatId,
        `🌐 *Domain Server*\n\nURL aktif: \`${cfg.domain || process.env.SERVER_URL || '(belum diset)'}\`\n\nGanti: /setdomain https://domain-baru.com`
      );
      return;
    }

    // /setdomain
    if (text.startsWith('/setdomain ')) {
      const newDomain = text.replace('/setdomain ', '').trim().replace(/\/$/, '');
      if (!newDomain.startsWith('http')) {
        await sendMessage(chatId, '❌ Format: /setdomain https://domain-kamu.com');
        return;
      }
      const cfg    = await readConfig();
      const oldUrl = cfg.domain || '';
      cfg.domain   = newDomain;
      await writeConfig(cfg);
      const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
      let webhookResult = '(tidak diupdate)';
      if (BOT_TOKEN) {
        const wh = await tgRequest('setWebhook', { url: `${newDomain}/api/telegram/webhook` });
        webhookResult = wh.ok ? '✅ Webhook diperbarui' : `⚠️ ${wh.description}`;
      }
      await sendMessage(chatId,
        `✅ *Domain diperbarui!*\n\nLama: \`${oldUrl || '-'}\`\nBaru: \`${newDomain}\`\n\nTelegram Webhook: ${webhookResult}`
      );
      return;
    }

    // /markup
    if (text === '/markup') {
      const cfg   = await readConfig();
      const isOff = !cfg.markup || cfg.markup === 0;
      await sendMessage(chatId,
        `📊 *Markup Withdraw Saat Ini*\n\nType: ${cfg.markup_type || 'flat'}\nNilai: ${isOff ? 'OFF (0)' : cfg.markup_type === 'percent' ? cfg.markup + '%' : 'Rp' + cfg.markup}\n\n_Gunakan /setmarkup untuk ubah_`
      );
      return;
    }

    // /setmarkup
    if (text.startsWith('/setmarkup')) {
      const parts = text.split(' ');
      const type  = parts[1];
      const val   = parts[2];
      if (type === 'off') {
        const cfg = await readConfig(); cfg.markup = 0; cfg.markup_type = 'flat';
        await writeConfig(cfg);
        await sendMessage(chatId, '✅ Markup withdraw dimatikan (0).');
        return;
      }
      if ((type === 'flat' || type === 'percent') && val && !isNaN(val)) {
        const cfg = await readConfig(); cfg.markup = Number(val); cfg.markup_type = type;
        await writeConfig(cfg);
        await sendMessage(chatId, `✅ Markup diset:\nType: *${type}*\nNilai: *${type === 'percent' ? val + '%' : 'Rp' + val}*`);
        return;
      }
      await sendMessage(chatId, `❌ Format:\n• /setmarkup flat 500\n• /setmarkup percent 10\n• /setmarkup off`);
      return;
    }

    // /withdrawlist — lihat daftar nominal
    if (text === '/withdrawlist') {
      const cfg  = await readConfig();
      const list = cfg.withdraw_nominals || [10000, 20000, 30000, 50000, 75000, 100000, 150000, 200000];
      await sendMessage(chatId,
        `💳 *Daftar Nominal Withdraw*\n\n${list.map((n, i) => `${i + 1}. Rp${n.toLocaleString('id-ID')}`).join('\n')}\n\n` +
        `Ubah: /setwithdraw 10000,20000,50000,100000`
      );
      return;
    }

    // /setwithdraw
    if (text.startsWith('/setwithdraw ')) {
      const raw = text.replace('/setwithdraw ', '').trim();
      const list = raw.split(',').map((s) => parseInt(s.trim())).filter((n) => !isNaN(n) && n > 0);
      if (list.length < 2) {
        await sendMessage(chatId, '❌ Minimal 2 nominal. Contoh: /setwithdraw 10000,20000,50000');
        return;
      }
      const cfg = await readConfig();
      cfg.withdraw_nominals = list;
      await writeConfig(cfg);
      await sendMessage(chatId,
        `✅ *Nominal Withdraw Diperbarui!*\n\n${list.map((n) => `• Rp${n.toLocaleString('id-ID')}`).join('\n')}`
      );
      return;
    }

    // /gojoprice — lihat harga gojo
    if (text === '/gojoprice') {
      const cfg    = await readConfig();
      const prices = cfg.gojo_prices || [
        { label: '1 Hari', harga: 1000 }, { label: '2 Hari', harga: 2000 },
        { label: '3 Hari', harga: 3000 }, { label: '5 Hari', harga: 5000 },
      ];
      let txt = `🎮 *Harga Gojo Crasher*\n\n`;
      prices.forEach((p) => { txt += `• ${p.label}: Rp${p.harga.toLocaleString('id-ID')}\n`; });
      txt += `\nUbah: /setgojo [hari] [harga]\nContoh: /setgojo 1 1500`;
      await sendMessage(chatId, txt);
      return;
    }

    // /setgojo [hari] [harga]
    if (text.startsWith('/setgojo ')) {
      const parts = text.split(' ');
      const hari  = parseInt(parts[1]);
      const harga = parseInt(parts[2]);
      if (isNaN(hari) || isNaN(harga) || hari < 1 || harga < 0) {
        await sendMessage(chatId, '❌ Format: /setgojo [hari] [harga]\nContoh: /setgojo 1 1500');
        return;
      }
      const cfg    = await readConfig();
      const prices = cfg.gojo_prices || [];
      const idx    = prices.findIndex((p) => p.label === `${hari} Hari`);
      if (idx >= 0) {
        prices[idx].harga = harga;
      } else {
        prices.push({ label: `${hari} Hari`, harga, jam: hari * 24 });
        prices.sort((a, b) => a.jam - b.jam);
      }
      cfg.gojo_prices = prices;
      await writeConfig(cfg);
      await sendMessage(chatId, `✅ Harga Gojo Crasher *${hari} Hari* diset ke *Rp${harga.toLocaleString('id-ID')}*`);
      return;
    }

    // /resetgojo
    if (text === '/resetgojo') {
      const cfg = await readConfig();
      cfg.gojo_prices = null; // akan pakai default di fr3.js
      await writeConfig(cfg);
      await sendMessage(chatId, '✅ Harga Gojo Crasher direset ke default.');
      return;
    }

    // /panelprice — lihat harga panel
    if (text === '/panelprice') {
      const cfg    = await readConfig();
      const prices = cfg.panel_prices || [
        { label: '5 GB', harga: 7000, note: 'Panel Cepat' },
        { label: '10 GB', harga: 12000, note: 'Panel Cepat' },
        { label: 'Unlimited', harga: 19000, note: 'Panel Cepat' },
      ];
      let txt = `📡 *Harga Panel*\n\n`;
      prices.forEach((p) => { txt += `• ${p.label}: Rp${p.harga.toLocaleString('id-ID')} — ${p.note || ''}\n`; });
      txt += `\nUbah: /setpanel [label] [harga] [note]\nContoh: /setpanel 5gb 7000 Panel\\ Cepat`;
      await sendMessage(chatId, txt);
      return;
    }

    // /setpanel [label] [harga] [note]
    if (text.startsWith('/setpanel ')) {
      const parts  = text.split(' ');
      const label  = parts[1]; // e.g. 5gb / 10gb / unli
      const harga  = parseInt(parts[2]);
      const note   = parts.slice(3).join(' ') || 'Panel Cepat';
      if (!label || isNaN(harga)) {
        await sendMessage(chatId, '❌ Format: /setpanel [5gb/10gb/unli] [harga] [keterangan]');
        return;
      }
      const labelMap = { '5gb': '5 GB', '10gb': '10 GB', 'unli': 'Unlimited', 'unlimited': 'Unlimited' };
      const cleanLabel = labelMap[label.toLowerCase()] || label.toUpperCase();
      const cfg    = await readConfig();
      const prices = cfg.panel_prices || [];
      const idx    = prices.findIndex((p) => p.label.toLowerCase() === cleanLabel.toLowerCase());
      if (idx >= 0) {
        prices[idx].harga = harga;
        prices[idx].note  = note;
      } else {
        prices.push({ label: cleanLabel, harga, note });
      }
      cfg.panel_prices = prices;
      await writeConfig(cfg);
      await sendMessage(chatId, `✅ Harga Panel *${cleanLabel}* diset ke *Rp${harga.toLocaleString('id-ID')}* — ${note}`);
      return;
    }

    // /resetpanel
    if (text === '/resetpanel') {
      const cfg = await readConfig();
      cfg.panel_prices = null;
      await writeConfig(cfg);
      await sendMessage(chatId, '✅ Harga Panel direset ke default.');
      return;
    }

    // /maintenance
    if (text === '/maintenance') {
      const cfg = await readConfig();
      await sendMessage(chatId,
        `🔧 *Maintenance Mode*\n\nStatus: ${cfg.maintenance ? '🔴 AKTIF' : '🟢 NONAKTIF'}\nPesan: _${cfg.maintenance_msg}_\n\n• /maintenance on\n• /maintenance off\n• /maintenance msg [pesan]`,
        [[{ text: cfg.maintenance ? '✅ Matikan' : '🔧 Aktifkan', callback_data: 'toggle_maintenance' }]]
      );
      return;
    }
    if (text === '/maintenance on') {
      const cfg = await readConfig(); cfg.maintenance = true; await writeConfig(cfg);
      await sendMessage(chatId, `🔧 Maintenance *AKTIF*.\nPesan user: _${cfg.maintenance_msg}_`);
      return;
    }
    if (text === '/maintenance off') {
      const cfg = await readConfig(); cfg.maintenance = false; await writeConfig(cfg);
      await sendMessage(chatId, '✅ Maintenance *NONAKTIF*. App normal kembali.');
      return;
    }
    if (text.startsWith('/maintenance msg ')) {
      const newMsg = text.replace('/maintenance msg ', '').trim();
      if (!newMsg) { await sendMessage(chatId, '❌ Pesan tidak boleh kosong!'); return; }
      const cfg = await readConfig(); cfg.maintenance_msg = newMsg; await writeConfig(cfg);
      await sendMessage(chatId, `✅ Pesan maintenance:\n_${newMsg}_`);
      return;
    }

    // /users
    if (text === '/users') {
      const users = await readUsers();
      const list  = Object.values(users).sort((a, b) =>
        new Date(b.last_seen || b.created_at) - new Date(a.last_seen || a.created_at)
      );
      if (list.length === 0) { await sendMessage(chatId, '📭 Belum ada pengguna terdaftar.'); return; }
      let txt = `👥 *PENGGUNA TERDAFTAR (${list.length})*\n\n`;
      list.slice(0, 15).forEach(u => {
        txt += `👤 \`${(u.username || u.userId || '?').slice(0, 20)}\`\n`;
        txt += `  📅 Daftar: ${fmtDate(u.created_at)}\n`;
        txt += `  🕐 Terakhir: ${fmtDate(u.last_seen)}\n\n`;
      });
      if (list.length > 15) txt += `_...dan ${list.length - 15} lainnya_`;
      await sendMessage(chatId, txt);
      return;
    }

    // /stats
    if (text === '/stats') {
      const users = await readUsers();
      await sendMessage(chatId,
        `📈 *Statistik MiwaChan*\n\n👥 Total pengguna: *${Object.keys(users).length}*\n\n💳 Topup & transaksi diproses via *FR3 NEWERA*`
      );
      return;
    }
  }
});

// GET /api/telegram/set-webhook
router.get('/set-webhook', async (req, res) => {
  const BOT_TOKEN  = process.env.TELEGRAM_BOT_TOKEN;
  const cfg        = await readConfig();
  const SERVER_URL = cfg.domain || process.env.SERVER_URL;
  if (!BOT_TOKEN || !SERVER_URL)
    return res.json({ success: false, message: 'TELEGRAM_BOT_TOKEN dan SERVER_URL wajib diset' });
  const result = await tgRequest('setWebhook', { url: `${SERVER_URL}/api/telegram/webhook` });
  res.json(result);
});

module.exports = router;
