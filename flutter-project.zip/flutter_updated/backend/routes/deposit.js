const express = require('express');
const router  = express.Router();
const multer  = require('multer');
const path    = require('path');
const fs      = require('fs');
const { authMiddleware } = require('../middleware/auth');
const { readDeposits, writeDeposits, readConfig, readUsers, writeUsers } = require('../config/db');
const { sendTelegramNotif } = require('../config/telegram');

const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, UPLOAD_DIR),
  filename: (_, file, cb) => {
    const ext = path.extname(file.originalname) || '.jpg';
    cb(null, `DEP-${Date.now()}${ext}`);
  },
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 } });

router.use(authMiddleware);

// ─── GET /api/deposit/qris-info ──────────────────────────────────────────────
// QRIS pakai gambar statis dari assets Flutter (assets/qris/qris_static.png) — bukan API.
router.get('/qris-info', async (req, res) => {
  res.json({
    success: true,
    data: {
      merchant_name: process.env.MERCHANT_NAME || 'MIWACHAN GROSIR',
      // qris_source: 'assets' - Flutter pakai gambar QRIS statis dari assets, bukan generate API
    },
  });
});

// ─── POST /api/deposit/submit ────────────────────────────────────────────────
// User transfer manual ke QRIS statis lalu upload bukti. Saldo masuk setelah admin konfirmasi.
router.post('/submit', upload.single('bukti'), async (req, res) => {
  const { amount } = req.body;
  const userId = req.user.userId;

  if (!amount || isNaN(amount) || Number(amount) < 500) {
    return res.status(400).json({ success: false, message: 'Amount minimal Rp500' });
  }
  if (!req.file) {
    return res.status(400).json({ success: false, message: 'Upload bukti transfer dulu!' });
  }

  const nominal    = Number(amount);
  const invoiceId  = `DEP-${Date.now()}`;
  const buktiUrl   = `/uploads/${req.file.filename}`;
  const buktiPath  = req.file.path;
  const cfg        = await readConfig();
  const serverUrl  = cfg.domain || process.env.SERVER_URL || '';

  const deposits = await readDeposits();
  deposits[invoiceId] = {
    invoice_id: invoiceId,
    user_id: userId,
    amount: nominal,
    bukti_path: buktiPath,
    bukti_url: buktiUrl,
    status: 'pending',
    created_at: new Date().toISOString(),
  };
  await writeDeposits(deposits);

  // Update user stats
  const users = await readUsers();
  if (users[userId]) {
    users[userId].total_deposits = (users[userId].total_deposits || 0) + 1;
    users[userId].last_activity  = new Date().toISOString();
    await writeUsers(users);
  }

  const fmtRp = (n) => `Rp${Number(n).toLocaleString('id-ID')}`;
  const msg =
    `💰 *DEPOSIT BARU MASUK*\n\n` +
    `👤 User: \`${userId}\`\n` +
    `🧾 Invoice: \`${invoiceId}\`\n` +
    `💵 Nominal: *${fmtRp(nominal)}*\n` +
    `🕐 Waktu: ${new Date().toLocaleString('id-ID')}\n\n` +
    `Bukti: [Lihat foto](${serverUrl}${buktiUrl})`;

  const buttons = [[
    { text: '✅ Konfirmasi', callback_data: `confirm_dep:${invoiceId}` },
    { text: '❌ Tolak',      callback_data: `cancel_dep:${invoiceId}` },
  ]];

  await sendTelegramNotif(msg, buttons, buktiPath).catch(console.error);

  res.json({
    success: true,
    message: 'Bukti terkirim! Tunggu konfirmasi admin ya 🙏',
    data: { invoice_id: invoiceId, status: 'pending' },
  });
});

// ─── GET /api/deposit/status ─────────────────────────────────────────────────
router.get('/status', async (req, res) => {
  const { invoice_id } = req.query;
  if (!invoice_id) return res.status(400).json({ success: false, message: 'invoice_id wajib' });
  const deposits = await readDeposits();
  const dep = deposits[invoice_id];
  if (!dep) return res.status(404).json({ success: false, message: 'Deposit tidak ditemukan' });
  res.json({ success: true, data: dep });
});

// ─── GET /api/deposit/history ────────────────────────────────────────────────
router.get('/history', async (req, res) => {
  const userId   = req.user.userId;
  const deposits = await readDeposits();
  const myDeps   = Object.values(deposits)
    .filter(d => d.user_id === userId)
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
    .slice(0, 20);
  res.json({ success: true, data: myDeps });
});

// ─── POST /api/deposit/cancel ────────────────────────────────────────────────
router.post('/cancel', async (req, res) => {
  const { invoice_id } = req.body;
  if (!invoice_id) return res.status(400).json({ success: false, message: 'invoice_id wajib' });
  const deposits = await readDeposits();
  if (!deposits[invoice_id]) return res.status(404).json({ success: false, message: 'Deposit tidak ditemukan' });
  if (deposits[invoice_id].status !== 'pending') {
    return res.status(400).json({ success: false, message: 'Deposit sudah diproses, tidak bisa cancel' });
  }
  deposits[invoice_id].status     = 'cancelled';
  deposits[invoice_id].updated_at = new Date().toISOString();
  await writeDeposits(deposits);
  res.json({ success: true, message: 'Deposit dibatalkan' });
});

module.exports = router;
