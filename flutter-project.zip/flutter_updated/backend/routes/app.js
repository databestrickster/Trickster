// Route publik - cek status app (maintenance, versi, dll)
const express = require('express');
const router = express.Router();
const { readConfig } = require('../config/db');

router.get('/status', async (req, res) => {
  const cfg = await readConfig();
  res.json({
    success: true,
    maintenance: cfg.maintenance || false,
    maintenance_msg: cfg.maintenance_msg || '',
    version: process.env.APP_VERSION || '1.0.0',
  });
});

module.exports = router;
