require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const path = require('path');

const authRoutes      = require('./routes/auth');
const servicesRoutes  = require('./routes/services');
const ordersRoutes    = require('./routes/orders');
const depositRoutes   = require('./routes/deposit');
const fr3Routes       = require('./routes/fr3');
const transactionsRoutes = require('./routes/transactions');
const telegramRoutes  = require('./routes/telegram_webhook');
const appRoutes       = require('./routes/app');

const { maintenanceMiddleware } = require('./middleware/maintenance');

const app = express();
const PORT = process.env.PORT || 3000;

// ── Middleware ──────────────────────────────────────────────────────────────
app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(cors({ origin: '*', methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'], allowedHeaders: ['Content-Type', 'Authorization'] }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan('dev'));

// Static uploads
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Rate limiter
const limiter = rateLimit({
  windowMs: Number(process.env.RATE_LIMIT_WINDOW_MS) || 60_000,
  max: Number(process.env.RATE_LIMIT_MAX) || 60,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Terlalu banyak request. Tunggu bentar ya!' },
});
app.use(limiter);

// ── Routes publik (sebelum maintenance check) ────────────────────────────────
app.get('/', (req, res) => res.json({
  success: true, app: 'OTP MiwaChan Backend', version: process.env.APP_VERSION || '1.0.0',
  status: 'running', timestamp: new Date().toISOString(),
}));
app.use('/api/app', appRoutes);
app.use('/api/telegram', telegramRoutes); // webhook Telegram juga skip maintenance

// ── Maintenance middleware (block semua route di bawah ini) ──────────────────
app.use(maintenanceMiddleware);

// ── Routes protected ─────────────────────────────────────────────────────────
app.use('/api/auth',     authRoutes);
app.use('/api/services', servicesRoutes);
app.use('/api/orders',   ordersRoutes);
app.use('/api/deposit',  depositRoutes);
app.use('/api/fr3',      fr3Routes);
app.use('/api/transactions', transactionsRoutes);

// 404
app.use((req, res) => res.status(404).json({ success: false, message: `Route ${req.method} ${req.path} tidak ditemukan` }));

// Error handler
app.use((err, req, res, next) => {
  console.error('[ERROR]', err.stack);
  res.status(500).json({ success: false, message: 'Internal server error', error: process.env.NODE_ENV === 'development' ? err.message : undefined });
});

// ── Start ───────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`
╔═══════════════════════════════════════════╗
║      OTP MIWACHAN BACKEND v1.1.0         ║
╠═══════════════════════════════════════════╣
║  Server   : http://localhost:${PORT}          ║
║  Telegram : ${process.env.TELEGRAM_BOT_TOKEN ? 'Connected ✓' : 'NOT SET ✗'}              ║
║  Admin ID : ${process.env.TELEGRAM_ADMIN_ID || 'NOT SET'}              ║
╚═══════════════════════════════════════════╝
  `);
});

module.exports = app;
