const fs = require('fs');
const https = require('https');
const http = require('http');
const path = require('path');

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '';
const ADMIN_CHAT_ID = process.env.TELEGRAM_ADMIN_ID || '';

function tgRequest(method, body) {
  return new Promise((resolve, reject) => {
    if (!BOT_TOKEN) return resolve({ ok: false, description: 'No bot token' });
    const data = JSON.stringify(body);
    const options = {
      hostname: 'api.telegram.org',
      path: `/bot${BOT_TOKEN}/${method}`,
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) },
    };
    const req = https.request(options, (res) => {
      let raw = '';
      res.on('data', (c) => raw += c);
      res.on('end', () => resolve(JSON.parse(raw)));
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

// Kirim foto + caption + inline buttons
async function sendTelegramNotif(caption, buttons = [], imagePath = null) {
  if (!BOT_TOKEN || !ADMIN_CHAT_ID) {
    console.warn('[Telegram] Token/ChatID belum diset');
    return;
  }

  const replyMarkup = buttons.length
    ? { inline_keyboard: buttons }
    : undefined;

  if (imagePath && fs.existsSync(imagePath)) {
    // sendPhoto via multipart
    const boundary = '----FormBoundary' + Math.random().toString(16).slice(2);
    const fileBuffer = fs.readFileSync(imagePath);
    const ext = path.extname(imagePath).replace('.', '') || 'jpg';
    const mime = ext === 'png' ? 'image/png' : 'image/jpeg';

    let body = Buffer.from('');
    const append = (str) => { body = Buffer.concat([body, Buffer.from(str)]); };
    const appendBuf = (buf) => { body = Buffer.concat([body, buf]); };

    append(`--${boundary}\r\nContent-Disposition: form-data; name="chat_id"\r\n\r\n${ADMIN_CHAT_ID}\r\n`);
    append(`--${boundary}\r\nContent-Disposition: form-data; name="caption"\r\n\r\n${caption}\r\n`);
    append(`--${boundary}\r\nContent-Disposition: form-data; name="parse_mode"\r\n\r\nMarkdown\r\n`);
    if (replyMarkup) {
      append(`--${boundary}\r\nContent-Disposition: form-data; name="reply_markup"\r\n\r\n${JSON.stringify(replyMarkup)}\r\n`);
    }
    append(`--${boundary}\r\nContent-Disposition: form-data; name="photo"; filename="${path.basename(imagePath)}"\r\nContent-Type: ${mime}\r\n\r\n`);
    appendBuf(fileBuffer);
    append(`\r\n--${boundary}--\r\n`);

    return new Promise((resolve, reject) => {
      const options = {
        hostname: 'api.telegram.org',
        path: `/bot${BOT_TOKEN}/sendPhoto`,
        method: 'POST',
        headers: { 'Content-Type': `multipart/form-data; boundary=${boundary}`, 'Content-Length': body.length },
      };
      const req = https.request(options, (res) => {
        let raw = '';
        res.on('data', (c) => raw += c);
        res.on('end', () => resolve(JSON.parse(raw)));
      });
      req.on('error', reject);
      req.write(body);
      req.end();
    });
  } else {
    return tgRequest('sendMessage', {
      chat_id: ADMIN_CHAT_ID,
      text: caption,
      parse_mode: 'Markdown',
      ...(replyMarkup ? { reply_markup: replyMarkup } : {}),
    });
  }
}

async function sendMessage(chatId, text, buttons = []) {
  return tgRequest('sendMessage', {
    chat_id: chatId,
    text,
    parse_mode: 'Markdown',
    ...(buttons.length ? { reply_markup: { inline_keyboard: buttons } } : {}),
  });
}

async function answerCallback(callbackQueryId, text) {
  return tgRequest('answerCallbackQuery', { callback_query_id: callbackQueryId, text });
}

async function editMessage(chatId, messageId, text, buttons = []) {
  return tgRequest('editMessageText', {
    chat_id: chatId,
    message_id: messageId,
    text,
    parse_mode: 'Markdown',
    ...(buttons.length ? { reply_markup: { inline_keyboard: buttons } } : {}),
  });
}

module.exports = { sendTelegramNotif, sendMessage, answerCallback, editMessage, tgRequest };
