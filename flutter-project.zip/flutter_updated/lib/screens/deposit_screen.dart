import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import '../services/fr3_service.dart';
import '../theme/app_theme.dart';

class DepositScreen extends StatefulWidget {
  final String userId;
  const DepositScreen({super.key, required this.userId});

  @override
  State<DepositScreen> createState() => _DepositScreenState();
}

class _DepositScreenState extends State<DepositScreen> {
  final _amountCtrl = TextEditingController();
  bool _loading = false;
  bool _submitted = false;
  String? _invoiceId;
  XFile? _bukti;

  final List<int> _quick = [5000, 10000, 20000, 50000, 100000, 200000];

  @override
  void dispose() {
    _amountCtrl.dispose();
    super.dispose();
  }

  int get _nominal => int.tryParse(_amountCtrl.text.replaceAll('.', '')) ?? 0;

  String _fmt(int n) {
    final s = n.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }

  Future<void> _pickBukti() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 80,
    );
    if (picked != null) setState(() => _bukti = picked);
  }

  Future<void> _pickCamera() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 80,
    );
    if (picked != null) setState(() => _bukti = picked);
  }

  Future<void> _submit() async {
    if (_nominal < 500) {
      _snack('Minimal deposit Rp500', AppTheme.red);
      return;
    }
    if (_bukti == null) {
      _snack('Upload bukti transfer dulu!', AppTheme.red);
      return;
    }
    setState(() => _loading = true);

    final res = await Fr3Service.submitDeposit(
      amount: _nominal,
      buktiPath: _bukti!.path,
    );
    setState(() => _loading = false);

    if (res['success'] == true) {
      setState(() {
        _submitted = true;
        _invoiceId = res['data']?['invoice_id'] ?? '';
      });
    } else {
      _snack(res['message'] ?? 'Gagal kirim deposit', AppTheme.red);
    }
  }

  void _reset() {
    setState(() {
      _submitted = false;
      _invoiceId = null;
      _bukti = null;
      _amountCtrl.clear();
    });
  }

  void _snack(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: color),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        title: const Text('DEPOSIT SALDO'),
        backgroundColor: AppTheme.bg,
        actions: _submitted
            ? [
                IconButton(
                  onPressed: _reset,
                  icon: const Icon(Icons.refresh_rounded, color: AppTheme.textSecondary),
                )
              ]
            : null,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: _submitted ? _buildSuccess() : _buildForm(),
      ),
    );
  }

  // ── FORM ──────────────────────────────────────────────────────────────────

  Widget _buildForm() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

      // Banner info
      Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [
            AppTheme.accent.withValues(alpha: 0.12),
            AppTheme.cyan.withValues(alpha: 0.06),
          ]),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppTheme.accent.withValues(alpha: 0.25)),
        ),
        child: Column(children: [
          Text('DEPOSIT VIA QRIS MIWACHAN',
              style: AppTheme.eyebrow(color: AppTheme.accentLight)),
          const SizedBox(height: 4),
          Text('Scan QRIS di bawah → transfer → upload bukti',
              style: AppTheme.body(size: 12, color: AppTheme.textSecondary),
              textAlign: TextAlign.center),
        ]),
      ),

      const SizedBox(height: 20),

      // QRIS statis - improved design
      Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFE53935).withValues(alpha: 0.18),
              blurRadius: 24,
              spreadRadius: 2,
              offset: const Offset(0, 6),
            ),
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.12),
              blurRadius: 12,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(children: [
          // Header merah ala QRIS
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
            decoration: const BoxDecoration(
              color: Color(0xFFE53935),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('SCAN QRIS INI',
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.w800,
                        letterSpacing: 1.5, fontSize: 12)),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: const Text('QRIS',
                      style: TextStyle(
                          color: Color(0xFFE53935), fontWeight: FontWeight.w900,
                          fontSize: 11, letterSpacing: 1)),
                ),
              ],
            ),
          ),
          // QR Image
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 20, 24, 12),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFE53935).withValues(alpha: 0.3), width: 2),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.06),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.asset(
                  'assets/qris/qris_static.png',
                  width: double.infinity,
                  fit: BoxFit.fitWidth,
                  errorBuilder: (_, __, ___) => Container(
                    height: 260,
                    color: Colors.grey[100],
                    child: const Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.qr_code_2_rounded, size: 100, color: Colors.black38),
                        SizedBox(height: 8),
                        Text('qris_static.png\ndi assets/qris/',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.black38, fontSize: 11)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
          // Footer info
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Column(children: [
              const Text('MIWACHAN GROSIR',
                  style: TextStyle(
                      color: Colors.black87, fontWeight: FontWeight.w800,
                      fontSize: 16, letterSpacing: 0.5)),
              const SizedBox(height: 4),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Text('DANA · GoPay · OVO · ShopeePay · m-Banking',
                    style: TextStyle(color: Colors.black54, fontSize: 10, fontWeight: FontWeight.w500),
                    textAlign: TextAlign.center),
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(width: 8, height: 8,
                      decoration: const BoxDecoration(color: Colors.green, shape: BoxShape.circle)),
                  const SizedBox(width: 5),
                  const Text('Satu QRIS untuk semua pembayaran',
                      style: TextStyle(color: Colors.black45, fontSize: 10)),
                ],
              ),
            ]),
          ),
        ]),
      ),

      const SizedBox(height: 20),

      // Nominal
      Text('NOMINAL DEPOSIT', style: AppTheme.eyebrow()),
      const SizedBox(height: 10),
      Container(
        decoration: BoxDecoration(
          color: AppTheme.card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppTheme.border),
        ),
        child: Row(children: [
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Text('Rp',
                style: TextStyle(
                    color: AppTheme.accentLight,
                    fontWeight: FontWeight.bold,
                    fontSize: 18)),
          ),
          Expanded(
            child: TextField(
              controller: _amountCtrl,
              keyboardType: TextInputType.number,
              style: const TextStyle(
                  color: AppTheme.textPrimary,
                  fontSize: 22,
                  fontWeight: FontWeight.bold),
              decoration: const InputDecoration(
                hintText: '0',
                hintStyle: TextStyle(color: AppTheme.textSecondary),
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(vertical: 16),
              ),
              onChanged: (_) => setState(() {}),
            ),
          ),
        ]),
      ),

      const SizedBox(height: 10),
      Wrap(
        spacing: 8, runSpacing: 8,
        children: _quick.map((a) => GestureDetector(
          onTap: () => setState(() => _amountCtrl.text = a.toString()),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: AppTheme.card,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                  color: _nominal == a ? AppTheme.accentLight : AppTheme.border),
            ),
            child: Text('Rp${_fmt(a)}',
                style: TextStyle(
                    color: _nominal == a
                        ? AppTheme.accentLight
                        : AppTheme.textSecondary,
                    fontSize: 12)),
          ),
        )).toList(),
      ),

      // Info pajak
      if (_nominal >= 500) ...[
        const SizedBox(height: 12),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: AppTheme.yellow.withValues(alpha: 0.07),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppTheme.yellow.withValues(alpha: 0.3)),
          ),
          child: Column(children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('Nominal transfer', style: AppTheme.body(size: 12, color: AppTheme.textSecondary)),
              Text('Rp${_fmt(_nominal)}', style: AppTheme.body(size: 12, color: AppTheme.textPrimary)),
            ]),
            const SizedBox(height: 4),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('Pajak', style: AppTheme.body(size: 12, color: AppTheme.textSecondary)),
              Text('- Rp100', style: AppTheme.body(size: 12, color: AppTheme.yellow)),
            ]),
            const Divider(color: AppTheme.border, height: 12),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('Saldo masuk', style: AppTheme.body(size: 12, weight: FontWeight.bold, color: AppTheme.green)),
              Text('Rp${_fmt(_nominal - 100)}', style: AppTheme.body(size: 13, weight: FontWeight.bold, color: AppTheme.green)),
            ]),
          ]),
        ),
      ],

      const SizedBox(height: 24),

      // Upload bukti
      Text('BUKTI TRANSFER', style: AppTheme.eyebrow()),
      const SizedBox(height: 10),

      GestureDetector(
        onTap: _showPickerDialog,
        child: Container(
          width: double.infinity,
          height: _bukti != null ? null : 120,
          decoration: BoxDecoration(
            color: AppTheme.card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
                color: _bukti != null
                    ? AppTheme.green.withValues(alpha: 0.5)
                    : AppTheme.border,
                width: _bukti != null ? 1.5 : 1),
          ),
          child: _bukti != null
              ? ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: Stack(
                    children: [
                      Image.file(
                        File(_bukti!.path),
                        width: double.infinity,
                        fit: BoxFit.cover,
                      ),
                      Positioned(
                        top: 8, right: 8,
                        child: GestureDetector(
                          onTap: _showPickerDialog,
                          child: Container(
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: AppTheme.bg.withValues(alpha: 0.8),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Row(mainAxisSize: MainAxisSize.min, children: [
                              Icon(Icons.edit_rounded, color: AppTheme.accentLight, size: 14),
                              SizedBox(width: 4),
                              Text('Ganti', style: TextStyle(color: AppTheme.accentLight, fontSize: 11)),
                            ]),
                          ),
                        ),
                      ),
                    ],
                  ),
                )
              : const Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.cloud_upload_outlined, color: AppTheme.textSecondary, size: 36),
                    SizedBox(height: 8),
                    Text('Tap untuk upload bukti transfer',
                        style: TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
                    SizedBox(height: 2),
                    Text('JPG / PNG · Maks 5MB',
                        style: TextStyle(color: AppTheme.textMuted, fontSize: 11)),
                  ],
                ),
        ),
      ),

      const SizedBox(height: 24),

      // Tombol submit
      SizedBox(
        width: double.infinity,
        height: 52,
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: (_nominal >= 500 && _bukti != null)
                  ? [AppTheme.accent, AppTheme.cyan]
                  : [AppTheme.border, AppTheme.border],
            ),
            borderRadius: BorderRadius.circular(14),
            boxShadow: (_nominal >= 500 && _bukti != null)
                ? [
                    BoxShadow(
                      color: AppTheme.accent.withValues(alpha: 0.4),
                      blurRadius: 20,
                      offset: const Offset(0, 6),
                    )
                  ]
                : [],
          ),
          child: TextButton(
            onPressed: _loading
                ? null
                : (_nominal >= 500 && _bukti != null ? _submit : null),
            child: _loading
                ? const SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: Colors.white))
                : const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(Icons.send_rounded, color: Colors.white, size: 18),
                    SizedBox(width: 8),
                    Text('KIRIM BUKTI DEPOSIT',
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 2,
                            fontSize: 14)),
                  ]),
          ),
        ),
      ),

      const SizedBox(height: 16),
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppTheme.card,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppTheme.border),
        ),
        child: const Row(children: [
          Icon(Icons.info_outline_rounded, color: AppTheme.cyan, size: 16),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              'Saldo akan masuk setelah admin konfirmasi bukti transfer kamu. Proses biasanya 1-5 menit.',
              style: TextStyle(
                  color: AppTheme.textSecondary, fontSize: 11, height: 1.5),
            ),
          ),
        ]),
      ),
    ]);
  }

  void _showPickerDialog() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 40, height: 4,
            decoration: BoxDecoration(
              color: AppTheme.border,
              borderRadius: BorderRadius.circular(2)),
          ),
          const SizedBox(height: 16),
          ListTile(
            leading: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppTheme.accent.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.photo_library_rounded, color: AppTheme.accentLight)),
            title: const Text('Pilih dari Galeri',
                style: TextStyle(color: AppTheme.textPrimary)),
            subtitle: const Text('Pilih foto bukti dari galeri HP',
                style: TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
            onTap: () { Navigator.pop(context); _pickBukti(); },
          ),
          ListTile(
            leading: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppTheme.cyan.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.camera_alt_rounded, color: AppTheme.cyan)),
            title: const Text('Ambil Foto',
                style: TextStyle(color: AppTheme.textPrimary)),
            subtitle: const Text('Foto langsung bukti transfer',
                style: TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
            onTap: () { Navigator.pop(context); _pickCamera(); },
          ),
        ]),
      ),
    );
  }

  // ── SUCCESS ────────────────────────────────────────────────────────────────

  Widget _buildSuccess() {
    return Column(children: [
      const SizedBox(height: 32),
      Container(
        width: double.infinity,
        padding: const EdgeInsets.all(28),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [
            AppTheme.green.withValues(alpha: 0.12),
            AppTheme.accent.withValues(alpha: 0.06),
          ]),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppTheme.green.withValues(alpha: 0.3)),
        ),
        child: Column(children: [
          const Icon(Icons.check_circle_rounded, color: AppTheme.green, size: 72),
          const SizedBox(height: 16),
          Text('BUKTI TERKIRIM!', style: AppTheme.display(size: 20, weight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text(
            'Bukti depositmu sudah diterima admin.\nSaldo akan masuk setelah dikonfirmasi.',
            style: AppTheme.body(size: 13, color: AppTheme.textSecondary),
            textAlign: TextAlign.center,
          ),
        ]),
      ),

      if (_invoiceId != null && _invoiceId!.isNotEmpty) ...[
        const SizedBox(height: 16),
        GestureDetector(
          onTap: () {
            Clipboard.setData(ClipboardData(text: _invoiceId!));
            _snack('Invoice ID disalin!', AppTheme.accent);
          },
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppTheme.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.border),
            ),
            child: Row(children: [
              const Icon(Icons.receipt_long_rounded, color: AppTheme.accentLight, size: 16),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Invoice ID', style: AppTheme.eyebrow()),
                  const SizedBox(height: 2),
                  Text(_invoiceId!,
                      style: AppTheme.mono(size: 12, color: AppTheme.textPrimary)),
                ]),
              ),
              const Icon(Icons.copy_rounded, color: AppTheme.textSecondary, size: 14),
            ]),
          ),
        ),
      ],

      const SizedBox(height: 24),
      SizedBox(
        width: double.infinity,
        height: 50,
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [AppTheme.accent, AppTheme.cyan]),
            borderRadius: BorderRadius.circular(14),
          ),
          child: TextButton(
            onPressed: _reset,
            child: const Text('DEPOSIT LAGI',
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2)),
          ),
        ),
      ),
    ]);
  }
}
