import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/user_prefs.dart';
import '../theme/app_theme.dart';
import 'login_screen.dart';

class ProfileScreen extends StatelessWidget {
  final String userId;
  const ProfileScreen({super.key, required this.userId});

  // ── GANTI NOMOR DI SINI ──────────────────────────────────────────────────
  static const String _waNumber  = '6283175593052';
  static const String _tgCs      = 'https://t.me/Miwachan76';
  static const String _tgOrder   = 'https://t.me/Miwachan76';

  void _snack(BuildContext ctx, String msg) =>
    ScaffoldMessenger.of(ctx).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: AppTheme.accent));

  void _copy(BuildContext ctx, String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    _snack(ctx, '$label disalin!');
  }

  void _logout(BuildContext ctx) async {
    await UserPrefs.clear();
    if (!ctx.mounted) return;
    Navigator.pushAndRemoveUntil(ctx,
        MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

            // ── Header ─────────────────────────────────────────────────
            Row(children: [
              // Logo Miwa Pay
              Container(
                width: 42, height: 42,
                decoration: BoxDecoration(
                  shape: BoxShape.circle, gradient: AppTheme.cursedGradient,
                  boxShadow: [BoxShadow(color: AppTheme.accent.withValues(alpha: 0.35), blurRadius: 12)],
                ),
                child: ClipOval(
                  child: Image.asset(
                    'assets/icons/icon_512.png',
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) =>
                        const Icon(Icons.person_rounded, color: Colors.white, size: 22),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('PROFIL', style: AppTheme.display(size: 15, weight: FontWeight.w700, letterSpacing: 1)),
                Text('Miwa Pay • Miwa Pay', style: AppTheme.body(size: 11, color: AppTheme.textMuted)),
              ]),
              const Spacer(),
              IconButton(
                onPressed: () => _logout(context),
                icon: const Icon(Icons.logout_rounded, color: AppTheme.textSecondary),
              ),
            ]),

            const SizedBox(height: 20),

            // ── Kartu Akun User ─────────────────────────────────────────
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [
                  AppTheme.accent.withValues(alpha: 0.2), AppTheme.cyan.withValues(alpha: 0.08),
                ]),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppTheme.accent.withValues(alpha: 0.3)),
                boxShadow: [BoxShadow(
                  color: AppTheme.accent.withValues(alpha: 0.12), blurRadius: 24, offset: const Offset(0, 6))],
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  // Avatar akun sendiri — pakai icon app
                  CircleAvatar(
                    radius: 28,
                    backgroundColor: AppTheme.accent.withValues(alpha: 0.2),
                    child: ClipOval(
                      child: Image.asset(
                        'assets/icons/icon_512.png',
                        width: 56, height: 56, fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => const Icon(
                            Icons.person_rounded, color: AppTheme.accentLight, size: 30),
                      ),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Pengguna Miwa Pay',
                        style: AppTheme.body(size: 14, weight: FontWeight.bold)),
                    const SizedBox(height: 2),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: AppTheme.green.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: AppTheme.green.withValues(alpha: 0.4)),
                      ),
                      child: Text('AKTIF', style: TextStyle(
                          color: AppTheme.green, fontSize: 10, fontWeight: FontWeight.bold)),
                    ),
                  ])),
                ]),
                const SizedBox(height: 16),
                const Divider(color: AppTheme.border, height: 1),
                const SizedBox(height: 14),
                Text('USER ID', style: AppTheme.eyebrow()),
                const SizedBox(height: 6),
                GestureDetector(
                  onTap: () => _copy(context, userId, 'User ID'),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: AppTheme.bg.withValues(alpha: 0.5),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: AppTheme.border),
                    ),
                    child: Row(children: [
                      Expanded(child: Text(userId,
                          style: AppTheme.mono(size: 12), overflow: TextOverflow.ellipsis)),
                      const SizedBox(width: 8),
                      const Icon(Icons.copy_rounded, color: AppTheme.textSecondary, size: 16),
                    ]),
                  ),
                ),
              ]),
            ),

            const SizedBox(height: 24),

            // ── Tombol CS ───────────────────────────────────────────────
            Text('HUBUNGI CS', style: AppTheme.eyebrow()),
            const SizedBox(height: 12),

            // WA dengan logo asli
            _CsButton(
              logoPath: 'assets/icons/wa_logo.png',
              fallbackIcon: Icons.chat_rounded,
              color: const Color(0xFF25D366),
              title: 'WhatsApp CS',
              subtitle: _waNumber,
              onTap: () => _copy(context, _waNumber, 'Nomor WA'),
              badge: 'ONLINE',
            ),
            const SizedBox(height: 10),

            // Telegram CS dengan logo asli
            _CsButton(
              logoPath: 'assets/icons/tele_logo.png',
              fallbackIcon: Icons.send_rounded,
              color: const Color(0xFF2AABEE),
              title: 'Telegram CS',
              subtitle: _tgCs,
              onTap: () => _copy(context, _tgCs, 'Link Telegram'),
              badge: 'SUPPORT',
            ),
            const SizedBox(height: 10),

            // Telegram Order dengan logo asli
            _CsButton(
              logoPath: 'assets/icons/tele_logo.png',
              fallbackIcon: Icons.shopping_cart_rounded,
              color: AppTheme.accentLight,
              title: 'Order via Telegram',
              subtitle: _tgOrder,
              onTap: () => _copy(context, _tgOrder, 'Link Order'),
              badge: 'ORDER',
            ),

            const SizedBox(height: 24),

            // ── Info App ─────────────────────────────────────────────────
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppTheme.card,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppTheme.border),
              ),
              child: Column(children: [
                _infoRow(Icons.apps_rounded, 'Aplikasi', 'Miwa Pay v1.0'),
                const Divider(color: AppTheme.border, height: 20),
                _infoRow(Icons.verified_rounded, 'Provider', 'Miwa Pay'),
                const Divider(color: AppTheme.border, height: 20),
                _infoRow(Icons.security_rounded, 'Status', '100% Aman & Terpercaya'),
              ]),
            ),

            const SizedBox(height: 24),

            // ── Logout ───────────────────────────────────────────────────
            SizedBox(
              width: double.infinity, height: 48,
              child: OutlinedButton.icon(
                onPressed: () => _logout(context),
                icon: const Icon(Icons.logout_rounded, size: 18),
                label: const Text('KELUAR'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppTheme.red,
                  side: const BorderSide(color: AppTheme.red),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ),
            const SizedBox(height: 20),
          ]),
        ),
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) => Row(children: [
    Icon(icon, color: AppTheme.accentLight, size: 16),
    const SizedBox(width: 10),
    Text(label, style: AppTheme.body(size: 12, color: AppTheme.textSecondary)),
    const Spacer(),
    Text(value, style: AppTheme.body(size: 12, weight: FontWeight.w600)),
  ]);
}

// ── CS Button Widget (dengan logo gambar asli) ───────────────────────────────
class _CsButton extends StatelessWidget {
  final String logoPath;
  final IconData fallbackIcon;
  final Color color;
  final String title, subtitle, badge;
  final VoidCallback onTap;
  const _CsButton({required this.logoPath, required this.fallbackIcon,
      required this.color, required this.title,
      required this.subtitle, required this.badge, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Row(children: [
        Container(
          width: 44, height: 44,
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.15),
            borderRadius: BorderRadius.circular(12),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.asset(
              logoPath,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Icon(fallbackIcon, color: color, size: 22),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Text(title, style: AppTheme.body(size: 13, weight: FontWeight.bold)),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(5),
                border: Border.all(color: color.withValues(alpha: 0.4)),
              ),
              child: Text(badge, style: TextStyle(color: color, fontSize: 9, fontWeight: FontWeight.bold)),
            ),
          ]),
          const SizedBox(height: 2),
          Text(subtitle, style: AppTheme.body(size: 11, color: AppTheme.textSecondary),
              overflow: TextOverflow.ellipsis),
        ])),
        const Icon(Icons.copy_rounded, color: AppTheme.textSecondary, size: 16),
      ]),
    ),
  );
}
