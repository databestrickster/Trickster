
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:just_audio/just_audio.dart';

// ══════════════════════════════════════════════
// MODEL
// ══════════════════════════════════════════════
class KisahNabi {
  final String nama;
  final String kisah;
  final String thnLahir;
  final String usia;
  final String? audio;

  KisahNabi({
    required this.nama,
    required this.kisah,
    required this.thnLahir,
    required this.usia,
    this.audio,
  });

  factory KisahNabi.fromJson(Map<String, dynamic> json) {
    return KisahNabi(
      nama: json['name'] ?? json['nama'] ?? json['nabi'] ?? json['judul'] ?? 'Nabi',
      kisah: json['description'] ?? json['kisah'] ?? json['cerita'] ?? json['story'] ?? json['teks'] ?? '',
      thnLahir: json['thn_kelahiran']?.toString() ?? '',
      usia: json['usia']?.toString() ?? '',
      audio: json['audio'] ?? json['url_audio'] ?? json['mp3'] ?? json['voice'],
    );
  }
}

// ══════════════════════════════════════════════
// PAGE
// ══════════════════════════════════════════════
class KisahNabiPage extends StatefulWidget {
  const KisahNabiPage({super.key});

  @override
  State<KisahNabiPage> createState() => _KisahNabiPageState();
}

class _KisahNabiPageState extends State<KisahNabiPage>
    with TickerProviderStateMixin {
  final TextEditingController _searchCtrl = TextEditingController();

  List<KisahNabi> _allData = [];
  List<KisahNabi> _filtered = [];
  bool _loading = false;
  String? _errorMsg;
  KisahNabi? _selected;

  // Audio
  final AudioPlayer _player = AudioPlayer();
  bool _playing = false;
  bool _audioLoading = false;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;

  // Anim
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;

  // Colors
  static const Color _bg      = Color(0xFF0A0A0F);
  static const Color _surface = Color(0xFF12121A);
  static const Color _card    = Color(0xFF1A1A28);
  static const Color _gold    = Color(0xFFD4A853);
  static const Color _goldDim = Color(0xFF8A6830);
  static const Color _green   = Color(0xFF2ECC71);
  static const Color _text    = Colors.white;

  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    _fadeCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 400),
    );
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);

    _player.positionStream.listen((pos) {
      if (mounted) setState(() => _position = pos);
    });
    _player.durationStream.listen((dur) {
      if (mounted) setState(() => _duration = dur ?? Duration.zero);
    });
    _player.playerStateStream.listen((state) {
      if (mounted) {
        setState(() => _playing = state.playing);
        if (state.processingState == ProcessingState.completed) {
          setState(() { _playing = false; _position = Duration.zero; });
        }
      }
    });

    _fetchData();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    _player.dispose();
    _pulseCtrl.dispose();
    _fadeCtrl.dispose();
    super.dispose();
  }

  // ── Fetch ──
  Future<void> _fetchData() async {
    setState(() { _loading = true; _errorMsg = null; });
    try {
      final dio = Dio(BaseOptions(
        connectTimeout: const Duration(seconds: 30),
        receiveTimeout: const Duration(seconds: 30),
        followRedirects: true,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 12; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
          'Accept': 'application/json, text/plain, */*',
          'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
          'Referer': 'https://api.botcahx.eu.org/',
        },
      ));

      final res = await dio.get(
        'https://api.botcahx.eu.org/api/islamic/kisahnabi2',
        queryParameters: {'apikey': 'Miwa'},
      );

      debugPrint('>>> KisahNabi status: \${res.statusCode}');

      final json = res.data;

      if (json is Map && json['status'] == false) {
        setState(() => _errorMsg = json['message'] ?? 'API menolak permintaan');
        return;
      }

      final List<KisahNabi> list = [];

      dynamic raw;
      if (json is Map) {
        raw = json['result'] ?? json['data'] ?? json['kisah'] ??
              json['nabi'] ?? json['list'];
      }
      raw ??= json;

      if (raw is List) {
        for (final item in raw) {
          if (item is Map<String, dynamic>) {
            list.add(KisahNabi.fromJson(item));
          }
        }
      } else if (raw is Map<String, dynamic>) {
        list.add(KisahNabi.fromJson(raw));
      }

      if (list.isNotEmpty) {
        setState(() { _allData = list; _filtered = list; });
      } else {
        setState(() => _errorMsg = 'Tidak ada data dari API');
      }
    } on DioException catch (e) {
      debugPrint('>>> DioError: \${e.response?.statusCode} - \${e.message}');
      setState(() => _errorMsg = 'API error: \${e.response?.statusCode ?? e.message}');
    } catch (e) {
      debugPrint('>>> ERROR: $e');
      setState(() => _errorMsg = 'Gagal memuat: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _onSearch(String q) {
    final query = q.toLowerCase();
    setState(() {
      _filtered = _allData.where((k) =>
        k.nama.toLowerCase().contains(query) ||
        k.kisah.toLowerCase().contains(query)
      ).toList();
    });
  }

  Future<void> _select(KisahNabi item) async {
    await _player.stop();
    setState(() {
      _selected = item;
      _playing = false;
      _position = Duration.zero;
      _duration = Duration.zero;
      _audioLoading = false;
    });
    _fadeCtrl.forward(from: 0);
  }

  Future<void> _togglePlay() async {
    if (_selected == null) return;

    if (_playing) {
      await _player.pause();
      return;
    }

    if (_selected!.audio == null || _selected!.audio!.isEmpty) {
      _snack('Tidak ada audio untuk kisah ini', err: true);
      return;
    }

    try {
      setState(() => _audioLoading = true);
      await _player.setUrl(_selected!.audio!);
      await _player.play();
    } catch (e) {
      _snack('Gagal memuat audio: $e', err: true);
    } finally {
      if (mounted) setState(() => _audioLoading = false);
    }
  }

  void _seekTo(double val) {
    final ms = (val * _duration.inMilliseconds).toInt();
    _player.seek(Duration(milliseconds: ms));
  }

  void _snack(String msg, {bool err = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: err ? Colors.red.shade700 : _green,
      behavior: SnackBarBehavior.floating,
    ));
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  // ══════════════════════════════════════════════
  // BUILD
  // ══════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: _appBar(),
      body: _selected != null ? _detailView() : _listView(),
    );
  }

  AppBar _appBar() => AppBar(
    backgroundColor: _bg,
    leading: _selected != null
        ? IconButton(
            icon: const Icon(Icons.arrow_back_ios_rounded, color: _gold),
            onPressed: () async {
              await _player.stop();
              setState(() => _selected = null);
            },
          )
        : null,
    title: Row(children: [
      if (_selected == null) ...[
        AnimatedBuilder(
          animation: _pulseAnim,
          builder: (_, __) => Opacity(
            opacity: _pulseAnim.value,
            child: Container(
              width: 8, height: 8,
              decoration: const BoxDecoration(color: _gold, shape: BoxShape.circle),
            ),
          ),
        ),
        const SizedBox(width: 10),
      ],
      Expanded(
        child: Text(
          _selected != null ? _selected!.nama : 'Kisah Para Nabi',
          style: TextStyle(
            color: _gold,
            fontWeight: FontWeight.bold,
            fontSize: _selected != null ? 16 : 18,
            letterSpacing: 0.5,
          ),
          overflow: TextOverflow.ellipsis,
        ),
      ),
    ]),
    centerTitle: false,
    bottom: PreferredSize(
      preferredSize: const Size.fromHeight(1),
      child: Container(height: 1, color: _goldDim.withOpacity(0.3)),
    ),
    actions: [
      if (_selected == null)
        IconButton(
          icon: const Icon(Icons.refresh_rounded, color: _gold),
          onPressed: _fetchData,
        ),
    ],
  );

  // ── LIST VIEW ──
  Widget _listView() {
    return Column(children: [
      _searchBar(),
      if (_errorMsg != null) _errorBanner(),
      if (_loading)
        const Expanded(child: Center(
          child: CircularProgressIndicator(color: _gold, strokeWidth: 2),
        ))
      else if (_filtered.isEmpty)
        _emptyState()
      else
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
            itemCount: _filtered.length,
            itemBuilder: (_, i) => _listCard(i, _filtered[i]),
          ),
        ),
    ]);
  }

  Widget _searchBar() => Padding(
    padding: const EdgeInsets.all(16),
    child: Container(
      decoration: BoxDecoration(
        color: _surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _goldDim.withOpacity(0.4)),
      ),
      child: TextField(
        controller: _searchCtrl,
        style: const TextStyle(color: _text, fontSize: 14),
        onChanged: _onSearch,
        decoration: InputDecoration(
          hintText: 'Cari nama nabi...',
          hintStyle: TextStyle(color: _text.withOpacity(0.3), fontSize: 13),
          prefixIcon: const Icon(Icons.search_rounded, color: _gold, size: 20),
          suffixIcon: _searchCtrl.text.isNotEmpty
              ? IconButton(
                  icon: Icon(Icons.clear_rounded, color: _text.withOpacity(0.4), size: 18),
                  onPressed: () {
                    _searchCtrl.clear();
                    _onSearch('');
                  },
                )
              : null,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        ),
      ),
    ),
  );

  Widget _listCard(int i, KisahNabi item) {
    final hasAudio = item.audio != null && item.audio!.isNotEmpty;
    return GestureDetector(
      onTap: () => _select(item),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _goldDim.withOpacity(0.25)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 8, offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Row(children: [
          Container(
            width: 44, height: 44,
            decoration: BoxDecoration(
              color: _goldDim.withOpacity(0.15),
              shape: BoxShape.circle,
              border: Border.all(color: _goldDim.withOpacity(0.4)),
            ),
            child: Center(
              child: Text('${i + 1}',
                style: const TextStyle(
                  color: _gold, fontWeight: FontWeight.bold, fontSize: 14)),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(item.nama,
                style: const TextStyle(
                  color: _gold, fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(height: 3),
              // Tahun lahir & usia
              if (item.thnLahir.isNotEmpty || item.usia.isNotEmpty)
                Row(children: [
                  if (item.thnLahir.isNotEmpty) ...[
                    Icon(Icons.calendar_today_rounded,
                      color: _goldDim, size: 10),
                    const SizedBox(width: 3),
                    Text(item.thnLahir,
                      style: TextStyle(color: _goldDim, fontSize: 10)),
                    const SizedBox(width: 8),
                  ],
                  if (item.usia.isNotEmpty) ...[
                    Icon(Icons.access_time_rounded,
                      color: _goldDim, size: 10),
                    const SizedBox(width: 3),
                    Text('${item.usia} tahun',
                      style: TextStyle(color: _goldDim, fontSize: 10)),
                  ],
                ]),
              const SizedBox(height: 4),
              Text(
                item.kisah.length > 80
                    ? '${item.kisah.substring(0, 80)}...'
                    : item.kisah,
                style: TextStyle(color: _text.withOpacity(0.45), fontSize: 11),
                maxLines: 2, overflow: TextOverflow.ellipsis,
              ),
            ]),
          ),
          const SizedBox(width: 10),
          Column(children: [
            Icon(Icons.menu_book_rounded, color: _gold.withOpacity(0.7), size: 18),
            if (hasAudio) ...[
              const SizedBox(height: 4),
              Icon(Icons.headphones_rounded, color: _green.withOpacity(0.7), size: 16),
            ],
          ]),
        ]),
      ),
    );
  }

  Widget _errorBanner() => Padding(
    padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.red.shade900.withOpacity(0.2),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.redAccent.withOpacity(0.6)),
      ),
      child: Row(children: [
        const Icon(Icons.error_outline, color: Colors.redAccent, size: 18),
        const SizedBox(width: 8),
        Expanded(child: Text(_errorMsg!,
            style: const TextStyle(color: Colors.redAccent, fontSize: 12))),
        IconButton(
          icon: const Icon(Icons.refresh_rounded, color: Colors.redAccent, size: 18),
          onPressed: _fetchData,
          padding: EdgeInsets.zero, constraints: const BoxConstraints(),
        ),
      ]),
    ),
  );

  Widget _emptyState() => Expanded(
    child: Center(
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        AnimatedBuilder(
          animation: _pulseAnim,
          builder: (_, __) => Opacity(
            opacity: 0.3 + _pulseAnim.value * 0.2,
            child: const Icon(Icons.menu_book_rounded, color: _gold, size: 64),
          ),
        ),
        const SizedBox(height: 16),
        Text('Belum ada data',
            style: TextStyle(color: _text.withOpacity(0.4), fontSize: 14)),
        const SizedBox(height: 6),
        Text('Tap refresh untuk memuat ulang',
            style: TextStyle(color: _text.withOpacity(0.25), fontSize: 11)),
      ]),
    ),
  );

  // ── DETAIL VIEW ──
  Widget _detailView() {
    final item = _selected!;
    final hasAudio = item.audio != null && item.audio!.isNotEmpty;
    final progress = _duration.inMilliseconds > 0
        ? _position.inMilliseconds / _duration.inMilliseconds
        : 0.0;

    return FadeTransition(
      opacity: _fadeAnim,
      child: Column(children: [
        if (hasAudio) _audioPlayer(progress),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              // Header
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: _goldDim.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _goldDim.withOpacity(0.3)),
                ),
                child: Column(children: [
                  const Icon(Icons.menu_book_rounded, color: _gold, size: 32),
                  const SizedBox(height: 8),
                  Text('Kisah Nabi ${item.nama}',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: _gold, fontSize: 18,
                      fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                  // Info tahun & usia
                  if (item.thnLahir.isNotEmpty || item.usia.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      if (item.thnLahir.isNotEmpty) ...[
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: _goldDim.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: _goldDim.withOpacity(0.3)),
                          ),
                          child: Row(mainAxisSize: MainAxisSize.min, children: [
                            Icon(Icons.calendar_today_rounded, color: _goldDim, size: 11),
                            const SizedBox(width: 4),
                            Text(item.thnLahir,
                              style: TextStyle(color: _goldDim, fontSize: 11)),
                          ]),
                        ),
                        const SizedBox(width: 8),
                      ],
                      if (item.usia.isNotEmpty)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: _goldDim.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: _goldDim.withOpacity(0.3)),
                          ),
                          child: Row(mainAxisSize: MainAxisSize.min, children: [
                            Icon(Icons.access_time_rounded, color: _goldDim, size: 11),
                            const SizedBox(width: 4),
                            Text('${item.usia} tahun',
                              style: TextStyle(color: _goldDim, fontSize: 11)),
                          ]),
                        ),
                    ]),
                  ],
                ]),
              ),
              const SizedBox(height: 20),

              // Isi Kisah
              Text(item.kisah,
                style: TextStyle(
                  color: _text.withOpacity(0.85),
                  fontSize: 14, height: 1.8,
                  letterSpacing: 0.2,
                )),

              if (!hasAudio) ...[
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.orange.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.orange.withOpacity(0.3)),
                  ),
                  child: Row(children: [
                    const Icon(Icons.info_outline, color: Colors.orange, size: 16),
                    const SizedBox(width: 8),
                    Text('Tidak tersedia audio untuk kisah ini',
                      style: TextStyle(color: Colors.orange.withOpacity(0.8), fontSize: 12)),
                  ]),
                ),
              ],
              const SizedBox(height: 40),
            ]),
          ),
        ),
      ]),
    );
  }

  Widget _audioPlayer(double progress) => Container(
    margin: const EdgeInsets.all(16),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: _card,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: _green.withOpacity(0.3)),
      boxShadow: [
        BoxShadow(color: _green.withOpacity(0.05), blurRadius: 20),
      ],
    ),
    child: Column(children: [
      Row(children: [
        const Icon(Icons.headphones_rounded, color: _green, size: 16),
        const SizedBox(width: 8),
        const Text('Audio Kisah',
          style: TextStyle(color: _green, fontSize: 12, fontWeight: FontWeight.bold)),
        const Spacer(),
        Text(_fmt(_position),
          style: TextStyle(color: _text.withOpacity(0.4), fontSize: 11)),
        Text(' / ', style: TextStyle(color: _text.withOpacity(0.2), fontSize: 11)),
        Text(_fmt(_duration),
          style: TextStyle(color: _text.withOpacity(0.4), fontSize: 11)),
      ]),
      const SizedBox(height: 10),

      SliderTheme(
        data: SliderThemeData(
          trackHeight: 3,
          thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
          overlayShape: const RoundSliderOverlayShape(overlayRadius: 14),
          activeTrackColor: _green,
          inactiveTrackColor: _green.withOpacity(0.15),
          thumbColor: _green,
          overlayColor: _green.withOpacity(0.2),
        ),
        child: Slider(
          value: progress.clamp(0.0, 1.0),
          onChanged: _seekTo,
        ),
      ),

      const SizedBox(height: 8),

      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        IconButton(
          icon: const Icon(Icons.replay_10_rounded, color: Colors.white54, size: 28),
          onPressed: () {
            final newPos = _position - const Duration(seconds: 10);
            _player.seek(newPos < Duration.zero ? Duration.zero : newPos);
          },
        ),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: _togglePlay,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: 56, height: 56,
            decoration: BoxDecoration(
              color: _green,
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: _green.withOpacity(0.4), blurRadius: 16)],
            ),
            child: _audioLoading
                ? const Padding(
                    padding: EdgeInsets.all(14),
                    child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : Icon(
                    _playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                    color: Colors.white, size: 30),
          ),
        ),
        const SizedBox(width: 8),
        IconButton(
          icon: const Icon(Icons.forward_10_rounded, color: Colors.white54, size: 28),
          onPressed: () {
            if (_duration > Duration.zero) {
              final newPos = _position + const Duration(seconds: 10);
              _player.seek(newPos > _duration ? _duration : newPos);
            }
          },
        ),
      ]),
    ]),
  );
}
