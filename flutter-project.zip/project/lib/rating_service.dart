import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'config_service.dart';

class RatingService {
  static const String _productId = 'gojo_crasher_app';
  static const String _prefKeyStars = 'user_rating';
  static const String _prefKeyComment = 'user_rating_comment';

  // Polling stream — update tiap 10 detik (real-time feel tanpa WebSocket)
  static Stream<Map<String, dynamic>> ratingStream() async* {
    while (true) {
      try {
        final data = await fetchRatings();
        yield data;
      } catch (_) {}
      await Future.delayed(const Duration(seconds: 10));
    }
  }

  static Future<Map<String, dynamic>> fetchRatings({String? sessionKey}) async {
    final uri = Uri.parse(
      '${ConfigService.baseUrl}/api/shop/rating'
      '?productId=$_productId'
      '${sessionKey != null ? '&key=$sessionKey' : ''}',
    );
    final res = await http.get(uri).timeout(const Duration(seconds: 8));
    final data = jsonDecode(res.body);
    if (data['success'] == true) {
      return {
        'averageRating': (data['avg'] as num?)?.toDouble() ?? 0.0,
        'totalRatings': data['total'] as int? ?? 0,
        'ratings': data['ratings'] as List? ?? [],
        'myRating': data['myRating'],
      };
    }
    return {'averageRating': 0.0, 'totalRatings': 0, 'ratings': [], 'myRating': null};
  }

  static Future<bool> submitRating({
    required String sessionKey,
    required int stars,
    String comment = '',
  }) async {
    try {
      final res = await http.post(
        Uri.parse('${ConfigService.baseUrl}/api/shop/rating'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': sessionKey,
          'productId': _productId,
          'stars': stars,
          'comment': comment,
        }),
      ).timeout(const Duration(seconds: 8));

      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setInt(_prefKeyStars, stars);
        await prefs.setString(_prefKeyComment, comment);
        return true;
      }
      return false;
    } catch (_) {
      return false;
    }
  }

  static Future<int> getUserRating() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_prefKeyStars) ?? 0;
  }

  static Future<String> getUserComment() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_prefKeyComment) ?? '';
  }
}
