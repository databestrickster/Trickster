import 'dart:math';
import 'package:flutter/material.dart';
import 'ludo_player.dart';

// ─────────────────────────────────────────────────────────────
// 🗺️ MAP MODEL & DATA
// ─────────────────────────────────────────────────────────────
class GameMap {
  final String name;
  final String description;
  final Map<int, int> snakes;
  final Map<int, int> ladders;
  final Color themeColor;
  final String icon;

  const GameMap({
    required this.name,
    required this.description,
    required this.snakes,
    required this.ladders,
    required this.themeColor,
    required this.icon,
  });
}

// Koleksi Map yang bisa dipilih
final List<GameMap> availableMaps = [
  const GameMap(
    name: "CLASSIC NEON",
    description: "Keseimbangan antara ular dan tangga.",
    icon: "🎲",
    themeColor: Color(0xFF00CFFF),
    snakes: {99: 2, 95: 13, 87: 24, 64: 60, 54: 34, 17: 7},
    ladders: {4: 25, 9: 31, 20: 38, 28: 84, 40: 59, 51: 67, 63: 81, 71: 91},
  ),
  const GameMap(
    name: "SNAKE PIT",
    description: "Hati-hati! Banyak ular berbisa di sini.",
    icon: "🐍",
    themeColor: Color(0xFFFF2255),
    snakes: {98: 10, 92: 50, 85: 40, 73: 15, 62: 30, 50: 5, 33: 8, 21: 2},
    ladders: {2: 25, 45: 70, 75: 95},
  ),
  const GameMap(
    name: "LADDER HEAVEN",
    description: "Cepat naik ke puncak dengan bantuan tangga.",
    icon: "🪜",
    themeColor: Color(0xFF00FF88),
    snakes: {99: 80, 40: 20},
    ladders: {3: 30, 8: 45, 15: 55, 22: 70, 35: 85, 50: 92, 60: 98},
  ),
];

enum GamePhase { setup, playing, finished }

// ─────────────────────────────────────────────────────────────
// 🧠 CORE GAME LOGIC
// ─────────────────────────────────────────────────────────────
class SnakeLadderGame extends ChangeNotifier {
  List<SnakeLadderPlayer> players = [];
  int currentPlayerIndex = 0;
  int diceValue = 0;
  bool canRoll = true;
  bool diceRolled = false;
  GamePhase phase = GamePhase.setup;
  List<String> gameLog = [];
  SnakeLadderPlayer? winner;
  
  // Map State (Kunci di sini)
  GameMap selectedMap = availableMaps[0];
  
  final Random _rng = Random();
  bool isMoving = false;
  
  // Tracking untuk animasi UI
  int? lastSnakeHead;
  int? lastLadderBottom;
  int? lastMovedPlayerIndex;

  /// Fungsi Utama untuk memulai game dari Setup
  void setupGame(List<Map<String, dynamic>> configs, GameMap map) {
    selectedMap = map;
    
    players = configs.asMap().entries.map((entry) {
      int idx = entry.key;
      var c = entry.value;
      return SnakeLadderPlayer(
        name: c['name'],
        pawnColor: c['pawnColor'],
        role: c['role'],
        playerIndex: idx, // ID unik untuk skin
        isBot: c['isBot'] ?? false,
      );
    }).toList();

    currentPlayerIndex = 0;
    diceValue = 0;
    canRoll = true;
    diceRolled = false;
    phase = GamePhase.playing;
    gameLog.clear();
    winner = null;
    
    _addLog('🚀 Memasuki: ${selectedMap.name}');
    _addLog('🎲 Game dimulai! ${players.length} pemain siap.');
    
    notifyListeners();

    // Jika pemain pertama adalah bot
    if (players.isNotEmpty && players[0].isBot) {
      Future.delayed(const Duration(milliseconds: 1000), _botTurn);
    }
  }

  SnakeLadderPlayer get currentPlayer => players[currentPlayerIndex];

  Future<void> rollDice() async {
    if (!canRoll || phase != GamePhase.playing || isMoving) return;
    
    diceValue = _rng.nextInt(6) + 1;
    canRoll = false;
    diceRolled = true;
    currentPlayer.totalRolls++;
    
    _addLog('${currentPlayer.name} melempar: $diceValue');
    notifyListeners();
    
    await Future.delayed(const Duration(milliseconds: 800)); // Animasi dadu kocok
    await _movePlayer(diceValue);
  }

  Future<void> _movePlayer(int steps) async {
    isMoving = true;
    final player = currentPlayer;
    lastMovedPlayerIndex = currentPlayerIndex;
    
    int targetPos = player.position + steps;

    if (targetPos > 100) {
      _addLog('⚠️ ${player.name} butuh angka pas untuk finish!');
      _finishMovement();
      return;
    }

    // Gerak satu per satu (Animasi langkah)
    for (int i = 0; i < steps; i++) {
      player.position++;
      notifyListeners();
      await Future.delayed(const Duration(milliseconds: 200));
    }

    // Cek Tangga
    if (selectedMap.ladders.containsKey(player.position)) {
      final top = selectedMap.ladders[player.position]!;
      lastLadderBottom = player.position;
      _addLog('🪜 HORE! ${player.name} naik tangga ke $top');
      player.laddersClimbed++;
      notifyListeners();
      
      await Future.delayed(const Duration(milliseconds: 600));
      player.position = top;
      lastLadderBottom = null;
    } 
    // Cek Ular
    else if (selectedMap.snakes.containsKey(player.position)) {
      final tail = selectedMap.snakes[player.position]!;
      lastSnakeHead = player.position;
      _addLog('🐍 OUCH! ${player.name} dipatuk ular ke $tail');
      player.snakesHit++;
      notifyListeners();
      
      await Future.delayed(const Duration(milliseconds: 600));
      player.position = tail;
      lastSnakeHead = null;
    }

    // Cek Menang
    if (player.position >= 100) {
      player.position = 100;
      winner = player;
      phase = GamePhase.finished;
      _addLog('🏆 WINNER: ${player.name}!');
      isMoving = false;
      notifyListeners();
      return;
    }

    _finishMovement();
  }

  void _finishMovement() async {
    isMoving = false;
    diceRolled = false;
    
    // Rule: Jika dapat 6, main lagi
    if (diceValue == 6 && phase == GamePhase.playing) {
      _addLog('🎰 BONUS! ${currentPlayer.name} dapat 6.');
      canRoll = true;
      notifyListeners();
      if (currentPlayer.isBot) {
        await Future.delayed(const Duration(milliseconds: 1000));
        _botTurn();
      }
    } else {
      _nextTurn();
    }
  }

  void _nextTurn() {
    currentPlayerIndex = (currentPlayerIndex + 1) % players.length;
    canRoll = true;
    _addLog('👉 Giliran ${currentPlayer.name}');
    notifyListeners();
    
    if (currentPlayer.isBot && phase == GamePhase.playing) {
      Future.delayed(const Duration(milliseconds: 1000), _botTurn);
    }
  }

  void _botTurn() => rollDice();

  void _addLog(String msg) {
    gameLog.insert(0, "[${DateTime.now().second}s] $msg");
    if (gameLog.length > 50) gameLog.removeLast();
  }

  void resetToSetup() {
    phase = GamePhase.setup;
    players.clear();
    winner = null;
    notifyListeners();
  }
}