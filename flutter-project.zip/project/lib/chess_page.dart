import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'dart:math';
import 'leaderboard_page.dart';

// ─────────────────────────────────────────────────────────────
// 🎨 PALETTE
// ─────────────────────────────────────────────────────────────
const _kDark       = Color(0xFF0A0A0A);
const _kDarkCard   = Color(0xFF151515);
const _kDarkPanel  = Color(0xFF1A1A1A);
const _kGold       = Color(0xFFFFD700);
const _kGoldDark   = Color(0xFFB8860B);
const _kWhite      = Color(0xFFF0D9B5);
const _kBlack      = Color(0xFFB58863);
const _kHighlight  = Color(0xFF7FC97F);
const _kSelected   = Color(0xFFADD8E6);
const _kCheck      = Color(0xFFFF4444);
const _kLastMove   = Color(0xFFCDD16E);

// ─────────────────────────────────────────────────────────────
// ♟️ PIECE TYPES & COLORS
// ─────────────────────────────────────────────────────────────
enum PieceType { king, queen, rook, bishop, knight, pawn }
enum PieceColor { white, black }

class ChessPiece {
  final PieceType type;
  final PieceColor color;
  bool hasMoved;

  ChessPiece(this.type, this.color, {this.hasMoved = false});

  String get symbol {
    if (color == PieceColor.white) {
      switch (type) {
        case PieceType.king:   return '♔';
        case PieceType.queen:  return '♕';
        case PieceType.rook:   return '♖';
        case PieceType.bishop: return '♗';
        case PieceType.knight: return '♘';
        case PieceType.pawn:   return '♙';
      }
    } else {
      switch (type) {
        case PieceType.king:   return '♚';
        case PieceType.queen:  return '♛';
        case PieceType.rook:   return '♜';
        case PieceType.bishop: return '♝';
        case PieceType.knight: return '♞';
        case PieceType.pawn:   return '♟';
      }
    }
  }

  ChessPiece copy() => ChessPiece(type, color, hasMoved: hasMoved);
}

// ─────────────────────────────────────────────────────────────
// 🎮 CHESS LOGIC
// ─────────────────────────────────────────────────────────────
class ChessGame {
  List<List<ChessPiece?>> board;
  PieceColor currentTurn;
  int? enPassantCol; // column where en passant is possible
  int? enPassantRow;
  bool isCheck = false;
  bool isCheckmate = false;
  bool isStalemate = false;

  ChessGame()
      : board = List.generate(8, (_) => List.filled(8, null)),
        currentTurn = PieceColor.white {
    _setupBoard();
  }

  // Empty board for serialization/deserialization
  ChessGame._empty()
      : board = List.generate(8, (_) => List.filled(8, null)),
        currentTurn = PieceColor.white;

  void _setupBoard() {
    // Black pieces (top)
    board[0][0] = ChessPiece(PieceType.rook,   PieceColor.black);
    board[0][1] = ChessPiece(PieceType.knight, PieceColor.black);
    board[0][2] = ChessPiece(PieceType.bishop, PieceColor.black);
    board[0][3] = ChessPiece(PieceType.queen,  PieceColor.black);
    board[0][4] = ChessPiece(PieceType.king,   PieceColor.black);
    board[0][5] = ChessPiece(PieceType.bishop, PieceColor.black);
    board[0][6] = ChessPiece(PieceType.knight, PieceColor.black);
    board[0][7] = ChessPiece(PieceType.rook,   PieceColor.black);
    for (int c = 0; c < 8; c++) board[1][c] = ChessPiece(PieceType.pawn, PieceColor.black);

    // White pieces (bottom)
    board[7][0] = ChessPiece(PieceType.rook,   PieceColor.white);
    board[7][1] = ChessPiece(PieceType.knight, PieceColor.white);
    board[7][2] = ChessPiece(PieceType.bishop, PieceColor.white);
    board[7][3] = ChessPiece(PieceType.queen,  PieceColor.white);
    board[7][4] = ChessPiece(PieceType.king,   PieceColor.white);
    board[7][5] = ChessPiece(PieceType.bishop, PieceColor.white);
    board[7][6] = ChessPiece(PieceType.knight, PieceColor.white);
    board[7][7] = ChessPiece(PieceType.rook,   PieceColor.white);
    for (int c = 0; c < 8; c++) board[6][c] = ChessPiece(PieceType.pawn, PieceColor.white);
  }

  // Deep copy board
  List<List<ChessPiece?>> _copyBoard(List<List<ChessPiece?>> b) {
    return List.generate(8, (r) => List.generate(8, (c) => b[r][c]?.copy()));
  }

  // Get all valid moves for a piece at (row, col)
  List<List<int>> getValidMoves(int row, int col) {
    final piece = board[row][col];
    if (piece == null) return [];
    final raw = _getRawMoves(board, row, col, piece, enPassantRow, enPassantCol);
    // Filter moves that leave own king in check
    return raw.where((move) {
      final testBoard = _copyBoard(board);
      testBoard[move[0]][move[1]] = testBoard[row][col];
      testBoard[row][col] = null;
      return !_isKingInCheck(testBoard, piece.color);
    }).toList();
  }

  List<List<int>> _getRawMoves(
    List<List<ChessPiece?>> b, int row, int col, ChessPiece piece,
    int? epRow, int? epCol, {bool checkCastling = true}
  ) {
    final moves = <List<int>>[];
    final color = piece.color;
    final enemy = color == PieceColor.white ? PieceColor.black : PieceColor.white;

    bool inBounds(int r, int c) => r >= 0 && r < 8 && c >= 0 && c < 8;
    bool isEmpty(int r, int c) => inBounds(r, c) && b[r][c] == null;
    bool isEnemy(int r, int c) => inBounds(r, c) && b[r][c]?.color == enemy;
    bool canMove(int r, int c) => isEmpty(r, c) || isEnemy(r, c);

    void addSlide(List<int> dir) {
      int r = row + dir[0], c = col + dir[1];
      while (inBounds(r, c)) {
        if (b[r][c] == null) {
          moves.add([r, c]);
        } else {
          if (b[r][c]!.color == enemy) moves.add([r, c]);
          break;
        }
        r += dir[0]; c += dir[1];
      }
    }

    switch (piece.type) {
      case PieceType.pawn:
        final dir = color == PieceColor.white ? -1 : 1;
        final startRow = color == PieceColor.white ? 6 : 1;
        if (isEmpty(row + dir, col)) {
          moves.add([row + dir, col]);
          if (row == startRow && isEmpty(row + 2 * dir, col)) {
            moves.add([row + 2 * dir, col]);
          }
        }
        for (final dc in [-1, 1]) {
          if (isEnemy(row + dir, col + dc)) moves.add([row + dir, col + dc]);
          // En passant
          if (epRow != null && epCol != null &&
              row + dir == epRow && col + dc == epCol) {
            moves.add([epRow, epCol]);
          }
        }
        break;

      case PieceType.knight:
        for (final d in [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]) {
          if (canMove(row + d[0], col + d[1])) moves.add([row + d[0], col + d[1]]);
        }
        break;

      case PieceType.bishop:
        for (final d in [[-1,-1],[-1,1],[1,-1],[1,1]]) addSlide(d);
        break;

      case PieceType.rook:
        for (final d in [[-1,0],[1,0],[0,-1],[0,1]]) addSlide(d);
        break;

      case PieceType.queen:
        for (final d in [[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]]) addSlide(d);
        break;

      case PieceType.king:
        for (final d in [[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]]) {
          if (canMove(row + d[0], col + d[1])) moves.add([row + d[0], col + d[1]]);
        }
        // Castling
        if (checkCastling && !piece.hasMoved && !_isKingInCheck(b, color)) {
          // Kingside
          final rookC = 7;
          final rookPiece = b[row][rookC];
          if (rookPiece?.type == PieceType.rook &&
              rookPiece?.color == color &&
              rookPiece?.hasMoved == false &&
              b[row][5] == null && b[row][6] == null) {
            final t1 = _copyBoard(b); t1[row][5] = t1[row][col]; t1[row][col] = null;
            final t2 = _copyBoard(b); t2[row][6] = t2[row][col]; t2[row][col] = null;
            if (!_isKingInCheck(t1, color) && !_isKingInCheck(t2, color)) {
              moves.add([row, 6]);
            }
          }
          // Queenside
          final rookC2 = 0;
          final rookPiece2 = b[row][rookC2];
          if (rookPiece2?.type == PieceType.rook &&
              rookPiece2?.color == color &&
              rookPiece2?.hasMoved == false &&
              b[row][1] == null && b[row][2] == null && b[row][3] == null) {
            final t1 = _copyBoard(b); t1[row][3] = t1[row][col]; t1[row][col] = null;
            final t2 = _copyBoard(b); t2[row][2] = t2[row][col]; t2[row][col] = null;
            if (!_isKingInCheck(t1, color) && !_isKingInCheck(t2, color)) {
              moves.add([row, 2]);
            }
          }
        }
        break;
    }

    return moves;
  }

  bool _isKingInCheck(List<List<ChessPiece?>> b, PieceColor color) {
    int kr = -1, kc = -1;
    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        if (b[r][c]?.type == PieceType.king && b[r][c]?.color == color) {
          kr = r; kc = c;
        }
      }
    }
    if (kr == -1) return true;
    final enemy = color == PieceColor.white ? PieceColor.black : PieceColor.white;
    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        final p = b[r][c];
        if (p?.color == enemy) {
          final raw = _getRawMoves(b, r, c, p!, null, null, checkCastling: false);
          if (raw.any((m) => m[0] == kr && m[1] == kc)) return true;
        }
      }
    }
    return false;
  }

  // Get king position
  List<int>? _getKingPos(PieceColor color) {
    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        if (board[r][c]?.type == PieceType.king && board[r][c]?.color == color) {
          return [r, c];
        }
      }
    }
    return null;
  }

  bool _hasAnyValidMove(PieceColor color) {
    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        if (board[r][c]?.color == color) {
          if (getValidMoves(r, c).isNotEmpty) return true;
        }
      }
    }
    return false;
  }

  // Returns promotion row if pawn reaches end, else null
  List<int>? movePiece(int fromRow, int fromCol, int toRow, int toCol) {
    final piece = board[fromRow][fromCol]!;
    int? newEpRow, newEpCol;

    // En passant capture
    if (piece.type == PieceType.pawn &&
        toCol != fromCol &&
        board[toRow][toCol] == null) {
      // Capture the pawn
      board[fromRow][toCol] = null;
    }

    // Castling
    if (piece.type == PieceType.king && (toCol - fromCol).abs() == 2) {
      if (toCol == 6) {
        // Kingside
        board[fromRow][5] = board[fromRow][7];
        board[fromRow][5]!.hasMoved = true;
        board[fromRow][7] = null;
      } else if (toCol == 2) {
        // Queenside
        board[fromRow][3] = board[fromRow][0];
        board[fromRow][3]!.hasMoved = true;
        board[fromRow][0] = null;
      }
    }

    // En passant setup
    if (piece.type == PieceType.pawn && (toRow - fromRow).abs() == 2) {
      newEpRow = (fromRow + toRow) ~/ 2;
      newEpCol = fromCol;
    }

    board[toRow][toCol] = piece;
    board[fromRow][fromCol] = null;
    piece.hasMoved = true;
    enPassantRow = newEpRow;
    enPassantCol = newEpCol;

    // Check promotion
    List<int>? promotionPos;
    if (piece.type == PieceType.pawn && (toRow == 0 || toRow == 7)) {
      promotionPos = [toRow, toCol];
    }

    currentTurn = currentTurn == PieceColor.white ? PieceColor.black : PieceColor.white;
    isCheck = _isKingInCheck(board, currentTurn);

    if (!_hasAnyValidMove(currentTurn)) {
      if (isCheck) {
        isCheckmate = true;
      } else {
        isStalemate = true;
      }
    }

    return promotionPos;
  }

  void promote(int row, int col, PieceType type) {
    final color = board[row][col]!.color;
    board[row][col] = ChessPiece(type, color, hasMoved: true);
  }

  List<int>? get kingInCheckPos {
    if (!isCheck) return null;
    return _getKingPos(currentTurn);
  }
}

// ─────────────────────────────────────────────────────────────
// 🔧 COMPUTE HELPERS (top-level for isolate)
// ─────────────────────────────────────────────────────────────

class _GameMoveResult {
  final ChessGame game;
  final List<int>? promotionPos;
  _GameMoveResult(this.game, this.promotionPos);
}

class _GameMoveParams {
  final List<List<List<int?>>> boardData; // [row][col] = [type.index, color.index, hasMoved ? 1 : 0] or null
  final int currentTurnIndex;
  final int? enPassantRow;
  final int? enPassantCol;
  // for getValidMoves
  final int? selectRow;
  final int? selectCol;
  // for movePiece
  final int? fromRow;
  final int? fromCol;
  final int? toRow;
  final int? toCol;

  _GameMoveParams({
    required this.boardData,
    required this.currentTurnIndex,
    this.enPassantRow,
    this.enPassantCol,
    this.selectRow,
    this.selectCol,
    this.fromRow,
    this.fromCol,
    this.toRow,
    this.toCol,
  });

  factory _GameMoveParams.forMoves(ChessGame game, int row, int col) {
    return _GameMoveParams(
      boardData: _encodeBoard(game.board),
      currentTurnIndex: game.currentTurn.index,
      enPassantRow: game.enPassantRow,
      enPassantCol: game.enPassantCol,
      selectRow: row,
      selectCol: col,
    );
  }

  factory _GameMoveParams.forMove(ChessGame game, int fromR, int fromC, int toR, int toC) {
    return _GameMoveParams(
      boardData: _encodeBoard(game.board),
      currentTurnIndex: game.currentTurn.index,
      enPassantRow: game.enPassantRow,
      enPassantCol: game.enPassantCol,
      fromRow: fromR,
      fromCol: fromC,
      toRow: toR,
      toCol: toC,
    );
  }

  factory _GameMoveParams.forAi(ChessGame game) {
    return _GameMoveParams(
      boardData: _encodeBoard(game.board),
      currentTurnIndex: game.currentTurn.index,
      enPassantRow: game.enPassantRow,
      enPassantCol: game.enPassantCol,
    );
  }

  static List<List<List<int?>>> _encodeBoard(List<List<ChessPiece?>> board) {
    return List.generate(8, (r) => List.generate(8, (c) {
      final p = board[r][c];
      if (p == null) return [null, null, null];
      return [p.type.index, p.color.index, p.hasMoved ? 1 : 0];
    }));
  }

  ChessGame toGame() {
    final game = ChessGame._empty();
    game.currentTurn = PieceColor.values[currentTurnIndex];
    game.enPassantRow = enPassantRow;
    game.enPassantCol = enPassantCol;
    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        final d = boardData[r][c];
        if (d[0] != null) {
          game.board[r][c] = ChessPiece(
            PieceType.values[d[0]!],
            PieceColor.values[d[1]!],
            hasMoved: d[2] == 1,
          );
        }
      }
    }
    return game;
  }
}

List<List<int>> _computeValidMoves(_GameMoveParams params) {
  final game = params.toGame();
  return game.getValidMoves(params.selectRow!, params.selectCol!);
}

_GameMoveResult _computeMovePiece(_GameMoveParams params) {
  final game = params.toGame();
  final promPos = game.movePiece(params.fromRow!, params.fromCol!, params.toRow!, params.toCol!);
  return _GameMoveResult(game, promPos);
}

// ─────────────────────────────────────────────────────────────
// 🤖 AI ENGINE (Minimax + Alpha-Beta, depth 3)
// ─────────────────────────────────────────────────────────────

// Piece values
const _pieceValue = {
  PieceType.pawn:   100,
  PieceType.knight: 320,
  PieceType.bishop: 330,
  PieceType.rook:   500,
  PieceType.queen:  900,
  PieceType.king:   20000,
};

// Positional bonuses (from white's perspective, flip for black)
const _pawnTable = [
  [0,  0,  0,  0,  0,  0,  0,  0],
  [50, 50, 50, 50, 50, 50, 50, 50],
  [10, 10, 20, 30, 30, 20, 10, 10],
  [5,  5, 10, 25, 25, 10,  5,  5],
  [0,  0,  0, 20, 20,  0,  0,  0],
  [5, -5,-10,  0,  0,-10, -5,  5],
  [5, 10, 10,-20,-20, 10, 10,  5],
  [0,  0,  0,  0,  0,  0,  0,  0],
];
const _knightTable = [
  [-50,-40,-30,-30,-30,-30,-40,-50],
  [-40,-20,  0,  0,  0,  0,-20,-40],
  [-30,  0, 10, 15, 15, 10,  0,-30],
  [-30,  5, 15, 20, 20, 15,  5,-30],
  [-30,  0, 15, 20, 20, 15,  0,-30],
  [-30,  5, 10, 15, 15, 10,  5,-30],
  [-40,-20,  0,  5,  5,  0,-20,-40],
  [-50,-40,-30,-30,-30,-30,-40,-50],
];
const _bishopTable = [
  [-20,-10,-10,-10,-10,-10,-10,-20],
  [-10,  0,  0,  0,  0,  0,  0,-10],
  [-10,  0,  5, 10, 10,  5,  0,-10],
  [-10,  5,  5, 10, 10,  5,  5,-10],
  [-10,  0, 10, 10, 10, 10,  0,-10],
  [-10, 10, 10, 10, 10, 10, 10,-10],
  [-10,  5,  0,  0,  0,  0,  5,-10],
  [-20,-10,-10,-10,-10,-10,-10,-20],
];
const _rookTable = [
  [0,  0,  0,  0,  0,  0,  0,  0],
  [5, 10, 10, 10, 10, 10, 10,  5],
  [-5,  0,  0,  0,  0,  0,  0, -5],
  [-5,  0,  0,  0,  0,  0,  0, -5],
  [-5,  0,  0,  0,  0,  0,  0, -5],
  [-5,  0,  0,  0,  0,  0,  0, -5],
  [-5,  0,  0,  0,  0,  0,  0, -5],
  [0,  0,  0,  5,  5,  0,  0,  0],
];
const _queenTable = [
  [-20,-10,-10, -5, -5,-10,-10,-20],
  [-10,  0,  0,  0,  0,  0,  0,-10],
  [-10,  0,  5,  5,  5,  5,  0,-10],
  [-5,   0,  5,  5,  5,  5,  0, -5],
  [0,    0,  5,  5,  5,  5,  0, -5],
  [-10,  5,  5,  5,  5,  5,  0,-10],
  [-10,  0,  5,  0,  0,  0,  0,-10],
  [-20,-10,-10, -5, -5,-10,-10,-20],
];
const _kingTable = [
  [-30,-40,-40,-50,-50,-40,-40,-30],
  [-30,-40,-40,-50,-50,-40,-40,-30],
  [-30,-40,-40,-50,-50,-40,-40,-30],
  [-30,-40,-40,-50,-50,-40,-40,-30],
  [-20,-30,-30,-40,-40,-30,-30,-20],
  [-10,-20,-20,-20,-20,-20,-20,-10],
  [20,  20,  0,  0,  0,  0, 20, 20],
  [20,  30, 10,  0,  0, 10, 30, 20],
];

int _posBonus(PieceType type, int row, int col, PieceColor color) {
  final r = color == PieceColor.white ? row : 7 - row;
  switch (type) {
    case PieceType.pawn:   return _pawnTable[r][col];
    case PieceType.knight: return _knightTable[r][col];
    case PieceType.bishop: return _bishopTable[r][col];
    case PieceType.rook:   return _rookTable[r][col];
    case PieceType.queen:  return _queenTable[r][col];
    case PieceType.king:   return _kingTable[r][col];
  }
}

int _evaluate(ChessGame game) {
  int score = 0;
  for (int r = 0; r < 8; r++) {
    for (int c = 0; c < 8; c++) {
      final p = game.board[r][c];
      if (p == null) continue;
      final val = (_pieceValue[p.type] ?? 0) + _posBonus(p.type, r, c, p.color);
      score += p.color == PieceColor.black ? val : -val;
    }
  }
  return score; // positive = good for black (AI)
}

// Returns [fromRow, fromCol, toRow, toCol] of best move
List<int> _aiBestMove(_GameMoveParams params) {
  final game = params.toGame();
  const depth = 3;
  List<int>? best;
  int bestScore = -999999;

  for (int r = 0; r < 8; r++) {
    for (int c = 0; c < 8; c++) {
      final p = game.board[r][c];
      if (p == null || p.color != PieceColor.black) continue;
      final moves = game.getValidMoves(r, c);
      for (final m in moves) {
        final copy = _cloneGame(game);
        copy.movePiece(r, c, m[0], m[1]);
        // Auto-promote to queen
        if (copy.board[m[0]][m[1]]?.type == PieceType.pawn &&
            (m[0] == 0 || m[0] == 7)) {
          copy.promote(m[0], m[1], PieceType.queen);
        }
        final score = _minimax(copy, depth - 1, -999999, 999999, false);
        if (score > bestScore) {
          bestScore = score;
          best = [r, c, m[0], m[1]];
        }
      }
    }
  }
  return best ?? [0, 0, 0, 0];
}

int _minimax(ChessGame game, int depth, int alpha, int beta, bool maximizing) {
  if (depth == 0 || game.isCheckmate || game.isStalemate) return _evaluate(game);
  final color = maximizing ? PieceColor.black : PieceColor.white;

  if (maximizing) {
    int maxEval = -999999;
    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        if (game.board[r][c]?.color != color) continue;
        for (final m in game.getValidMoves(r, c)) {
          final copy = _cloneGame(game);
          copy.movePiece(r, c, m[0], m[1]);
          if (copy.board[m[0]][m[1]]?.type == PieceType.pawn &&
              (m[0] == 0 || m[0] == 7)) copy.promote(m[0], m[1], PieceType.queen);
          final eval = _minimax(copy, depth - 1, alpha, beta, false);
          maxEval = eval > maxEval ? eval : maxEval;
          alpha = eval > alpha ? eval : alpha;
          if (beta <= alpha) return maxEval;
        }
      }
    }
    return maxEval;
  } else {
    int minEval = 999999;
    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        if (game.board[r][c]?.color != color) continue;
        for (final m in game.getValidMoves(r, c)) {
          final copy = _cloneGame(game);
          copy.movePiece(r, c, m[0], m[1]);
          if (copy.board[m[0]][m[1]]?.type == PieceType.pawn &&
              (m[0] == 0 || m[0] == 7)) copy.promote(m[0], m[1], PieceType.queen);
          final eval = _minimax(copy, depth - 1, alpha, beta, true);
          minEval = eval < minEval ? eval : minEval;
          beta = eval < beta ? eval : beta;
          if (beta <= alpha) return minEval;
        }
      }
    }
    return minEval;
  }
}

ChessGame _cloneGame(ChessGame src) {
  final g = ChessGame._empty();
  g.currentTurn = src.currentTurn;
  g.enPassantRow = src.enPassantRow;
  g.enPassantCol = src.enPassantCol;
  g.isCheck = src.isCheck;
  g.isCheckmate = src.isCheckmate;
  g.isStalemate = src.isStalemate;
  for (int r = 0; r < 8; r++)
    for (int c = 0; c < 8; c++)
      g.board[r][c] = src.board[r][c]?.copy();
  return g;
}

// ─────────────────────────────────────────────────────────────
// 🖼️ CHESS PAGE WIDGET
// ─────────────────────────────────────────────────────────────
class ChessPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const ChessPage({
    super.key,
    this.username = '',
    this.sessionKey = '',
  });

  @override
  State<ChessPage> createState() => _ChessPageState();
}

class _ChessPageState extends State<ChessPage> with TickerProviderStateMixin {
  late ChessGame _game;
  int? _selectedRow, _selectedCol;
  List<List<int>> _validMoves = [];
  List<int>? _lastFrom, _lastTo;
  List<int>? _promotionPos;
  String _statusMsg = "Giliran: Putih ♔";
  int _whiteCaptures = 0;
  int _blackCaptures = 0;
  bool _isComputing = false;

  // AI mode
  bool _vsAi = true;
  PieceColor _aiColor = PieceColor.black; // AI selalu hitam, player putih

  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;
  late AnimationController _checkCtrl;
  late Animation<double> _checkAnim;

  @override
  void initState() {
    super.initState();
    _game = ChessGame();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.7, end: 1.0).animate(_pulseCtrl);
    _checkCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 500))
      ..repeat(reverse: true);
    _checkAnim = Tween<double>(begin: 0.3, end: 1.0).animate(_checkCtrl);
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _checkCtrl.dispose();
    super.dispose();
  }

  Future<void> _onTap(int row, int col) async {
    if (_game.isCheckmate || _game.isStalemate) return;
    if (_promotionPos != null) return;
    if (_isComputing) return;
    // Block tap when it's AI's turn
    if (_vsAi && _game.currentTurn == _aiColor) return;

    final piece = _game.board[row][col];

    // Select own piece
    if (_selectedRow == null) {
      if (piece != null && piece.color == _game.currentTurn) {
        setState(() { _isComputing = true; });
        final moves = await compute(_computeValidMoves, _GameMoveParams.forMoves(_game, row, col));
        if (!mounted) return;
        setState(() {
          _selectedRow = row;
          _selectedCol = col;
          _validMoves = moves;
          _isComputing = false;
        });
      }
      return;
    }

    // Deselect or re-select
    if (_selectedRow == row && _selectedCol == col) {
      setState(() { _selectedRow = null; _selectedCol = null; _validMoves = []; });
      return;
    }

    // Re-select another own piece
    if (piece != null && piece.color == _game.currentTurn) {
      setState(() { _isComputing = true; });
      final moves = await compute(_computeValidMoves, _GameMoveParams.forMoves(_game, row, col));
      if (!mounted) return;
      setState(() {
        _selectedRow = row;
        _selectedCol = col;
        _validMoves = moves;
        _isComputing = false;
      });
      return;
    }

    // Try to move
    final isValid = _validMoves.any((m) => m[0] == row && m[1] == col);
    if (isValid) {
      HapticFeedback.lightImpact();
      final captured = _game.board[row][col];
      if (captured != null) {
        if (captured.color == PieceColor.black) _whiteCaptures++;
        else _blackCaptures++;
      }
      _lastFrom = [_selectedRow!, _selectedCol!];
      _lastTo   = [row, col];

      setState(() { _isComputing = true; });
      final result = await compute(_computeMovePiece, _GameMoveParams.forMove(_game, _selectedRow!, _selectedCol!, row, col));
      if (!mounted) return;

      _game = result.game;
      setState(() {
        _selectedRow = null;
        _selectedCol = null;
        _validMoves = [];
        _promotionPos = result.promotionPos;
        _isComputing = false;
        _updateStatus();
      });

      if (result.promotionPos != null) {
        _showPromotionDialog(result.promotionPos![0], result.promotionPos![1]);
      } else if (_vsAi && !_game.isCheckmate && !_game.isStalemate) {
        // Trigger AI after short delay
        await Future.delayed(const Duration(milliseconds: 300));
        if (mounted) await _doAiMove();
      }
    } else {
      setState(() { _selectedRow = null; _selectedCol = null; _validMoves = []; });
    }
  }

  Future<void> _doAiMove() async {
    if (_game.isCheckmate || _game.isStalemate) return;
    setState(() { _isComputing = true; });
    final best = await compute(_aiBestMove, _GameMoveParams.forAi(_game));
    if (!mounted) return;

    final fromR = best[0], fromC = best[1], toR = best[2], toC = best[3];
    final captured = _game.board[toR][toC];
    if (captured != null) {
      if (captured.color == PieceColor.black) _whiteCaptures++;
      else _blackCaptures++;
    }
    _lastFrom = [fromR, fromC];
    _lastTo   = [toR, toC];

    final result = await compute(_computeMovePiece, _GameMoveParams.forMove(_game, fromR, fromC, toR, toC));
    if (!mounted) return;

    _game = result.game;
    // AI auto-promote to queen
    if (result.promotionPos != null) {
      _game.promote(result.promotionPos![0], result.promotionPos![1], PieceType.queen);
    }
    setState(() {
      _isComputing = false;
      _updateStatus();
    });
    HapticFeedback.lightImpact();
  }

  void _updateStatus() {
    if (_game.isCheckmate) {
      final winner = _game.currentTurn == PieceColor.white ? 'Hitam' : 'Putih';
      _statusMsg = '🏆 $winner Menang! Checkmate!';
      _submitToLeaderboard();
    } else if (_game.isStalemate) {
      _statusMsg = '🤝 Seri! Stalemate.';
    } else if (_game.isCheck) {
      final who = _game.currentTurn == PieceColor.white ? 'Putih' : 'Hitam';
      _statusMsg = '⚠️ Check! Giliran: $who';
    } else {
      final who = _game.currentTurn == PieceColor.white ? 'Putih ♔' : 'Hitam ♚';
      _statusMsg = 'Giliran: $who';
    }
  }

  Future<void> _submitToLeaderboard() async {
    if (widget.username.isEmpty) return;
    final isWhiteWinner = _game.currentTurn == PieceColor.black; // turn sudah ganti setelah checkmate
    final winnerName = isWhiteWinner ? '${widget.username} (Putih)' : 'Lawan (Hitam)';
    final totalMoves = (_whiteCaptures + _blackCaptures); // approx activity
    await LeaderboardApi.submitResult(
      players: [
        {
          'username': widget.username,
          'score': _whiteCaptures * 10,
          'coins': _whiteCaptures * 5,
          'wins': isWhiteWinner ? 1 : 0,
          'game': 'Chess',
          'icon': '♟',
        },
      ],
      winnerName: winnerName,
      roomCode: 'chess_${DateTime.now().millisecondsSinceEpoch}',
      duration: totalMoves,
    );
  }

  void _showPromotionDialog(int row, int col) {
    final color = _game.board[row][col]!.color;
    final pieces = [PieceType.queen, PieceType.rook, PieceType.bishop, PieceType.knight];
    final symbols = color == PieceColor.white
        ? ['♕', '♖', '♗', '♘']
        : ['♛', '♜', '♝', '♞'];

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: _kDarkPanel,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: _kGold, width: 1),
        ),
        title: const Text('Promosi Pion!',
          style: TextStyle(color: _kGold, fontWeight: FontWeight.bold)),
        content: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: List.generate(4, (i) => GestureDetector(
            onTap: () {
              _game.promote(row, col, pieces[i]);
              setState(() {
                _promotionPos = null;
                _updateStatus();
              });
              Navigator.pop(ctx);
            },
            child: Container(
              width: 56, height: 56,
              decoration: BoxDecoration(
                color: _kDarkCard,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _kGold.withOpacity(0.5)),
              ),
              child: Center(
                child: Text(symbols[i], style: const TextStyle(fontSize: 32)),
              ),
            ),
          )),
        ),
      ),
    );
  }

  void _resetGame() {
    setState(() {
      _game = ChessGame();
      _selectedRow = null;
      _selectedCol = null;
      _validMoves = [];
      _lastFrom = null;
      _lastTo = null;
      _promotionPos = null;
      _whiteCaptures = 0;
      _blackCaptures = 0;
      _statusMsg = 'Giliran: Putih ♔';
      _isComputing = false;
    });
  }

  Color _squareColor(int row, int col) {
    final isLight = (row + col) % 2 == 0;
    final base = isLight ? _kWhite : _kBlack;

    if (_selectedRow == row && _selectedCol == col) return _kSelected.withOpacity(0.85);
    if (_lastFrom != null && _lastFrom![0] == row && _lastFrom![1] == col) return _kLastMove.withOpacity(0.7);
    if (_lastTo != null && _lastTo![0] == row && _lastTo![1] == col) return _kLastMove.withOpacity(0.7);

    final checkPos = _game.kingInCheckPos;
    if (checkPos != null && checkPos[0] == row && checkPos[1] == col) return _kCheck.withOpacity(0.75);

    return base;
  }

  @override
  Widget build(BuildContext context) {
    final screenW = MediaQuery.of(context).size.width;
    final boardSize = screenW - 16;
    final cellSize = boardSize / 8;

    return Scaffold(
      backgroundColor: _kDark,
      appBar: AppBar(
        backgroundColor: _kDarkCard,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: _kGold),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          '♟ Chess',
          style: TextStyle(
            color: _kGold,
            fontWeight: FontWeight.bold,
            fontSize: 20,
            letterSpacing: 2,
          ),
        ),
        centerTitle: true,
        actions: [
          // Toggle AI / PvP
          GestureDetector(
            onTap: () {
              setState(() { _vsAi = !_vsAi; });
              _resetGame();
            },
            child: Container(
              margin: const EdgeInsets.only(right: 6),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: _vsAi ? _kGold.withOpacity(0.15) : Colors.white10,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _vsAi ? _kGold : Colors.white24),
              ),
              child: Text(
                _vsAi ? '🤖 AI' : '👥 PvP',
                style: TextStyle(
                  color: _vsAi ? _kGold : Colors.white60,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.refresh, color: _kGold),
            onPressed: _resetGame,
            tooltip: 'Reset',
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 8),

            // ── Status Bar ──
            _buildStatusBar(),

            const SizedBox(height: 8),

            // ── Black player info ──
            _buildPlayerBar(PieceColor.black, _blackCaptures),

            const SizedBox(height: 4),

            // ── Board ──
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  _buildBoard(boardSize, cellSize),
                  if (_isComputing)
                    Container(
                      width: boardSize,
                      height: boardSize,
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.35),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: const Center(
                        child: CircularProgressIndicator(color: _kGold, strokeWidth: 3),
                      ),
                    ),
                ],
              ),
            ),

            const SizedBox(height: 4),

            // ── White player info ──
            _buildPlayerBar(PieceColor.white, _whiteCaptures),

            const SizedBox(height: 8),

            // ── Game over banner ──
            if (_game.isCheckmate || _game.isStalemate)
              _buildGameOverBanner(),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusBar() {
    final isCheck = _game.isCheck && !_game.isCheckmate;
    return AnimatedBuilder(
      animation: _checkAnim,
      builder: (_, __) => Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: isCheck
              ? _kCheck.withOpacity(_checkAnim.value * 0.3)
              : _kDarkPanel,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isCheck ? _kCheck : _kGold.withOpacity(0.4),
            width: 1,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              _statusMsg,
              style: TextStyle(
                color: isCheck ? _kCheck : _kGold,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPlayerBar(PieceColor color, int captures) {
    final isActive = _game.currentTurn == color &&
        !_game.isCheckmate && !_game.isStalemate;
    final isAiPlayer = _vsAi && color == _aiColor;
    final label = isAiPlayer ? '🤖 AI'
        : color == PieceColor.white
            ? (widget.username.isNotEmpty ? widget.username : 'Putih')
            : 'Hitam';
    final icon  = color == PieceColor.white ? '♔' : '♚';

    return AnimatedBuilder(
      animation: _pulseAnim,
      builder: (_, __) => Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: isActive
              ? _kGold.withOpacity(0.12 * _pulseAnim.value)
              : _kDarkPanel,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: isActive ? _kGold : Colors.white12,
            width: isActive ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 32, height: 32,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color == PieceColor.white
                    ? Colors.white.withOpacity(0.9)
                    : Colors.black87,
                border: Border.all(color: _kGold.withOpacity(0.5), width: 1),
              ),
              child: Center(
                child: Text(icon, style: const TextStyle(fontSize: 16)),
              ),
            ),
            const SizedBox(width: 10),
            Text(
              label,
              style: TextStyle(
                color: isActive ? _kGold : Colors.white60,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
            const Spacer(),
            if (captures > 0)
              Text(
                '+$captures bidak',
                style: TextStyle(
                  color: isActive ? _kGold.withOpacity(0.8) : Colors.white38,
                  fontSize: 12,
                ),
              ),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
              decoration: BoxDecoration(
                color: isActive ? _kGold : Colors.white10,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                isActive ? 'GILIRAN' : 'MENUNGGU',
                style: TextStyle(
                  color: isActive ? _kDark : Colors.white38,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBoard(double boardSize, double cellSize) {
    return Container(
      width: boardSize,
      height: boardSize,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: _kGold.withOpacity(0.6), width: 2),
        boxShadow: [
          BoxShadow(color: _kGold.withOpacity(0.15), blurRadius: 20, spreadRadius: 2),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(4),
        child: Stack(
          children: [
            // Board squares
            Column(
              children: List.generate(8, (row) => Row(
                children: List.generate(8, (col) {
                  final piece = _game.board[row][col];
                  final isValidMove = _validMoves.any((m) => m[0] == row && m[1] == col);
                  final squareColor = _squareColor(row, col);
                  final hasEnemy = piece != null && piece.color != _game.currentTurn;

                  return GestureDetector(
                    onTap: () => _onTap(row, col),
                    child: Container(
                      width: cellSize,
                      height: cellSize,
                      color: squareColor,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          // Valid move indicator
                          if (isValidMove)
                            hasEnemy
                                ? Container(
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                        color: _kHighlight.withOpacity(0.9),
                                        width: 3,
                                      ),
                                    ),
                                  )
                                : Center(
                                    child: Container(
                                      width: cellSize * 0.32,
                                      height: cellSize * 0.32,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: _kHighlight.withOpacity(0.7),
                                      ),
                                    ),
                                  ),

                          // Piece
                          if (piece != null)
                            Text(
                              piece.symbol,
                              style: TextStyle(
                                fontSize: cellSize * 0.65,
                                shadows: [
                                  Shadow(
                                    color: Colors.black87,
                                    blurRadius: 4,
                                    offset: const Offset(1, 1),
                                  ),
                                ],
                              ),
                              textAlign: TextAlign.center,
                            ),

                          // Rank/file labels
                          if (col == 0)
                            Positioned(
                              top: 1, left: 2,
                              child: Text(
                                '${8 - row}',
                                style: TextStyle(
                                  fontSize: 9,
                                  fontWeight: FontWeight.bold,
                                  color: (row + col) % 2 == 0
                                      ? _kBlack.withOpacity(0.7)
                                      : _kWhite.withOpacity(0.7),
                                ),
                              ),
                            ),
                          if (row == 7)
                            Positioned(
                              bottom: 1, right: 2,
                              child: Text(
                                String.fromCharCode(97 + col),
                                style: TextStyle(
                                  fontSize: 9,
                                  fontWeight: FontWeight.bold,
                                  color: (row + col) % 2 == 0
                                      ? _kBlack.withOpacity(0.7)
                                      : _kWhite.withOpacity(0.7),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  );
                }),
              )),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGameOverBanner() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1A1200), Color(0xFF3D2D00)],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _kGold, width: 1.5),
        boxShadow: [
          BoxShadow(color: _kGold.withOpacity(0.3), blurRadius: 16),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text('🏆', style: TextStyle(fontSize: 24)),
          const SizedBox(width: 10),
          Text(
            _game.isStalemate ? 'Seri!' : 'Game Over!',
            style: const TextStyle(
              color: _kGold,
              fontWeight: FontWeight.bold,
              fontSize: 18,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(width: 16),
          TextButton(
            onPressed: _resetGame,
            style: TextButton.styleFrom(
              backgroundColor: _kGold,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: const Text(
              'Main Lagi',
              style: TextStyle(
                color: _kDark,
                fontWeight: FontWeight.bold,
                fontSize: 13,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
