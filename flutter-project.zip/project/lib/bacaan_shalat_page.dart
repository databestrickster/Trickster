import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'config_service.dart';
import 'package:http/http.dart' as http;

// ─────────────────────────────────────────────
// 🕌 PALETTE ISLAMI PREMIUM
// ─────────────────────────────────────────────
const _kEmerald      = Color(0xFF00B894);
const _kEmeraldLight = Color(0xFF55EFC4);
const _kEmeraldDark  = Color(0xFF00785A);
const _kGold         = Color(0xFFFFD700);
const _kGoldDim      = Color(0xFFB8960C);
const _kDark         = Color(0xFF070D0D);
const _kDarkCard     = Color(0xFF0F1A1A);
const _kDarkCard2    = Color(0xFF162020);
const _kWhite70      = Color(0xB3FFFFFF);
const _kWhite38      = Color(0x61FFFFFF);

class BacaanShalatPage extends StatefulWidget {
  final String sessionKey;

  const BacaanShalatPage({super.key, required this.sessionKey}); // ← required

  @override
  State<BacaanShalatPage> createState() => _BacaanShalatPageState();
}

class _BacaanShalatPageState extends State<BacaanShalatPage>
    with TickerProviderStateMixin {
  List<dynamic> _data = [];
  bool _isLoading = true;
  String _error = "";
  int? _expandedIndex;

  late AnimationController _shimmerCtrl;
  late AnimationController _glowCtrl;

  @override
  void initState() {
    super.initState();
    _shimmerCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat();
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);
    _fetchData();
  }

  Future<void> _fetchData() async {
    try {
      final res = await http.get(Uri.parse(
     "${ConfigService.baseUrl}/bacaanShalat?key=${widget.sessionKey}"
      ));
      final json = jsonDecode(res.body);
      setState(() {
        _data = json["result"] ?? [];
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _error = "Gagal memuat data";
        _isLoading = false;
      });
    }
  }

  @override
  void dispose() {
    _shimmerCtrl.dispose();
    _glowCtrl.dispose();
    super.dispose();
  }

  // ─────────────────────────────────────────
  // BUILD
  // ─────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kDark,
      body: Stack(
        children: [
          _buildBackground(),
          SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                Expanded(
                  child: _isLoading
                      ? _buildLoading()
                      : _error.isNotEmpty
                          ? _buildError()
                          : _buildList(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── BACKGROUND ───
  Widget _buildBackground() {
    return AnimatedBuilder(
      animation: _glowCtrl,
      builder: (_, __) {
        return Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: Alignment(-0.3, -0.6),
              radius: 1.2,
              colors: [
                _kEmeraldDark.withOpacity(0.15 + _glowCtrl.value * 0.05),
                _kDark,
                _kDark,
              ],
            ),
          ),
        );
      },
    );
  }

  // ─── HEADER ───
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
      decoration: BoxDecoration(
        color: _kDarkCard.withOpacity(0.9),
        border: const Border(
          bottom: BorderSide(color: Color(0xFF1E3232), width: 1),
        ),
      ),
      child: Row(
        children: [
          // Icon masjid
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: _kEmeraldDark.withOpacity(0.3),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _kEmerald.withOpacity(0.4)),
            ),
            child: const Center(
              child: Text("🕌", style: TextStyle(fontSize: 22)),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "BACAAN SHALAT",
                  style: TextStyle(
                    color: _kGold,
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2.5,
                  ),
                ),
                Text(
                  "Doa & Dzikir Lengkap",
                  style: TextStyle(
                    color: _kEmeraldLight.withOpacity(0.7),
                    fontSize: 11,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
          // Count badge
          if (_data.isNotEmpty)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: _kEmerald.withOpacity(0.15),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _kEmerald.withOpacity(0.3)),
              ),
              child: Text(
                "${_data.length} Bacaan",
                style: const TextStyle(
                  color: _kEmeraldLight,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ─── LOADING ───
  Widget _buildLoading() {
    return AnimatedBuilder(
      animation: _shimmerCtrl,
      builder: (_, __) {
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: 5,
          itemBuilder: (_, i) => _buildSkeletonCard(i),
        );
      },
    );
  }

  Widget _buildSkeletonCard(int i) {
    final shimmer = _shimmerCtrl.value;
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: _kDarkCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.05)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 120 + (i * 20.0),
            height: 12,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.05 + shimmer * 0.05),
              borderRadius: BorderRadius.circular(6),
            ),
          ),
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            height: 10,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.03 + shimmer * 0.03),
              borderRadius: BorderRadius.circular(6),
            ),
          ),
        ],
      ),
    );
  }

  // ─── ERROR ───
  Widget _buildError() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text("😔", style: TextStyle(fontSize: 48)),
          const SizedBox(height: 16),
          Text(_error, style: const TextStyle(color: _kWhite70, fontSize: 15)),
          const SizedBox(height: 20),
          GestureDetector(
            onTap: () {
              setState(() { _isLoading = true; _error = ""; });
              _fetchData();
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
              decoration: BoxDecoration(
                color: _kEmerald.withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _kEmerald),
              ),
              child: const Text("Coba Lagi", style: TextStyle(color: _kEmeraldLight, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  // ─── LIST ───
  Widget _buildList() {
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
      itemCount: _data.length,
      itemBuilder: (context, index) {
        final item = _data[index];
        final isExpanded = _expandedIndex == index;
        return _buildCard(item, index, isExpanded);
      },
    );
  }

  // ─── CARD ───
  Widget _buildCard(dynamic item, int index, bool isExpanded) {
  final nama = item["name"] ?? "";
  final arab = item["arabic"] ?? "";
  final latin = item["latin"] ?? "";
  final arti = item["terjemahan"] ?? "";

    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        setState(() {
          _expandedIndex = isExpanded ? null : index;
        });
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeInOut,
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(
          color: isExpanded ? _kDarkCard2 : _kDarkCard,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: isExpanded
                ? _kEmerald.withOpacity(0.5)
                : Colors.white.withOpacity(0.06),
            width: isExpanded ? 1.2 : 1,
          ),
          boxShadow: isExpanded
              ? [BoxShadow(color: _kEmerald.withOpacity(0.08), blurRadius: 20, spreadRadius: 2)]
              : [],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Header Row ──
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  // Nomor
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: isExpanded
                            ? [_kEmeraldDark, _kEmerald]
                            : [Colors.white10, Colors.white10],
                      ),
                    ),
                    child: Center(
                      child: Text(
                        "${index + 1}",
                        style: TextStyle(
                          color: isExpanded ? Colors.white : _kWhite38,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      nama,
                      style: TextStyle(
                        color: isExpanded ? _kGold : _kWhite70,
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.3,
                      ),
                    ),
                  ),
                  Icon(
                    isExpanded ? Icons.keyboard_arrow_up_rounded : Icons.keyboard_arrow_down_rounded,
                    color: isExpanded ? _kEmerald : _kWhite38,
                    size: 22,
                  ),
                ],
              ),
            ),

            // ── Expanded Content ──
            if (isExpanded) ...[
              Divider(color: _kEmerald.withOpacity(0.2), height: 1),

              // Arab
              Container(
                width: double.infinity,
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.2),
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(0),
                    bottomRight: Radius.circular(0),
                  ),
                ),
                child: Text(
                  arab,
                  textAlign: TextAlign.right,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    height: 2.2,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),

              // Latin
              if (latin.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
                  child: Text(
                    latin,
                    style: const TextStyle(
                      color: _kEmeraldLight,
                      fontSize: 13,
                      fontStyle: FontStyle.italic,
                      height: 1.7,
                    ),
                  ),
                ),

              // Arti
              if (arti.isNotEmpty)
                Container(
                  margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _kGold.withOpacity(0.06),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _kGoldDim.withOpacity(0.2)),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("✨ ", style: TextStyle(fontSize: 13)),
                      Expanded(
                        child: Text(
                          arti,
                          style: const TextStyle(
                            color: _kWhite70,
                            fontSize: 13,
                            height: 1.6,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

              // Copy button
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                child: GestureDetector(
                  onTap: () {
                    Clipboard.setData(ClipboardData(text: "$arab\n\n$latin\n\n$arti"));
                    HapticFeedback.mediumImpact();
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text("📋 $nama disalin!"),
                        backgroundColor: _kEmeraldDark,
                        duration: const Duration(seconds: 2),
                        behavior: SnackBarBehavior.floating,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                    );
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 9),
                    decoration: BoxDecoration(
                      color: _kEmerald.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: _kEmerald.withOpacity(0.3)),
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.copy_rounded, color: _kEmeraldLight, size: 14),
                        SizedBox(width: 6),
                        Text(
                          "Salin Bacaan",
                          style: TextStyle(
                            color: _kEmeraldLight,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
