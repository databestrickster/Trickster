import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:just_audio/just_audio.dart';

class NovelReadPage extends StatefulWidget {
  final Map<String, dynamic> novel;
  const NovelReadPage({super.key, required this.novel});

  @override
  State<NovelReadPage> createState() => _NovelReadPageState();
}

class _NovelReadPageState extends State<NovelReadPage> {
  static const _groqApiKey = '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';
  static const _groqModel = 'llama-3.3-70b-versatile';

  final ScrollController _scrollController = ScrollController();
  final AudioPlayer _audioPlayer = AudioPlayer();

  final List<String> _chapters = [];
  bool _loading = false;
  bool _hasError = false;
  String _errorMsg = '';
  int _chapterNumber = 1;

  int? _playingChapter;
  bool _isPlaying = false;
  bool _ttsLoading = false;

  @override
  void initState() {
    super.initState();
    _generateChapter();
    _scrollController.addListener(_onScroll);
    _audioPlayer.playerStateStream.listen((state) {
      if (state.processingState == ProcessingState.completed) {
        setState(() {
          _isPlaying = false;
          _playingChapter = null;
        });
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
            _scrollController.position.maxScrollExtent - 300 &&
        !_loading) {
      _generateChapter();
    }
  }

  Future<void> _generateChapter() async {
    if (_loading) return;
    setState(() {
      _loading = true;
      _hasError = false;
    });

    final title = widget.novel['title'] as String;
    final genre = widget.novel['genre'] as String;
    final desc = widget.novel['desc'] as String;

    final previousContext = _chapters.isEmpty
        ? ''
        : 'Lanjutan dari: ${_chapters.last.substring(0, _chapters.last.length.clamp(0, 300))}...';

    final prompt = '''
Kamu adalah penulis novel Indonesia. Tulis BAB $_chapterNumber dari novel "$title" bergenre $genre.

Sinopsis: $desc
$previousContext

Ketentuan:
- Bahasa Indonesia natural dan enak dibaca
- Panjang 400-600 kata
- Ada dialog, deskripsi suasana, dan emosi karakter
- Akhiri dengan cliffhanger atau momen yang membuat pembaca ingin lanjut
- Jangan tulis judul bab, langsung mulai cerita
- Genre $genre harus terasa kuat
''';

    try {
      final response = await http.post(
        Uri.parse('https://api.groq.com/openai/v1/chat/completions'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $_groqApiKey',
        },
        body: jsonEncode({
          'model': _groqModel,
          'messages': [
            {'role': 'user', 'content': prompt}
          ],
          'max_tokens': 1024,
          'temperature': 0.85,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final content = data['choices'][0]['message']['content'] as String;
        setState(() {
          _chapters.add(content.trim());
          _chapterNumber++;
          _loading = false;
        });
      } else {
        debugPrint('GROQ STATUS: ${response.statusCode}');
        debugPrint('GROQ BODY: ${response.body}');
        setState(() {
          _hasError = true;
          _errorMsg = '${response.statusCode}: ${response.body}';
          _loading = false;
        });
      }
    } catch (e, stack) {
      debugPrint('GROQ ERROR: $e');
      debugPrint('GROQ STACK: $stack');
      setState(() {
        _hasError = true;
        _errorMsg = e.toString();
        _loading = false;
      });
    }
  }

  // Split text to chunks ≤200 chars at sentence boundary
  List<String> _splitChunks(String text) {
    final List<String> chunks = [];
    final sentences = text.split(RegExp(r'(?<=[.!?])\s+'));
    String current = '';
    for (final s in sentences) {
      if ((current + s).length > 200) {
        if (current.isNotEmpty) chunks.add(current.trim());
        current = s;
      } else {
        current += (current.isEmpty ? '' : ' ') + s;
      }
    }
    if (current.isNotEmpty) chunks.add(current.trim());
    return chunks;
  }

  Future<void> _playChapter(int index) async {
    // Same chapter → toggle pause/resume
    if (_playingChapter == index && !_ttsLoading) {
      if (_isPlaying) {
        await _audioPlayer.pause();
        setState(() => _isPlaying = false);
      } else {
        await _audioPlayer.play();
        setState(() => _isPlaying = true);
      }
      return;
    }

    // Stop previous
    await _audioPlayer.stop();
    setState(() {
      _playingChapter = index;
      _isPlaying = false;
      _ttsLoading = true;
    });

    final text = _chapters[index];
    final chunks = _splitChunks(text);

    final List<AudioSource> sources = chunks.map((chunk) {
      final encoded = Uri.encodeComponent(chunk);
      final url =
          'https://translate.google.com/translate_tts?ie=UTF-8&q=$encoded&tl=id&client=tw-ob';
      return AudioSource.uri(
        Uri.parse(url),
        headers: {'User-Agent': 'Mozilla/5.0'},
      ) as AudioSource;
    }).toList();

    try {
      final playlist = ConcatenatingAudioSource(children: sources);
      await _audioPlayer.setAudioSource(playlist);
      await _audioPlayer.play();
      setState(() {
        _isPlaying = true;
        _ttsLoading = false;
      });
    } catch (e) {
      setState(() {
        _ttsLoading = false;
        _playingChapter = null;
      });
    }
  }

  Future<void> _stopAudio() async {
    await _audioPlayer.stop();
    setState(() {
      _isPlaying = false;
      _playingChapter = null;
    });
  }

  Color get _genreColor {
    const colors = {
      'Horror': Color(0xFF8B0000),
      'Romance': Color(0xFFB5006E),
      'Fantasy': Color(0xFF4A00B0),
      'Mystery': Color(0xFF00506B),
      'Sci-Fi': Color(0xFF003D6B),
      'Adventure': Color(0xFF1A5C00),
      'Thriller': Color(0xFF5C3800),
      'Drama': Color(0xFF5C0050),
      'Supernatural': Color(0xFF2D006B),
      'Comedy': Color(0xFF8B6200),
    };
    return colors[widget.novel['genre']] ?? const Color(0xFF333355);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      body: Stack(
        children: [
          CustomScrollView(
            controller: _scrollController,
            slivers: [
              // AppBar with cover
              SliverAppBar(
                expandedHeight: 220,
                pinned: true,
                backgroundColor: const Color(0xFF0A0A0F),
                leading: IconButton(
                  icon: const Icon(Icons.arrow_back_ios_new,
                      color: Colors.white, size: 20),
                  onPressed: () {
                    _stopAudio();
                    Navigator.pop(context);
                  },
                ),
                flexibleSpace: FlexibleSpaceBar(
                  background: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.network(
                        widget.novel['cover'],
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: _genreColor.withOpacity(0.3),
                          child: Center(
                            child: Text(
                              widget.novel['emoji'],
                              style: const TextStyle(fontSize: 60),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.transparent,
                              const Color(0xFF0A0A0F).withOpacity(0.8),
                              const Color(0xFF0A0A0F),
                            ],
                            stops: const [0.2, 0.75, 1.0],
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 16,
                        left: 20,
                        right: 20,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: _genreColor,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                '${widget.novel['emoji']} ${widget.novel['genre']}',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              widget.novel['title'],
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              widget.novel['desc'],
                              style: const TextStyle(
                                  color: Colors.white54, fontSize: 12),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // Chapters
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (ctx, i) => _ChapterBlock(
                      chapterNumber: i + 1,
                      content: _chapters[i],
                      color: _genreColor,
                      isPlaying: _playingChapter == i && _isPlaying,
                      isLoading: _playingChapter == i && _ttsLoading,
                      onPlayTap: () => _playChapter(i),
                    ),
                    childCount: _chapters.length,
                  ),
                ),
              ),

              // Loading / error / bottom padding
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 120),
                sliver: SliverToBoxAdapter(
                  child: _loading
                      ? Column(
                          children: [
                            SizedBox(
                              width: 26,
                              height: 26,
                              child: CircularProgressIndicator(
                                  color: _genreColor, strokeWidth: 2.5),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              'Menulis bab $_chapterNumber...',
                              style: const TextStyle(
                                  color: Colors.white38, fontSize: 13),
                            ),
                          ],
                        )
                      : _hasError
                          ? Column(
                              children: [
                                const Text('Gagal generate cerita 😞',
                                    style: TextStyle(
                                        color: Colors.white54, fontSize: 14)),
                                const SizedBox(height: 8),
                                Text(
                                  _errorMsg,
                                  style: const TextStyle(
                                      color: Colors.red, fontSize: 11),
                                  textAlign: TextAlign.center,
                                ),
                                const SizedBox(height: 12),
                                TextButton(
                                  onPressed: _generateChapter,
                                  child: Text('Coba Lagi',
                                      style: TextStyle(color: _genreColor)),
                                ),
                              ],
                            )
                          : const SizedBox.shrink(),
                ),
              ),
            ],
          ),

          // Bottom audio player bar
          if (_playingChapter != null)
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                padding: const EdgeInsets.fromLTRB(20, 12, 12, 28),
                decoration: BoxDecoration(
                  color: const Color(0xFF12121F),
                  border: Border(
                      top: BorderSide(color: _genreColor.withOpacity(0.4))),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.5),
                      blurRadius: 20,
                      offset: const Offset(0, -4),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    // Emoji avatar
                    Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        color: _genreColor.withOpacity(0.2),
                        shape: BoxShape.circle,
                        border:
                            Border.all(color: _genreColor, width: 1.5),
                      ),
                      child: Center(
                        child: Text(widget.novel['emoji'],
                            style: const TextStyle(fontSize: 18)),
                      ),
                    ),
                    const SizedBox(width: 12),
                    // Title + chapter
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            widget.novel['title'],
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 13,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                          Text(
                            'BAB ${(_playingChapter ?? 0) + 1}',
                            style: TextStyle(
                                color: _genreColor, fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                    // Play/Pause
                    if (_ttsLoading)
                      Padding(
                        padding: const EdgeInsets.all(12),
                        child: SizedBox(
                          width: 22,
                          height: 22,
                          child: CircularProgressIndicator(
                              color: _genreColor, strokeWidth: 2),
                        ),
                      )
                    else
                      IconButton(
                        icon: Icon(
                          _isPlaying
                              ? Icons.pause_rounded
                              : Icons.play_arrow_rounded,
                          color: Colors.white,
                          size: 30,
                        ),
                        onPressed: () => _playChapter(_playingChapter!),
                      ),
                    // Stop
                    IconButton(
                      icon: const Icon(Icons.stop_rounded,
                          color: Colors.white38, size: 26),
                      onPressed: _stopAudio,
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _ChapterBlock extends StatelessWidget {
  final int chapterNumber;
  final String content;
  final Color color;
  final bool isPlaying;
  final bool isLoading;
  final VoidCallback onPlayTap;

  const _ChapterBlock({
    required this.chapterNumber,
    required this.content,
    required this.color,
    required this.isPlaying,
    required this.isLoading,
    required this.onPlayTap,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 40),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Chapter header + play button
          Row(
            children: [
              Container(
                width: 3,
                height: 20,
                decoration: BoxDecoration(
                    color: color, borderRadius: BorderRadius.circular(2)),
              ),
              const SizedBox(width: 10),
              Text(
                'BAB $chapterNumber',
                style: TextStyle(
                  color: color,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                ),
              ),
              const Spacer(),
              // TTS button
              GestureDetector(
                onTap: onPlayTap,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: isPlaying
                        ? color.withOpacity(0.25)
                        : color.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                        color: color.withOpacity(isPlaying ? 0.9 : 0.3)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (isLoading)
                        SizedBox(
                          width: 12,
                          height: 12,
                          child: CircularProgressIndicator(
                              color: color, strokeWidth: 1.5),
                        )
                      else
                        Icon(
                          isPlaying
                              ? Icons.pause_rounded
                              : Icons.volume_up_rounded,
                          color: color,
                          size: 14,
                        ),
                      const SizedBox(width: 6),
                      Text(
                        isLoading
                            ? 'Loading...'
                            : isPlaying
                                ? 'Pause'
                                : 'Dengarkan',
                        style: TextStyle(
                          color: color,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Novel text
          Text(
            content,
            style: const TextStyle(
              color: Color(0xFFD0D0E0),
              fontSize: 15,
              height: 1.85,
              letterSpacing: 0.2,
            ),
          ),
          const SizedBox(height: 24),

          // Divider
          Row(
            children: [
              Expanded(
                  child: Divider(
                      color: color.withOpacity(0.2), thickness: 1)),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Text('✦',
                    style: TextStyle(color: color.withOpacity(0.4))),
              ),
              Expanded(
                  child: Divider(
                      color: color.withOpacity(0.2), thickness: 1)),
            ],
          ),
        ],
      ),
    );
  }
}
