import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ─── Color Preset (warna biasa) ───────────────────────────────────────────────
class ColorPreset {
  final String name;
  final Color primary;
  final Color accent;

  const ColorPreset({
    required this.name,
    required this.primary,
    required this.accent,
  });
}

// ─── Dashboard Theme Preset (full tema dengan bg & card) ─────────────────────
class DashboardThemePreset {
  final String id;
  final String name;
  final String emoji;
  final Color bg;
  final Color card;
  final Color cardAlt;
  final Color primary;
  final Color accent;

  const DashboardThemePreset({
    required this.id,
    required this.name,
    required this.emoji,
    required this.bg,
    required this.card,
    required this.cardAlt,
    required this.primary,
    required this.accent,
  });
}

// ─── ThemeProvider ────────────────────────────────────────────────────────────
class ThemeProvider extends ChangeNotifier {
  static const String _primaryColorKey    = 'primary_color';
  static const String _accentColorKey     = 'accent_color';
  static const String _isDarkModeKey      = 'is_dark_mode';
  static const String _dashThemeIdKey     = 'dashboard_theme_id';

  Color _primaryColor = Colors.purple;
  Color _accentColor  = Colors.purpleAccent;
  bool  _isDarkMode   = true;
  String _dashThemeId = 'default';

  ThemeProvider() {
    loadThemeFromPrefs();
  }

  Color get primaryColor  => _primaryColor;
  Color get accentColor   => _accentColor;
  bool  get isDarkMode    => _isDarkMode;
  String get dashThemeId  => _dashThemeId;

  // ─── Dashboard Theme Presets ──────────────────────────────────────────────
  static const List<DashboardThemePreset> dashboardThemes = [
    DashboardThemePreset(
      id:       'default',
      name:     'VOID BLUE',
      emoji:    '🔵',
      bg:       Color(0xFF060D18),
      card:     Color(0xFF0D1B2A),
      cardAlt:  Color(0xFF0A1520),
      primary:  Color(0xFF6366F1),
      accent:   Color(0xFFA78BFA),
    ),
    DashboardThemePreset(
      id:       'toxic',
      name:     'TOXIC GREEN',
      emoji:    '🟢',
      bg:       Color(0xFF030F08),
      card:     Color(0xFF071A0E),
      cardAlt:  Color(0xFF041209),
      primary:  Color(0xFF10B981),
      accent:   Color(0xFF34D399),
    ),
    DashboardThemePreset(
      id:       'cyber',
      name:     'CYBER GOLD',
      emoji:    '🟡',
      bg:       Color(0xFF0F0C00),
      card:     Color(0xFF1A1500),
      cardAlt:  Color(0xFF130F00),
      primary:  Color(0xFFEAB308),
      accent:   Color(0xFFFBBF24),
    ),
    DashboardThemePreset(
      id:       'abyss',
      name:     'ABYSS CYAN',
      emoji:    '🩵',
      bg:       Color(0xFF000F12),
      card:     Color(0xFF001A1F),
      cardAlt:  Color(0xFF001218),
      primary:  Color(0xFF06B6D4),
      accent:   Color(0xFF22D3EE),
    ),
  ];

  // ─── Get active dashboard theme ───────────────────────────────────────────
  DashboardThemePreset get activeDashTheme {
    return dashboardThemes.firstWhere(
      (t) => t.id == _dashThemeId,
      orElse: () => dashboardThemes.first,
    );
  }

  // ─── Derived bg/card (pake dashboard theme override jika aktif) ───────────
  Color get bgColor   => activeDashTheme.bg;
  Color get cardColor => activeDashTheme.card;
  Color get cardAltColor => activeDashTheme.cardAlt;

  // ─── Derived UI Colours ───────────────────────────────────────────────────
  Color get backgroundColor =>
      _isDarkMode ? const Color(0xFF0D0D0D) : const Color(0xFFF5F5F5);

  Color get textPrimaryColor =>
      _isDarkMode ? const Color(0xFFEEEEEE) : const Color(0xFF111111);

  Color get textSecondaryColor =>
      _isDarkMode ? const Color(0xFF888888) : const Color(0xFF666666);

  Color get glassPrimary =>
      _isDarkMode
          ? _primaryColor.withOpacity(0.10)
          : _primaryColor.withOpacity(0.08);

  Color get glassSecondary =>
      _isDarkMode
          ? const Color(0xFF1A1A1A)
          : const Color(0xFFE8E8E8);

  // ─── 20 Preset Warna ─────────────────────────────────────────────────────
  static const List<ColorPreset> colorPresets = [
    ColorPreset(name: 'Purple',      primary: Colors.purple,      accent: Colors.purpleAccent),
    ColorPreset(name: 'Deep Purple', primary: Colors.deepPurple,  accent: Colors.deepPurpleAccent),
    ColorPreset(name: 'Red',         primary: Colors.red,         accent: Colors.redAccent),
    ColorPreset(name: 'Pink',        primary: Colors.pink,        accent: Colors.pinkAccent),
    ColorPreset(name: 'Orange',      primary: Colors.orange,      accent: Colors.orangeAccent),
    ColorPreset(name: 'Deep Orange', primary: Colors.deepOrange,  accent: Colors.deepOrangeAccent),
    ColorPreset(name: 'Amber',       primary: Colors.amber,       accent: Colors.amberAccent),
    ColorPreset(name: 'Yellow',      primary: Colors.yellow,      accent: Colors.yellowAccent),
    ColorPreset(name: 'Green',       primary: Colors.green,       accent: Colors.greenAccent),
    ColorPreset(name: 'Light Green', primary: Colors.lightGreen,  accent: Colors.lightGreenAccent),
    ColorPreset(name: 'Teal',        primary: Colors.teal,        accent: Colors.tealAccent),
    ColorPreset(name: 'Cyan',        primary: Colors.cyan,        accent: Colors.cyanAccent),
    ColorPreset(name: 'Light Blue',  primary: Colors.lightBlue,   accent: Colors.lightBlueAccent),
    ColorPreset(name: 'Blue',        primary: Colors.blue,        accent: Colors.blueAccent),
    ColorPreset(name: 'Indigo',      primary: Colors.indigo,      accent: Colors.indigoAccent),
    ColorPreset(name: 'Brown',       primary: Colors.brown,       accent: Color(0xFFBCAAA4)),
    ColorPreset(name: 'Blue Grey',   primary: Colors.blueGrey,    accent: Color(0xFF90A4AE)),
    ColorPreset(name: 'Grey',        primary: Colors.grey,        accent: Color(0xFFEEEEEE)),
    ColorPreset(name: 'Black',       primary: Colors.black,       accent: Colors.white),
    ColorPreset(name: 'White',       primary: Colors.white,       accent: Colors.black),
  ];

  // ─── Load ─────────────────────────────────────────────────────────────────
  Future<void> loadThemeFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final primaryVal  = prefs.getInt(_primaryColorKey);
    final accentVal   = prefs.getInt(_accentColorKey);
    final darkModeVal = prefs.getBool(_isDarkModeKey);
    final dashTheme   = prefs.getString(_dashThemeIdKey);
    if (primaryVal  != null) _primaryColor = Color(primaryVal);
    if (accentVal   != null) _accentColor  = Color(accentVal);
    if (darkModeVal != null) _isDarkMode   = darkModeVal;
    if (dashTheme   != null) _dashThemeId  = dashTheme;
    notifyListeners();
  }

  // ─── Apply Dashboard Theme ────────────────────────────────────────────────
  Future<void> applyDashboardTheme(DashboardThemePreset theme) async {
    _dashThemeId  = theme.id;
    _primaryColor = theme.primary;
    _accentColor  = theme.accent;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_dashThemeIdKey,  theme.id);
    await prefs.setInt(_primaryColorKey,    theme.primary.value);
    await prefs.setInt(_accentColorKey,     theme.accent.value);
    notifyListeners();
  }

  // ─── Apply Color Preset ───────────────────────────────────────────────────
  Future<void> applyPreset(ColorPreset preset) async {
    _primaryColor = preset.primary;
    _accentColor  = preset.accent;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_primaryColorKey, preset.primary.value);
    await prefs.setInt(_accentColorKey,  preset.accent.value);
    notifyListeners();
  }

  // ─── Set Custom Primary ───────────────────────────────────────────────────
  Future<void> setPrimaryColor(Color color) async {
    _primaryColor = color;
    _accentColor  = _generateAccent(color);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_primaryColorKey, color.value);
    await prefs.setInt(_accentColorKey,  _accentColor.value);
    notifyListeners();
  }

  // ─── Set Custom Accent ────────────────────────────────────────────────────
  Future<void> setAccentColor(Color color) async {
    _accentColor = color;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_accentColorKey, color.value);
    notifyListeners();
  }

  // ─── Toggle Dark/Light ────────────────────────────────────────────────────
  Future<void> toggleDarkMode() async {
    _isDarkMode = !_isDarkMode;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_isDarkModeKey, _isDarkMode);
    notifyListeners();
  }

  // ─── Reset ke Default ─────────────────────────────────────────────────────
  Future<void> resetToDefault() async {
    _primaryColor = Colors.purple;
    _accentColor  = Colors.purpleAccent;
    _isDarkMode   = true;
    _dashThemeId  = 'default';
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_primaryColorKey,    Colors.purple.value);
    await prefs.setInt(_accentColorKey,     Colors.purpleAccent.value);
    await prefs.setBool(_isDarkModeKey,     true);
    await prefs.setString(_dashThemeIdKey,  'default');
    notifyListeners();
  }

  // ─── Helper ───────────────────────────────────────────────────────────────
  bool isActivePreset(ColorPreset preset) =>
      _primaryColor.value == preset.primary.value;

  bool isActiveDashTheme(DashboardThemePreset theme) =>
      _dashThemeId == theme.id;

  Color _generateAccent(Color color) {
    final hsl = HSLColor.fromColor(color);
    return hsl
        .withLightness((hsl.lightness + 0.15).clamp(0.0, 1.0))
        .withSaturation((hsl.saturation + 0.10).clamp(0.0, 1.0))
        .toColor();
  }
}
