import 'config_service.dart';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:google_fonts/google_fonts.dart';

class BugSenderPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const BugSenderPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<BugSenderPage> createState() => _BugSenderPageState();
}

class _BugSenderPageState extends State<BugSenderPage>
    with SingleTickerProviderStateMixin {
  List<dynamic> privateSenderList = [];
  bool isLoadingPrivate = false;
  String? errorPrivate;

  List<dynamic> globalSenderList = [];
  bool isLoadingGlobal = false;
  String? errorGlobal;

  late TabController _tabController;
  late VoidCallback _tabListener;
  Timer? _autoRefreshTimer;
  bool _isDeleting = false;
  bool _isRefreshing = false;

  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;

  bool get isVip => widget.role.toLowerCase() == 'vip';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: isVip ? 2 : 1, vsync: this);

    _tabListener = () => setState(() {});
    _tabController.addListener(_tabListener);

    _fetchPrivateSenders();
    if (isVip) _fetchGlobalSenders();
    _startAutoRefresh();
    _initAnimations();
  }

  void _initAnimations() {
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.05).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.3, end: 0.8).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
  }

  void _startAutoRefresh() {
    _autoRefreshTimer?.cancel();
    _autoRefreshTimer = Timer.periodic(const Duration(seconds: 10), (_) {
      if (_isDeleting || _isRefreshing) return;
      _fetchPrivateSenders();
      if (isVip) _fetchGlobalSenders();
    });
  }

  @override
  void dispose() {
    _autoRefreshTimer?.cancel();
    _tabController.removeListener(_tabListener);
    _tabController.dispose();
    _pulseController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  // ─── PROGRESS PENGECEKAN 20 DETIK (SETELAH KLIK SUDAH PAIRING) ────────────
  Future<void> _showCheckingProgress(String number) async {
    int remainingSeconds = 20;
    
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) {
          Timer.periodic(const Duration(seconds: 1), (timer) async {
            if (remainingSeconds <= 1) {
              timer.cancel();
              
              await _fetchPrivateSenders(showSuccessMessage: false);
              
              final isSuccess = privateSenderList.any((s) => 
                s['sessionName']?.toString().contains(number) == true ||
                s['id']?.toString().contains(number) == true
              );
              
              if (mounted && Navigator.of(context).canPop()) {
                Navigator.of(context).pop();
                
                if (isSuccess) {
                  _showPremiumSnackbar(
                    "✅ Sender berhasil ditambahkan! Sekarang bisa digunakan untuk mengirim bug.",
                    isError: false,
                  );
                } else {
                  _showPremiumSnackbar(
                    "⚠️ Sender belum muncul, coba refresh manual atau tunggu beberapa saat.",
                    isError: true,
                  );
                }
              }
            }
            remainingSeconds--;
            if (mounted) setDialogState(() {});
          });
          
          return PopScope(
            canPop: false,
            child: Dialog(
              backgroundColor: Colors.transparent,
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Theme.of(context).cardColor, Theme.of(context).primaryColor.withOpacity(0.2)],
                  ),
                  borderRadius: BorderRadius.circular(28),
                  border: Border.all(color: Colors.green.withOpacity(0.4), width: 2),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 80, height: 80,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(colors: [Colors.green, Colors.green.shade700]),
                      ),
                      child: const Icon(Icons.check_circle, color: Colors.white, size: 45),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      "MENUNGGU KONEKSI 🔄",
                      style: GoogleFonts.orbitron(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      "Sedang mengecek sender...",
                      style: GoogleFonts.outfit(color: Colors.white70, fontSize: 14),
                    ),
                    const SizedBox(height: 24),
                    LinearProgressIndicator(
                      value: (20 - remainingSeconds) / 20,
                      backgroundColor: Colors.white.withOpacity(0.1),
                      color: Colors.green,
                      borderRadius: BorderRadius.circular(10),
                      minHeight: 8,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      "Tunggu $remainingSeconds detik",
                      style: GoogleFonts.outfit(color: Colors.white54, fontSize: 12),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      "Jangan tutup aplikasi",
                      style: GoogleFonts.outfit(color: Colors.white24, fontSize: 10),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // ─── DIALOG PAIRING CODE (LANGSUNG MUNCUL, NO PROGRESS, 2 TOMBOL) ─────────
  void _showPairingCodeDialog(String number, String code) {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = theme.colorScheme.secondary;
    final bgColor = theme.scaffoldBackgroundColor;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: TweenAnimationBuilder(
          tween: Tween<double>(begin: 0, end: 1),
          duration: const Duration(milliseconds: 300),
          builder: (_, double value, __) => Transform.scale(
            scale: value,
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [bgColor, primaryColor.withOpacity(0.2)],
                ),
                borderRadius: BorderRadius.circular(28),
                border: Border.all(color: accentColor.withOpacity(0.4), width: 1.5),
                boxShadow: [BoxShadow(color: accentColor.withOpacity(0.3), blurRadius: 25, spreadRadius: 3)],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 70, height: 70,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(colors: [Colors.blue, Colors.blue.shade700]),
                    ),
                    child: const Icon(Icons.qr_code_scanner, color: Colors.white, size: 35),
                  ),
                  const SizedBox(height: 20),
                  Text("Masukkan Kode ke WhatsApp",
                      style: GoogleFonts.orbitron(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold, letterSpacing: 1)),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: accentColor, width: 2),
                      boxShadow: [BoxShadow(color: accentColor.withOpacity(0.4), blurRadius: 20, spreadRadius: 2)],
                    ),
                    child: Column(
                      children: [
                        Text("Number: $number", style: GoogleFonts.outfit(color: Colors.white70, fontSize: 13)),
                        const SizedBox(height: 16),
                        GestureDetector(
                          onTap: () async {
                            await Clipboard.setData(ClipboardData(text: code));
                            _showPremiumSnackbar("Code copied!", isError: false);
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                            decoration: BoxDecoration(
                              color: accentColor.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: accentColor.withOpacity(0.3)),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(code, style: GoogleFonts.shareTechMono(color: accentColor, fontSize: 28, fontWeight: FontWeight.bold, letterSpacing: 4)),
                                const SizedBox(width: 12),
                                Icon(Icons.copy, color: accentColor, size: 20),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.orange.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.orange.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.info_outline, color: Colors.orange, size: 16),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            "1. Buka WhatsApp\n2. Settings → Linked Devices → Link a Device\n3. Masukkan kode di atas\n\nSetelah selesai, klik SUDAH PAIRING",
                            style: GoogleFonts.outfit(color: Colors.white70, fontSize: 11),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                  Row(
                    children: [
                      // TOMBOL BATAL
                      Expanded(
                        child: GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: Center(
                              child: Text(
                                "BATAL",
                                style: GoogleFonts.outfit(color: Colors.white70, fontWeight: FontWeight.bold),
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      // TOMBOL SUDAH PAIRING
                      Expanded(
                        child: GestureDetector(
                          onTap: () async {
                            Navigator.pop(context);
                            await _showCheckingProgress(number);
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(colors: [Colors.green, Colors.green.shade700]),
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: Center(
                              child: Text(
                                "SUDAH PAIRING",
                                style: GoogleFonts.outfit(color: Colors.white, fontWeight: FontWeight.bold),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ─── MANUAL REFRESH WITH PROGRESS DIALOG ─────────────────────────────────
  Future<void> _manualRefreshWithProgress() async {
    if (_isRefreshing || _isDeleting) {
      _showPremiumSnackbar("Please wait, another process is running...", isError: true);
      return;
    }

    setState(() => _isRefreshing = true);

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => PopScope(
        canPop: false,
        child: Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(32),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: Theme.of(context).colorScheme.secondary.withOpacity(0.3)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(
                  width: 50,
                  height: 50,
                  child: CircularProgressIndicator(strokeWidth: 3),
                ),
                const SizedBox(height: 24),
                Text(
                  "Refreshing Senders...",
                  style: GoogleFonts.outfit(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  "Mohon tunggu hingga proses refresh selesai",
                  style: GoogleFonts.outfit(color: Colors.white54, fontSize: 12),
                ),
                const SizedBox(height: 8),
                Text(
                  "(max 30 detik)",
                  style: GoogleFonts.outfit(color: Colors.white38, fontSize: 10),
                ),
              ],
            ),
          ),
        ),
      ),
    );

    try {
      await Future.wait([
        _fetchPrivateSenders(showSuccessMessage: true),
        if (isVip) _fetchGlobalSenders(showSuccessMessage: true),
      ]).timeout(
        const Duration(seconds: 30),
        onTimeout: () {
          throw TimeoutException("Refresh timeout after 30 seconds");
        },
      );

      if (mounted) Navigator.of(context).pop();
      _showPremiumSnackbar(
        "✅ Refresh completed! ${privateSenderList.length} private senders${isVip ? " + ${globalSenderList.length} global senders" : ""}",
        isError: false,
      );
    } catch (e) {
      if (mounted) Navigator.of(context).pop();
      _showPremiumSnackbar("❌ Refresh failed: $e", isError: true);
    } finally {
      if (mounted) setState(() => _isRefreshing = false);
    }
  }

  // ─── PRIVATE SENDER ───────────────────────────────────────────────────────
  Future<void> _fetchPrivateSenders({bool showSuccessMessage = false}) async {
    if (_isDeleting) return;

    setState(() {
      isLoadingPrivate = true;
      errorPrivate = null;
    });

    try {
      final res = await http.get(
        Uri.parse("${ConfigService.baseUrl}/mySender?key=${widget.sessionKey}"),
        headers: {'Content-Type': 'application/json'},
      );

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data["valid"] == true) {
          final raw = List<Map<String, dynamic>>.from(data["connections"] ?? []);
          final seen = <String>{};
          final unique = raw.where((s) {
            final id = s['id']?.toString() ?? '';
            if (id.isEmpty) return true;
            return seen.add(id);
          }).toList();

          setState(() => privateSenderList = unique);

          if (showSuccessMessage) {
            _showPremiumSnackbar("✅ Private senders refreshed successfully!", isError: false);
          }
        } else {
          setState(() => errorPrivate = data["message"] ?? "Failed to fetch senders");
          if (showSuccessMessage) {
            _showPremiumSnackbar(errorPrivate ?? "Failed to refresh", isError: true);
          }
        }
      } else {
        setState(() => errorPrivate = "Server error: ${res.statusCode}");
        if (showSuccessMessage) {
          _showPremiumSnackbar("Server error: ${res.statusCode}", isError: true);
        }
      }
    } catch (e) {
      setState(() => errorPrivate = "Connection failed: $e");
      if (showSuccessMessage) {
        _showPremiumSnackbar("Connection failed: $e", isError: true);
      }
    } finally {
      if (mounted) setState(() => isLoadingPrivate = false);
    }
  }

  Future<void> _addPrivateSender(String number) async {
    setState(() => isLoadingPrivate = true);
    try {
      final res = await http.get(
        Uri.parse("${ConfigService.baseUrl}/getPairing?key=${widget.sessionKey}&number=$number"),
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data["valid"] == true) {
          final pairingCode = data['pairingCode'].toString();
          
          // ✅ LANGSUNG TAMPILKAN DIALOG PAIRING (TANPA TUNGGU)
          _showPairingCodeDialog(number, pairingCode);
          _showPremiumSnackbar("Pairing code generated!", isError: false);
          
        } else {
          _showPremiumSnackbar(data['message'] ?? "Failed to generate pairing code", isError: true);
        }
      } else {
        _showPremiumSnackbar("Server error: ${res.statusCode}", isError: true);
      }
    } catch (e) {
      _showPremiumSnackbar("Connection failed: $e", isError: true);
    } finally {
      setState(() => isLoadingPrivate = false);
    }
  }

  Future<void> _deletePrivateSender(String senderId) async {
    if (senderId.isEmpty) {
      _showPremiumSnackbar("Invalid sender ID", isError: true);
      return;
    }
    final confirmed = await _confirmDelete();
    if (confirmed != true) return;

    _isDeleting = true;
    _autoRefreshTimer?.cancel();

    setState(() {
      privateSenderList.removeWhere((s) => s['id']?.toString() == senderId);
      isLoadingPrivate = true;
    });

    try {
      final res = await http.delete(
        Uri.parse("${ConfigService.baseUrl}/deleteSender?key=${widget.sessionKey}&id=$senderId"),
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data["valid"] == true) {
          _showPremiumSnackbar("Sender deleted!", isError: false);
        } else {
          _showPremiumSnackbar(data["message"] ?? "Failed to delete", isError: true);
          await _fetchPrivateSenders();
        }
      } else {
        _showPremiumSnackbar("Server error: ${res.statusCode}", isError: true);
        await _fetchPrivateSenders();
      }
    } catch (e) {
      _showPremiumSnackbar("Connection failed: $e", isError: true);
      await _fetchPrivateSenders();
    } finally {
      setState(() => isLoadingPrivate = false);
      await Future.delayed(const Duration(seconds: 1));
      _isDeleting = false;
      _startAutoRefresh();
    }
  }

  // ─── GLOBAL SENDER ────────────────────────────────────────────────────────
  Future<void> _fetchGlobalSenders({bool showSuccessMessage = false}) async {
    if (_isDeleting) return;

    setState(() {
      isLoadingGlobal = true;
      errorGlobal = null;
    });

    try {
      final res = await http.get(
        Uri.parse("${ConfigService.baseUrl}/globalSender?key=${widget.sessionKey}"),
        headers: {'Content-Type': 'application/json'},
      );

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data["valid"] == true) {
          final raw = List<Map<String, dynamic>>.from(data["connections"] ?? []);
          final seen = <String>{};
          final unique = raw.where((s) {
            final id = s['id']?.toString() ?? '';
            if (id.isEmpty) return true;
            return seen.add(id);
          }).toList();

          setState(() => globalSenderList = unique);

          if (showSuccessMessage) {
            _showPremiumSnackbar("🌍 Global senders refreshed!", isError: false);
          }
        } else {
          setState(() => errorGlobal = data["message"] ?? "Failed to fetch global senders");
        }
      } else {
        setState(() => errorGlobal = "Server error: ${res.statusCode}");
      }
    } catch (e) {
      setState(() => errorGlobal = "Connection failed: $e");
    } finally {
      if (mounted) setState(() => isLoadingGlobal = false);
    }
  }

  Future<void> _deleteGlobalSender(String senderId) async {
    if (senderId.isEmpty) {
      _showPremiumSnackbar("Invalid sender ID", isError: true);
      return;
    }
    final confirmed = await _confirmDelete();
    if (confirmed != true) return;

    _isDeleting = true;
    _autoRefreshTimer?.cancel();

    setState(() {
      globalSenderList.removeWhere((s) => s['id']?.toString() == senderId);
      isLoadingGlobal = true;
    });

    try {
      final res = await http.delete(
        Uri.parse("${ConfigService.baseUrl}/deleteGlobalSender?key=${widget.sessionKey}&id=$senderId"),
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data["valid"] == true) {
          _showPremiumSnackbar("Global sender deleted!", isError: false);
        } else {
          _showPremiumSnackbar(data["message"] ?? "Failed to delete", isError: true);
          await _fetchGlobalSenders();
        }
      } else {
        _showPremiumSnackbar("Server error: ${res.statusCode}", isError: true);
        await _fetchGlobalSenders();
      }
    } catch (e) {
      _showPremiumSnackbar("Connection failed: $e", isError: true);
      await _fetchGlobalSenders();
    } finally {
      setState(() => isLoadingGlobal = false);
      await Future.delayed(const Duration(seconds: 1));
      _isDeleting = false;
      _startAutoRefresh();
    }
  }

  // ─── DIALOG ADD PRIVATE SENDER ───────────────────────────────────────────
  void _showAddPrivateSenderDialog() {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = theme.colorScheme.secondary;
    final bgColor = theme.scaffoldBackgroundColor;
    final phoneController = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: TweenAnimationBuilder(
          tween: Tween<double>(begin: 0, end: 1),
          duration: const Duration(milliseconds: 300),
          builder: (_, double value, __) => Transform.scale(
            scale: value,
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [bgColor, primaryColor.withOpacity(0.2)],
                ),
                borderRadius: BorderRadius.circular(28),
                border: Border.all(color: accentColor.withOpacity(0.3), width: 1.5),
                boxShadow: [BoxShadow(color: accentColor.withOpacity(0.2), blurRadius: 20, spreadRadius: 2)],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AnimatedBuilder(
                    animation: _pulseController,
                    builder: (_, __) => Transform.scale(
                      scale: _pulseAnimation.value,
                      child: Container(
                        width: 70,
                        height: 70,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(colors: [primaryColor, accentColor]),
                          boxShadow: [BoxShadow(color: accentColor.withOpacity(0.4), blurRadius: 15)],
                        ),
                        child: const Icon(Icons.phone_android, color: Colors.white, size: 32),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text("Add Private Sender",
                      style: GoogleFonts.orbitron(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold, letterSpacing: 1)),
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: accentColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: accentColor.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.info_outline, color: accentColor, size: 18),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            "Tambahkan nomor WA kamu sebagai sender pribadi untuk mengirim bug.",
                            style: GoogleFonts.outfit(color: Colors.white70, fontSize: 12),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  TextField(
                    controller: phoneController,
                    keyboardType: TextInputType.phone,
                    style: GoogleFonts.outfit(color: Colors.white),
                    decoration: InputDecoration(
                      labelText: "Phone Number",
                      labelStyle: GoogleFonts.outfit(color: accentColor),
                      hintText: "628xxxxxxxxx",
                      hintStyle: GoogleFonts.outfit(color: Colors.white38),
                      prefixIcon: Icon(Icons.phone, color: accentColor),
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.05),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: accentColor, width: 1.5)),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                    ),
                  ),
                  const SizedBox(height: 24),
                  Row(
                    children: [
                      Expanded(
                        child: GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            decoration: BoxDecoration(color: Colors.white.withOpacity(0.1), borderRadius: BorderRadius.circular(16)),
                            child: Center(child: Text("CANCEL", style: GoogleFonts.outfit(color: Colors.white70, fontWeight: FontWeight.bold))),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: GestureDetector(
                          onTap: () async {
                            final number = phoneController.text.trim();
                            if (number.isEmpty) {
                              _showPremiumSnackbar("Please enter phone number", isError: true);
                              return;
                            }
                            Navigator.pop(context);
                            await _addPrivateSender(number);
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(colors: [primaryColor, accentColor]),
                              borderRadius: BorderRadius.circular(16),
                              boxShadow: [BoxShadow(color: primaryColor.withOpacity(0.4), blurRadius: 12)],
                            ),
                            child: Center(child: Text("ADD SENDER", style: GoogleFonts.outfit(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1))),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<bool?> _confirmDelete() {
    final theme = Theme.of(context);
    final bgColor = theme.scaffoldBackgroundColor;

    return showDialog<bool>(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [bgColor, theme.cardColor],
            ),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: Colors.redAccent.withOpacity(0.3), width: 1.5),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 70, height: 70,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.redAccent.withOpacity(0.1),
                  border: Border.all(color: Colors.redAccent, width: 2),
                ),
                child: const Icon(Icons.warning_amber_rounded, color: Colors.redAccent, size: 35),
              ),
              const SizedBox(height: 20),
              Text("Confirm Delete", style: GoogleFonts.orbitron(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Text(
                "Yakin ingin hapus sender ini? Tindakan ini tidak bisa dibatalkan.",
                textAlign: TextAlign.center,
                style: GoogleFonts.outfit(color: Colors.white70, fontSize: 14),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () => Navigator.pop(context, false),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(color: Colors.white.withOpacity(0.1), borderRadius: BorderRadius.circular(16)),
                        child: Center(child: Text("CANCEL", style: GoogleFonts.outfit(color: Colors.white70, fontWeight: FontWeight.bold))),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: GestureDetector(
                      onTap: () => Navigator.pop(context, true),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(colors: [Colors.redAccent, Colors.red]),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Center(child: Text("DELETE", style: GoogleFonts.outfit(color: Colors.white, fontWeight: FontWeight.bold))),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showPremiumSnackbar(String message, {bool isError = false}) {
    final accentColor = Theme.of(context).colorScheme.secondary;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(isError ? Icons.error_outline : Icons.check_circle, color: Colors.white, size: 20),
            const SizedBox(width: 12),
            Expanded(child: Text(message, style: GoogleFonts.outfit(color: Colors.white, fontWeight: FontWeight.w600))),
          ],
        ),
        backgroundColor: isError ? Colors.redAccent : accentColor,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 4),
      ),
    );
  }

  // ─── CARDS ────────────────────────────────────────────────────────────────
  Widget _buildPrivateSenderCard(Map<String, dynamic> sender) {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = theme.colorScheme.secondary;
    final name = sender['sessionName'] ?? 'WhatsApp Sender';
    final senderId = sender['id']?.toString() ?? '';

    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [theme.cardColor.withOpacity(0.4), theme.cardColor.withOpacity(0.2)],
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: accentColor.withOpacity(0.2), width: 1),
        boxShadow: [BoxShadow(color: primaryColor.withOpacity(0.08), blurRadius: 15, offset: const Offset(0, 5))],
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                AnimatedBuilder(
                  animation: _glowController,
                  builder: (_, __) => Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [
                        accentColor.withOpacity(0.2 + _glowAnimation.value * 0.1),
                        accentColor.withOpacity(0.1),
                      ]),
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: accentColor.withOpacity(_glowAnimation.value), blurRadius: 12)],
                    ),
                    child: Icon(Icons.phone_android, color: accentColor, size: 24),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(name, style: GoogleFonts.outfit(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      Text("Private Sender • Active", style: GoogleFonts.outfit(color: accentColor.withOpacity(0.7), fontSize: 11)),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [Colors.green, Colors.green.shade700]),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [BoxShadow(color: Colors.green.withOpacity(0.3), blurRadius: 8)],
                  ),
                  child: const Text("CONNECTED", style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1)),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: _isRefreshing ? null : _manualRefreshWithProgress,
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.05),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: Colors.white.withOpacity(0.1)),
                      ),
                      child: Center(
                        child: _isRefreshing
                            ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                            : Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                                const Icon(Icons.refresh, size: 16, color: Colors.white70),
                                const SizedBox(width: 8),
                                Text("REFRESH", style: GoogleFonts.outfit(color: Colors.white70, fontSize: 13, fontWeight: FontWeight.w500)),
                              ]),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: GestureDetector(
                    onTap: () {
                      if (senderId.isEmpty) { _showPremiumSnackbar("Invalid sender ID", isError: true); return; }
                      _deletePrivateSender(senderId);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [Colors.redAccent.withOpacity(0.2), Colors.red.withOpacity(0.1)]),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: Colors.redAccent.withOpacity(0.4)),
                      ),
                      child: Center(
                        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          const Icon(Icons.delete_outline, size: 16, color: Colors.redAccent),
                          const SizedBox(width: 8),
                          Text("DELETE", style: GoogleFonts.outfit(color: Colors.redAccent, fontSize: 13, fontWeight: FontWeight.w500)),
                        ]),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGlobalSenderCard(Map<String, dynamic> sender) {
    final theme = Theme.of(context);
    final name = sender['sessionName'] ?? 'Global Sender';
    final senderId = sender['id']?.toString() ?? '';
    final senderType = sender['type'] ?? 'Unknown';

    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [theme.cardColor.withOpacity(0.4), theme.cardColor.withOpacity(0.2)],
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.amber.withOpacity(0.3), width: 1),
        boxShadow: [BoxShadow(color: Colors.amber.withOpacity(0.08), blurRadius: 15, offset: const Offset(0, 5))],
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: Colors.amber.withOpacity(0.15), shape: BoxShape.circle),
                  child: const Icon(Icons.public, color: Colors.amber, size: 24),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(name, style: GoogleFonts.outfit(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      Row(children: [
                        Icon(Icons.smart_toy_outlined, color: Colors.amber.withOpacity(0.7), size: 12),
                        const SizedBox(width: 4),
                        Text("Bot Managed • $senderType", style: GoogleFonts.outfit(color: Colors.amber.withOpacity(0.7), fontSize: 11)),
                      ]),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [Colors.green, Colors.green.shade700]),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Text("ACTIVE", style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1)),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: _isRefreshing ? null : _manualRefreshWithProgress,
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.05),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: Colors.white.withOpacity(0.1)),
                      ),
                      child: Center(
                        child: _isRefreshing
                            ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                            : Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                                const Icon(Icons.refresh, size: 16, color: Colors.white70),
                                const SizedBox(width: 8),
                                Text("REFRESH", style: GoogleFonts.outfit(color: Colors.white70, fontSize: 13, fontWeight: FontWeight.w500)),
                              ]),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: GestureDetector(
                    onTap: () {
                      if (senderId.isEmpty) { _showPremiumSnackbar("Invalid sender ID", isError: true); return; }
                      _deleteGlobalSender(senderId);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [Colors.redAccent.withOpacity(0.2), Colors.red.withOpacity(0.1)]),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: Colors.redAccent.withOpacity(0.4)),
                      ),
                      child: Center(
                        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          const Icon(Icons.delete_outline, size: 16, color: Colors.redAccent),
                          const SizedBox(width: 8),
                          Text("DELETE", style: GoogleFonts.outfit(color: Colors.redAccent, fontSize: 13, fontWeight: FontWeight.w500)),
                        ]),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ─── EMPTY / ERROR STATES ─────────────────────────────────────────────────
  Widget _buildPrivateEmptyState() {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = theme.colorScheme.secondary;

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedBuilder(
              animation: _pulseController,
              builder: (_, __) => Transform.scale(
                scale: _pulseAnimation.value,
                child: Container(
                  width: 100, height: 100,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(colors: [accentColor.withOpacity(0.2), primaryColor.withOpacity(0.1)]),
                    border: Border.all(color: accentColor.withOpacity(0.3), width: 2),
                  ),
                  child: Icon(Icons.phone_iphone, color: accentColor, size: 50),
                ),
              ),
            ),
            const SizedBox(height: 24),
            Text("No Private Senders", style: GoogleFonts.orbitron(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Text("Tambahkan nomor WA kamu sebagai sender pribadi.",
                style: GoogleFonts.outfit(color: Colors.white54, fontSize: 14), textAlign: TextAlign.center),
            const SizedBox(height: 40),
            GestureDetector(
              onTap: _showAddPrivateSenderDialog,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [primaryColor, accentColor]),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [BoxShadow(color: primaryColor.withOpacity(0.4), blurRadius: 15)],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.add, color: Colors.white),
                    const SizedBox(width: 8),
                    Text("ADD SENDER", style: GoogleFonts.outfit(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 1)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGlobalEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 100, height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.amber.withOpacity(0.1),
                border: Border.all(color: Colors.amber.withOpacity(0.3), width: 2),
              ),
              child: const Icon(Icons.public_off, color: Colors.amber, size: 50),
            ),
            const SizedBox(height: 24),
            Text("No Global Senders", style: GoogleFonts.orbitron(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Text("Pool Global belum ada nomor aktif.\nNomor dikelola otomatis oleh bot.",
                style: GoogleFonts.outfit(color: Colors.white54, fontSize: 14), textAlign: TextAlign.center),
            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              decoration: BoxDecoration(
                color: Colors.amber.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.amber.withOpacity(0.3)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.smart_toy_outlined, color: Colors.amber, size: 18),
                  const SizedBox(width: 8),
                  Text("Tambah nomor melalui bot", style: GoogleFonts.outfit(color: Colors.amber, fontSize: 13)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorState({required bool isGlobal, required VoidCallback onRetry}) {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = theme.colorScheme.secondary;
    final error = isGlobal ? errorGlobal : errorPrivate;

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, color: Colors.redAccent, size: 80),
            const SizedBox(height: 24),
            Text("Failed to Load", style: GoogleFonts.orbitron(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Text(error ?? "Unknown error",
                style: GoogleFonts.outfit(color: Colors.white54, fontSize: 14), textAlign: TextAlign.center),
            const SizedBox(height: 40),
            GestureDetector(
              onTap: onRetry,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [primaryColor, accentColor]),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [BoxShadow(color: primaryColor.withOpacity(0.4), blurRadius: 15)],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.refresh, color: Colors.white),
                    const SizedBox(width: 8),
                    Text("TRY AGAIN", style: GoogleFonts.outfit(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 1)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── TAB VIEWS ────────────────────────────────────────────────────────────
  Widget _buildPrivateTab() {
    final accentColor = Theme.of(context).colorScheme.secondary;
    if (isLoadingPrivate && privateSenderList.isEmpty) {
      return Center(child: CircularProgressIndicator(color: accentColor, strokeWidth: 3));
    }
    if (errorPrivate != null && privateSenderList.isEmpty) {
      return _buildErrorState(isGlobal: false, onRetry: () => _fetchPrivateSenders(showSuccessMessage: true));
    }
    if (privateSenderList.isEmpty) return _buildPrivateEmptyState();

    return RefreshIndicator(
      color: accentColor,
      backgroundColor: Theme.of(context).cardColor,
      onRefresh: () => _fetchPrivateSenders(showSuccessMessage: true),
      child: ListView.builder(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.only(top: 8, bottom: 20),
        itemCount: privateSenderList.length,
        itemBuilder: (context, i) =>
            _buildPrivateSenderCard(Map<String, dynamic>.from(privateSenderList[i])),
      ),
    );
  }

  Widget _buildGlobalTab() {
    if (isLoadingGlobal && globalSenderList.isEmpty) {
      return const Center(child: CircularProgressIndicator(color: Colors.amber));
    }
    if (errorGlobal != null && globalSenderList.isEmpty) {
      return _buildErrorState(isGlobal: true, onRetry: () => _fetchGlobalSenders(showSuccessMessage: true));
    }
    if (globalSenderList.isEmpty) return _buildGlobalEmptyState();

    return RefreshIndicator(
      color: Colors.amber,
      backgroundColor: Theme.of(context).cardColor,
      onRefresh: () => _fetchGlobalSenders(showSuccessMessage: true),
      child: ListView.builder(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.only(top: 8, bottom: 20),
        itemCount: globalSenderList.length,
        itemBuilder: (context, i) =>
            _buildGlobalSenderCard(Map<String, dynamic>.from(globalSenderList[i])),
      ),
    );
  }

  // ─── BUILD ────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = theme.colorScheme.secondary;
    final bgColor = theme.scaffoldBackgroundColor;

    return Scaffold(
      backgroundColor: bgColor,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 100,
            floating: true,
            pinned: true,
            backgroundColor: Colors.transparent,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [primaryColor.withOpacity(0.3), bgColor],
                  ),
                ),
              ),
              title: Text("", style: GoogleFonts.orbitron(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1)),
              centerTitle: true,
            ),
            leading: Container(
              margin: const EdgeInsets.only(left: 12),
              decoration: BoxDecoration(color: Colors.white.withOpacity(0.1), shape: BoxShape.circle),
              child: IconButton(
                icon: Icon(Icons.arrow_back_ios_new, color: accentColor),
                onPressed: () => Navigator.pop(context),
              ),
            ),
            actions: [
              Container(
                margin: const EdgeInsets.only(right: 12),
                decoration: BoxDecoration(color: Colors.white.withOpacity(0.1), shape: BoxShape.circle),
                child: IconButton(
                  icon: _isRefreshing
                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : Icon(Icons.refresh, color: accentColor),
                  onPressed: (_isRefreshing || _isDeleting) ? null : _manualRefreshWithProgress,
                ),
              ),
            ],
            bottom: isVip
                ? PreferredSize(
                    preferredSize: const Size.fromHeight(56),
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.05),
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(color: Colors.white.withOpacity(0.1)),
                      ),
                      child: TabBar(
                        controller: _tabController,
                        indicator: BoxDecoration(
                          gradient: LinearGradient(colors: [primaryColor, accentColor]),
                          borderRadius: BorderRadius.circular(30),
                        ),
                        indicatorSize: TabBarIndicatorSize.tab,
                        dividerColor: Colors.transparent,
                        labelColor: Colors.white,
                        unselectedLabelColor: Colors.white54,
                        labelStyle: GoogleFonts.outfit(fontWeight: FontWeight.bold, fontSize: 13),
                        tabs: const [
                          Tab(
                            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                              Icon(Icons.phone_android, size: 16),
                              SizedBox(width: 6),
                              Text("PRIVATE"),
                            ]),
                          ),
                          Tab(
                            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                              Icon(Icons.public, size: 16),
                              SizedBox(width: 6),
                              Text("GLOBAL"),
                            ]),
                          ),
                        ],
                      ),
                    ),
                  )
                : null,
          ),
          SliverFillRemaining(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [bgColor, primaryColor.withOpacity(0.1), bgColor],
                ),
              ),
              child: isVip
                  ? TabBarView(
                      controller: _tabController,
                      children: [_buildPrivateTab(), _buildGlobalTab()],
                    )
                  : _buildPrivateTab(),
            ),
          ),
        ],
      ),
      floatingActionButton: isVip && _tabController.index == 0
          ? AnimatedBuilder(
              animation: _pulseController,
              builder: (_, __) => Transform.scale(
                scale: _pulseAnimation.value,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: [primaryColor, accentColor]),
                    shape: BoxShape.circle,
                    boxShadow: [BoxShadow(color: primaryColor.withOpacity(0.4), blurRadius: 20, spreadRadius: 2)],
                  ),
                  child: FloatingActionButton(
                    onPressed: _showAddPrivateSenderDialog,
                    backgroundColor: Colors.transparent,
                    child: const Icon(Icons.add, color: Colors.white),
                  ),
                ),
              ),
            )
          : null,
    );
  }
}