import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Global singleton  hidup selama app berjalan, tidak ikut dispose halaman
class MusicService extends ChangeNotifier {
  static final MusicService _instance = MusicService._internal();
  factory MusicService() => _instance;
  MusicService._internal();

  YoutubePlayerController? _controller;
  Map<String, dynamic>? _currentTrack;
  bool _isPlaying = false;
  List<Map<String, dynamic>> _favorites = [];

  YoutubePlayerController? get controller => _controller;
  Map<String, dynamic>? get currentTrack => _currentTrack;
  bool get isPlaying => _isPlaying;
  List<Map<String, dynamic>> get favorites => _favorites;
  bool get hasTrack => _currentTrack != null;

  void play(Map<String, dynamic> track) {
    final videoId = track['videoId'] as String;

    if (_controller != null && _currentTrack?['videoId'] == videoId) {
      // Resume same track
      _controller!.play();
      _isPlaying = true;
      notifyListeners();
      return;
    }

    // Dispose old controller
    _controller?.dispose();

    _currentTrack = track;
    _isPlaying = true;
    _controller = YoutubePlayerController(
      initialVideoId: videoId,
      flags: const YoutubePlayerFlags(autoPlay: true, mute: false, forceHD: false),
    )..addListener(_onControllerUpdate);

    notifyListeners();
  }

  void _onControllerUpdate() {
    final playing = _controller?.value.isPlaying ?? false;
    if (playing != _isPlaying) {
      _isPlaying = playing;
      notifyListeners();
    }
  }

  void pause() {
    _controller?.pause();
    _isPlaying = false;
    notifyListeners();
  }

  void resume() {
    _controller?.play();
    _isPlaying = true;
    notifyListeners();
  }

  void stop() {
    _controller?.dispose();
    _controller = null;
    _currentTrack = null;
    _isPlaying = false;
    notifyListeners();
  }

  //  FAVORITES 
  Future<void> loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList('music_favorites') ?? [];
    _favorites = raw.map((e) => Map<String, dynamic>.from(jsonDecode(e))).toList();
    notifyListeners();
  }

  Future<void> saveFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('music_favorites', _favorites.map((e) => jsonEncode(e)).toList());
  }

  bool isFavorite(String videoId) => _favorites.any((f) => f['videoId'] == videoId);

  void toggleFavorite(Map<String, dynamic> item) {
    if (isFavorite(item['videoId'])) {
      _favorites.removeWhere((f) => f['videoId'] == item['videoId']);
    } else {
      _favorites.add(item);
    }
    saveFavorites();
    notifyListeners();
  }
}
