import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'asset_service.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz_data;

// ══════════════════════════════════════════════
// MODEL WAKTU SHALAT
// ══════════════════════════════════════════════
class PrayerTimes {
  final String fajr;
  final String dhuhr;
  final String asr;
  final String maghrib;
  final String isha;
  final String city;
  final String country;
  final DateTime date;

  PrayerTimes({
    required this.fajr,
    required this.dhuhr,
    required this.asr,
    required this.maghrib,
    required this.isha,
    required this.city,
    required this.country,
    required this.date,
  });

  Map<String, String> get all => {
    'Subuh': fajr,
    'Dzuhur': dhuhr,
    'Ashar': asr,
    'Maghrib': maghrib,
    'Isya': isha,
  };

  factory PrayerTimes.fromJson(Map<String, dynamic> json) {
    final timings = json['data']['timings'];
    final metaInfo = json['data']['meta'];
    return PrayerTimes(
      fajr: _stripTimezone(timings['Fajr']),
      dhuhr: _stripTimezone(timings['Dhuhr']),
      asr: _stripTimezone(timings['Asr']),
      maghrib: _stripTimezone(timings['Maghrib']),
      isha: _stripTimezone(timings['Isha']),
      city: metaInfo['timezone'] ?? '',
      country: '',
      date: DateTime.now(),
    );
  }

  static String _stripTimezone(String time) => time.split(' ')[0];
}

// ══════════════════════════════════════════════
// ADZAN SERVICE
// ══════════════════════════════════════════════
class AdzanService {
  static final AdzanService _instance = AdzanService._internal();
  factory AdzanService() => _instance;
  AdzanService._internal();

  final FlutterLocalNotificationsPlugin _notif = FlutterLocalNotificationsPlugin();
  final AudioPlayer _audioPlayer = AudioPlayer();
  Timer? _checkTimer;
  PrayerTimes? _todayPrayers;
  bool _isInitialized = false;
  bool _isEnabled = true;
  Set<String> _notifiedToday = {};

  // ── Init ──────────────────────────────────────
  Future<void> init() async {
    if (_isInitialized) return;

    tz_data.initializeTimeZones();

    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );
    const initSettings = InitializationSettings(android: androidSettings, iOS: iosSettings);

    await _notif.initialize(
      initSettings,
      onDidReceiveNotificationResponse: (details) {
        // Handle tap action "stop_adzan"
        if (details.actionId == 'stop_adzan') {
          stopAdzan();
        }
      },
    );

    await _createNotifChannel();
    await _loadPrefs();
    _isInitialized = true;

    await fetchAndSchedule();
    _startDailyCheck();
  }

  Future<void> _createNotifChannel() async {
    const channel = AndroidNotificationChannel(
      'adzan_channel_v2',
      'Waktu Shalat',
      description: 'Notifikasi pengingat waktu shalat',
      importance: Importance.high,
      enableVibration: true,
      playSound: true,
      sound: RawResourceAndroidNotificationSound('adzan'),
    );
    await _notif
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);
  }

  Future<void> _loadPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    _isEnabled = prefs.getBool('adzan_enabled') ?? true;
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final saved = prefs.getStringList('adzan_notified_$today') ?? [];
    _notifiedToday = Set.from(saved);
  }

  Future<void> _saveNotified(String name) async {
    _notifiedToday.add(name);
    final prefs = await SharedPreferences.getInstance();
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
    await prefs.setStringList('adzan_notified_$today', _notifiedToday.toList());
  }

  // ── Fetch & Schedule ──────────────────────────
  Future<PrayerTimes?> fetchAndSchedule() async {
    try {
      final pos = await _getLocation();
      if (pos == null) return null;
      final prayers = await _fetchPrayerTimes(pos.latitude, pos.longitude);
      if (prayers != null) {
        _todayPrayers = prayers;
        final prefs = await SharedPreferences.getInstance();
        final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
        final lastDay = prefs.getString('adzan_last_day') ?? '';
        if (lastDay != today) {
          _notifiedToday.clear();
          await prefs.setString('adzan_last_day', today);
        }
        await _scheduleAllPrayerAlarms(prayers);
      }
      return prayers;
    } catch (e) {
      debugPrint('[Adzan] fetchAndSchedule error: $e');
      return null;
    }
  }

  Future<void> _scheduleAllPrayerAlarms(PrayerTimes prayers) async {
    if (!_isEnabled) return;

    await _notif.cancelAll();

    final now = DateTime.now();
    int id = 100;

    for (final entry in prayers.all.entries) {
      final parts = entry.value.split(':');
      if (parts.length < 2) { id++; continue; }

      final prayerTime = DateTime(
        now.year, now.month, now.day,
        int.parse(parts[0]), int.parse(parts[1]),
      );

      if (prayerTime.isBefore(now)) { id++; continue; }

      final tzTime = tz.TZDateTime.from(prayerTime, tz.local);
      final emoji = _getEmoji(entry.key);

      const androidDetails = AndroidNotificationDetails(
        'adzan_channel_v2',
        'Waktu Shalat',
        channelDescription: 'Notifikasi pengingat waktu shalat',
        importance: Importance.max,
        priority: Priority.max,
        playSound: true,
        sound: RawResourceAndroidNotificationSound('adzan'),
        enableVibration: true,
        fullScreenIntent: true,
        color: Color(0xFFDC143C),
        icon: '@mipmap/ic_launcher',
        ongoing: false,
      );
      const iosDetails = DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
        sound: 'adzan.mp3',
      );
      const details = NotificationDetails(android: androidDetails, iOS: iosDetails);

      try {
        await _notif.zonedSchedule(
          id,
          '$emoji Waktu ${entry.key}',
          '🕌 Sudah masuk waktu ${entry.key} - ${entry.value}\nMari kita tunaikan shalat',
          tzTime,
          details,
          androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
          uiLocalNotificationDateInterpretation:
              UILocalNotificationDateInterpretation.absoluteTime,
        );
        debugPrint('[Adzan] Dijadwalkan: ${entry.key} jam ${entry.value} (id=$id)');
      } catch (e) {
        debugPrint('[Adzan] Gagal jadwalkan ${entry.key}: $e');
      }
      id++;
    }
  }

  Future<Position?> _getLocation() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) return null;

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) return null;
      }
      if (permission == LocationPermission.deniedForever) return null;

      return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
        timeLimit: const Duration(seconds: 10),
      );
    } catch (e) {
      debugPrint('[Adzan] GPS error: $e');
      return null;
    }
  }

  Future<PrayerTimes?> _fetchPrayerTimes(double lat, double lng) async {
    try {
      final today = DateFormat('dd-MM-yyyy').format(DateTime.now());
      final url =
          'https://api.aladhan.com/v1/timings/$today?latitude=$lat&longitude=$lng&method=11';
      final res = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final json = jsonDecode(res.body);
        if (json['code'] == 200) return PrayerTimes.fromJson(json);
      }
    } catch (e) {
      debugPrint('[Adzan] API error: $e');
    }
    return null;
  }

  // ── Timer cek tiap menit ──────────────────────
  void _startDailyCheck() {
    _checkTimer?.cancel();
    _checkTimer = Timer.periodic(const Duration(minutes: 1), (_) => _checkPrayerTime());
  }

  void _checkPrayerTime() {
    if (!_isEnabled || _todayPrayers == null) return;

    final now = DateTime.now();
    final nowStr = DateFormat('HH:mm').format(now);

    if (nowStr == '00:01') {
      _notifiedToday.clear();
      fetchAndSchedule();
      return;
    }

    _todayPrayers!.all.forEach((name, time) {
      if (time == nowStr && !_notifiedToday.contains(name)) {
        _sendNotif(name, time);
        _saveNotified(name);
      }
    });
  }

  // ── Play adzan SEKALI (tidak loop) ────────────
  Future<void> _sendNotif(String prayerName, String time) async {
    final emoji = _getEmoji(prayerName);

    try {
      await _audioPlayer.stop();
      await _audioPlayer.setVolume(1.0);
      // ✅ SEKALI PLAY - tidak loop
      await _audioPlayer.setReleaseMode(ReleaseMode.release);
      await _audioPlayer.play(DeviceFileSource(AssetService.audioPathSync('fajr_128_44.mp3')));

      // Auto cancel notif ongoing setelah audio selesai
      _audioPlayer.onPlayerComplete.listen((_) async {
        await _notif.cancel(999);
        debugPrint('[Adzan] Audio selesai, notif ongoing dihapus');
      });

      debugPrint('[Adzan] Audio adzan diputar (sekali)');
    } catch (e) {
      debugPrint('[Adzan] Gagal putar audio: $e');
    }

    await _showOngoingAdzanNotif(prayerName);

    const androidDetails = AndroidNotificationDetails(
      'adzan_channel_v2',
      'Waktu Shalat',
      channelDescription: 'Notifikasi pengingat waktu shalat',
      importance: Importance.max,
      priority: Priority.max,
      playSound: false, // sudah diputar via audioplayers
      enableVibration: true,
      styleInformation: BigTextStyleInformation(''),
      color: Color(0xFFDC143C),
      icon: '@mipmap/ic_launcher',
      ongoing: false,
      fullScreenIntent: true,
    );
    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
      sound: 'adzan.mp3',
    );
    const details = NotificationDetails(android: androidDetails, iOS: iosDetails);

    await _notif.show(
      prayerName.hashCode,
      '$emoji Waktu $prayerName',
      '🕌 Sudah masuk waktu $prayerName - $time\nMari kita tunaikan shalat',
      details,
    );
    debugPrint('[Adzan] Notif sent: $prayerName at $time');
  }

  Future<void> _showOngoingAdzanNotif(String prayerName) async {
    final emoji = _getEmoji(prayerName);
    const androidDetails = AndroidNotificationDetails(
      'adzan_channel_v2',
      'Waktu Shalat',
      channelDescription: 'Notifikasi otomatis waktu shalat dengan audio adzan',
      importance: Importance.max,
      priority: Priority.max,
      ongoing: true,
      autoCancel: false,
      playSound: false,
      enableVibration: false,
      color: Color(0xFFDC143C),
      icon: '@mipmap/ic_launcher',
      fullScreenIntent: true,
      actions: [
        AndroidNotificationAction('stop_adzan', '⏹ Stop Adzan', showsUserInterface: true),
      ],
    );
    const details = NotificationDetails(android: androidDetails);
    await _notif.show(
      999,
      '$emoji Waktu $prayerName',
      '🕌 Adzan sedang diputar... Tap untuk stop',
      details,
    );
  }

  // ── Test adzan manual ─────────────────────────
  Future<void> testAdzan() async {
    try {
      await _audioPlayer.stop();
      await _audioPlayer.setVolume(1.0);
      // ✅ SEKALI PLAY
      await _audioPlayer.setReleaseMode(ReleaseMode.release);
      await _audioPlayer.play(DeviceFileSource(AssetService.audioPathSync('fajr_128_44.mp3')));

      _audioPlayer.onPlayerComplete.listen((_) async {
        await _notif.cancel(999);
        await _notif.cancel(998);
      });

      debugPrint('[Adzan] TEST audio diputar (sekali)');
    } catch (e) {
      debugPrint('[Adzan] TEST gagal putar audio: $e');
    }

    const androidDetails = AndroidNotificationDetails(
      'adzan_channel_v2',
      'Waktu Shalat',
      channelDescription: 'Notifikasi otomatis waktu shalat dengan audio adzan',
      importance: Importance.max,
      priority: Priority.max,
      playSound: false,
      enableVibration: true,
      ongoing: true,
      autoCancel: false,
      color: Color(0xFFDC143C),
      icon: '@mipmap/ic_launcher',
      fullScreenIntent: true,
      actions: [
        AndroidNotificationAction('stop_adzan', '⏹ Stop Adzan', showsUserInterface: true),
      ],
    );
    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
      sound: 'adzan.mp3',
    );
    const details = NotificationDetails(android: androidDetails, iOS: iosDetails);
    await _notif.show(
      998,
      '🔔 TEST Waktu Shalat',
      '🕌 Ini adalah test notifikasi adzan — kalau bunyi berarti beres!',
      details,
    );
    debugPrint('[Adzan] TEST notif dikirim');
  }

  // ── Stop adzan manual ─────────────────────────
  Future<void> stopAdzan() async {
    try {
      await _audioPlayer.stop();
    } catch (_) {}
    await _notif.cancel(999);
    await _notif.cancel(998);
    debugPrint('[Adzan] Audio dihentikan manual');
  }

  // ── Toggle on/off ─────────────────────────────
  Future<void> setEnabled(bool value) async {
    _isEnabled = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('adzan_enabled', value);
    if (value) {
      if (_todayPrayers == null) {
        await fetchAndSchedule();
      } else {
        await _scheduleAllPrayerAlarms(_todayPrayers!);
      }
    } else {
      await _notif.cancelAll();
      await stopAdzan();
    }
  }

  String _getEmoji(String name) {
    switch (name) {
      case 'Subuh':   return '🌙';
      case 'Dzuhur':  return '☀️';
      case 'Ashar':   return '🌤️';
      case 'Maghrib': return '🌅';
      case 'Isya':    return '🌙';
      default:        return '🕌';
    }
  }

  bool get isEnabled => _isEnabled;
  PrayerTimes? get todayPrayers => _todayPrayers;

  void dispose() {
    _checkTimer?.cancel();
    _audioPlayer.dispose();
  }
}
