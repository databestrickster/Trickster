import 'config_service.dart';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

// 
// MODEL
// 
class AttackStats {
  final int totalAttacks;
  final int successCount;
  final int failCount;
  final int todayCount;
  final int streak;
  final int bestStreak;
  final String favoriteBug;
  final List<DailyCount> last7Days;
  final List<BugCount> bugBreakdown;

  AttackStats({
    required this.totalAttacks,
    required this.successCount,
    required this.failCount,
    required this.todayCount,
    required this.streak,
    required this.bestStreak,
    required this.favoriteBug,
    required this.last7Days,
    required this.bugBreakdown,
  });

  double get successRate => totalAttacks == 0 ? 0 : (successCount / totalAttacks * 100);
}

class DailyCount {
  final String day;
  final int count;
  DailyCount({required this.day, required this.count});
}

class BugCount {
  final String name;
  final int count;
  final Color color;
  BugCount({required this.name, required this.count, required this.color});
}

// 
// STATS PAGE
// 
class StatsPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const StatsPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<StatsPage> createState() => _StatsPageState();
}

class _StatsPageState extends State<StatsPage> with TickerProviderStateMixin {
  bool _isLoading = true;
  AttackStats? _stats;
  late AnimationController _barCtrl;
  late Animation<double> _barAnim;
  late AnimationController _countCtrl;
  late Animation<double> _countAnim;

  @override
  void initState() {
    super.initState();
    _barCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200));
    _barAnim = CurvedAnimation(parent: _barCtrl, curve: Curves.easeOutCubic);
    _countCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1000));
    _countAnim = CurvedAnimation(parent: _countCtrl, curve: Curves.easeOutCubic);
    _loadStats();
  }

  @override
  void dispose() {
    _barCtrl.dispose();
    _countCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadStats() async {
    setState(() => _isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('${ConfigService.baseUrl}/api/stats/attack?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['success'] == true) {
          _stats = _parseStats(data);
        } else {
          _stats = _mockStats();
        }
      } else {
        _stats = _mockStats();
      }
    } catch (e) {
      _stats = _mockStats();
    }

    setState(() => _isLoading = false);
    _barCtrl.forward();
    _countCtrl.forward();
  }

  AttackStats _parseStats(Map<String, dynamic> data) {
    final d = data['data'] ?? {};
    final List<DailyCount> days = (d['last7Days'] as List? ?? [])
        .map((e) => DailyCount(day: e['day'] ?? '', count: e['count'] ?? 0))
        .toList();
    final bugColors = [
      const Color(0xFFDC143C),
      const Color(0xFFFF6B35),
      const Color(0xFF4ECDC4),
      const Color(0xFF45B7D1),
      const Color(0xFF96CEB4),
      const Color(0xFFFFEAA7),
      const Color(0xFFDDA0DD),
    ];
    final List<BugCount> bugs = (d['bugBreakdown'] as List? ?? []).asMap().entries
        .map((e) => BugCount(
              name: e.value['name'] ?? '',
              count: e.value['count'] ?? 0,
              color: bugColors[e.key % bugColors.length],
            ))
        .toList();
    return AttackStats(
      totalAttacks: d['totalAttacks'] ?? 0,
      successCount: d['successCount'] ?? 0,
      failCount: d['failCount'] ?? 0,
      todayCount: d['todayCount'] ?? 0,
      streak: d['streak'] ?? 0,
      bestStreak: d['bestStreak'] ?? 0,
      favoriteBug: d['favoriteBug'] ?? '-',
      last7Days: days,
      bugBreakdown: bugs,
    );
  }

  AttackStats _mockStats() {
    final rng = Random();
    final days = ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'];
    return AttackStats(
      totalAttacks: 0,
      successCount: 0,
      failCount: 0,
      todayCount: 0,
      streak: 0,
      bestStreak: 0,
      favoriteBug: '-',
      last7Days: days.map((d) => DailyCount(day: d, count: 0)).toList(),
      bugBreakdown: [],
    );
  }

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFFDC143C);
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: SafeArea(
        child: Column(
          children: [
            // Top bar
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.white.withAlpha(15),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.white12),
                      ),
                      child: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 18),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Stats Serangan', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900, fontFamily: 'Orbitron')),
                        Text(widget.username, style: const TextStyle(color: Colors.white38, fontSize: 11)),
                      ],
                    ),
                  ),
                  GestureDetector(
                    onTap: _loadStats,
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.white.withAlpha(15),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.white12),
                      ),
                      child: const Icon(Icons.refresh, color: Colors.white54, size: 20),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: _isLoading
                  ? Center(child: CircularProgressIndicator(color: accent, strokeWidth: 2))
                  : _buildContent(accent),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContent(Color accent) {
    final s = _stats!;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 8),

          // 4 stat cards
          AnimatedBuilder(
            animation: _countAnim,
            builder: (_, __) => Column(
              children: [
                Row(
                  children: [
                    _buildStatCard('⚡ Total\nSerangan', (s.totalAttacks * _countAnim.value).toInt().toString(), accent),
                    const SizedBox(width: 12),
                    _buildStatCard('✅ Berhasil', (s.successCount * _countAnim.value).toInt().toString(), Colors.greenAccent),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    _buildStatCard('📅 Hari Ini', (s.todayCount * _countAnim.value).toInt().toString(), Colors.blueAccent),
                    const SizedBox(width: 12),
                    _buildStatCard('🔥 Streak', '${(s.streak * _countAnim.value).toInt()} hari', Colors.orangeAccent),
                  ],
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),

          // Success rate bar
          _buildSectionTitle('Success Rate', accent),
          const SizedBox(height: 10),
          _buildSuccessRateBar(s.successRate, accent),

          const SizedBox(height: 20),

          // 7 hari terakhir bar chart
          _buildSectionTitle('7 Hari Terakhir', accent),
          const SizedBox(height: 12),
          _buildBarChart(s.last7Days, accent),

          const SizedBox(height: 20),

          // Bug breakdown
          if (s.bugBreakdown.isNotEmpty) ...[
            _buildSectionTitle('Bug Favorit', accent),
            const SizedBox(height: 12),
            _buildBugBreakdown(s.bugBreakdown),
            const SizedBox(height: 20),
          ],

          // Achievement / streak card
          _buildStreakCard(s, accent),

          const SizedBox(height: 20),

          // Info kalau data kosong
          if (s.totalAttacks == 0)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white.withAlpha(8),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white.withAlpha(15)),
              ),
              child: Column(
                children: [
                  const Text('📊', style: TextStyle(fontSize: 40)),
                  const SizedBox(height: 10),
                  const Text('Belum ada serangan', style: TextStyle(color: Colors.white54, fontSize: 14, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  const Text('Mulai kirim bug untuk lihat stats kamu disini!', style: TextStyle(color: Colors.white24, fontSize: 12), textAlign: TextAlign.center),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildStatCard(String label, String value, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          color: Colors.white.withAlpha(10),
          border: Border.all(color: color.withAlpha(51)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: TextStyle(color: Colors.white38, fontSize: 11, height: 1.4)),
            const SizedBox(height: 8),
            Text(
              value,
              style: TextStyle(
                color: Colors.white,
                fontSize: 28,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                shadows: [Shadow(color: color.withAlpha(153), blurRadius: 10)],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title, Color accent) {
    return Row(
      children: [
        Container(width: 3, height: 16, decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(3))),
        const SizedBox(width: 8),
        Text(title, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700, fontFamily: 'Orbitron', letterSpacing: 1)),
      ],
    );
  }

  Widget _buildSuccessRateBar(double rate, Color accent) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withAlpha(10),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withAlpha(15)),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Tingkat Keberhasilan', style: TextStyle(color: Colors.white54, fontSize: 12)),
              AnimatedBuilder(
                animation: _barAnim,
                builder: (_, __) => Text(
                  '${(rate * _barAnim.value).toStringAsFixed(1)}%',
                  style: TextStyle(
                    color: rate >= 70 ? Colors.greenAccent : rate >= 40 ? Colors.orangeAccent : accent,
                    fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'Orbitron',
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: AnimatedBuilder(
              animation: _barAnim,
              builder: (_, __) => LinearProgressIndicator(
                value: (rate / 100) * _barAnim.value,
                minHeight: 10,
                backgroundColor: Colors.white.withAlpha(20),
                valueColor: AlwaysStoppedAnimation(
                  rate >= 70 ? Colors.greenAccent : rate >= 40 ? Colors.orangeAccent : accent,
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('✅ ${_stats!.successCount} sukses', style: const TextStyle(color: Colors.white38, fontSize: 11)),
              Text('❌ ${_stats!.failCount} gagal', style: const TextStyle(color: Colors.white38, fontSize: 11)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBarChart(List<DailyCount> days, Color accent) {
    if (days.isEmpty) return const SizedBox.shrink();
    final maxCount = days.map((d) => d.count).reduce(max);
    String today;
    try {
      today = DateFormat('EEE', 'id').format(DateTime.now());
    } catch (_) {
      today = DateFormat('EEE').format(DateTime.now());
    }

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      decoration: BoxDecoration(
        color: Colors.white.withAlpha(10),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withAlpha(15)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: days.map((d) {
          final isToday = d.day.toLowerCase() == today.toLowerCase();
          final heightRatio = maxCount == 0 ? 0.0 : d.count / maxCount;
          return Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              if (d.count > 0)
                Text('${d.count}', style: TextStyle(color: isToday ? accent : Colors.white38, fontSize: 9, fontFamily: 'Orbitron')),
              const SizedBox(height: 4),
              AnimatedBuilder(
                animation: _barAnim,
                builder: (_, __) => Container(
                  width: 28,
                  height: max(4.0, 80 * heightRatio * _barAnim.value),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6),
                    color: isToday ? accent : Colors.white.withAlpha(38),
                    boxShadow: isToday ? [BoxShadow(color: accent.withAlpha(102), blurRadius: 8)] : null,
                  ),
                ),
              ),
              const SizedBox(height: 6),
              Text(d.day, style: TextStyle(color: isToday ? accent : Colors.white38, fontSize: 10, fontWeight: isToday ? FontWeight.bold : FontWeight.normal)),
            ],
          );
        }).toList(),
      ),
    );
  }

  Widget _buildBugBreakdown(List<BugCount> bugs) {
    final total = bugs.fold(0, (sum, b) => sum + b.count);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withAlpha(10),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withAlpha(15)),
      ),
      child: Column(
        children: bugs.map((bug) {
          final pct = total == 0 ? 0.0 : bug.count / total;
          return Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(bug.name, style: TextStyle(color: bug.color, fontSize: 12, fontWeight: FontWeight.w600)),
                    Text('${bug.count}x  (${(pct * 100).toStringAsFixed(0)}%)', style: const TextStyle(color: Colors.white38, fontSize: 11)),
                  ],
                ),
                const SizedBox(height: 5),
                AnimatedBuilder(
                  animation: _barAnim,
                  builder: (_, __) => ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: pct * _barAnim.value,
                      minHeight: 6,
                      backgroundColor: Colors.white.withAlpha(15),
                      valueColor: AlwaysStoppedAnimation(bug.color),
                    ),
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildStreakCard(AttackStats s, Color accent) {
    String badge = '';
    String title = '';
    if (s.streak >= 30) { badge = '👑'; title = 'LEGENDA'; }
    else if (s.streak >= 14) { badge = '🔥'; title = 'ON FIRE'; }
    else if (s.streak >= 7) { badge = '⚡'; title = 'AKTIF'; }
    else if (s.streak >= 3) { badge = '💪'; title = 'WARMING UP'; }
    else { badge = '😴'; title = 'MULAI STREAK'; }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: LinearGradient(
          colors: [accent.withAlpha(38), Colors.transparent],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        border: Border.all(color: accent.withAlpha(64)),
      ),
      child: Row(
        children: [
          Text(badge, style: const TextStyle(fontSize: 36)),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(color: accent, fontSize: 14, fontWeight: FontWeight.w900, fontFamily: 'Orbitron', letterSpacing: 1.5)),
                const SizedBox(height: 4),
                Text(
                  s.streak == 0
                      ? 'Serang hari ini untuk mulai streak!'
                      : 'Streak ${s.streak} hari  Best: ${s.bestStreak} hari',
                  style: const TextStyle(color: Colors.white54, fontSize: 12),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}