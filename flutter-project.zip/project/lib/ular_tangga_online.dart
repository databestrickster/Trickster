// lib/ular_tangga_online.dart
// Ular Tangga  FULL FEATURED: Offline + Bot + Online Multiplayer
// Animasi: Chess Intro, Kocok Dadu, Jalan Pion Step-by-Step

import 'config_service.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'asset_service.dart';
import 'package:flutter/services.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'ludo_player.dart';
import 'leaderboard_page.dart';
import 'ular_tangga_bet.dart';



const String _wsUrl = 'ws://angkasaandolin.angkasanyabobo.my.id:1327';
const Map<int, int> kSnakes  = {99:2, 95:13, 87:24, 64:60, 54:34, 17:7};
const Map<int, int> kLadders = {4:25, 9:31, 20:38, 28:84, 40:59, 51:67, 63:81, 71:91};

// 
// MAP THEMES
// 
enum MapTheme { ramadan, halloween, christmas }

class MapConfig {
  final String name;
  final String emoji;
  final MapTheme theme;
  final Map<int, int> snakes;
  final Map<int, int> ladders;
  final Color bgColor;
  final Color cellA;
  final Color cellB;
  final Color snakeColor;
  final Color ladderColor;
  final String snakeEmoji;
  final String ladderEmoji;
  final String bgEmoji; // decorative bg emoji

  const MapConfig({
    required this.name, required this.emoji, required this.theme,
    required this.snakes, required this.ladders,
    required this.bgColor, required this.cellA, required this.cellB,
    required this.snakeColor, required this.ladderColor,
    required this.snakeEmoji, required this.ladderEmoji, required this.bgEmoji,
  });
}

const kMapConfigs = [
  //  RAMADAN 🌙 
  MapConfig(
    name: 'Ramadan', emoji: '🌙', theme: MapTheme.ramadan,
    snakes:  {96:14, 88:24, 75:32, 56:12, 44:8,  19:5},
    ladders: {3:22,  10:35, 23:55, 36:70, 53:80, 66:90},
    bgColor: const Color(0xFF0A0D1A),
    cellA:   const Color(0xFF1A2240),
    cellB:   const Color(0xFF111830),
    snakeColor:  const Color(0xFFFF6B35),
    ladderColor: const Color(0xFFFFD700),
    snakeEmoji: '🌙', ladderEmoji: '�', bgEmoji: '��',
  ),
  //  HALLOWEEN 🎃 
  MapConfig(
    name: 'Halloween', emoji: '🎃', theme: MapTheme.halloween,
    snakes:  {98:3,  90:18, 82:44, 70:25, 52:30, 16:6},
    ladders: {6:28,  13:40, 25:60, 42:72, 58:82, 74:92},
    bgColor: const Color(0xFF0D0800),
    cellA:   const Color(0xFF1F0E00),
    cellB:   const Color(0xFF160A00),
    snakeColor:  const Color(0xFF9B59B6),
    ladderColor: const Color(0xFFFF8C00),
    snakeEmoji: '�️', ladderEmoji: '🎃', bgEmoji: '�',
  ),
  //  CHRISTMAS 🎄 
  MapConfig(
    name: 'Natal', emoji: '🎄', theme: MapTheme.christmas,
    snakes:  {97:7,  86:22, 74:38, 60:15, 47:27, 22:4},
    ladders: {5:30,  18:42, 32:65, 45:78, 62:85, 77:95},
    bgColor: const Color(0xFF060F0A),
    cellA:   const Color(0xFF0D2010),
    cellB:   const Color(0xFF081509),
    snakeColor:  const Color(0xFFE74C3C),
    ladderColor: const Color(0xFF2ECC71),
    snakeEmoji: '�️', ladderEmoji: '�', bgEmoji: '��',
  ),
];


// 
// SISTEM XP & RANK
// 
const List<Map<String, dynamic>> kRanks = [
  {'name': 'Rookie',    'emoji': '🥉', 'minXP': 0,    'color': 0xFF8D6E63},
  {'name': 'Bronze',    'emoji': '🥉', 'minXP': 100,  'color': 0xFFCD7F32},
  {'name': 'Silver',    'emoji': '🥈', 'minXP': 300,  'color': 0xFF9E9E9E},
  {'name': 'Gold',      'emoji': '🥇', 'minXP': 600,  'color': 0xFFFFD700},
  {'name': 'Platinum',  'emoji': '💎', 'minXP': 1000, 'color': 0xFF00BCD4},
  {'name': 'Diamond',   'emoji': '�', 'minXP': 1500, 'color': 0xFF2196F3},
  {'name': 'Master',    'emoji': '�', 'minXP': 2500, 'color': 0xFF9C27B0},
  {'name': 'Legend',    'emoji': '�', 'minXP': 4000, 'color': 0xFFFF5722},
];

Map<String, dynamic> getRankInfo(int xp) {
  Map<String, dynamic> current = kRanks[0];
  for (final r in kRanks) {
    if (xp >= (r['minXP'] as int)) current = r;
  }
  return current;
}

int getXpForNextRank(int xp) {
  for (int i = 0; i < kRanks.length - 1; i++) {
    if (xp < (kRanks[i + 1]['minXP'] as int)) return kRanks[i + 1]['minXP'] as int;
  }
  return (kRanks.last['minXP'] as int);
}

class XpManager {
  static Future<int> getXP() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt('player_xp') ?? 0;
  }

  static Future<void> addXP(int amount) async {
    final prefs = await SharedPreferences.getInstance();
    final current = prefs.getInt('player_xp') ?? 0;
    await prefs.setInt('player_xp', current + amount);
  }

  static Future<int> getCampaignStage() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt('campaign_stage') ?? 1;
  }

  static Future<void> unlockNextStage(int current) async {
    final prefs = await SharedPreferences.getInstance();
    final unlocked = prefs.getInt('campaign_stage') ?? 1;
    if (current >= unlocked) {
      await prefs.setInt('campaign_stage', current + 1);
    }
  }
}

// 
// CAMPAIGN STAGE CONFIG (20 STAGE)
// 
class CampaignStage {
  final int stage;
  final String name;
  final String emoji;
  final int botCount;
  final double botDifficulty;
  final Map<int, int> snakes;
  final Map<int, int> ladders;
  final int xpReward;
  final Color color;
  final bool isBoss;

  const CampaignStage({
    required this.stage, required this.name, required this.emoji,
    required this.botCount, required this.botDifficulty,
    required this.snakes, required this.ladders,
    required this.xpReward, required this.color,
    this.isBoss = false,
  });
}

// Lazy cache  tidak generate 5000 stage sekaligus saat startup
final Map<int, CampaignStage> _stageCache = {};
CampaignStage _getStage(int index) =>
    _stageCache.putIfAbsent(index, () => _buildStage(index + 1));
const int kTotalCampaignStages = 5000;

CampaignStage _buildStage(int s) {
  final bool isBoss = s % 100 == 0;
  final int cycle = (s - 1) % 20;

  // Difficulty naik terus 0.05��0.97, boss selalu 1.0
  final double diff = isBoss ? 1.0 : (0.05 + (s / 5000) * 0.92).clamp(0.05, 0.97);

  // Bot: 1 bot stage 1-50, 2 bot 51-150, 3 bot 151+
  final int bots = s <= 50 ? 1 : s <= 150 ? 2 : 3;

  // XP reward naik terus
  final int xp = isBoss ? (s * 5) : (10 + s ~/ 2).clamp(10, 9999);

  // Ular makin banyak, tangga makin sedikit
  final int snakeCount = (2 + s ~/ 50).clamp(2, 12);
  final int ladderCount = isBoss ? 0 : (6 - s ~/ 80).clamp(0, 6);

  const snakePool = [
    [17,7],[54,34],[64,60],[87,24],[95,13],[99,2],
    [16,4],[49,11],[79,19],[68,9],[92,3],[85,5],
  ];
  const ladderPool = [
    [4,25],[9,31],[20,38],[28,84],[40,59],[51,67],
  ];

  final snakes = <int,int>{};
  for (int i = 0; i < snakeCount && i < snakePool.length; i++) {
    snakes[snakePool[i][0]] = snakePool[i][1];
  }
  final ladders = <int,int>{};
  for (int i = 0; i < ladderCount && i < ladderPool.length; i++) {
    ladders[ladderPool[i][0]] = ladderPool[i][1];
  }

  const names = [
    'Pemula','Latihan','Penantang','Pejuang','Berani',
    'Tangguh','Veteran','Elite','Ahli','Jagoan',
    'Pemberani','Pahlawan','Legenda','Dewa','Tak Terkalahkan',
    'Iblis','Monster','Godzilla','Titan','Champion',
  ];
  const emojis = [
    '🌱','🎯','️','🛡️','�','💪','🎖️','�','🏅','�',
    '�','�','🏆','�','�','😈','�','�','�','🏅',
  ];
  const colors = [
    Color(0xFF4CAF50),Color(0xFF66BB6A),Color(0xFFFFC107),Color(0xFFFFB300),Color(0xFFFF9800),
    Color(0xFFFF7043),Color(0xFFEF5350),Color(0xFFE53935),Color(0xFFAB47BC),Color(0xFF9C27B0),
    Color(0xFF7B1FA2),Color(0xFF5E35B1),Color(0xFF3949AB),Color(0xFF1E88E5),Color(0xFF0288D1),
    Color(0xFF00838F),Color(0xFF00695C),Color(0xFF2E7D32),Color(0xFFF57F17),Color(0xFFB71C1C),
  ];

  final bossNames = {100:'� BOSS LV.1',200:'� BOSS LV.2',300:'😈 BOSS LV.3',400:'� BOSS LV.4',500:'💥 FINAL BOSS'};

  return CampaignStage(
    stage: s,
    name: isBoss ? bossNames[s]! : '${names[cycle]} ${s ~/ 20 + 1}',
    emoji: isBoss ? '💥' : emojis[cycle],
    botCount: bots,
    botDifficulty: diff,
    snakes: snakes,
    ladders: ladders,
    xpReward: xp,
    color: isBoss ? const Color(0xFFB71C1C) : colors[cycle],
    isBoss: isBoss,
  );
}



const _kColors = [Color(0xFFE74C3C), Color(0xFF3498DB), Color(0xFF2ECC71), Color(0xFFF39C12)];
const _kEmojis = ['�','�','🟢','🟡'];

// 
// AUDIO
// 
class _Sfx {
  static final Map<String, AudioPlayer> _pool = {};
  static bool _init = false;

  static Future<void> init() async {
    if (_init) return;
    _init = true;
    await AudioPlayer.global.setAudioContext(AudioContext(
      android: const AudioContextAndroid(
        isSpeakerphoneOn: false, stayAwake: false,
        contentType: AndroidContentType.music,
        usageType: AndroidUsageType.game,
        audioFocus: AndroidAudioFocus.gain,
      ),
      iOS: AudioContextIOS(
        category: AVAudioSessionCategory.ambient,
        options: {AVAudioSessionOptions.mixWithOthers},
      ),
    ));
    for (final n in ['ludo_dice','ludo_step','ludo_ular','ludo_naik','ludo_win','ludo_turn']) {
      final p = AudioPlayer();
      await p.setVolume(1.0);
      await p.setReleaseMode(ReleaseMode.stop);
      _pool[n] = p;
    }
  }

  static String _ext(String name) {
    // ludo_dice pakai .wav, semua ludo sfx .wav
    return '$name.wav';
  }

  static Future<void> play(String name) async {
    try {
      final p = _pool[name]; if (p == null) return;
      final path = AssetService.audioPathSync(_ext(name));
      if (path.isEmpty) return;
      await p.stop();
      await p.play(DeviceFileSource(path));
    } catch (_) {}
  }

  static Future<void> dispose() async {
    for (final p in _pool.values) await p.dispose();
    _pool.clear(); _init = false;
  }
}

// 
// ENTRY PAGE  Chess Intro �� Mode Select
// 
class UlarTanggaOnlinePage extends StatefulWidget {
  final String username;
  final String userRole;
  final String sessionKey;

  const UlarTanggaOnlinePage({
    super.key,
    required this.username,
    required this.userRole,
    required this.sessionKey,
  });

  @override
  State<UlarTanggaOnlinePage> createState() => _UlarTanggaOnlinePageState();
}

class _UlarTanggaOnlinePageState extends State<UlarTanggaOnlinePage>
    with TickerProviderStateMixin {

  // Intro animasi
  late AnimationController _introCtrl;       // board reveal
  late AnimationController _titleCtrl;       // title + subtitle shimmer
  late AnimationController _glowCtrl;        // pulsing glow
  late AnimationController _exitCtrl;        // fade-out sebelum masuk main
  late Animation<double> _introScale;
  late Animation<double> _titleSlide;
  late Animation<double> _titleFade;
  late Animation<double> _subtitleFade;
  late Animation<double> _glowAnim;
  late Animation<double> _exitFade;
  bool _introFinished = false;

  // Stagger cell reveal (100 kotak board)
  final List<AnimationController> _cellCtrl = [];
  final List<Animation<double>> _cellAnim = [];

  // Pion bounce masuk (4 pion)
  final List<AnimationController> _pieceCtrl = [];
  final List<Animation<double>> _pieceAnim = [];

  // Main content fade
  late AnimationController _mainCtrl;
  late Animation<double> _mainFade;
  late Animation<Offset> _mainSlide;

  // Saldo koin
  int _saldo = 0;
  bool _saldoLoading = true;

  Future<void> _loadSaldo() async {
    try {
      final s = await BetApi.getSaldo(widget.sessionKey);
      if (mounted) setState(() { _saldo = s < 0 ? 0 : s; _saldoLoading = false; });
    } catch (e) {
      if (mounted) setState(() { _saldo = 0; _saldoLoading = false; });
    }
  }
  Future<void> _checkAndShowDailyBonus() async {
    if (!mounted) return;
    final data = await BetApi.checkDaily(widget.sessionKey);
    if (!mounted) return;
    if (data['valid'] == true && data['canClaim'] == true) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => _DailyBonusDialog(
          sessionKey: widget.sessionKey,
          bonusAmount: 10000,
          onClaimed: _loadSaldo,
        ),
      );
    }
  }

  @override
  void initState() {
    super.initState();
    _Sfx.init();
    _loadSaldo();
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkAndShowDailyBonus());

    // Board reveal controller (600ms)
    _introCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _introScale = Tween(begin: 0.82, end: 1.0).animate(
      CurvedAnimation(parent: _introCtrl, curve: Curves.easeOutBack));

    // Title controller (800ms)
    _titleCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _titleFade    = CurvedAnimation(parent: _titleCtrl, curve: Curves.easeOut);
    _titleSlide   = Tween(begin: 40.0, end: 0.0).animate(
      CurvedAnimation(parent: _titleCtrl, curve: Curves.easeOutCubic));
    _subtitleFade = Tween(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _titleCtrl, curve: const Interval(0.4, 1.0, curve: Curves.easeOut)));

    // Glow pulse (repeating)
    _glowCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400));
    _glowAnim = Tween(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut));

    // Exit fade
    _exitCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _exitFade = Tween(begin: 1.0, end: 0.0).animate(
      CurvedAnimation(parent: _exitCtrl, curve: Curves.easeIn));

    // Stagger 100 cell reveal
    for (int i = 0; i < 100; i++) {
      final ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 250));
      _cellCtrl.add(ctrl);
      _cellAnim.add(CurvedAnimation(parent: ctrl, curve: Curves.easeOut));
    }

    // Pion bounce (4 pion)
    for (int i = 0; i < 4; i++) {
      final ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
      _pieceCtrl.add(ctrl);
      _pieceAnim.add(Tween(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(parent: ctrl, curve: Curves.elasticOut)));
    }

    _mainCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _mainFade  = CurvedAnimation(parent: _mainCtrl, curve: Curves.easeOut);
    _mainSlide = Tween<Offset>(begin: const Offset(0, 0.15), end: Offset.zero)
        .animate(CurvedAnimation(parent: _mainCtrl, curve: Curves.easeOut));

    _runIntro();
  }

  Future<void> _runIntro() async {
    try {
      await Future.delayed(const Duration(milliseconds: 150));
      if (!mounted) return;

      // Phase 1: board scale in
      _introCtrl.forward();

      // Phase 2: reveal kotak satu per satu (wave pattern dari tengah)
      final center = 55; // cell 55 ~ tengah board
      for (int n = 1; n <= 100; n++) {
        final row = (n - 1) ~/ 10;
        final col = (n - 1) % 10;
        final dist = ((row - 4).abs() + (col - 4).abs());
        final delay = 200 + dist * 45;
        Future.delayed(Duration(milliseconds: delay), () {
          if (mounted) _cellCtrl[n - 1].forward();
        });
      }

      // Phase 3: title slide up setelah board mulai keliatan
      await Future.delayed(const Duration(milliseconds: 700));
      if (!mounted) return;
      _titleCtrl.forward();

      // Phase 4: glow pulse repeating
      await Future.delayed(const Duration(milliseconds: 400));
      if (!mounted) return;
      _glowCtrl.repeat(reverse: true);

      // Phase 5: pion bounce masuk satu per satu
      await Future.delayed(const Duration(milliseconds: 300));
      for (int i = 0; i < 4; i++) {
        Future.delayed(Duration(milliseconds: i * 180), () {
          if (mounted) _pieceCtrl[i].forward();
        });
      }

      // Hold sebentar supaya keliatan keren
      await Future.delayed(const Duration(milliseconds: 1500));
      if (!mounted) return;

      // Phase 6: cinematic exit fade
      _exitCtrl.forward();
      await Future.delayed(const Duration(milliseconds: 480));

    } catch (e) {
      // skip intro kalau error
    } finally {
      if (!mounted) return;
      _glowCtrl.stop();
      setState(() => _introFinished = true);
      _mainCtrl.forward();
    }
  }

  @override
  void dispose() {
    _introCtrl.dispose();
    _titleCtrl.dispose();
    _glowCtrl.dispose();
    _exitCtrl.dispose();
    for (final c in _cellCtrl) c.dispose();
    for (final c in _pieceCtrl) c.dispose();
    _mainCtrl.dispose();
    super.dispose();
  }

  PlayerRole _mapRole(String r) {
    switch (r.toLowerCase()) {
      case 'owner': return PlayerRole.owner;
      case 'admin': return PlayerRole.admin;
      case 'vip':   return PlayerRole.vip;
      case 'member':return PlayerRole.member;
      default:      return PlayerRole.guest;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final accent = theme.colorScheme.secondary;
    final primary = theme.primaryColor;

    return Scaffold(
      backgroundColor: const Color(0xFF060B14),
      body: Stack(children: [

        //  Background blobs 
        _Blob(color: primary, size: 300, top: -100, right: -80),
        _Blob(color: accent, size: 250, bottom: -80, left: -60, delay: 1.2),

        //  Intro overlay 
        if (!_introFinished)
          AnimatedBuilder(
            animation: Listenable.merge([_introCtrl, _titleCtrl, _glowCtrl, _exitCtrl]),
            builder: (_, __) => Opacity(
              opacity: _exitFade.value,
              child: Container(
                color: Colors.black,
                alignment: Alignment.center,
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  // Board dengan glow pulsing
                  Transform.scale(
                    scale: _introScale.value.clamp(0.01, 10.0),
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0xFFFFD700).withValues(alpha: _glowAnim.value * 0.6),
                            blurRadius: 40 + _glowAnim.value * 30,
                            spreadRadius: 4,
                          ),
                          BoxShadow(
                            color: Colors.purple.withValues(alpha: _glowAnim.value * 0.3),
                            blurRadius: 60,
                            spreadRadius: 8,
                          ),
                        ],
                      ),
                      child: _SnakeLadderIntroWidget(
                        cellAnims: _cellAnim,
                        pieceAnims: _pieceAnim,
                      ),
                    ),
                  ),
                  const SizedBox(height: 28),
                  // Title slide up
                  Transform.translate(
                    offset: Offset(0, _titleSlide.value),
                    child: Opacity(
                      opacity: _titleFade.value.clamp(0.0, 1.0),
                      child: Column(children: [
                        ShaderMask(
                          shaderCallback: (bounds) => const LinearGradient(
                            colors: [Color(0xFFFFD700), Color(0xFFFFFFFF), Color(0xFFFFAA00)],
                            stops: [0.0, 0.5, 1.0],
                          ).createShader(bounds),
                          child: const Text('� ULAR TANGGA',
                            style: TextStyle(
                              fontFamily: 'Orbitron', fontSize: 30, fontWeight: FontWeight.w900,
                              color: Colors.white, letterSpacing: 3,
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Opacity(
                          opacity: _subtitleFade.value.clamp(0.0, 1.0),
                          child: const Text('BOARD GAME',
                            style: TextStyle(
                              color: Colors.white38, fontFamily: 'ShareTechMono',
                              fontSize: 11, letterSpacing: 6,
                            ),
                          ),
                        ),
                      ]),
                    ),
                  ),
                ]),
              ),
            ),
          ),

        //  Main content 
        if (_introFinished)
          SafeArea(
            child: FadeTransition(
              opacity: _mainFade,
              child: SlideTransition(
                position: _mainSlide,
                child: _ModeSelectContent(
                  username: widget.username,
                  userRole: widget.userRole,
                  sessionKey: widget.sessionKey,
                  role: _mapRole(widget.userRole),
                  primary: primary,
                  accent: accent,
                  saldo: _saldo,
                  saldoLoading: _saldoLoading,
                ),
              ),
            ),
          ),
      ]),
    );
  }
}

//  Snake Ladder Intro Widget 
class _SnakeLadderIntroWidget extends StatelessWidget {
  final List<Animation<double>> cellAnims;
  final List<Animation<double>> pieceAnims;
  const _SnakeLadderIntroWidget({required this.cellAnims, required this.pieceAnims});

  static const _snakeCells  = {17, 54, 64, 87, 95, 99};
  static const _ladderCells = {4, 9, 20, 28, 40, 51};
  static const _pionEmojis  = ['�','�','🟢','🟡'];

  Color _cellColorBase(int n) {
    if (_snakeCells.contains(n))  return const Color(0xFF7B1010);
    if (_ladderCells.contains(n)) return const Color(0xFF0F5C1A);
    final row = (n - 1) ~/ 10;
    final col = (n - 1) % 10;
    return (row + col) % 2 == 0 ? const Color(0xFF1A1A40) : const Color(0xFF2A1A5E);
  }

  @override
  Widget build(BuildContext context) {
    final sz = MediaQuery.of(context).size.width * 0.80;
    final cs = sz / 10;
    return Container(
      width: sz, height: sz,
      decoration: BoxDecoration(
        border: Border.all(color: const Color(0xFFFFD700), width: 2.5),
        borderRadius: BorderRadius.circular(10),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Stack(children: [
          // Background
          Container(color: const Color(0xFF0D0D2B)),
          // Grid dengan wave reveal
          GridView.builder(
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 10),
            itemCount: 100,
            itemBuilder: (_, idx) {
              final gridRow = idx ~/ 10;
              final gridCol = idx % 10;
              final boardRow = 9 - gridRow;
              final col = boardRow % 2 == 0 ? gridCol : 9 - gridCol;
              final n = boardRow * 10 + col + 1;
              final anim = cellAnims[n - 1];
              final isSnake  = _snakeCells.contains(n);
              final isLadder = _ladderCells.contains(n);
              return AnimatedBuilder(
                animation: anim,
                builder: (_, __) {
                  final v = anim.value;
                  return Transform.scale(
                    scale: 0.4 + v * 0.6,
                    child: Opacity(
                      opacity: v.clamp(0.0, 1.0),
                      child: Container(
                        decoration: BoxDecoration(
                          color: _cellColorBase(n),
                          border: Border.all(
                            color: isSnake
                                ? Colors.red.withValues(alpha: 0.5)
                                : isLadder
                                    ? Colors.green.withValues(alpha: 0.5)
                                    : Colors.white.withValues(alpha: 0.06),
                            width: 0.5,
                          ),
                        ),
                        alignment: Alignment.center,
                        child: isSnake
                            ? Text('�', style: TextStyle(fontSize: cs * 0.52))
                            : isLadder
                                ? Text('🪜', style: TextStyle(fontSize: cs * 0.52))
                                : Text('$n',
                                    style: TextStyle(
                                      fontSize: cs * 0.24,
                                      color: Colors.white.withValues(alpha: 0.45),
                                      fontFamily: 'ShareTechMono',
                                    )),
                      ),
                    ),
                  );
                },
              );
            },
          ),
          // 4 pion bounce masuk dengan trail
          for (int i = 0; i < 4; i++)
            Positioned(
              left: [cs * 0.05, cs * 1.1, cs * 0.05, cs * 2.15][i],
              bottom: cs * 0.08,
              child: AnimatedBuilder(
                animation: pieceAnims[i],
                builder: (_, __) {
                  final v = pieceAnims[i].value;
                  return Transform.translate(
                    offset: Offset(0, -30 * (1 - v) * (1 - v)),
                    child: Transform.scale(
                      scale: v.clamp(0.0, 1.2),
                      child: Opacity(
                        opacity: v.clamp(0.0, 1.0),
                        child: Stack(alignment: Alignment.center, children: [
                          // Shadow/glow di bawah pion
                          if (v > 0.5)
                            Container(
                              width: cs * 0.85,
                              height: cs * 0.2,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.black.withValues(alpha: 0.4 * ((v - 0.5) * 2)),
                                boxShadow: [BoxShadow(
                                  color: [Colors.red, Colors.blue, Colors.green, Colors.yellow][i]
                                    .withValues(alpha: 0.5 * ((v - 0.5) * 2)),
                                  blurRadius: 8,
                                )],
                              ),
                            ),
                          Text(_pionEmojis[i], style: TextStyle(fontSize: cs * 0.72)),
                        ]),
                      ),
                    ),
                  );
                },
              ),
            ),
        ]),
      ),
    );
  }
}

//  Mode Select Content 
class _ModeSelectContent extends StatelessWidget {
  final String username, userRole, sessionKey;
  final PlayerRole role;
  final Color primary, accent;
  final int saldo;
  final bool saldoLoading;

  const _ModeSelectContent({
    required this.username, required this.userRole, required this.sessionKey,
    required this.role, required this.primary, required this.accent,
    this.saldo = 0, this.saldoLoading = false,
  });

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(children: [
          _IconBtn(icon: Icons.arrow_back, accent: accent, onTap: () => Navigator.pop(context)),
          const Spacer(),
          Column(children: [
            Text('� ULAR TANGGA',
              style: TextStyle(fontFamily: 'Orbitron', fontSize: 16, fontWeight: FontWeight.w900,
                color: Colors.white, letterSpacing: 2, shadows: [Shadow(color: accent, blurRadius: 10)])),
            const Text('Select Mode', style: TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 10)),
          ]),
          const Spacer(),
          // Saldo badge + optional owner topup
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            SaldoBadge(saldo: saldo, isLoading: saldoLoading),
            if (userRole.toLowerCase() == 'owner') ...[
              const SizedBox(height: 4),
              GestureDetector(
                onTap: () => Navigator.push(context, PageRouteBuilder(
                  pageBuilder: (_, __, ___) => OwnerTopUpPage(ownerUsername: username, sessionKey: sessionKey, userRole: userRole),
                  transitionsBuilder: (_, anim, __, child) => SlideTransition(
                    position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)), child: child),
                  transitionDuration: const Duration(milliseconds: 280),
                )),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: Color(0xFFFFD700).withValues(alpha: 0.15),
                    border: Border.all(color: Color(0xFFFFD700).withValues(alpha: 0.5)),
                  ),
                  child: const Text('💰 TOP UP', style: TextStyle(color: Color(0xFFFFD700), fontFamily: 'Orbitron', fontSize: 8, fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ]),
        ]),
      ),

      // Player info
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: _PlayerInfoCard(username: username, role: role, primary: primary, accent: accent),
      ),

      const SizedBox(height: 28),

      // Mode buttons
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: _AnimDelay(delay: 100, child: _ModeBtn(
          icon: Icons.people_alt_outlined,
          title: 'OFFLINE',
          subtitle: '2�4 Pemain di satu device',
          gradient: LinearGradient(colors: [primary, accent]),
          onTap: () => Navigator.push(context, _slideRoute(
            _OfflineSetupPage(username: username, userRole: userRole, sessionKey: sessionKey))),
        )),
      ),

      const SizedBox(height: 12),

      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: _AnimDelay(delay: 200, child: _ModeBtn(
          icon: Icons.smart_toy_outlined,
          title: 'VS BOT',
          subtitle: 'Main sendiri lawan AI',
          gradient: const LinearGradient(colors: [Color(0xFF9B59B6), Color(0xFF6C3483)]),
          onTap: () => Navigator.push(context, _slideRoute(
            _BotSetupPage(username: username, userRole: userRole, sessionKey: sessionKey))),
        )),
      ),

      const SizedBox(height: 12),

      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: _AnimDelay(delay: 300, child: _ModeBtn(
          icon: Icons.map_outlined,
          title: 'CAMPAIGN',
          subtitle: '20 Stage  makin susah tiap level!',
          gradient: const LinearGradient(colors: [Color(0xFFFF6F00), Color(0xFFE65100)]),
          onTap: () => Navigator.push(context, _slideRoute(
            _CampaignPage(username: username, userRole: userRole, sessionKey: sessionKey))),
        )),
      ),

      const Spacer(),

      // Shop + Rank buttons
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(children: [
          Expanded(child: _AnimDelay(delay: 350, child: GestureDetector(
            onTap: () => Navigator.push(context, _slideRoute(_ShopPage(sessionKey: sessionKey))),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                gradient: const LinearGradient(colors: [Color(0xFFFFD700), Color(0xFFFF8F00)]),
              ),
              child: const Center(child: Text('🛒 SHOP', style: TextStyle(fontFamily: 'Orbitron', fontSize: 12, fontWeight: FontWeight.bold, color: Colors.black))),
            ),
          ))),
          const SizedBox(width: 10),
          Expanded(child: _AnimDelay(delay: 400, child: GestureDetector(
            onTap: () => Navigator.push(context, _slideRoute(_RankPage(username: username))),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                gradient: const LinearGradient(colors: [Color(0xFF9C27B0), Color(0xFF4A148C)]),
              ),
              child: const Center(child: Text('🏆 RANK', style: TextStyle(fontFamily: 'Orbitron', fontSize: 12, fontWeight: FontWeight.bold, color: Colors.white))),
            ),
          ))),
        ]),
      ),

      // Top Up button  hanya untuk owner/vip/reseller
      if (['owner','vip','reseller','reseller1'].contains(userRole.toLowerCase()))
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
          child: _AnimDelay(delay: 450, child: GestureDetector(
            onTap: () => Navigator.push(context, _slideRoute(
              _TopUpCoinsPage(sessionKey: sessionKey, username: username, userRole: userRole))),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                color: Colors.white.withValues(alpha: 0.05),
                border: Border.all(color: Color(0xFFFFD700).withValues(alpha: 0.4)),
              ),
              child: const Center(child: Text('🪙 TOP UP KOIN USER', style: TextStyle(
                fontFamily: 'Orbitron', fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFFFFD700)))),
            ),
          )),
        ),

      const SizedBox(height: 16),

      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.04),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.white12)),
          child: const Text(
            '��️  Offline: main bareng 1 device\n🤖  VS Bot: lawan AI\n�️  Campaign: 5000 stage + BOSS',
            style: TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 10, height: 1.8)),
        ),
      ),
    ]);
  }
}

// 
// OFFLINE SETUP PAGE
// 
class _OfflineSetupPage extends StatefulWidget {
  final String username, userRole, sessionKey;
  const _OfflineSetupPage({required this.username, required this.userRole, required this.sessionKey});
  @override State<_OfflineSetupPage> createState() => _OfflineSetupPageState();
}

class _OfflineSetupPageState extends State<_OfflineSetupPage> {
  int _count = 2;
  final List<TextEditingController> _ctrls = List.generate(4, (i) => TextEditingController());
  PawnSkin _selectedSkin = PawnSkin.circle;
  MapConfig _selectedMap = kMapConfigs[0];

  @override
  void initState() {
    super.initState();
    final defaults = ['Pemain 1','Pemain 2','Pemain 3','Pemain 4'];
    for (int i = 0; i < 4; i++) _ctrls[i].text = i == 0 ? widget.username : defaults[i];
  }

  @override
  void dispose() {
    for (final c in _ctrls) c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final accent = Theme.of(context).colorScheme.secondary;
    final primary = Theme.of(context).primaryColor;

    return Scaffold(
      backgroundColor: const Color(0xFF060B14),
      body: SafeArea(child: SingleChildScrollView(child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            _IconBtn(icon: Icons.arrow_back, accent: accent, onTap: () => Navigator.pop(context)),
            const SizedBox(width: 12),
            Text('OFFLINE SETUP',
              style: TextStyle(fontFamily: 'Orbitron', fontSize: 14, fontWeight: FontWeight.w900,
                color: Colors.white, shadows: [Shadow(color: accent, blurRadius: 8)])),
          ]),
          const SizedBox(height: 24),
          const Text('JUMLAH PEMAIN', style: TextStyle(color: Colors.white38, fontFamily: 'Orbitron', fontSize: 10, letterSpacing: 2)),
          const SizedBox(height: 10),
          Row(children: List.generate(3, (i) {
            final n = i + 2;
            final sel = _count == n;
            return Expanded(child: Padding(
              padding: EdgeInsets.only(right: i < 2 ? 8 : 0),
              child: GestureDetector(
                onTap: () => setState(() => _count = n),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: sel ? accent : Colors.white12, width: sel ? 2 : 1),
                    color: sel ? accent.withValues(alpha: 0.15) : Colors.white.withValues(alpha: 0.04),
                    boxShadow: sel ? [BoxShadow(color: accent.withValues(alpha: 0.3), blurRadius: 12)] : [],
                  ),
                  child: Center(child: Text('$n',
                    style: TextStyle(fontFamily: 'Orbitron', fontSize: 22, fontWeight: FontWeight.w900,
                      color: sel ? Colors.white : Colors.white38))),
                ),
              ),
            ));
          })),
          const SizedBox(height: 24),
          const Text('SKIN PION', style: TextStyle(color: Colors.white38, fontFamily: 'Orbitron', fontSize: 10, letterSpacing: 2)),
          const SizedBox(height: 10),
          _SkinPicker(selected: _selectedSkin, onChanged: (s) => setState(() => _selectedSkin = s)),
          const SizedBox(height: 24),
          const Text('NAMA PEMAIN', style: TextStyle(color: Colors.white38, fontFamily: 'Orbitron', fontSize: 10, letterSpacing: 2)),
          const SizedBox(height: 10),
          ...List.generate(_count, (i) => Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Row(children: [
              _PawnPreview(playerIdx: i, skin: _selectedSkin, size: 28),
              const SizedBox(width: 10),
              Expanded(child: TextField(
                controller: _ctrls[i],
                style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono'),
                decoration: InputDecoration(
                  hintText: '${_kEmojis[i]} Nama pemain ${i+1}',
                  hintStyle: const TextStyle(color: Colors.white24),
                  filled: true, fillColor: Colors.white.withValues(alpha: 0.05),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: Colors.white12)),
                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Colors.white12)),
                  focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: accent)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                ),
              )),
            ]),
          )),
          const SizedBox(height: 20),
          const Text('PILIH MAP', style: TextStyle(color: Colors.white38, fontFamily: 'Orbitron', fontSize: 10, letterSpacing: 2)),
          const SizedBox(height: 10),
          Row(children: kMapConfigs.asMap().entries.map((entry) {
            final idx = entry.key;
            final m = entry.value;
            final isSel = _selectedMap.name == m.name;
            return Expanded(child: Padding(
              padding: EdgeInsets.only(right: idx < kMapConfigs.length - 1 ? 8 : 0),
              child: GestureDetector(
                onTap: () => setState(() => _selectedMap = m),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: isSel ? m.snakeColor : Colors.white12, width: isSel ? 2 : 1),
                    color: isSel ? m.snakeColor.withValues(alpha: 0.15) : Colors.white.withValues(alpha: 0.04),
                    boxShadow: isSel ? [BoxShadow(color: m.snakeColor.withValues(alpha: 0.3), blurRadius: 10)] : [],
                  ),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Text(m.emoji, style: const TextStyle(fontSize: 22)),
                    const SizedBox(height: 4),
                    Text(m.name, style: TextStyle(fontFamily: 'Orbitron', fontSize: 8,
                        fontWeight: FontWeight.bold, color: isSel ? m.snakeColor : Colors.white38),
                      textAlign: TextAlign.center),
                  ]),
                ),
              ),
            ));
          }).toList()),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: _GradientBtn(
              label: '� MULAI MAIN',
              gradient: LinearGradient(colors: [primary, accent]),
              onTap: () async {
                final names = List.generate(_count, (i) => _ctrls[i].text.trim().isEmpty ? 'Pemain ${i+1}' : _ctrls[i].text.trim());
                final players = List.generate(_count, (i) => SnakeLadderPlayer(
                  name: names[i], pawnColor: PawnColor.values[i], role: PlayerRole.guest, isBot: false, pawnSkin: _selectedSkin, playerIndex: i));
                if (!context.mounted) return;
                Navigator.pushReplacement(context, _slideRoute(
                  _GamePage(players: players, isOnline: false, myIndex: 0, betAmount: 0,
                    mapConfig: _selectedMap,
                    onGameOver: (winner, all) => Navigator.push(context, _slideRoute(
                      _ResultPage(winnerName: winner.name, players: all,
                        username: widget.username, userRole: widget.userRole,
                        betAmount: 0, sessionKey: widget.sessionKey))))));
              },
            ),
          ),
        ]),
      ))),
    );
  }
}

// 
// BOT SETUP PAGE
// 
class _BotSetupPage extends StatefulWidget {
  final String username, userRole, sessionKey;
  const _BotSetupPage({required this.username, required this.userRole, required this.sessionKey});
  @override State<_BotSetupPage> createState() => _BotSetupPageState();
}

class _BotSetupPageState extends State<_BotSetupPage> {
  int _botCount = 1;
  late TextEditingController _nameCtrl;
  String _difficulty = 'Normal';
  PawnSkin _selectedSkin = PawnSkin.circle;

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(text: widget.username);
  }

  @override
  void dispose() { _nameCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final accent = Theme.of(context).colorScheme.secondary;

    return Scaffold(
      backgroundColor: const Color(0xFF060B14),
      body: SafeArea(child: SingleChildScrollView(child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            _IconBtn(icon: Icons.arrow_back, accent: accent, onTap: () => Navigator.pop(context)),
            const SizedBox(width: 12),
            Text('VS BOT',
              style: TextStyle(fontFamily: 'Orbitron', fontSize: 14, fontWeight: FontWeight.w900,
                color: Colors.white, shadows: [Shadow(color: accent, blurRadius: 8)])),
          ]),
          const SizedBox(height: 24),
          const Text('NAMA KAMU', style: TextStyle(color: Colors.white38, fontFamily: 'Orbitron', fontSize: 10, letterSpacing: 2)),
          const SizedBox(height: 10),
          Row(children: [
            Container(width: 12, height: 12, decoration: BoxDecoration(color: _kColors[0], shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: _kColors[0].withValues(alpha: 0.5), blurRadius: 6)])),
            const SizedBox(width: 10),
            Expanded(child: TextField(
              controller: _nameCtrl,
              style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono'),
              decoration: InputDecoration(
                hintText: 'Nama kamu',
                hintStyle: const TextStyle(color: Colors.white24),
                filled: true, fillColor: Colors.white.withValues(alpha: 0.05),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Colors.white12)),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Colors.white12)),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: accent)),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              ),
            )),
          ]),
          const SizedBox(height: 24),
          const SizedBox(height: 24),
          const Text('SKIN PION', style: TextStyle(color: Colors.white38, fontFamily: 'Orbitron', fontSize: 10, letterSpacing: 2)),
          const SizedBox(height: 10),
          _SkinPicker(selected: _selectedSkin, onChanged: (s) => setState(() => _selectedSkin = s)),
          const SizedBox(height: 24),
          const Text('JUMLAH BOT', style: TextStyle(color: Colors.white38, fontFamily: 'Orbitron', fontSize: 10, letterSpacing: 2)),
          const SizedBox(height: 10),
          Row(children: List.generate(3, (i) {
            final n = i + 1; final sel = _botCount == n;
            return Expanded(child: Padding(
              padding: EdgeInsets.only(right: i < 2 ? 8 : 0),
              child: GestureDetector(
                onTap: () => setState(() => _botCount = n),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: sel ? const Color(0xFF9B59B6) : Colors.white12, width: sel ? 2 : 1),
                    color: sel ? Color(0xFF9B59B6).withValues(alpha: 0.15) : Colors.white.withValues(alpha: 0.04),
                  ),
                  child: Center(child: Text('$n Bot',
                    style: TextStyle(fontFamily: 'Orbitron', fontSize: 13, fontWeight: FontWeight.w700,
                      color: sel ? Colors.white : Colors.white38))),
                ),
              ),
            ));
          })),
          const SizedBox(height: 24),
          const Text('KESULITAN BOT', style: TextStyle(color: Colors.white38, fontFamily: 'Orbitron', fontSize: 10, letterSpacing: 2)),
          const SizedBox(height: 10),
          Row(children: ['Mudah','Normal','Susah'].map((d) {
            final sel = _difficulty == d;
            final colors = {'Mudah': Colors.green, 'Normal': Colors.orange, 'Susah': Colors.red};
            return Expanded(child: Padding(
              padding: EdgeInsets.only(right: d != 'Susah' ? 8 : 0),
              child: GestureDetector(
                onTap: () => setState(() => _difficulty = d),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: sel ? colors[d]! : Colors.white12, width: sel ? 2 : 1),
                    color: sel ? colors[d]!.withValues(alpha: 0.15) : Colors.white.withValues(alpha: 0.04),
                  ),
                  child: Center(child: Text(d,
                    style: TextStyle(fontFamily: 'Orbitron', fontSize: 11, fontWeight: FontWeight.w700,
                      color: sel ? Colors.white : Colors.white38))),
                ),
              ),
            ));
          }).toList()),
          const SizedBox(height: 28),
          SizedBox(
            width: double.infinity,
            child: _GradientBtn(
              label: '🤖 LAWAN BOT!',
              gradient: const LinearGradient(colors: [Color(0xFF9B59B6), Color(0xFF6C3483)]),
              onTap: () async {
                final name = _nameCtrl.text.trim().isEmpty ? widget.username : _nameCtrl.text.trim();
                final players = <SnakeLadderPlayer>[
                  SnakeLadderPlayer(name: name, pawnColor: PawnColor.red, role: PlayerRole.guest, isBot: false, playerIndex: 0),
                  ...List.generate(_botCount, (i) => SnakeLadderPlayer(
                    name: 'Bot ${i+1} 🤖', pawnColor: PawnColor.values[i+1], role: PlayerRole.guest,
                    isBot: true, playerIndex: i + 1)),
                ];
                if (!context.mounted) return;
                Navigator.pushReplacement(context, _slideRoute(
                  _GamePage(players: players, isOnline: false, myIndex: 0, botDifficulty: _difficulty, betAmount: 0,
                    onGameOver: (winner, all) => Navigator.push(context, _slideRoute(
                      _ResultPage(winnerName: winner.name, players: all,
                        username: widget.username, userRole: widget.userRole,
                        betAmount: 0, sessionKey: widget.sessionKey))))));
              },
            ),
          ),
        ]),
      ))),
    );
  }
}

// 
// GAME PAGE  Core gameplay + Animations
// 
class _GamePage extends StatefulWidget {
  final List<SnakeLadderPlayer> players;
  final bool isOnline;
  final int myIndex;
  final String botDifficulty;
  final WebSocketChannel? channel;
  final String roomCode;
  final int betAmount;
  final void Function(SnakeLadderPlayer winner, List<SnakeLadderPlayer> all)? onGameOver;
  final CampaignStage? campaignStage;
  final MapConfig? mapConfig;

  const _GamePage({
    required this.players,
    required this.isOnline,
    required this.myIndex,
    this.botDifficulty = 'Normal',
    this.channel,
    this.roomCode = '',
    this.betAmount = 0,
    this.onGameOver,
    this.campaignStage,
    this.mapConfig,
  });

  @override
  State<_GamePage> createState() => _GamePageState();
}

class _GamePageState extends State<_GamePage> with TickerProviderStateMixin {

  late MapConfig _mapConfig;
  int _currentPlayer = 0;
  int _diceValue = 0;
  bool _isRolling = false;
  bool _isMoving = false;
  String? _eventMsg;
  Color? _eventColor;

  // Pion position tweens  one per player
  late List<_PionController> _pionControllers;

  // Dice shake animation
  late AnimationController _diceCtrl;
  late Animation<double> _diceShakeX;
  late Animation<double> _diceShakeY;
  late Animation<double> _diceRotation;
  late Animation<double> _diceScale;

  // Event overlay
  late AnimationController _eventCtrl;
  late Animation<double> _eventScale;
  late Animation<double> _eventFade;

  // Online websocket
  StreamSubscription? _wsSub;
  bool _gameOver = false;

  @override
  void initState() {
    super.initState();
    _Sfx.init();
    _mapConfig = widget.mapConfig ?? kMapConfigs[0];

    _pionControllers = List.generate(widget.players.length, (i) => _PionController(vsync: this));

    // Dice
    _diceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
    _diceShakeX = TweenSequence([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: -12.0), weight: 10),
      TweenSequenceItem(tween: Tween(begin: -12.0, end: 12.0), weight: 20),
      TweenSequenceItem(tween: Tween(begin: 12.0, end: -8.0), weight: 20),
      TweenSequenceItem(tween: Tween(begin: -8.0, end: 8.0), weight: 20),
      TweenSequenceItem(tween: Tween(begin: 8.0, end: -4.0), weight: 15),
      TweenSequenceItem(tween: Tween(begin: -4.0, end: 0.0), weight: 15),
    ]).animate(CurvedAnimation(parent: _diceCtrl, curve: Curves.easeInOut));
    _diceShakeY = TweenSequence([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: -7.0), weight: 15),
      TweenSequenceItem(tween: Tween(begin: -7.0, end: 7.0), weight: 30),
      TweenSequenceItem(tween: Tween(begin: 7.0, end: -5.0), weight: 25),
      TweenSequenceItem(tween: Tween(begin: -5.0, end: 0.0), weight: 30),
    ]).animate(CurvedAnimation(parent: _diceCtrl, curve: Curves.easeInOut));
    _diceRotation = TweenSequence([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: -0.3), weight: 15),
      TweenSequenceItem(tween: Tween(begin: -0.3, end: 0.3), weight: 30),
      TweenSequenceItem(tween: Tween(begin: 0.3, end: -0.2), weight: 25),
      TweenSequenceItem(tween: Tween(begin: -0.2, end: 0.0), weight: 30),
    ]).animate(CurvedAnimation(parent: _diceCtrl, curve: Curves.easeInOut));
    _diceScale = TweenSequence([
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 1.0), weight: 60),
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 1.5), weight: 12),
      TweenSequenceItem(tween: Tween(begin: 1.5, end: 0.85), weight: 15),
      TweenSequenceItem(tween: Tween(begin: 0.85, end: 1.0), weight: 13),
    ]).animate(CurvedAnimation(parent: _diceCtrl, curve: Curves.easeOut));

    // Event
    _eventCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _eventScale = TweenSequence([
      TweenSequenceItem(tween: Tween(begin: 0.2, end: 1.15), weight: 60),
      TweenSequenceItem(tween: Tween(begin: 1.15, end: 1.0), weight: 40),
    ]).animate(CurvedAnimation(parent: _eventCtrl, curve: Curves.elasticOut));
    _eventFade = Tween(begin: 0.0, end: 1.0)
        .animate(CurvedAnimation(parent: _eventCtrl, curve: const Interval(0, 0.3)));

    if (widget.isOnline && widget.channel != null) {
      _wsSub = widget.channel!.stream.listen(_onWsMessage);
    }

    // Trigger bot jika player pertama adalah bot
    WidgetsBinding.instance.addPostFrameCallback((_) => _maybeTriggerBot());
  }

  @override
  void dispose() {
    _diceCtrl.dispose();
    _eventCtrl.dispose();
    for (final pc in _pionControllers) pc.dispose();
    _wsSub?.cancel();
    _Sfx.dispose();
    super.dispose();
  }

  // Game sudah mulai jika ada player yang sudah mengocok dadu
  bool get _gameStarted => widget.players.any((p) => p.totalRolls > 0);

  //  Bot turn trigger 
  void _maybeTriggerBot() {
    if (_gameOver || _isRolling || _isMoving) return;
    final p = widget.players[_currentPlayer];
    if (p.isBot) {
      Future.delayed(const Duration(milliseconds: 900), () {
        if (mounted && !_gameOver && widget.players[_currentPlayer].isBot) {
          _doRoll(isBot: true);
        }
      });
    }
  }

  //  Roll dice 
  Future<void> _doRoll({bool isBot = false}) async {
    if (_isRolling || _isMoving || _gameOver) return;
    if (!isBot && widget.players[_currentPlayer].isBot) return;
    if (widget.isOnline && _currentPlayer != widget.myIndex) return;

    setState(() => _isRolling = true);

    // Shake animation
    _diceCtrl.forward(from: 0);
    _Sfx.play('ludo_dice');

    // Flash random numbers during shake
    for (int f = 0; f < 8; f++) {
      await Future.delayed(const Duration(milliseconds: 75));
      if (mounted) setState(() => _diceValue = Random().nextInt(6) + 1);
    }

    await Future.delayed(const Duration(milliseconds: 150));

    final result = Random().nextInt(6) + 1;
    if (mounted) setState(() { _diceValue = result; _isRolling = false; });

    if (widget.isOnline) {
      widget.channel?.sink.add(jsonEncode({'type': 'roll_dice', 'payload': {}}));
    } else {
      await _movePlayer(_currentPlayer, result);
    }
  }

  //  Move player step by step 
  Future<void> _movePlayer(int pIdx, int steps) async {
    if (!mounted) return;
    setState(() => _isMoving = true);
    final player = widget.players[pIdx];
    final fromPos = player.position;
    player.totalRolls++;

    // Step by step movement with smooth lerp animation
    for (int s = 1; s <= steps; s++) {
      final nextPos = min(fromPos + s, 100);
      player.position = nextPos;
      await Future.wait([
        _pionControllers[pIdx].stepTo(nextPos),
        _Sfx.play('ludo_step'),
      ]);
      if (mounted) setState(() {});
    }

    final landedPos = player.position;

    // Win check
    if (landedPos >= 100) {
      player.position = 100;
      _pionControllers[pIdx].jumpTo(100);
      if (mounted) setState(() => _isMoving = false);
      await Future.delayed(const Duration(milliseconds: 300));
      _Sfx.play('ludo_win');
      _gameOver = true;
      // XP & Koin reward
      if (!player.isBot) {
        if (widget.campaignStage != null) {
          final xp    = widget.campaignStage!.xpReward;
          final coins = (xp ~/ 2).clamp(5, 9999);
          final stage = widget.campaignStage!.stage;
          final isBoss = stage % 100 == 0;
          final bonusCoins = isBoss ? coins * 3 : coins; // bonus 3x kalau boss
          await XpManager.addXP(xp);
          await XpManager.unlockNextStage(stage);
          await ShopManager.addCoins(bonusCoins);
          // Popup reward
          if (mounted) {
            await showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => _StageRewardDialog(
                stage: stage,
                xp: xp,
                coins: bonusCoins,
                isBoss: isBoss,
              ),
            );
          }
        } else {
          await XpManager.addXP(10);
          await ShopManager.addCoins(5);
        }
      }
      widget.onGameOver?.call(player, widget.players);
      return;
    }

    // Snake / Ladder check
    if (_mapConfig.snakes.containsKey(landedPos)) {
      await Future.delayed(const Duration(milliseconds: 200));
      _Sfx.play('ludo_ular');
      player.snakesHit++;
      _showEvent('${_mapConfig.snakeEmoji} KENA ${_mapConfig.name.toUpperCase()}!', Colors.red.shade700);
      final snakeTail = _mapConfig.snakes[landedPos]!;
      // Slide animation
      await _slidePion(pIdx, landedPos, snakeTail);
      player.position = snakeTail;
    } else if (_mapConfig.ladders.containsKey(landedPos)) {
      await Future.delayed(const Duration(milliseconds: 200));
      _Sfx.play('ludo_naik');
      player.laddersClimbed++;
      _showEvent('${_mapConfig.ladderEmoji} NAIK!', Colors.green.shade600);
      final ladderTop = _mapConfig.ladders[landedPos]!;
      await _slidePion(pIdx, landedPos, ladderTop);
      player.position = ladderTop;
    }

    if (mounted) setState(() {
      _currentPlayer = (_currentPlayer + 1) % widget.players.length;
      _isMoving = false;
    });

    _maybeTriggerBot();
  }

  Future<void> _slidePion(int pIdx, int from, int to) async {
    if (mounted) setState(() {});
    await _pionControllers[pIdx].slideTo(to);
    if (mounted) setState(() {});
  }

  void _showMapPicker() {
    if (_gameStarted) return; // tidak bisa ganti map setelah game mulai
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        padding: const EdgeInsets.all(20),
        decoration: const BoxDecoration(
          color: Color(0xFF0D1426),
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          border: Border(top: BorderSide(color: Colors.white12)),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 16),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          const Text('PILIH MAP', style: TextStyle(color: Colors.white, fontFamily: 'Orbitron',
            fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 2)),
          const SizedBox(height: 20),
          Row(children: kMapConfigs.map((m) {
            final isSel = _mapConfig.name == m.name;
            return Expanded(child: GestureDetector(
              onTap: () {
                setState(() { _mapConfig = m; });
                Navigator.pop(ctx);
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                margin: const EdgeInsets.symmetric(horizontal: 6),
                padding: const EdgeInsets.symmetric(vertical: 16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: isSel ? m.ladderColor.withValues(alpha: 0.15) : Colors.white.withValues(alpha: 0.04),
                  border: Border.all(color: isSel ? m.ladderColor : Colors.white12, width: isSel ? 2 : 1),
                  boxShadow: isSel ? [BoxShadow(color: m.ladderColor.withValues(alpha: 0.25), blurRadius: 16)] : [],
                ),
                child: Column(children: [
                  Text(m.emoji, style: const TextStyle(fontSize: 32)),
                  const SizedBox(height: 8),
                  Text(m.name, style: TextStyle(
                    color: isSel ? Colors.white : Colors.white54,
                    fontFamily: 'Orbitron', fontSize: 10, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text('${m.snakeEmoji}ular  ${m.ladderEmoji}tangga',
                    style: const TextStyle(color: Colors.white30, fontSize: 9)),
                ]),
              ),
            ));
          }).toList()),
          const SizedBox(height: 20),
        ]),
      ),
    );
  }

  void _showEvent(String msg, Color color) {
    setState(() { _eventMsg = msg; _eventColor = color; });
    _eventCtrl.forward(from: 0);
    Future.delayed(const Duration(milliseconds: 1600), () {
      if (mounted) setState(() => _eventMsg = null);
    });
  }

  void _onWsMessage(dynamic raw) {
    final msg = jsonDecode(raw as String);
    final type = msg['type'] as String;
    if (type == 'game_update') {
      final gs = msg['gameState'] as Map;
      final event = msg['event'] as String?;
      final newDice = gs['diceValue'] as int? ?? 0;

      if (newDice != _diceValue) {
        _diceCtrl.forward(from: 0);
        _Sfx.play('ludo_dice');
      }

      if (event == 'snake') { _Sfx.play('ludo_ular'); _showEvent('� KENA ULAR!', Colors.red.shade700); }
      if (event == 'ladder') { _Sfx.play('ludo_naik'); _showEvent('🪜 NAIK TANGGA!', Colors.green.shade600); }

      final gsPlayers = gs['players'] as List? ?? [];
      for (int i = 0; i < widget.players.length && i < gsPlayers.length; i++) {
        final newPos = (gsPlayers[i] as Map)['position'] as int? ?? 0;
        if (newPos != widget.players[i].position) {
          widget.players[i].position = newPos;
          _pionControllers[i].jumpTo(newPos);
        }
      }

      setState(() {
        _diceValue = newDice;
        _currentPlayer = gs['currentPlayerIndex'] as int? ?? 0;
        _isRolling = false;
        _isMoving = false;
      });
    } else if (type == 'game_over') {
      _Sfx.play('ludo_win');
      final winnerName = msg['winnerName'] as String? ?? '';
      setState(() { _gameOver = true; });
      final winner = widget.players.firstWhere((p) => p.name == winnerName, orElse: () => widget.players[0]);
      widget.onGameOver?.call(winner, widget.players);
    }
  }

  bool get _isMyTurn => !widget.isOnline || _currentPlayer == widget.myIndex;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final accent = theme.colorScheme.secondary;
    final curPlayer = widget.players[_currentPlayer];
    final curColor = _kColors[_currentPlayer % _kColors.length];
    final isMyTurn = _isMyTurn && !widget.players[_currentPlayer].isBot;

    return Scaffold(
      backgroundColor: const Color(0xFF060B14),
      body: SafeArea(child: Stack(children: [
        Column(children: [
          // Header
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(children: [
              _IconBtn(icon: Icons.arrow_back, accent: accent, onTap: () => _confirmExit(context)),
              const Spacer(),
              Column(children: [
                Text('${_mapConfig.emoji} ULAR TANGGA',
                  style: TextStyle(fontFamily: 'Orbitron', fontSize: 12, fontWeight: FontWeight.w900,
                    color: Colors.white, shadows: [Shadow(color: accent, blurRadius: 8)])),
                Text(_mapConfig.name, style: TextStyle(color: accent.withValues(alpha: 0.8), fontFamily: 'ShareTechMono', fontSize: 9)),
                if (widget.roomCode.isNotEmpty)
                  Text('Room: ${widget.roomCode}', style: const TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 9)),
              ]),
              const Spacer(),
              // Tombol ganti map
              GestureDetector(
                onTap: (_isMoving || _isRolling || _gameStarted) ? null : _showMapPicker,
                child: Opacity(
                opacity: _gameStarted ? 0.3 : 1.0,
                child: Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: accent.withValues(alpha: 0.12),
                    border: Border.all(color: accent.withValues(alpha: 0.4)),
                  ),
                  child: const Center(child: Text('🗺️', style: TextStyle(fontSize: 18))),
                ),
              ),
              ),
            ]),
          ),

          // Player strip
          _PlayerStrip(players: widget.players, currentIdx: _currentPlayer),

          // Bet info bar
          BetInfoBar(betAmount: widget.betAmount, playerCount: widget.players.length, isActive: widget.betAmount > 0),

          // Board
          Expanded(child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            child: _BoardWidget(
              players: widget.players,
              pionControllers: _pionControllers,
              currentIdx: _currentPlayer,
              mapConfig: _mapConfig,
            ),
          )),

          // Bottom panel
          Container(
            margin: const EdgeInsets.fromLTRB(10, 0, 10, 10),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: curColor.withValues(alpha: 0.4), width: 1.5),
              color: curColor.withValues(alpha: 0.07)),
            child: Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('GILIRAN', style: TextStyle(color: Colors.white30, fontSize: 8, fontFamily: 'Orbitron', letterSpacing: 2)),
                const SizedBox(height: 3),
                Row(children: [
                  Text(_kEmojis[_currentPlayer % _kEmojis.length], style: const TextStyle(fontSize: 14)),
                  const SizedBox(width: 6),
                  Flexible(child: Text(curPlayer.name,
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 13, fontFamily: 'Orbitron'),
                    overflow: TextOverflow.ellipsis)),
                  if (curPlayer.isBot) ...[
                    const SizedBox(width: 6),
                    Container(padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                      decoration: BoxDecoration(color: Colors.purple.withValues(alpha: 0.3), borderRadius: BorderRadius.circular(4)),
                      child: const Text('BOT', style: TextStyle(color: Colors.purple, fontSize: 8, fontWeight: FontWeight.bold))),
                  ],
                ]),
                const SizedBox(height: 5),
                AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: isMyTurn ? Colors.green.withValues(alpha: 0.2) : Colors.orange.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: isMyTurn ? Colors.green.withValues(alpha: 0.5) : Colors.orange.withValues(alpha: 0.3))),
                  child: Text(
                    isMyTurn ? '�� TAP DADU!' : curPlayer.isBot ? '🤖 Bot berpikir...' : '�� Giliran ${curPlayer.name}',
                    style: TextStyle(color: isMyTurn ? Colors.green : Colors.orange,
                      fontSize: 9, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
                ),
              ])),
              const SizedBox(width: 12),

              // DICE
              GestureDetector(
                onTap: (isMyTurn && !_isRolling && !_isMoving) ? () => _doRoll() : null,
                child: AnimatedBuilder(
                  animation: _diceCtrl,
                  builder: (_, child) => Transform.translate(
                    offset: Offset(_diceShakeX.value, _diceShakeY.value),
                    child: Transform.rotate(
                      angle: _diceRotation.value,
                      child: Transform.scale(scale: _diceScale.value, child: child),
                    ),
                  ),
                  child: Column(children: [
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      width: 70, height: 70,
                      decoration: BoxDecoration(
                        color: isMyTurn ? Colors.white : Colors.white24,
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: isMyTurn
                            ? [BoxShadow(color: curColor.withValues(alpha: 0.7), blurRadius: 18, spreadRadius: 2),
                               BoxShadow(color: curColor.withValues(alpha: 0.3), blurRadius: 32, spreadRadius: 4)]
                            : []),
                      child: _isRolling
                          ? const Center(child: SizedBox(width: 28, height: 28,
                              child: CircularProgressIndicator(strokeWidth: 3, color: Colors.grey)))
                          : _diceValue == 0
                              ? const Center(child: Text('🎲', style: TextStyle(fontSize: 32)))
                              : _DiceFace(value: _diceValue),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      isMyTurn ? 'TAP DADU!' : _isRolling ? '🎲 Rolling...' : 'Tunggu...',
                      style: TextStyle(
                        color: isMyTurn ? curColor : Colors.white38,
                        fontSize: 8, fontFamily: 'Orbitron',
                        fontWeight: isMyTurn ? FontWeight.bold : FontWeight.normal),
                    ),
                  ]),
                ),
              ),
            ]),
          ),
        ]),

        // Event overlay
        if (_eventMsg != null)
          Positioned.fill(child: IgnorePointer(child: Center(
            child: AnimatedBuilder(
              animation: _eventCtrl,
              builder: (_, child) => Opacity(
                opacity: _eventFade.value,
                child: Transform.scale(scale: _eventScale.value, child: child),
              ),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 20),
                decoration: BoxDecoration(
                  color: _eventColor!.withValues(alpha: 0.92),
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [BoxShadow(color: _eventColor!.withValues(alpha: 0.6), blurRadius: 40, spreadRadius: 8)],
                ),
                child: Text(_eventMsg!,
                  style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron',
                    fontSize: 26, fontWeight: FontWeight.w900, letterSpacing: 2)),
              ),
            ),
          ))),
      ])),
    );
  }

  void _confirmExit(BuildContext context) {
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: const Color(0xFF0D0D1A),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: const BorderSide(color: Colors.white24)),
      title: const Text('Keluar?', style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 14)),
      content: const Text('Progress game akan hilang.', style: TextStyle(color: Colors.white54, fontFamily: 'ShareTechMono')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal', style: TextStyle(color: Colors.white38))),
        ElevatedButton(
          onPressed: () => Navigator.of(context).popUntil((r) => r.isFirst),
          style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
          child: const Text('Keluar')),
      ],
    ));
  }
}

//  Pion Controller (manages animated position) 
class _PionController {
  final TickerProvider vsync;
  int _fromPos = 0;
  int _toPos = 0;
  late final AnimationController moveCtrl;
  late final Animation<double> moveAnim;
  // Bounce idle animation for active pion
  late final AnimationController bounceCtrl;
  late final Animation<double> bounceAnim;

  _PionController({required this.vsync}) {
    moveCtrl = AnimationController(vsync: vsync, duration: const Duration(milliseconds: 220));
    moveAnim = CurvedAnimation(parent: moveCtrl, curve: Curves.easeInOutCubic);
    bounceCtrl = AnimationController(vsync: vsync, duration: const Duration(milliseconds: 600))
      ..repeat(reverse: true);
    bounceAnim = CurvedAnimation(parent: bounceCtrl, curve: Curves.easeInOut);
  }

  int get displayPos => _toPos;

  void jumpTo(int pos) {
    _fromPos = pos;
    _toPos = pos;
    moveCtrl.value = 1.0;
  }

  Future<void> stepTo(int target) async {
    _fromPos = _toPos;
    _toPos = target;
    await moveCtrl.forward(from: 0);
    _fromPos = target;
  }

  Future<void> slideTo(int target) async {
    _fromPos = _toPos;
    _toPos = target;
    moveCtrl.duration = const Duration(milliseconds: 550);
    await moveCtrl.forward(from: 0);
    moveCtrl.duration = const Duration(milliseconds: 220);
    _fromPos = target;
  }

  Offset lerpOffset(double cs) {
    final fromSafe = _fromPos > 0 ? _fromPos : 1;
    final toSafe = _toPos > 0 ? _toPos : 1;
    final a = _BoardPainter.cellCenter(fromSafe, cs);
    final b = _BoardPainter.cellCenter(toSafe, cs);
    if (_fromPos == _toPos || moveCtrl.value >= 1.0) return b;
    return Offset.lerp(a, b, moveAnim.value)!;
  }

  void dispose() { moveCtrl.dispose(); bounceCtrl.dispose(); }
}

//  Board Widget 
class _BoardWidget extends StatelessWidget {
  final List<SnakeLadderPlayer> players;
  final List<_PionController> pionControllers;
  final int currentIdx;
  final MapConfig mapConfig;

  const _BoardWidget({required this.players, required this.pionControllers, required this.currentIdx, required this.mapConfig});

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1,
      child: Container(
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(12),
          boxShadow: [const BoxShadow(color: Colors.black54, blurRadius: 20)]),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: CustomPaint(
            painter: _BoardPainter(players: players, pionControllers: pionControllers, currentIdx: currentIdx, mapConfig: mapConfig),
          ),
        ),
      ),
    );
  }
}

class _BoardPainter extends CustomPainter {
  final List<SnakeLadderPlayer> players;
  final List<_PionController> pionControllers;
  final int currentIdx;
  final MapConfig mapConfig;

  _BoardPainter({required this.players, required this.pionControllers, required this.currentIdx, required this.mapConfig})
    : super(repaint: Listenable.merge([
      ...pionControllers.map((c) => c.moveCtrl),
      ...pionControllers.map((c) => c.bounceCtrl),
    ]));

  static Offset cellCenter(int n, double cs) {
    final idx = n - 1;
    final row = idx ~/ 10;
    final col = row % 2 == 0 ? idx % 10 : 9 - (idx % 10);
    return Offset((col + 0.5) * cs, ((9 - row) + 0.5) * cs);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final cs = size.width / 10;

    // Board background
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height),
        Paint()..color = mapConfig.bgColor);

    // BG decorative emojis (subtle)
    for (int r = 1; r < 9; r += 3) {
      for (int c = 1; c < 9; c += 3) {
        final tp = TextPainter(text: TextSpan(text: mapConfig.bgEmoji, style: const TextStyle(fontSize: 18)), textDirection: TextDirection.ltr)..layout();
        tp.paint(canvas, Offset(c * cs + cs * .1, (9 - r) * cs + cs * .1));
      }
    }

    for (int n = 1; n <= 100; n++) {
      final idx = n - 1;
      final row = idx ~/ 10;
      final col = row % 2 == 0 ? idx % 10 : 9 - (idx % 10);
      final x = col * cs, y = (9 - row) * cs;

      Color cellColor = (row + col) % 2 == 0 ? mapConfig.cellA : mapConfig.cellB;
      if (mapConfig.snakes.containsKey(n))        cellColor = mapConfig.snakeColor.withValues(alpha: 0.3);
      if (mapConfig.ladders.containsKey(n))        cellColor = mapConfig.ladderColor.withValues(alpha: 0.25);
      if (mapConfig.snakes.values.contains(n))     cellColor = mapConfig.snakeColor.withValues(alpha: 0.15);
      if (mapConfig.ladders.values.contains(n))    cellColor = mapConfig.ladderColor.withValues(alpha: 0.12);
      if (n == 100) cellColor = Color(0xFFCCA800).withValues(alpha: 0.9);
      if (n == 1)   cellColor = Color(0xFF0050C8).withValues(alpha: 0.7);

      canvas.drawRect(Rect.fromLTWH(x, y, cs, cs), Paint()..color = cellColor);
      canvas.drawRect(Rect.fromLTWH(x, y, cs, cs),
          Paint()..color = Colors.black38..style = PaintingStyle.stroke..strokeWidth = 0.5);

      _drawText(canvas, '$n', Offset(x + cs/2, y + cs/2), cs * 0.21,
          color: n == 100 ? Colors.black : Colors.white.withValues(alpha: 0.65));
    }

    // Gambar ular & tangga SETELAH grid, SEBELUM pion
    _drawSnakesAndLadders(canvas, cs);

    _drawPieces(canvas, cs);
  }

  //  Draw snakes & ladders inline (setelah grid, sebelum pion) 
  void _drawSnakesAndLadders(Canvas canvas, double cs) {
    _SnakeLadderPainter(mapConfig: mapConfig).paint(canvas, Size(cs * 10, cs * 10));
  }

  void _drawPieces(Canvas canvas, double cs) {
    // Draw each pion at its smooth-lerped position
    for (int i = 0; i < players.length; i++) {
      final displayPos = pionControllers[i].displayPos;
      if (displayPos <= 0 || displayPos > 100) continue;

      // Find siblings at same displayPos for offset
      final List<int> siblings = [];
      for (int k = 0; k < players.length; k++) {
        if (pionControllers[k].displayPos == displayPos) siblings.add(k);
      }
      final j = siblings.indexOf(i);

      final base = pionControllers[i].lerpOffset(cs);
      final c = _kColors[i % _kColors.length];
      final isCurrent = i == currentIdx;
      final skin = players[i].pawnSkin;
      Offset offset = Offset.zero;
      if (siblings.length > 1) {
        final angle = (j / siblings.length) * 2 * pi - pi / 2;
        offset = Offset(cos(angle) * cs * 0.2, sin(angle) * cs * 0.2);
      }
      // Apply bounce offset for active pion
      final bounce = (i == currentIdx)
          ? Offset(0, -pionControllers[i].bounceAnim.value * cs * 0.18)
          : Offset.zero;
      final pos = base + offset + bounce;
      // dummy pList for backward compat
      final pList = siblings;
        final r = cs * 0.19;

        // Glow
        if (isCurrent) {
          canvas.drawCircle(pos, cs * 0.3,
              Paint()..color = c.withValues(alpha: 0.45)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10));
        }
        // Shadow
        canvas.drawCircle(pos + const Offset(1.5, 1.5), r, Paint()..color = Colors.black45);

        if (skin == PawnSkin.circle) {
          //  DEFAULT CIRCLE 
          canvas.drawCircle(pos, r, Paint()..color = c);
          canvas.drawCircle(pos - Offset(cs * 0.05, cs * 0.05), cs * 0.07,
              Paint()..color = Colors.white.withValues(alpha: 0.45));
          canvas.drawCircle(pos, r,
              Paint()..color = Colors.white.withValues(alpha: isCurrent ? 0.95 : 0.5)
                ..style = PaintingStyle.stroke..strokeWidth = isCurrent ? 2.5 : 1.2);
          _drawText(canvas, 'P${i+1}', pos, cs * 0.15, color: Colors.white);

        } else if (skin == PawnSkin.chess) {
          //  CHESS SKIN 
          // Outer ring
          canvas.drawCircle(pos, r + 1,
              Paint()..color = Colors.white.withValues(alpha: isCurrent ? 0.9 : 0.4)
                ..style = PaintingStyle.stroke..strokeWidth = isCurrent ? 2.5 : 1.5);
          // BG circle
          canvas.drawCircle(pos, r, Paint()..color = c);
          // Inner shine
          canvas.drawCircle(pos - Offset(cs * 0.04, cs * 0.04), cs * 0.08,
              Paint()..color = Colors.white.withValues(alpha: 0.3));
          // Chess piece emoji
          _drawText(canvas, kChessIcons[i % kChessIcons.length], pos, cs * 0.26);

        } else if (skin == PawnSkin.animal) {
          //  ANIMAL SKIN 
          const animalIcons = ['🦁', '🐯', '🐼', '🦊'];
          canvas.drawCircle(pos, r + 1,
              Paint()..color = Colors.white.withValues(alpha: isCurrent ? 0.9 : 0.4)
                ..style = PaintingStyle.stroke..strokeWidth = isCurrent ? 2.5 : 1.5);
          canvas.drawCircle(pos, r, Paint()..color = c.withValues(alpha: 0.2));
          canvas.drawCircle(pos, r,
              Paint()..color = c..style = PaintingStyle.stroke..strokeWidth = isCurrent ? 2.5 : 1.5);
          _drawText(canvas, animalIcons[i % animalIcons.length], pos, cs * 0.26);

        } else {
          //  PLANET SKIN 
          // Planet glow halo
          canvas.drawCircle(pos, r + cs * 0.05,
              Paint()..color = c.withValues(alpha: 0.3)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4));
          // Planet body
          canvas.drawCircle(pos, r, Paint()..color = c.withValues(alpha: 0.2));
          canvas.drawCircle(pos, r,
              Paint()..color = c..style = PaintingStyle.stroke..strokeWidth = isCurrent ? 2.5 : 1.5);
          // Planet emoji
          _drawText(canvas, kPlanetIcons[i % kPlanetIcons.length], pos, cs * 0.26);
        }

        // Pulse ring (active player)
        if (isCurrent) {
          canvas.drawCircle(pos, cs * 0.27,
              Paint()..color = Colors.white.withValues(alpha: 0.35)..style = PaintingStyle.stroke..strokeWidth = 1.5);
          canvas.drawCircle(pos, cs * 0.33,
              Paint()..color = c.withValues(alpha: 0.2)..style = PaintingStyle.stroke..strokeWidth = 1.0);
        }
    }
  }

  void _drawText(Canvas canvas, String text, Offset center, double size, {Color color = Colors.white}) {
    final tp = TextPainter(
      text: TextSpan(text: text, style: TextStyle(color: color, fontSize: size, fontWeight: FontWeight.bold)),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, center - Offset(tp.width / 2, tp.height / 2));
  }

  @override bool shouldRepaint(_BoardPainter old) => true;
}

class _SnakeLadderPainter extends CustomPainter {
  final MapConfig mapConfig;
  const _SnakeLadderPainter({required this.mapConfig});

  @override
  void paint(Canvas canvas, Size size) {
    final cs = size.width / 10;

    Offset cellCenter(int n) {
      final idx = n - 1;
      final row = idx ~/ 10;
      final col = row % 2 == 0 ? idx % 10 : 9 - (idx % 10);
      return Offset((col + 0.5) * cs, ((9 - row) + 0.5) * cs);
    }

    void drawText(String text, Offset center, double fontSize) {
      final tp = TextPainter(
        text: TextSpan(text: text, style: TextStyle(fontSize: fontSize)),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, center - Offset(tp.width / 2, tp.height / 2));
    }

    void drawProperSnake(Canvas canvas, Offset head, Offset tail, Color color, double cs) {
      // Curved body
      final ctrl1 = Offset(head.dx + (tail.dx - head.dx) * 0.3 + cs * 0.7, head.dy + (tail.dy - head.dy) * 0.15);
      final ctrl2 = Offset(head.dx + (tail.dx - head.dx) * 0.7 - cs * 0.5, head.dy + (tail.dy - head.dy) * 0.7);

      final path = Path()..moveTo(head.dx, head.dy)..cubicTo(ctrl1.dx, ctrl1.dy, ctrl2.dx, ctrl2.dy, tail.dx, tail.dy);

      // Shadow glow
      canvas.drawPath(path, Paint()
        ..color = color.withValues(alpha: 0.25)
        ..strokeWidth = cs * 0.38
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5));

      // Thick dark outline (snake body shape)
      canvas.drawPath(path, Paint()
        ..color = color.withValues(alpha: 0.6)
        ..strokeWidth = cs * 0.32
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round);

      // Body highlight stripe
      canvas.drawPath(path, Paint()
        ..color = color.withValues(alpha: 0.9)
        ..strokeWidth = cs * 0.22
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round);

      // Center bright line
      canvas.drawPath(path, Paint()
        ..color = Colors.white.withValues(alpha: 0.25)
        ..strokeWidth = cs * 0.08
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round);

      // Scale pattern dots along body
      for (double t = 0.15; t < 0.95; t += 0.12) {
        // Approximate point on cubic bezier
        final bx = _cubicBezier(head.dx, ctrl1.dx, ctrl2.dx, tail.dx, t);
        final by = _cubicBezier(head.dy, ctrl1.dy, ctrl2.dy, tail.dy, t);
        canvas.drawCircle(Offset(bx, by), cs * 0.06,
          Paint()..color = Colors.black.withValues(alpha: 0.25));
        canvas.drawCircle(Offset(bx, by), cs * 0.04,
          Paint()..color = Colors.white.withValues(alpha: 0.15));
      }

      //  HEAD  proper snake head 
      // Head glow
      canvas.drawCircle(head, cs * 0.22,
        Paint()..color = color.withValues(alpha: 0.35)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8));
      // Head body
      canvas.drawCircle(head, cs * 0.2, Paint()..color = color.withValues(alpha: 0.8));
      canvas.drawCircle(head, cs * 0.18,
        Paint()..color = color..style = PaintingStyle.fill);
      // Head highlight
      canvas.drawCircle(head - Offset(cs * 0.06, cs * 0.06), cs * 0.07,
        Paint()..color = Colors.white.withValues(alpha: 0.35));
      // Head border
      canvas.drawCircle(head, cs * 0.19,
        Paint()..color = Colors.white.withValues(alpha: 0.5)
          ..style = PaintingStyle.stroke..strokeWidth = 1.5);

      // Eyes (two white dots with black pupils)
      final eyeOffset = cs * 0.07;
      // Left eye
      canvas.drawCircle(head + Offset(-eyeOffset, -eyeOffset * 0.8), cs * 0.055, Paint()..color = Colors.white);
      canvas.drawCircle(head + Offset(-eyeOffset, -eyeOffset * 0.8), cs * 0.03, Paint()..color = Colors.black);
      canvas.drawCircle(head + Offset(-eyeOffset + cs*0.01, -eyeOffset * 0.8 - cs*0.01), cs * 0.012, Paint()..color = Colors.white.withValues(alpha: 0.7));
      // Right eye
      canvas.drawCircle(head + Offset(eyeOffset, -eyeOffset * 0.8), cs * 0.055, Paint()..color = Colors.white);
      canvas.drawCircle(head + Offset(eyeOffset, -eyeOffset * 0.8), cs * 0.03, Paint()..color = Colors.black);
      canvas.drawCircle(head + Offset(eyeOffset + cs*0.01, -eyeOffset * 0.8 - cs*0.01), cs * 0.012, Paint()..color = Colors.white.withValues(alpha: 0.7));

      // Forked tongue
      final tongueBase = head + Offset(0, cs * 0.16);
      canvas.drawLine(tongueBase, tongueBase + Offset(0, cs * 0.1),
        Paint()..color = Colors.red.shade400..strokeWidth = cs * 0.025..strokeCap = StrokeCap.round);
      canvas.drawLine(tongueBase + Offset(0, cs * 0.1), tongueBase + Offset(-cs * 0.06, cs * 0.17),
        Paint()..color = Colors.red.shade400..strokeWidth = cs * 0.02..strokeCap = StrokeCap.round);
      canvas.drawLine(tongueBase + Offset(0, cs * 0.1), tongueBase + Offset(cs * 0.06, cs * 0.17),
        Paint()..color = Colors.red.shade400..strokeWidth = cs * 0.02..strokeCap = StrokeCap.round);

      // Theme emoji label
      drawText(mapConfig.snakeEmoji, head - Offset(0, cs * 0.32), cs * 0.22);
    }

    void drawProperLadder(Canvas canvas, Offset bottom, Offset top, Color color, double cs) {
      final dx = top.dx - bottom.dx;
      final dy = top.dy - bottom.dy;
      final len = sqrt(dx*dx + dy*dy);
      final px = -dy / len * cs * 0.12;
      final py = dx / len * cs * 0.12;

      final l1s = bottom + Offset(px, py);
      final l1e = top    + Offset(px, py);
      final l2s = bottom - Offset(px, py);
      final l2e = top    - Offset(px, py);

      // Rail shadow
      canvas.drawLine(l1s + const Offset(1.5, 1.5), l1e + const Offset(1.5, 1.5),
        Paint()..color = Colors.black45..strokeWidth = cs * 0.11..strokeCap = StrokeCap.round);
      canvas.drawLine(l2s + const Offset(1.5, 1.5), l2e + const Offset(1.5, 1.5),
        Paint()..color = Colors.black45..strokeWidth = cs * 0.11..strokeCap = StrokeCap.round);

      // Rail dark
      canvas.drawLine(l1s, l1e, Paint()..color = color.withValues(alpha: 0.5)..strokeWidth = cs * 0.1..strokeCap = StrokeCap.round);
      canvas.drawLine(l2s, l2e, Paint()..color = color.withValues(alpha: 0.5)..strokeWidth = cs * 0.1..strokeCap = StrokeCap.round);

      // Rail bright
      canvas.drawLine(l1s, l1e, Paint()..color = color..strokeWidth = cs * 0.06..strokeCap = StrokeCap.round);
      canvas.drawLine(l2s, l2e, Paint()..color = color..strokeWidth = cs * 0.06..strokeCap = StrokeCap.round);

      // Rail shine
      canvas.drawLine(l1s, l1e, Paint()..color = Colors.white.withValues(alpha: 0.3)..strokeWidth = cs * 0.02..strokeCap = StrokeCap.round);
      canvas.drawLine(l2s, l2e, Paint()..color = Colors.white.withValues(alpha: 0.3)..strokeWidth = cs * 0.02..strokeCap = StrokeCap.round);

      // Steps (rungs)
      final steps = max(3, (len / (cs * 0.48)).round()).clamp(3, 12);
      for (int i = 1; i < steps; i++) {
        final frac = i / steps;
        final rungL = l1s + (l1e - l1s) * frac;
        final rungR = l2s + (l2e - l2s) * frac;
        // shadow
        canvas.drawLine(rungL + const Offset(1, 1), rungR + const Offset(1, 1),
          Paint()..color = Colors.black38..strokeWidth = cs * 0.08..strokeCap = StrokeCap.round);
        // dark
        canvas.drawLine(rungL, rungR,
          Paint()..color = color.withValues(alpha: 0.6)..strokeWidth = cs * 0.075..strokeCap = StrokeCap.round);
        // bright
        canvas.drawLine(rungL, rungR,
          Paint()..color = color.withValues(alpha: 0.9)..strokeWidth = cs * 0.04..strokeCap = StrokeCap.round);
      }

      // End caps
      canvas.drawCircle(bottom, cs * 0.08, Paint()..color = color);
      canvas.drawCircle(top, cs * 0.08, Paint()..color = color);

      // Theme emoji
      drawText(mapConfig.ladderEmoji, bottom + Offset(0, cs * 0.05), cs * 0.24);
    }

    //  DRAW SNAKES 
    for (final e in mapConfig.snakes.entries) {
      drawProperSnake(canvas, cellCenter(e.key), cellCenter(e.value), mapConfig.snakeColor, cs);
    }

    //  DRAW LADDERS 
    for (final e in mapConfig.ladders.entries) {
      drawProperLadder(canvas, cellCenter(e.key), cellCenter(e.value), mapConfig.ladderColor, cs);
    }
  }

  // Helper: cubic bezier point
  double _cubicBezier(double p0, double p1, double p2, double p3, double t) {
    final mt = 1 - t;
    return mt*mt*mt*p0 + 3*mt*mt*t*p1 + 3*mt*t*t*p2 + t*t*t*p3;
  }

  @override bool shouldRepaint(_SnakeLadderPainter old) => old.mapConfig != mapConfig;
}

// 
// SKIN PICKER WIDGET
// 
class _SkinPicker extends StatelessWidget {
  final PawnSkin selected;
  final void Function(PawnSkin) onChanged;
  const _SkinPicker({required this.selected, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Row(children: PawnSkin.values.map((skin) {
      final isSel = selected == skin;
      return Expanded(child: Padding(
        padding: EdgeInsets.only(right: skin != PawnSkin.values.last ? 10 : 0),
        child: GestureDetector(
          onTap: () => onChanged(skin),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: isSel ? Colors.amber : Colors.white12, width: isSel ? 2 : 1),
              color: isSel ? Colors.amber.withValues(alpha: 0.12) : Colors.white.withValues(alpha: 0.04),
              boxShadow: isSel ? [BoxShadow(color: Colors.amber.withValues(alpha: 0.25), blurRadius: 12)] : [],
            ),
            child: Column(children: [
              // Preview 4 pion kecil
              Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(4, (i) =>
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 2),
                  child: _PawnPreview(playerIdx: i, skin: skin, size: 22),
                ),
              )),
              const SizedBox(height: 8),
              Text(skin.label, style: TextStyle(
                color: isSel ? Colors.amber : Colors.white38,
                fontFamily: 'Orbitron', fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1)),
            ]),
          ),
        ),
      ));
    }).toList());
  }
}

//  Pawn Preview (static) 
class _PawnPreview extends StatelessWidget {
  final int playerIdx;
  final PawnSkin skin;
  final double size;
  const _PawnPreview({required this.playerIdx, required this.skin, required this.size});

  @override
  Widget build(BuildContext context) {
    final color = _kColors[playerIdx % _kColors.length];
    switch (skin) {
      case PawnSkin.circle:
        return Container(
          width: size, height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle, color: color,
            border: Border.all(color: Colors.white54, width: 1.5),
            boxShadow: [BoxShadow(color: color.withValues(alpha: 0.5), blurRadius: 6)],
          ),
          child: Center(child: Text('P${playerIdx+1}',
            style: TextStyle(color: Colors.white, fontSize: size * 0.3, fontWeight: FontWeight.bold))),
        );
      case PawnSkin.chess:
        return Container(
          width: size, height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle, color: color.withValues(alpha: 0.85),
            border: Border.all(color: Colors.white60, width: 1.5),
            boxShadow: [BoxShadow(color: color.withValues(alpha: 0.5), blurRadius: 6)],
          ),
          child: Center(child: Text(kChessIcons[playerIdx % kChessIcons.length],
            style: TextStyle(fontSize: size * 0.52))),
        );
      case PawnSkin.planet:
        return Container(
          width: size, height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle, color: color.withValues(alpha: 0.2),
            border: Border.all(color: color, width: 1.5),
            boxShadow: [BoxShadow(color: color.withValues(alpha: 0.5), blurRadius: 6)],
          ),
          child: Center(child: Text(kPlanetIcons[playerIdx % kPlanetIcons.length],
            style: TextStyle(fontSize: size * 0.52))),
        );
      case PawnSkin.animal:
        const animalIcons = ['🦁', '🐯', '🐼', '🦊'];
        return Container(
          width: size, height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle, color: color.withValues(alpha: 0.2),
            border: Border.all(color: color, width: 1.5),
            boxShadow: [BoxShadow(color: color.withValues(alpha: 0.5), blurRadius: 6)],
          ),
          child: Center(child: Text(animalIcons[playerIdx % animalIcons.length],
            style: TextStyle(fontSize: size * 0.52))),
        );
    }
  }
}

//  Player Strip 
class _PlayerStrip extends StatelessWidget {
  final List<SnakeLadderPlayer> players;
  final int currentIdx;
  const _PlayerStrip({required this.players, required this.currentIdx});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 64,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        itemCount: players.length,
        itemBuilder: (_, i) {
          final p = players[i];
          final isCur = i == currentIdx;
          final c = _kColors[i % _kColors.length];
          return AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            margin: const EdgeInsets.only(right: 8),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: isCur ? c : Colors.white12, width: isCur ? 2 : 1),
              color: isCur ? c.withValues(alpha: 0.18) : Colors.white.withValues(alpha: 0.03),
              boxShadow: isCur ? [BoxShadow(color: c.withValues(alpha: 0.35), blurRadius: 12)] : [],
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
              Row(mainAxisSize: MainAxisSize.min, children: [
                Text(_kEmojis[i % _kEmojis.length], style: const TextStyle(fontSize: 11)),
                const SizedBox(width: 4),
                Text(p.name, style: TextStyle(color: isCur ? Colors.white : Colors.white60,
                    fontWeight: FontWeight.bold, fontFamily: 'Orbitron', fontSize: 9),
                  overflow: TextOverflow.ellipsis),
                if (p.isBot) ...[const SizedBox(width: 4), const Text('🤖', style: TextStyle(fontSize: 9))],
              ]),
              const SizedBox(height: 2),
              Text('Kotak: ${p.position}', style: const TextStyle(color: Colors.white38, fontSize: 8, fontFamily: 'ShareTechMono')),
            ]),
          );
        },
      ),
    );
  }
}

//  Dice Face 
class _DiceFace extends StatelessWidget {
  final int value;
  const _DiceFace({required this.value});

  static const _dots = {
    1: [Offset(0.5,0.5)],
    2: [Offset(0.25,0.25), Offset(0.75,0.75)],
    3: [Offset(0.25,0.25), Offset(0.5,0.5), Offset(0.75,0.75)],
    4: [Offset(0.25,0.25), Offset(0.75,0.25), Offset(0.25,0.75), Offset(0.75,0.75)],
    5: [Offset(0.25,0.25), Offset(0.75,0.25), Offset(0.5,0.5), Offset(0.25,0.75), Offset(0.75,0.75)],
    6: [Offset(0.25,0.18), Offset(0.75,0.18), Offset(0.25,0.5), Offset(0.75,0.5), Offset(0.25,0.82), Offset(0.75,0.82)],
  };

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (_, c) {
      final sz = c.maxWidth;
      return Stack(children: (_dots[value] ?? []).map((p) => Positioned(
        left: p.dx * sz - sz * 0.08,
        top: p.dy * sz - sz * 0.08,
        child: Container(width: sz * 0.18, height: sz * 0.18,
          decoration: const BoxDecoration(color: Color(0xFF111111), shape: BoxShape.circle)),
      )).toList());
    });
  }
}

// 
// RESULT PAGE
// 
// 
// CONFETTI PARTICLE SYSTEM
// 
class _ConfettiParticle {
  double x, y, vx, vy, angle, angleV, size;
  Color color;
  bool isRect;
  _ConfettiParticle(this.x, this.y, this.vx, this.vy, this.angle, this.angleV, this.size, this.color, this.isRect);
}

class _ConfettiPainter extends CustomPainter {
  final List<_ConfettiParticle> particles;
  _ConfettiPainter(this.particles);

  @override
  void paint(Canvas canvas, Size size) {
    for (final p in particles) {
      final paint = Paint()..color = p.color;
      canvas.save();
      canvas.translate(p.x, p.y);
      canvas.rotate(p.angle);
      if (p.isRect) {
        canvas.drawRect(Rect.fromCenter(center: Offset.zero, width: p.size, height: p.size * 0.5), paint);
      } else {
        canvas.drawCircle(Offset.zero, p.size * 0.5, paint);
      }
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(_ConfettiPainter old) => true;
}

class _ConfettiWidget extends StatefulWidget {
  final bool show;
  const _ConfettiWidget({required this.show});
  @override State<_ConfettiWidget> createState() => _ConfettiWidgetState();
}

class _ConfettiWidgetState extends State<_ConfettiWidget> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  final List<_ConfettiParticle> _particles = [];
  final _rng = Random();
  final _colors = [
    Colors.amber, Colors.red, Colors.blue, Colors.green,
    Colors.purple, Colors.orange, Colors.pink, Colors.cyan,
  ];

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 4))
      ..addListener(_tick);
    if (widget.show) _start();
  }

  @override
  void didUpdateWidget(_ConfettiWidget old) {
    super.didUpdateWidget(old);
    if (widget.show && !old.show) _start();
  }

  void _start() {
    _particles.clear();
    // Spawn 120 confetti particles from top
    for (int i = 0; i < 120; i++) {
      final screenW = 400.0; // estimate, recalc in build
      _particles.add(_ConfettiParticle(
        _rng.nextDouble() * screenW,
        -20 - _rng.nextDouble() * 200,
        (_rng.nextDouble() - 0.5) * 4,
        2 + _rng.nextDouble() * 5,
        _rng.nextDouble() * pi * 2,
        (_rng.nextDouble() - 0.5) * 0.15,
        6 + _rng.nextDouble() * 8,
        _colors[_rng.nextInt(_colors.length)].withValues(alpha: 0.85),
        _rng.nextBool(),
      ));
    }
    _ctrl.forward(from: 0);
  }

  void _tick() {
    if (!mounted) return;
    for (final p in _particles) {
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.12; // gravity
      p.vx *= 0.99;
      p.angle += p.angleV;
    }
    setState(() {});
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: SizedBox.expand(
        child: CustomPaint(painter: _ConfettiPainter(_particles)),
      ),
    );
  }
}

// 
// RESULT PAGE  Win Screen dengan animasi lengkap
// 
class _ResultPage extends StatefulWidget {
  final String winnerName;
  final List<SnakeLadderPlayer> players;
  final String username, userRole;
  final List<SnakeLadderPlayer>? originalPlayers;
  final bool isOnline;
  final int betAmount;
  final String sessionKey;

  const _ResultPage({
    required this.winnerName,
    required this.players,
    required this.username,
    required this.userRole,
    this.originalPlayers,
    this.isOnline = false,
    this.betAmount = 0,
    this.sessionKey = '',
  });
  @override State<_ResultPage> createState() => _ResultPageState();
}

class _ResultPageState extends State<_ResultPage> with TickerProviderStateMixin {
  late AnimationController _mainCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _staggerCtrl;
  late Animation<double> _trophyScale;
  late Animation<double> _trophyGlow;
  late Animation<double> _titleSlide;
  late Animation<double> _titleFade;
  late Animation<double> _pulse;

  bool _showConfetti = false;

  // Bet result
  bool _betProcessing = false;
  bool _betDone = false;
  String? _betError;
  int _newSaldo = 0;

  @override
  void initState() {
    super.initState();
    _processBet();
    _submitLeaderboard();

    // Main entry animation
    _mainCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200));
    _trophyScale = CurvedAnimation(parent: _mainCtrl, curve: const Interval(0.0, 0.55, curve: Curves.elasticOut));
    _trophyGlow  = CurvedAnimation(parent: _mainCtrl, curve: const Interval(0.3, 0.7, curve: Curves.easeOut));
    _titleSlide  = Tween(begin: 40.0, end: 0.0).animate(CurvedAnimation(parent: _mainCtrl, curve: const Interval(0.4, 0.8, curve: Curves.easeOutCubic)));
    _titleFade   = CurvedAnimation(parent: _mainCtrl, curve: const Interval(0.4, 0.75, curve: Curves.easeIn));

    // Pulse glow on trophy
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))..repeat(reverse: true);
    _pulse = Tween(begin: 0.85, end: 1.15).animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    // Stagger for list items
    _staggerCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));

    // Play sound and start animations
    _Sfx.play('ludo_win');
    _mainCtrl.forward();
    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted) setState(() => _showConfetti = true);
    });
    Future.delayed(const Duration(milliseconds: 700), () {
      if (mounted) _staggerCtrl.forward();
    });
  }

  @override
  void dispose() {
    _mainCtrl.dispose();
    _pulseCtrl.dispose();
    _staggerCtrl.dispose();
    super.dispose();
  }

  // Submit hasil game ke leaderboard (semua mode: offline, bot, campaign, online)
  Future<void> _submitLeaderboard() async {
    try {
      // Hanya submit player manusia (bukan bot)
      final humanPlayers = widget.players.where((p) => !p.isBot).toList();
      if (humanPlayers.isEmpty) return;

      final playerData = humanPlayers.map((p) => {
        'name': p.name,
        'isWinner': p.name == widget.winnerName,
        'position': p.position,
        'snakesHit': p.snakesHit,
        'laddersClimbed': p.laddersClimbed,
        'totalRolls': p.totalRolls,
        'role': widget.userRole,
      }).toList();

      await LeaderboardApi.submitResult(
        players: playerData,
        winnerName: widget.winnerName,
        roomCode: widget.isOnline ? 'online' : 'offline',
        duration: 0,
      );
    } catch (_) {}
  }

  // Process bet on game over
  Future<void> _processBet() async {
    if (widget.betAmount <= 0 || widget.sessionKey.isEmpty) return;
    final isWinner = widget.winnerName == widget.username;
    if (!isWinner) {
      // Kalah  saldo sudah dipotong saat mulai, tidak perlu aksi
      if (mounted) setState(() { _betDone = true; });
      return;
    }
    // Menang  claim total pot
    if (mounted) setState(() => _betProcessing = true);
    final totalPot = widget.betAmount * widget.players.length;
    final res = await BetApi.claimWin(widget.sessionKey, totalPot);
    if (mounted) {
      setState(() {
        _betProcessing = false;
        _betDone = true;
        if (res['valid'] == true) {
          _newSaldo = (res['saldo'] as num?)?.toInt() ?? 0;
        } else {
          _betError = res['message']?.toString() ?? 'Gagal claim kemenangan';
        }
      });
    }
  }

  // Main Lagi  restart dengan player yang sama
  void _mainLagi() {
    final List<SnakeLadderPlayer> players = widget.originalPlayers ?? widget.players.asMap().entries.map((e) =>
      SnakeLadderPlayer(name: e.value.name, pawnColor: e.value.pawnColor, role: e.value.role, isBot: e.value.isBot, pawnSkin: e.value.pawnSkin, playerIndex: e.key)
    ).toList();

    Navigator.of(context).pop(); // balik ke result
    Navigator.pushReplacement(context, _slideRoute(
      _GamePage(
        players: players,
        isOnline: false,
        myIndex: 0,
        onGameOver: (winner, all) => Navigator.pushReplacement(context, _slideRoute(
          _ResultPage(
            winnerName: winner.name,
            players: all,
            username: widget.username,
            userRole: widget.userRole,
            originalPlayers: players,
          ),
        )),
      ),
    ));
  }

  // Balik ke mode select
  void _kembaliMenu() {
    Navigator.of(context).popUntil((r) => r.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    final isWinner = widget.winnerName == widget.username;
    final winColor = isWinner ? Colors.amber : const Color(0xFF6C63FF);
    final sorted = [...widget.players]..sort((a, b) => b.position.compareTo(a.position));
    final medals = ['🥇', '🥈', '🥉', '4️�'];

    return Scaffold(
      backgroundColor: const Color(0xFF060B14),
      body: Stack(children: [

        //  BG gradient 
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                winColor.withValues(alpha: 0.22),
                const Color(0xFF060B14),
                const Color(0xFF060B14),
              ],
              stops: const [0.0, 0.45, 1.0],
            ),
          ),
        ),

        //  BG star dots 
        ...List.generate(30, (i) {
          final rng = Random(i * 7);
          return Positioned(
            left: rng.nextDouble() * MediaQuery.of(context).size.width,
            top: rng.nextDouble() * MediaQuery.of(context).size.height,
            child: Container(
              width: 2, height: 2,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withValues(alpha: 0.1 + rng.nextDouble() * 0.2),
              ),
            ),
          );
        }),

        //  Confetti 
        _ConfettiWidget(show: _showConfetti && isWinner),

        //  MAIN CONTENT 
        SafeArea(
          child: Column(children: [
            const SizedBox(height: 20),

            //  TROPHY 
            AnimatedBuilder(
              animation: Listenable.merge([_mainCtrl, _pulseCtrl]),
              builder: (_, child) => Transform.scale(
                scale: _trophyScale.value,
                child: Stack(alignment: Alignment.center, children: [
                  // outer glow pulse
                  Transform.scale(
                    scale: _pulse.value,
                    child: Container(
                      width: 130, height: 130,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: winColor.withValues(alpha: 0.35 * _trophyGlow.value),
                            blurRadius: 60, spreadRadius: 10,
                          ),
                        ],
                      ),
                    ),
                  ),
                  // middle ring
                  Container(
                    width: 110, height: 110,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: winColor.withValues(alpha: 0.5), width: 2),
                      color: winColor.withValues(alpha: 0.08),
                    ),
                  ),
                  // inner circle
                  Container(
                    width: 88, height: 88,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: winColor.withValues(alpha: 0.15),
                      border: Border.all(color: winColor, width: 2.5),
                      boxShadow: [BoxShadow(color: winColor.withValues(alpha: 0.4), blurRadius: 20)],
                    ),
                    child: Center(
                      child: Text(
                        isWinner ? '🏆' : '�',
                        style: const TextStyle(fontSize: 44),
                      ),
                    ),
                  ),
                ]),
              ),
            ),

            const SizedBox(height: 18),

            //  TITLE 
            AnimatedBuilder(
              animation: _mainCtrl,
              builder: (_, child) => Opacity(
                opacity: _titleFade.value.clamp(0.0, 1.0),
                child: Transform.translate(
                  offset: Offset(0, _titleSlide.value),
                  child: child,
                ),
              ),
              child: Column(children: [
                Text(
                  isWinner ? '🎉 KAMU MENANG!' : 'GAME SELESAI',
                  style: TextStyle(
                    color: Colors.white,
                    fontFamily: 'Orbitron',
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                    shadows: [
                      Shadow(color: winColor, blurRadius: 24),
                      Shadow(color: winColor.withValues(alpha: 0.5), blurRadius: 48),
                    ],
                  ),
                ),
                const SizedBox(height: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: winColor.withValues(alpha: 0.12),
                    border: Border.all(color: winColor.withValues(alpha: 0.4)),
                  ),
                  child: Text(
                    'Pemenang: ${widget.winnerName}',
                    style: TextStyle(
                      color: winColor,
                      fontFamily: 'ShareTechMono',
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ]),
            ),

            const SizedBox(height: 18),

            //  BET RESULT 
            if (widget.betAmount > 0)
              BetResultCard(
                isWinner: widget.winnerName == widget.username,
                betAmount: widget.betAmount,
                totalPot: widget.betAmount * widget.players.length,
                playerCount: widget.players.length,
                isLoading: _betProcessing,
                errorMsg: _betError,
              ),

            //  RANKING LIST 
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 18),
                itemCount: sorted.length,
                itemBuilder: (_, i) {
                  final p = sorted[i];
                  final isW = p.name == widget.winnerName;
                  final idx = widget.players.indexOf(p);
                  final c = idx >= 0 ? _kColors[idx % _kColors.length] : Colors.white;

                  return TweenAnimationBuilder<double>(
                    tween: Tween(begin: 0.0, end: 1.0),
                    duration: Duration(milliseconds: 350 + i * 130),
                    curve: Curves.easeOutCubic,
                    builder: (_, v, child) => Opacity(
                      opacity: v.clamp(0.0, 1.0),
                      child: Transform.translate(offset: Offset(30 * (1 - v), 0), child: child),
                    ),
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: isW ? c : Colors.white.withValues(alpha: 0.08),
                          width: isW ? 2 : 1,
                        ),
                        color: isW ? c.withValues(alpha: 0.12) : Colors.white.withValues(alpha: 0.03),
                        boxShadow: isW ? [BoxShadow(color: c.withValues(alpha: 0.2), blurRadius: 16)] : [],
                      ),
                      child: Row(children: [
                        // Medal
                        Text(i < medals.length ? medals[i] : '${i+1}',
                            style: const TextStyle(fontSize: 24)),
                        const SizedBox(width: 10),
                        // Pawn dot
                        Container(
                          width: 10, height: 10,
                          decoration: BoxDecoration(shape: BoxShape.circle, color: c,
                            boxShadow: [BoxShadow(color: c.withValues(alpha: 0.6), blurRadius: 6)]),
                        ),
                        const SizedBox(width: 10),
                        // Name + stats
                        Expanded(child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(children: [
                              Text(
                                p.name,
                                style: TextStyle(
                                  color: isW ? Colors.white : Colors.white70,
                                  fontFamily: 'Orbitron',
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              if (p.isBot) ...[
                                const SizedBox(width: 5),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(3),
                                    color: Colors.white.withValues(alpha: 0.08),
                                  ),
                                  child: const Text('BOT', style: TextStyle(color: Colors.white38, fontSize: 8)),
                                ),
                              ],
                            ]),
                            const SizedBox(height: 3),
                            Text(
                              '� ${p.snakesHit}x  🪜 ${p.laddersClimbed}x  🎲 ${p.totalRolls}x',
                              style: const TextStyle(color: Colors.white30, fontSize: 9, fontFamily: 'ShareTechMono'),
                            ),
                          ],
                        )),
                        // Position badge
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(6),
                            color: isW ? c.withValues(alpha: 0.2) : Colors.white.withValues(alpha: 0.05),
                          ),
                          child: Text(
                            'Kotak ${p.position}',
                            style: TextStyle(
                              color: isW ? c : Colors.white38,
                              fontWeight: FontWeight.bold,
                              fontSize: 11,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                        ),
                      ]),
                    ),
                  );
                },
              ),
            ),

            //  BUTTONS 
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              child: Column(children: [
                // Main Lagi  full width, prominent
                if (!widget.isOnline) ...[
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _mainLagi,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: winColor,
                        foregroundColor: Colors.black,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        elevation: 8,
                        shadowColor: winColor.withValues(alpha: 0.5),
                      ),
                      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                        const Text('�', style: TextStyle(fontSize: 18)),
                        const SizedBox(width: 8),
                        const Text('MAIN LAGI',
                          style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 2)),
                      ]),
                    ),
                  ),
                  const SizedBox(height: 10),
                ],

                // Bottom row: Leaderboard + Menu
                Row(children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => Navigator.push(context, _slideRoute(
                        LeaderboardPage(username: widget.username, userRole: widget.userRole))),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white.withValues(alpha: 0.08),
                        foregroundColor: Colors.white70,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                          side: BorderSide(color: Colors.white.withValues(alpha: 0.15)),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 13),
                        elevation: 0,
                      ),
                      child: const Text('🏆 Leaderboard',
                        style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 10)),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _kembaliMenu,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white.withValues(alpha: 0.08),
                        foregroundColor: Colors.white70,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                          side: BorderSide(color: Colors.white.withValues(alpha: 0.15)),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 13),
                        elevation: 0,
                      ),
                      child: const Text('� Menu',
                        style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 10)),
                    ),
                  ),
                ]),
              ]),
            ),
          ]),
        ),
      ]),
    );
  }
}

// 
// ONLINE LOBBY PAGE
// 

// 
// CAMPAIGN PAGE
// 

// 
// SHOP SYSTEM  Skin Pion, Map, Efek Dadu
// 
class ShopItem {
  final String id, name, emoji, desc;
  final int price;
  final String category; // 'pion', 'map', 'dice'
  const ShopItem({required this.id, required this.name, required this.emoji,
    required this.desc, required this.price, required this.category});
}

const kShopItems = [
  // SKIN PION
  ShopItem(id:'pion_star',   name:'Star',    emoji:'�', desc:'Pion bintang berkilau',  price:500,  category:'pion'),
  ShopItem(id:'pion_fire',   name:'Fire',    emoji:'�', desc:'Pion api membara',        price:800,  category:'pion'),
  ShopItem(id:'pion_crown',  name:'Crown',   emoji:'�', desc:'Pion mahkota raja',       price:1200, category:'pion'),
  ShopItem(id:'pion_ghost',  name:'Ghost',   emoji:'�', desc:'Pion hantu misterius',    price:600,  category:'pion'),
  ShopItem(id:'pion_robot',  name:'Robot',   emoji:'🤖', desc:'Pion robot futuristik',   price:700,  category:'pion'),
  ShopItem(id:'pion_alien',  name:'Alien',   emoji:'�', desc:'Pion alien dari luar angkasa', price:900, category:'pion'),
  ShopItem(id:'pion_ninja',  name:'Ninja',   emoji:'🥷', desc:'Pion ninja diam-diam',    price:1000, category:'pion'),
  ShopItem(id:'pion_dragon', name:'Dragon',  emoji:'�', desc:'Pion naga perkasa',       price:1500, category:'pion'),
  ShopItem(id:'pion_skull',  name:'Skull',   emoji:'�', desc:'Pion tengkorak seram',    price:1100, category:'pion'),
  ShopItem(id:'pion_gem',    name:'Gem',     emoji:'💎', desc:'Pion permata berharga',   price:2000, category:'pion'),
  // SKIN PION EXTRA (total 100)
  ShopItem(id:'pion_cat', name:'Cat', emoji:'�', desc:'Pion kucing imut', price:300, category:'pion'),
  ShopItem(id:'pion_dog', name:'Dog', emoji:'�', desc:'Pion anjing lucu', price:300, category:'pion'),
  ShopItem(id:'pion_lion', name:'Lion', emoji:'�', desc:'Pion singa gagah', price:400, category:'pion'),
  ShopItem(id:'pion_fox', name:'Fox', emoji:'�', desc:'Pion rubah licik', price:350, category:'pion'),
  ShopItem(id:'pion_wolf', name:'Wolf', emoji:'�', desc:'Pion serigala liar', price:400, category:'pion'),
  ShopItem(id:'pion_bear', name:'Bear', emoji:'�', desc:'Pion beruang kuat', price:450, category:'pion'),
  ShopItem(id:'pion_panda', name:'Panda', emoji:'�', desc:'Pion panda lucu', price:400, category:'pion'),
  ShopItem(id:'pion_tiger', name:'Tiger', emoji:'�', desc:'Pion harimau ganas', price:500, category:'pion'),
  ShopItem(id:'pion_monkey', name:'Monkey', emoji:'�', desc:'Pion monyet nakal', price:350, category:'pion'),
  ShopItem(id:'pion_horse', name:'Horse', emoji:'�', desc:'Pion kuda kencang', price:400, category:'pion'),
  ShopItem(id:'pion_unicorn', name:'Unicorn', emoji:'�', desc:'Pion unicorn ajaib', price:800, category:'pion'),
  ShopItem(id:'pion_penguin', name:'Penguin', emoji:'�', desc:'Pion penguin lucu', price:300, category:'pion'),
  ShopItem(id:'pion_owl', name:'Owl', emoji:'�', desc:'Pion burung hantu', price:400, category:'pion'),
  ShopItem(id:'pion_eagle', name:'Eagle', emoji:'�', desc:'Pion elang perkasa', price:500, category:'pion'),
  ShopItem(id:'pion_phoenix', name:'Phoenix', emoji:'�', desc:'Pion phoenix abadi', price:900, category:'pion'),
  ShopItem(id:'pion_dragon2', name:'Dragon2', emoji:'�', desc:'Pion naga klasik', price:1000, category:'pion'),
  ShopItem(id:'pion_dino', name:'Dino', emoji:'�', desc:'Pion dinosaurus', price:600, category:'pion'),
  ShopItem(id:'pion_t_rex', name:'T-Rex', emoji:'�', desc:'Pion T-Rex buas', price:700, category:'pion'),
  ShopItem(id:'pion_shark', name:'Shark', emoji:'�', desc:'Pion hiu ganas', price:500, category:'pion'),
  ShopItem(id:'pion_octopus', name:'Octopus', emoji:'�', desc:'Pion gurita cerdas', price:450, category:'pion'),
  ShopItem(id:'pion_crab', name:'Crab', emoji:'�', desc:'Pion kepiting merah', price:350, category:'pion'),
  ShopItem(id:'pion_lobster', name:'Lobster', emoji:'�', desc:'Pion lobster lezat', price:400, category:'pion'),
  ShopItem(id:'pion_frog', name:'Frog', emoji:'�', desc:'Pion katak hijau', price:300, category:'pion'),
  ShopItem(id:'pion_snake2', name:'Snake', emoji:'�', desc:'Pion ular berbisa', price:600, category:'pion'),
  ShopItem(id:'pion_turtle', name:'Turtle', emoji:'�', desc:'Pion kura perlahan', price:300, category:'pion'),
  ShopItem(id:'pion_bee', name:'Bee', emoji:'�', desc:'Pion lebah rajin', price:350, category:'pion'),
  ShopItem(id:'pion_butterfly', name:'Butterfly', emoji:'�', desc:'Pion kupu cantik', price:400, category:'pion'),
  ShopItem(id:'pion_mushroom', name:'Mushroom', emoji:'🍄', desc:'Pion jamur ajaib', price:500, category:'pion'),
  ShopItem(id:'pion_cactus', name:'Cactus', emoji:'🌵', desc:'Pion kaktus berduri', price:350, category:'pion'),
  ShopItem(id:'pion_tree', name:'Tree', emoji:'🌲', desc:'Pion pohon kuat', price:300, category:'pion'),
  ShopItem(id:'pion_rocket', name:'Rocket', emoji:'�', desc:'Pion roket cepat', price:700, category:'pion'),
  ShopItem(id:'pion_ufo', name:'UFO', emoji:'🛸', desc:'Pion UFO misterius', price:800, category:'pion'),
  ShopItem(id:'pion_satellite', name:'Satellite', emoji:'🛰️', desc:'Pion satelit luar', price:600, category:'pion'),
  ShopItem(id:'pion_comet', name:'Comet', emoji:'��️', desc:'Pion komet melesat', price:650, category:'pion'),
  ShopItem(id:'pion_moon', name:'Moon', emoji:'🌙', desc:'Pion bulan bercahaya', price:500, category:'pion'),
  ShopItem(id:'pion_sun', name:'Sun', emoji:'�️', desc:'Pion matahari terik', price:550, category:'pion'),
  ShopItem(id:'pion_star2', name:'Star2', emoji:'🌟', desc:'Pion bintang gemerlap', price:400, category:'pion'),
  ShopItem(id:'pion_rainbow2', name:'Rainbow2', emoji:'🌈', desc:'Pion pelangi indah', price:450, category:'pion'),
  ShopItem(id:'pion_thunder2', name:'Thunder2', emoji:'�', desc:'Pion petir menyambar', price:500, category:'pion'),
  ShopItem(id:'pion_fire2', name:'Fire2', emoji:'�', desc:'Pion api membara', price:400, category:'pion'),
  ShopItem(id:'pion_ice2', name:'Ice2', emoji:'🧊', desc:'Pion es membeku', price:350, category:'pion'),
  ShopItem(id:'pion_tornado', name:'Tornado', emoji:'🌪️', desc:'Pion tornado dahsyat', price:600, category:'pion'),
  ShopItem(id:'pion_volcano2', name:'Volcano2', emoji:'🌋', desc:'Pion letusan gunung', price:700, category:'pion'),
  ShopItem(id:'pion_wave', name:'Wave', emoji:'🌊', desc:'Pion ombak lautan', price:450, category:'pion'),
  ShopItem(id:'pion_crystal', name:'Crystal', emoji:'💎', desc:'Pion kristal bening', price:900, category:'pion'),
  ShopItem(id:'pion_gold', name:'Gold', emoji:'🥇', desc:'Pion emas murni', price:1000, category:'pion'),
  ShopItem(id:'pion_silver', name:'Silver', emoji:'🥈', desc:'Pion perak kilap', price:800, category:'pion'),
  ShopItem(id:'pion_bronze', name:'Bronze', emoji:'🥉', desc:'Pion perunggu kokoh', price:700, category:'pion'),
  ShopItem(id:'pion_trophy', name:'Trophy', emoji:'🏆', desc:'Pion trofi juara', price:1200, category:'pion'),
  ShopItem(id:'pion_medal', name:'Medal', emoji:'🏅', desc:'Pion medali kehormatan', price:900, category:'pion'),
  ShopItem(id:'pion_sword', name:'Sword', emoji:'️', desc:'Pion pedang tajam', price:600, category:'pion'),
  ShopItem(id:'pion_shield', name:'Shield', emoji:'🛡️', desc:'Pion perisai kuat', price:550, category:'pion'),
  ShopItem(id:'pion_bow', name:'Bow', emoji:'🏹', desc:'Pion panah cepat', price:500, category:'pion'),
  ShopItem(id:'pion_magic', name:'Magic', emoji:'🪄', desc:'Pion tongkat sihir', price:700, category:'pion'),
  ShopItem(id:'pion_potion', name:'Potion', emoji:'🧪', desc:'Pion ramuan ajaib', price:600, category:'pion'),
  ShopItem(id:'pion_bomb', name:'Bomb', emoji:'�', desc:'Pion bom berbahaya', price:800, category:'pion'),
  ShopItem(id:'pion_dart', name:'Dart', emoji:'🎯', desc:'Pion dart tepat', price:500, category:'pion'),
  ShopItem(id:'pion_joker', name:'Joker', emoji:'🃏', desc:'Pion joker liar', price:900, category:'pion'),
  ShopItem(id:'pion_dice2', name:'Dice2', emoji:'🎲', desc:'Pion dadu nasib', price:400, category:'pion'),
  ShopItem(id:'pion_chess', name:'Chess', emoji:'��️', desc:'Pion catur klasik', price:350, category:'pion'),
  ShopItem(id:'pion_crown2', name:'Crown2', emoji:'🫅', desc:'Pion mahkota mewah', price:1500, category:'pion'),
  ShopItem(id:'pion_king', name:'King', emoji:'🤴', desc:'Pion raja agung', price:1300, category:'pion'),
  ShopItem(id:'pion_queen', name:'Queen', emoji:'�', desc:'Pion ratu cantik', price:1400, category:'pion'),
  ShopItem(id:'pion_knight', name:'Knight', emoji:'🤺', desc:'Pion ksatria berani', price:800, category:'pion'),
  ShopItem(id:'pion_wizard', name:'Wizard', emoji:'🧙', desc:'Pion penyihir bijak', price:900, category:'pion'),
  ShopItem(id:'pion_vampire', name:'Vampire', emoji:'🧛', desc:'Pion vampir malam', price:1000, category:'pion'),
  ShopItem(id:'pion_zombie', name:'Zombie', emoji:'🧟', desc:'Pion zombie bangkit', price:700, category:'pion'),
  ShopItem(id:'pion_demon', name:'Demon', emoji:'😈', desc:'Pion iblis jahat', price:1100, category:'pion'),
  ShopItem(id:'pion_angel', name:'Angel', emoji:'�', desc:'Pion malaikat suci', price:1000, category:'pion'),
  ShopItem(id:'pion_genie', name:'Genie', emoji:'🧞', desc:'Pion jin pengabul', price:1200, category:'pion'),
  ShopItem(id:'pion_mermaid', name:'Mermaid', emoji:'🧜', desc:'Pion putri duyung', price:1100, category:'pion'),
  ShopItem(id:'pion_fairy', name:'Fairy', emoji:'�', desc:'Pion peri bunga', price:900, category:'pion'),
  ShopItem(id:'pion_elf', name:'Elf', emoji:'�', desc:'Pion elf hutan', price:800, category:'pion'),
  ShopItem(id:'pion_santa', name:'Santa', emoji:'🎅', desc:'Pion santa baik hati', price:600, category:'pion'),
  ShopItem(id:'pion_snowman', name:'Snowman', emoji:'��', desc:'Pion boneka salju', price:500, category:'pion'),
  ShopItem(id:'pion_pumpkin', name:'Pumpkin', emoji:'🎃', desc:'Pion labu halloween', price:550, category:'pion'),
  ShopItem(id:'pion_cherry', name:'Cherry', emoji:'🍒', desc:'Pion ceri segar', price:300, category:'pion'),
  ShopItem(id:'pion_strawberry', name:'Strawberry', emoji:'🍓', desc:'Pion stroberi manis', price:300, category:'pion'),
  ShopItem(id:'pion_pizza', name:'Pizza', emoji:'�', desc:'Pion pizza yummy', price:350, category:'pion'),
  ShopItem(id:'pion_burger', name:'Burger', emoji:'�', desc:'Pion burger lezat', price:350, category:'pion'),
  ShopItem(id:'pion_sushi', name:'Sushi', emoji:'�', desc:'Pion sushi enak', price:400, category:'pion'),
  ShopItem(id:'pion_ramen', name:'Ramen', emoji:'🍜', desc:'Pion ramen hangat', price:400, category:'pion'),
  ShopItem(id:'pion_diamond', name:'Diamond', emoji:'�', desc:'Pion berlian biru', price:1500, category:'pion'),
  ShopItem(id:'pion_ruby', name:'Ruby', emoji:'�️', desc:'Pion rubi merah', price:1600, category:'pion'),
  ShopItem(id:'pion_emerald', name:'Emerald', emoji:'�', desc:'Pion zamrud hijau', price:1700, category:'pion'),
  ShopItem(id:'pion_sapphire', name:'Sapphire', emoji:'💙', desc:'Pion safir biru', price:1800, category:'pion'),
  ShopItem(id:'pion_amethyst', name:'Amethyst', emoji:'💜', desc:'Pion ametis ungu', price:1900, category:'pion'),
  ShopItem(id:'pion_onyx', name:'Onyx', emoji:'🖤', desc:'Pion oniks hitam', price:2000, category:'pion'),
  ShopItem(id:'pion_opal', name:'Opal', emoji:'�', desc:'Pion opal pelangi', price:2500, category:'pion'),
  ShopItem(id:'pion_topaz', name:'Topaz', emoji:'🟡', desc:'Pion topaz kuning', price:2200, category:'pion'),
  ShopItem(id:'pion_obsidian', name:'Obsidian', emoji:'�', desc:'Pion obsidian gelap', price:2800, category:'pion'),
  ShopItem(id:'pion_legendary', name:'LEGENDARY', emoji:'��', desc:'Pion langka terbaik', price:5000, category:'pion'),
  // MAP BARU
  ShopItem(id:'map_neon',    name:'Neon City',  emoji:'🌆', desc:'Papan neon futuristik',  price:1000, category:'map'),
  ShopItem(id:'map_space',   name:'Outer Space', emoji:'�', desc:'Papan luar angkasa',    price:1200, category:'map'),
  ShopItem(id:'map_ocean',   name:'Deep Ocean', emoji:'🌊', desc:'Papan dasar laut',       price:800,  category:'map'),
  ShopItem(id:'map_forest',  name:'Dark Forest',emoji:'🌲', desc:'Papan hutan gelap',      price:700,  category:'map'),
  ShopItem(id:'map_volcano', name:'Volcano',    emoji:'🌋', desc:'Papan gunung berapi',    price:1500, category:'map'),
  ShopItem(id:'map_sakura',  name:'Sakura',     emoji:'🌸', desc:'Papan bunga sakura',     price:900,  category:'map'),
  ShopItem(id:'map_desert',  name:'Desert',     emoji:'🏜️', desc:'Papan gurun pasir',     price:600,  category:'map'),
  ShopItem(id:'map_arctic',  name:'Arctic',     emoji:'🧊', desc:'Papan kutub es',         price:1100, category:'map'),
  // MAP EXTRA
  ShopItem(id:'map_rainbow', name:'Rainbow Land', emoji:'🌈', desc:'Papan negeri pelangi', price:1300, category:'map'),
  ShopItem(id:'map_cyber', name:'Cyber City', emoji:'🤖', desc:'Papan kota cyber', price:1400, category:'map'),
  ShopItem(id:'map_candy', name:'Candy World', emoji:'🍭', desc:'Papan dunia permen', price:900, category:'map'),
  ShopItem(id:'map_haunted', name:'Haunted House', emoji:'�', desc:'Papan rumah hantu', price:1100, category:'map'),
  ShopItem(id:'map_sky', name:'Sky Kingdom', emoji:'�️', desc:'Papan kerajaan langit', price:1600, category:'map'),
  // EFEK DADU
  ShopItem(id:'dice_fire',   name:'Fire Dice',   emoji:'�', desc:'Dadu api berkobar',    price:500,  category:'dice'),
  ShopItem(id:'dice_ice',    name:'Ice Dice',    emoji:'�️', desc:'Dadu es membeku',      price:500,  category:'dice'),
  ShopItem(id:'dice_thunder',name:'Thunder Dice',emoji:'�', desc:'Dadu petir menggelegar',price:600, category:'dice'),
  ShopItem(id:'dice_galaxy', name:'Galaxy Dice', emoji:'🌌', desc:'Dadu galaksi misterius',price:800, category:'dice'),
  ShopItem(id:'dice_rainbow',name:'Rainbow Dice',emoji:'🌈', desc:'Dadu pelangi ceria',   price:700,  category:'dice'),
];

class ShopManager {
  static Future<int> getCoins() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt('shop_coins') ?? 0;
  }
  static Future<void> addCoins(int amount) async {
    final prefs = await SharedPreferences.getInstance();
    final c = prefs.getInt('shop_coins') ?? 0;
    await prefs.setInt('shop_coins', c + amount);
  }
  static Future<bool> spendCoins(int amount) async {
    final prefs = await SharedPreferences.getInstance();
    final c = prefs.getInt('shop_coins') ?? 0;
    if (c < amount) return false;
    await prefs.setInt('shop_coins', c - amount);
    return true;
  }
  static Future<Set<String>> getOwned() async {
    final prefs = await SharedPreferences.getInstance();
    return (prefs.getStringList('owned_items') ?? []).toSet();
  }
  static Future<void> purchaseItem(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final owned = (prefs.getStringList('owned_items') ?? []).toSet();
    owned.add(id);
    await prefs.setStringList('owned_items', owned.toList());
  }
  static Future<String?> getEquipped(String category) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('equipped_$category');
  }
  static Future<void> equip(String category, String id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('equipped_$category', id);
  }

  // Sync koin dari server (dipanggil saat buka ular tangga)
  static Future<void> syncFromServer(String sessionKey) async {
    try {
      final resp = await http.get(Uri.parse('${ConfigService.baseUrl}/api/coins/sync?key=$sessionKey'));
      if (resp.statusCode == 200) {
        final data = jsonDecode(resp.body);
        if (data['success'] == true && data['balance'] != null) {
          final serverCoins = data['balance'] as int;
          if (serverCoins > 0) {
            // SET langsung (bukan addCoins) supaya tidak double count
            final prefs = await SharedPreferences.getInstance();
            final localCoins = prefs.getInt('shop_coins') ?? 0;
            if (serverCoins > localCoins) {
              await prefs.setInt('shop_coins', serverCoins);
            }
          }
        }
      }
    } catch (_) {}
  }
}

// 
// SHOP PAGE
// 

// 
// RANK PAGE
// 

// 
// TOP UP KOIN PAGE (owner/vip/reseller)
// 
class _TopUpCoinsPage extends StatefulWidget {
  final String sessionKey, username, userRole;
  const _TopUpCoinsPage({required this.sessionKey, required this.username, required this.userRole});
  @override State<_TopUpCoinsPage> createState() => _TopUpCoinsPageState();
}

class _TopUpCoinsPageState extends State<_TopUpCoinsPage> {
  final _targetCtrl = TextEditingController();
  final _amountCtrl = TextEditingController();
  bool _loading = false;
  String _msg = '';
  bool _success = false;

  Future<void> _topUp() async {
    final target = _targetCtrl.text.trim();
    final amount = int.tryParse(_amountCtrl.text.trim());
    if (target.isEmpty || amount == null || amount <= 0) {
      setState(() { _msg = '� Isi username dan jumlah koin!'; _success = false; });
      return;
    }
    setState(() { _loading = true; _msg = ''; });
    try {
      final resp = await http.post(
        Uri.parse('${ConfigService.baseUrl}/api/coins/topup'),
        body: {'key': widget.sessionKey, 'targetUsername': target, 'amount': amount.toString()},
      );
      final data = jsonDecode(resp.body);
      setState(() {
        _success = data['success'] == true;
        _msg = data['message'] ?? (data['success'] == true ? '�� Berhasil!' : '� Gagal');
      });
      if (_success) {
        _targetCtrl.clear();
        _amountCtrl.clear();
      }
    } catch (e) {
      setState(() { _success = false; _msg = '� Gagal koneksi ke server'; });
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() { _targetCtrl.dispose(); _amountCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final presets = [100, 500, 1000, 5000, 10000];
    return Scaffold(
      backgroundColor: const Color(0xFF060B14),
      body: SafeArea(child: Column(children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(children: [
            _IconBtn(icon: Icons.arrow_back, accent: const Color(0xFFFFD700), onTap: () => Navigator.pop(context)),
            const Spacer(),
            const Text('🪙 TOP UP KOIN', style: TextStyle(fontFamily: 'Orbitron', fontSize: 15, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 1)),
            const Spacer(), const SizedBox(width: 40),
          ]),
        ),
        Expanded(child: SingleChildScrollView(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Info role
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: Color(0xFFFFD700).withValues(alpha: 0.08),
              border: Border.all(color: Color(0xFFFFD700).withValues(alpha: 0.3))),
            child: Row(children: [
              const Text('�', style: TextStyle(fontSize: 20)),
              const SizedBox(width: 10),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(widget.username, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                Text(widget.userRole.toUpperCase(), style: const TextStyle(color: Color(0xFFFFD700), fontFamily: 'ShareTechMono', fontSize: 11)),
              ]),
            ]),
          ),
          const SizedBox(height: 24),
          const Text('USERNAME TARGET', style: TextStyle(color: Colors.white54, fontFamily: 'ShareTechMono', fontSize: 11, letterSpacing: 1)),
          const SizedBox(height: 8),
          TextField(
            controller: _targetCtrl,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Masukkan username...',
              hintStyle: const TextStyle(color: Colors.white24),
              prefixIcon: const Icon(Icons.person, color: Color(0xFFFFD700), size: 20),
              filled: true, fillColor: Colors.white.withValues(alpha: 0.05),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.white12)),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFFFD700))),
            ),
          ),
          const SizedBox(height: 20),
          const Text('JUMLAH KOIN', style: TextStyle(color: Colors.white54, fontFamily: 'ShareTechMono', fontSize: 11, letterSpacing: 1)),
          const SizedBox(height: 8),
          TextField(
            controller: _amountCtrl,
            keyboardType: TextInputType.number,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Masukkan jumlah...',
              hintStyle: const TextStyle(color: Colors.white24),
              prefixIcon: const Text('🪙', style: TextStyle(fontSize: 18)),
              filled: true, fillColor: Colors.white.withValues(alpha: 0.05),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.white12)),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFFFD700))),
            ),
          ),
          const SizedBox(height: 12),
          // Preset amounts
          Wrap(spacing: 8, children: presets.map((p) => GestureDetector(
            onTap: () => _amountCtrl.text = p.toString(),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Colors.white.withValues(alpha: 0.05),
                border: Border.all(color: Color(0xFFFFD700).withValues(alpha: 0.3))),
              child: Text('+$p 🪙', style: const TextStyle(color: Color(0xFFFFD700), fontFamily: 'ShareTechMono', fontSize: 11)),
            ),
          )).toList()),
          const SizedBox(height: 28),
          // Top up button
          SizedBox(width: double.infinity, height: 50,
            child: ElevatedButton(
              onPressed: _loading ? null : _topUp,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFFD700),
                foregroundColor: Colors.black,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                elevation: 0,
              ),
              child: _loading
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                : const Text('🪙 TOP UP SEKARANG', style: TextStyle(fontFamily: 'Orbitron', fontSize: 13, fontWeight: FontWeight.bold)),
            ),
          ),
          if (_msg.isNotEmpty) ...[
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: (_success ? Colors.green : Colors.red).withValues(alpha: 0.1),
                border: Border.all(color: (_success ? Colors.green : Colors.red).withValues(alpha: 0.4))),
              child: Row(children: [
                Text(_success ? '��' : '�', style: const TextStyle(fontSize: 18)),
                const SizedBox(width: 10),
                Expanded(child: Text(_msg, style: TextStyle(color: _success ? Colors.green.shade300 : Colors.red.shade300, fontSize: 13))),
              ]),
            ),
          ],
        ]))),
      ])),
    );
  }
}

class _RankPage extends StatefulWidget {
  final String username;
  const _RankPage({required this.username});
  @override State<_RankPage> createState() => _RankPageState();
}

class _RankPageState extends State<_RankPage> {
  int _xp = 0, _coins = 0, _stage = 1;
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final xp = await XpManager.getXP();
    final coins = await ShopManager.getCoins();
    final stage = await XpManager.getCampaignStage();
    if (mounted) setState(() { _xp = xp; _coins = coins; _stage = stage; _loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(backgroundColor: Color(0xFF060B14), body: Center(child: CircularProgressIndicator()));
    final rank = getRankInfo(_xp);
    final nextXP = getXpForNextRank(_xp);
    final progress = (_xp / nextXP.clamp(1, 999999)).clamp(0.0, 1.0);
    final rankColor = Color(rank['color'] as int);

    return Scaffold(
      backgroundColor: const Color(0xFF060B14),
      body: SafeArea(child: Column(children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(children: [
            _IconBtn(icon: Icons.arrow_back, accent: rankColor, onTap: () => Navigator.pop(context)),
            const Spacer(),
            const Text('🏆 RANK', style: TextStyle(fontFamily: 'Orbitron', fontSize: 16, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 2)),
            const Spacer(), const SizedBox(width: 40),
          ]),
        ),
        Expanded(child: SingleChildScrollView(padding: const EdgeInsets.symmetric(horizontal: 20), child: Column(children: [
          const SizedBox(height: 20),
          // Big rank display
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: rankColor.withValues(alpha: 0.1),
              border: Border.all(color: rankColor.withValues(alpha: 0.5), width: 2),
            ),
            child: Column(children: [
              Text(rank['emoji'] as String, style: const TextStyle(fontSize: 64)),
              const SizedBox(height: 12),
              Text(rank['name'] as String, style: TextStyle(
                fontFamily: 'Orbitron', fontSize: 24, fontWeight: FontWeight.w900, color: rankColor,
                shadows: [Shadow(color: rankColor.withValues(alpha: 0.5), blurRadius: 15)])),
              const SizedBox(height: 6),
              Text(widget.username, style: const TextStyle(color: Colors.white54, fontFamily: 'ShareTechMono', fontSize: 14)),
            ]),
          ),
          const SizedBox(height: 20),
          // Stats
          Row(children: [
            _StatCard(label: 'Total XP', value: '$_xp', emoji: '�', color: const Color(0xFFFFD700)),
            const SizedBox(width: 12),
            _StatCard(label: 'Koin', value: '$_coins', emoji: '🪙', color: const Color(0xFFFF6F00)),
            const SizedBox(width: 12),
            _StatCard(label: 'Stage', value: '${_stage - 1}', emoji: '�️', color: const Color(0xFF4CAF50)),
          ]),
          const SizedBox(height: 20),
          // XP Progress
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              color: Colors.white.withValues(alpha: 0.05),
              border: Border.all(color: Colors.white12)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Text('Progress ke Rank Berikutnya', style: TextStyle(color: rankColor, fontFamily: 'ShareTechMono', fontSize: 11)),
                const Spacer(),
                Text('$_xp / $nextXP XP', style: const TextStyle(color: Colors.white54, fontSize: 11)),
              ]),
              const SizedBox(height: 10),
              ClipRRect(borderRadius: BorderRadius.circular(6), child: LinearProgressIndicator(
                value: progress, backgroundColor: Colors.white12,
                valueColor: AlwaysStoppedAnimation(rankColor), minHeight: 10)),
            ]),
          ),
          const SizedBox(height: 20),
          // All ranks
          const Text('SEMUA RANK', style: TextStyle(fontFamily: 'Orbitron', fontSize: 11, color: Colors.white38, letterSpacing: 2)),
          const SizedBox(height: 12),
          ...kRanks.map((r) {
            final rColor = Color(r['color'] as int);
            final active = rank['name'] == r['name'];
            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: active ? rColor.withValues(alpha: 0.15) : Colors.white.withValues(alpha: 0.03),
                border: Border.all(color: active ? rColor.withValues(alpha: 0.6) : Colors.white12)),
              child: Row(children: [
                Text(r['emoji'] as String, style: const TextStyle(fontSize: 20)),
                const SizedBox(width: 12),
                Text(r['name'] as String, style: TextStyle(color: active ? rColor : Colors.white54,
                  fontFamily: 'Orbitron', fontSize: 12, fontWeight: active ? FontWeight.bold : FontWeight.normal)),
                const Spacer(),
                Text('${r['minXP']} XP', style: TextStyle(color: active ? rColor : Colors.white24,
                  fontFamily: 'ShareTechMono', fontSize: 11)),
                if (active) ...[const SizedBox(width: 8), Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(color: rColor.withValues(alpha: 0.3), borderRadius: BorderRadius.circular(4)),
                  child: const Text('KAMU', style: TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.bold)))],
              ]),
            );
          }),
          const SizedBox(height: 20),
        ]))),
      ])),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label, value, emoji;
  final Color color;
  const _StatCard({required this.label, required this.value, required this.emoji, required this.color});
  @override
  Widget build(BuildContext context) {
    return Expanded(child: Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: color.withValues(alpha: 0.1),
        border: Border.all(color: color.withValues(alpha: 0.3))),
      child: Column(children: [
        Text(emoji, style: const TextStyle(fontSize: 20)),
        const SizedBox(height: 4),
        Text(value, style: TextStyle(color: color, fontFamily: 'Orbitron', fontSize: 14, fontWeight: FontWeight.bold)),
        const SizedBox(height: 2),
        Text(label, style: const TextStyle(color: Colors.white38, fontSize: 9)),
      ]),
    ));
  }
}

class _ShopPage extends StatefulWidget {
  final String sessionKey;
  const _ShopPage({required this.sessionKey});
  @override State<_ShopPage> createState() => _ShopPageState();
}

class _ShopPageState extends State<_ShopPage> with SingleTickerProviderStateMixin {
  int _coins = 0;
  Set<String> _owned = {};
  Map<String,String?> _equipped = {};
  String _tab = 'pion';
  bool _loading = true;
  late TabController _tabCtrl;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 3, vsync: this);
    _tabCtrl.addListener(() {
      final tabs = ['pion','map','dice'];
      setState(() => _tab = tabs[_tabCtrl.index]);
    });
    _load();
  }

  Future<void> _load() async {
    // Sync koin dari server dulu sebelum baca local
    await ShopManager.syncFromServer(widget.sessionKey);
    final coins = await ShopManager.getCoins();
    final owned = await ShopManager.getOwned();
    final ep = await ShopManager.getEquipped('pion');
    final em = await ShopManager.getEquipped('map');
    final ed = await ShopManager.getEquipped('dice');
    if (mounted) setState(() {
      _coins = coins; _owned = owned;
      _equipped = {'pion': ep, 'map': em, 'dice': ed};
      _loading = false;
    });
  }

  Future<void> _buy(ShopItem item) async {
    if (_owned.contains(item.id)) {
      // Sudah punya, langsung equip
      await ShopManager.equip(item.category, item.id);
      setState(() => _equipped[item.category] = item.id);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('�� ${item.name} dipakai!'), backgroundColor: Colors.green.shade800, duration: const Duration(seconds: 1)));
      return;
    }
    if (_coins < item.price) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: const Text('� Koin tidak cukup!'), backgroundColor: Colors.red.shade800, duration: const Duration(seconds: 1)));
      return;
    }
    // Konfirmasi beli
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF0D1117),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Beli ${item.emoji} ${item.name}?', style: const TextStyle(color: Colors.white, fontSize: 16)),
        content: Text('Harga: ${item.price} 🪙\nSaldo: \$_coins 🪙', style: const TextStyle(color: Colors.white70)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal', style: TextStyle(color: Colors.white38))),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFF6F00)),
            child: const Text('Beli!', style: TextStyle(color: Colors.white))),
        ],
      ),
    ) ?? false;
    if (!ok) return;
    final success = await ShopManager.spendCoins(item.price);
    if (success) {
      await ShopManager.purchaseItem(item.id);
      await ShopManager.equip(item.category, item.id);
      await _load();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('�� ${item.name} dibeli & dipakai!'), backgroundColor: Colors.green.shade800));
    }
  }

  @override
  void dispose() { _tabCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final items = kShopItems.where((i) => i.category == _tab).toList();
    return Scaffold(
      backgroundColor: const Color(0xFF060B14),
      body: SafeArea(child: Column(children: [
        // Header
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(children: [
            _IconBtn(icon: Icons.arrow_back, accent: const Color(0xFFFF6F00), onTap: () => Navigator.pop(context)),
            const Spacer(),
            const Text('🛒 SHOP', style: TextStyle(fontFamily: 'Orbitron', fontSize: 16, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 2)),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Color(0xFFFFD700).withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Color(0xFFFFD700).withValues(alpha: 0.5)),
              ),
              child: Text('$_coins 🪙', style: const TextStyle(color: Color(0xFFFFD700), fontFamily: 'Orbitron', fontSize: 12, fontWeight: FontWeight.bold)),
            ),
          ]),
        ),
        // Tabs
        TabBar(
          controller: _tabCtrl,
          indicatorColor: const Color(0xFFFF6F00),
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white38,
          labelStyle: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 11),
          tabs: const [Tab(text: '🎮 PION'), Tab(text: '�️ MAP'), Tab(text: '🎲 DADU')],
        ),
        const SizedBox(height: 8),
        // Items grid
        Expanded(
          child: _loading
            ? const Center(child: CircularProgressIndicator(color: Color(0xFFFF6F00)))
            : GridView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.5),
                itemCount: items.length,
                itemBuilder: (ctx, i) {
                  final item = items[i];
                  final owned = _owned.contains(item.id);
                  final equipped = _equipped[item.category] == item.id;
                  return GestureDetector(
                    onTap: () => _buy(item),
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        color: equipped
                          ? Color(0xFFFF6F00).withValues(alpha: 0.15)
                          : owned ? Colors.white.withValues(alpha: 0.07) : Colors.white.withValues(alpha: 0.04),
                        border: Border.all(
                          color: equipped ? const Color(0xFFFF6F00) : owned ? Colors.white24 : Colors.white12,
                          width: equipped ? 2 : 1),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Row(children: [
                          Text(item.emoji, style: const TextStyle(fontSize: 32)),
                          const SizedBox(width: 10),
                          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                            Text(item.name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                            const SizedBox(height: 2),
                            Text(item.desc, style: const TextStyle(color: Colors.white38, fontSize: 10), maxLines: 2, overflow: TextOverflow.ellipsis),
                            const SizedBox(height: 4),
                            if (equipped)
                              Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(color: Color(0xFFFF6F00).withValues(alpha: 0.3), borderRadius: BorderRadius.circular(4)),
                                child: const Text('�� DIPAKAI', style: TextStyle(color: Color(0xFFFF6F00), fontSize: 9, fontWeight: FontWeight.bold)))
                            else if (owned)
                              Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(4)),
                                child: const Text('�� DIMILIKI  Tap untuk pakai', style: TextStyle(color: Colors.white54, fontSize: 9)))
                            else
                              Text('${item.price} 🪙', style: const TextStyle(color: Color(0xFFFFD700), fontFamily: 'ShareTechMono', fontSize: 11, fontWeight: FontWeight.bold)),
                          ])),
                        ]),
                      ),
                    ),
                  );
                },
              ),
        ),
      ])),
    );
  }
}

//  Stage Reward Dialog 
class _StageRewardDialog extends StatefulWidget {
  final int stage, xp, coins;
  final bool isBoss;
  const _StageRewardDialog({required this.stage, required this.xp, required this.coins, required this.isBoss});
  @override State<_StageRewardDialog> createState() => _StageRewardDialogState();
}

class _StageRewardDialogState extends State<_StageRewardDialog> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;
  late Animation<double> _fade;
  late Animation<double> _coinBounce;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
    _scale = Tween(begin: 0.5, end: 1.0).animate(CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut));
    _fade  = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _coinBounce = Tween(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _ctrl, curve: const Interval(0.4, 1.0, curve: Curves.elasticOut)));
    _ctrl.forward();
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final isBoss = widget.isBoss;
    final Color accent = isBoss ? const Color(0xFFFF2D2D) : const Color(0xFFFFD700);
    final String title = isBoss ? '� BOSS CLEARED!' : '� STAGE ${widget.stage} CLEAR!';
    final String subtitle = isBoss ? 'Luar biasa! Kamu kalahkan BOSS!' : 'Lanjut ke Stage ${widget.stage + 1}';

    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) => Opacity(
        opacity: _fade.value.clamp(0.0, 1.0),
        child: Transform.scale(
          scale: _scale.value,
          child: Dialog(
            backgroundColor: Colors.transparent,
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: const Color(0xFF0D1117),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: accent.withValues(alpha: 0.6), width: 2),
                boxShadow: [BoxShadow(color: accent.withValues(alpha: 0.3), blurRadius: 40, spreadRadius: 4)],
              ),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                // Icon
                Container(
                  width: 72, height: 72,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: accent.withValues(alpha: 0.15),
                    border: Border.all(color: accent.withValues(alpha: 0.5), width: 2),
                    boxShadow: [BoxShadow(color: accent.withValues(alpha: 0.4), blurRadius: 20)],
                  ),
                  child: Center(child: Text(isBoss ? '�' : '🏆', style: const TextStyle(fontSize: 36))),
                ),
                const SizedBox(height: 16),
                // Title
                Text(title, style: TextStyle(
                  fontFamily: 'Orbitron', fontSize: 18, fontWeight: FontWeight.w900,
                  color: accent, letterSpacing: 1,
                  shadows: [Shadow(color: accent.withValues(alpha: 0.7), blurRadius: 12)],
                ), textAlign: TextAlign.center),
                const SizedBox(height: 6),
                Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 12, fontFamily: 'ShareTechMono')),
                const SizedBox(height: 24),
                // Reward cards
                Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                  _RewardCard(
                    emoji: '��', label: 'XP', value: '+${widget.xp}',
                    color: Colors.blue, anim: _coinBounce,
                  ),
                  _RewardCard(
                    emoji: '🪙', label: 'KOIN', value: '+${widget.coins}',
                    color: const Color(0xFFFFD700), anim: _coinBounce,
                    highlight: true,
                  ),
                  if (isBoss) _RewardCard(
                    emoji: '�', label: 'BONUS', value: '3x',
                    color: Colors.red, anim: _coinBounce,
                  ),
                ]),
                const SizedBox(height: 24),
                // Button
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: accent,
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      elevation: 0,
                    ),
                    onPressed: () => Navigator.pop(context),
                    child: Text(
                      isBoss ? '� LANJUT!' : '�� NEXT STAGE',
                      style: const TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 14),
                    ),
                  ),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

class _RewardCard extends StatelessWidget {
  final String emoji, label, value;
  final Color color;
  final Animation<double> anim;
  final bool highlight;
  const _RewardCard({required this.emoji, required this.label, required this.value,
    required this.color, required this.anim, this.highlight = false});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: anim,
      builder: (_, __) => Transform.translate(
        offset: Offset(0, -10 * (1 - anim.value) * (1 - anim.value)),
        child: Opacity(
          opacity: anim.value.clamp(0.0, 1.0),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: color.withValues(alpha: highlight ? 0.2 : 0.1),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: color.withValues(alpha: highlight ? 0.6 : 0.3), width: highlight ? 1.5 : 1),
              boxShadow: highlight ? [BoxShadow(color: color.withValues(alpha: 0.3), blurRadius: 12)] : null,
            ),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(emoji, style: const TextStyle(fontSize: 22)),
              const SizedBox(height: 4),
              Text(value, style: TextStyle(
                color: color, fontFamily: 'Orbitron', fontSize: 14, fontWeight: FontWeight.w900)),
              Text(label, style: const TextStyle(color: Colors.white38, fontSize: 9, fontFamily: 'ShareTechMono')),
            ]),
          ),
        ),
      ),
    );
  }
}

class _CampaignPage extends StatefulWidget {
  final String username, userRole, sessionKey;
  const _CampaignPage({required this.username, required this.userRole, required this.sessionKey});
  @override State<_CampaignPage> createState() => _CampaignPageState();
}

class _CampaignPageState extends State<_CampaignPage> {
  int _unlockedStage = 1;
  int _playerXP = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  final ScrollController _scrollCtrl = ScrollController();

  Future<void> _load() async {
    final stage = await XpManager.getCampaignStage();
    final xp = await XpManager.getXP();
    final coins = await ShopManager.getCoins();
    if (mounted) {
      setState(() { _unlockedStage = stage; _playerXP = xp; _loading = false; });
      // Auto scroll ke stage saat ini
      WidgetsBinding.instance.addPostFrameCallback((_) {
        final targetRow = ((stage - 1) ~/ 4) - 1;
        if (targetRow > 0 && _scrollCtrl.hasClients) {
          _scrollCtrl.animateTo(
            targetRow * 80.0,
            duration: const Duration(milliseconds: 600),
            curve: Curves.easeOut,
          );
        }
      });
    }
  }

  void _startStage(CampaignStage stage) {
    final mapConfig = kMapConfigs[stage.stage % kMapConfigs.length];
    final customMap = MapConfig(
      name: mapConfig.name, emoji: mapConfig.emoji, theme: mapConfig.theme,
      snakes: stage.snakes, ladders: stage.ladders,
      bgColor: mapConfig.bgColor, cellA: mapConfig.cellA, cellB: mapConfig.cellB,
      snakeColor: mapConfig.snakeColor, ladderColor: mapConfig.ladderColor,
      snakeEmoji: mapConfig.snakeEmoji, ladderEmoji: mapConfig.ladderEmoji, bgEmoji: mapConfig.bgEmoji,
    );

    final bots = List.generate(stage.botCount, (i) => SnakeLadderPlayer(
      name: 'Bot ${i+1}', isBot: true,
      role: PlayerRole.guest,
      pawnSkin: PawnSkin.chess,
      pawnColor: PawnColor.values[(i + 1) % PawnColor.values.length],
      playerIndex: i + 1,
    ));

    final players = [
      SnakeLadderPlayer(name: widget.username, isBot: false, role: PlayerRole.guest, pawnSkin: PawnSkin.circle, pawnColor: PawnColor.red, playerIndex: 0),
      ...bots,
    ];

    Navigator.push(context, _slideRoute(_GamePage(
      players: players,
      isOnline: false,
      myIndex: 0,
      botDifficulty: stage.botDifficulty >= 0.8 ? 'Hard' : stage.botDifficulty >= 0.5 ? 'Normal' : 'Easy',
      betAmount: 0,
      campaignStage: stage,
    ))).then((_) => _load());
  }

  @override
  Widget build(BuildContext context) {
    final rank = getRankInfo(_playerXP);
    final nextXP = getXpForNextRank(_playerXP);
    final progress = _playerXP / nextXP.clamp(1, 99999);

    return Scaffold(
      backgroundColor: const Color(0xFF060B14),
      body: SafeArea(
        child: Column(children: [
          // Header
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(children: [
              _IconBtn(icon: Icons.arrow_back, accent: const Color(0xFFFF6F00), onTap: () => Navigator.pop(context)),
              const Spacer(),
              const Column(children: [
                Text('�️ CAMPAIGN', style: TextStyle(fontFamily: 'Orbitron', fontSize: 16, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 2)),
                Text('5000 Stage + BOSS', style: TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 10)),
              ]),
              const Spacer(),
              GestureDetector(
                onTap: () => Navigator.push(context, _slideRoute(_ShopPage(sessionKey: widget.sessionKey))).then((_) => _load()),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: Color(0xFFFFD700).withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Color(0xFFFFD700).withValues(alpha: 0.4))),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    const Text('🪙', style: TextStyle(fontSize: 13)),
                    const SizedBox(width: 4),
                    Text('🛒', style: const TextStyle(fontSize: 13)),
                  ]),
                ),
              ),
            ]),
          ),

          // XP / Rank bar
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.05),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Color(rank['color'] as int).withValues(alpha: 0.4)),
              ),
              child: Row(children: [
                Text(rank['emoji'] as String, style: const TextStyle(fontSize: 28)),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Text(rank['name'] as String, style: TextStyle(
                      fontFamily: 'Orbitron', fontSize: 13, fontWeight: FontWeight.bold,
                      color: Color(rank['color'] as int))),
                    const Spacer(),
                    Text('$_playerXP XP', style: const TextStyle(color: Colors.white60, fontSize: 11, fontFamily: 'ShareTechMono')),
                  ]),
                  const SizedBox(height: 6),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: progress.clamp(0.0, 1.0),
                      backgroundColor: Colors.white12,
                      valueColor: AlwaysStoppedAnimation(Color(rank['color'] as int)),
                      minHeight: 6,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text('Next rank: $nextXP XP', style: const TextStyle(color: Colors.white30, fontSize: 9, fontFamily: 'ShareTechMono')),
                ])),
              ]),
            ),
          ),

          const SizedBox(height: 12),

          // Stage grid
          Expanded(
            child: _loading
              ? const Center(child: CircularProgressIndicator(color: Color(0xFFFF6F00)))
              : Builder(builder: (ctx) {
                  // Tampilkan sampai stage unlocked + 20 berikutnya, max 5000
                  final visibleCount = (_unlockedStage + 20).clamp(1, kTotalCampaignStages);
                  return GridView.builder(
                    controller: _scrollCtrl,
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 4, crossAxisSpacing: 8, mainAxisSpacing: 8, childAspectRatio: 0.82),
                    itemCount: visibleCount,
                    itemBuilder: (ctx, i) {
                    final s = _getStage(i);
                    final unlocked = s.stage <= _unlockedStage;
                    final isBoss = s.isBoss;
                    return GestureDetector(
                      onTap: unlocked ? () => _startStage(s) : null,
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(isBoss ? 14 : 10),
                          color: unlocked
                            ? (isBoss ? Color(0xFFB71C1C).withValues(alpha: 0.25) : s.color.withValues(alpha: 0.12))
                            : Colors.white.withValues(alpha: 0.03),
                          border: Border.all(
                            color: unlocked
                              ? (isBoss ? Colors.red.shade400 : s.color.withValues(alpha: 0.6))
                              : Colors.white12,
                            width: isBoss && unlocked ? 2 : 1,
                          ),
                          boxShadow: isBoss && unlocked ? [
                            BoxShadow(color: Colors.red.withValues(alpha: 0.3), blurRadius: 8, spreadRadius: 1)
                          ] : [],
                        ),
                        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                          if (isBoss && unlocked)
                            const Text('�', style: TextStyle(fontSize: 10)),
                          Text(unlocked ? s.emoji : '�',
                            style: TextStyle(fontSize: unlocked ? (isBoss ? 20 : 18) : 14)),
                          const SizedBox(height: 2),
                          Text('${s.stage}', style: TextStyle(
                            fontFamily: 'Orbitron', fontSize: isBoss ? 13 : 11, fontWeight: FontWeight.bold,
                            color: unlocked ? (isBoss ? Colors.red.shade300 : s.color) : Colors.white24)),
                          const SizedBox(height: 1),
                          Text(unlocked ? (isBoss ? 'BOSS' : s.name.split(' ').first) : '???',
                            style: TextStyle(
                              color: unlocked ? (isBoss ? Colors.red.shade200 : Colors.white60) : Colors.white24,
                              fontSize: 7, fontWeight: isBoss ? FontWeight.bold : FontWeight.normal),
                            textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis),
                          if (unlocked) ...[
                            const SizedBox(height: 2),
                            Text('+${s.xpReward}XP',
                              style: TextStyle(
                                color: isBoss ? Colors.red.shade300 : s.color,
                                fontSize: 7, fontFamily: 'ShareTechMono')),
                          ]
                        ]),
                      ),
                    );
                  },
                );
                }),
          ),
        ]),
      ),
    );
  }
}

class _OnlineLobbyPage extends StatefulWidget {
  final String username, userRole, sessionKey;
  const _OnlineLobbyPage({required this.username, required this.userRole, required this.sessionKey});
  @override State<_OnlineLobbyPage> createState() => _OnlineLobbyPageState();
}

class _OnlineLobbyPageState extends State<_OnlineLobbyPage> with SingleTickerProviderStateMixin {
  late AnimationController _entryCtrl;
  late Animation<double> _fadeIn;
  late Animation<Offset> _slideIn;

  @override
  void initState() {
    super.initState();
    _entryCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fadeIn = CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOut);
    _slideIn = Tween<Offset>(begin: const Offset(0, 0.1), end: Offset.zero)
        .animate(CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOut));
    _entryCtrl.forward();
  }

  @override
  void dispose() { _entryCtrl.dispose(); super.dispose(); }

  PlayerRole _mapRole(String r) {
    switch (r.toLowerCase()) {
      case 'owner': return PlayerRole.owner;
      case 'admin': return PlayerRole.admin;
      case 'vip':   return PlayerRole.vip;
      case 'member':return PlayerRole.member;
      default:      return PlayerRole.guest;
    }
  }

  @override
  Widget build(BuildContext context) {
    final accent = Theme.of(context).colorScheme.secondary;
    final primary = Theme.of(context).primaryColor;
    final role = _mapRole(widget.userRole);

    return Scaffold(
      backgroundColor: const Color(0xFF060B14),
      body: Stack(children: [
        _Blob(color: primary, size: 280, top: -80, right: -60),
        _Blob(color: accent, size: 220, bottom: -60, left: -40, delay: 1.5),
        SafeArea(child: FadeTransition(opacity: _fadeIn, child: SlideTransition(position: _slideIn,
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: Row(children: [
                _IconBtn(icon: Icons.arrow_back, accent: accent, onTap: () => Navigator.pop(context)),
                const Spacer(),
                Column(children: [
                  Text('� ONLINE', style: TextStyle(fontFamily: 'Orbitron', fontSize: 16, fontWeight: FontWeight.w900,
                      color: Colors.white, letterSpacing: 2, shadows: [Shadow(color: accent, blurRadius: 10)])),
                  const Text('Multiplayer', style: TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 10)),
                ]),
                const Spacer(), const SizedBox(width: 40),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: _PlayerInfoCard(username: widget.username, role: role, primary: primary, accent: accent)),
            const SizedBox(height: 28),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: _AnimDelay(delay: 120, child: _ModeBtn(
                icon: Icons.add_circle_outline,
                title: 'BUAT ROOM',
                subtitle: 'Buat room baru, share kode ke teman',
                gradient: LinearGradient(colors: [primary, accent]),
                onTap: () => Navigator.push(context, _slideRoute(_RoomLobbyPage(
                  username: widget.username, userRole: widget.userRole,
                  sessionKey: widget.sessionKey, isHost: true, roomCode: null))),
              ))),
            const SizedBox(height: 14),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: _AnimDelay(delay: 240, child: _ModeBtn(
                icon: Icons.login,
                title: 'JOIN ROOM',
                subtitle: 'Masukkan kode room dari teman',
                gradient: const LinearGradient(colors: [Color(0xFF2ECC71), Color(0xFF27AE60)]),
                onTap: () => _showJoinDialog(context),
              ))),
            const Spacer(),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.04),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.white12)),
                child: const Text(
                  '1. Buat room �� share kode ke teman\n2. Teman join pakai kode\n3. Host tap MULAI kalau sudah siap\n4. Main bareng secara online!',
                  style: TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 10, height: 1.7)),
              )),
          ]),
        ))),
      ]),
    );
  }

  void _showJoinDialog(BuildContext context) {
    final ctrl = TextEditingController();
    final accent = Theme.of(context).colorScheme.secondary;
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: const Color(0xFF0D0D1A),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: BorderSide(color: accent.withValues(alpha: 0.3))),
      title: const Text('🎮 Join Room', style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 14)),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('Masukkan kode room dari teman:', style: TextStyle(color: Colors.white54, fontFamily: 'ShareTechMono', fontSize: 12)),
        const SizedBox(height: 12),
        TextField(
          controller: ctrl,
          textCapitalization: TextCapitalization.characters,
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 6),
          maxLength: 6,
          decoration: InputDecoration(
            counterText: '',
            hintText: 'ABC123',
            hintStyle: const TextStyle(color: Colors.white24, fontSize: 22, letterSpacing: 6),
            filled: true, fillColor: Colors.white.withValues(alpha: 0.06),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: accent.withValues(alpha: 0.3))),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: accent.withValues(alpha: 0.3))),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: accent, width: 2)),
          ),
        ),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal', style: TextStyle(color: Colors.white38))),
        ElevatedButton(
          onPressed: () {
            if (ctrl.text.length == 6) {
              Navigator.pop(context);
              Navigator.push(context, _slideRoute(_RoomLobbyPage(
                username: widget.username, userRole: widget.userRole,
                sessionKey: widget.sessionKey, isHost: false, roomCode: ctrl.text.toUpperCase())));
            }
          },
          style: ElevatedButton.styleFrom(backgroundColor: accent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
          child: const Text('JOIN', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
        ),
      ],
    ));
  }
}

// 
// ROOM LOBBY PAGE (Online)
// 
class _RoomLobbyPage extends StatefulWidget {
  final String username, userRole, sessionKey;
  final bool isHost;
  final String? roomCode;
  const _RoomLobbyPage({required this.username, required this.userRole, required this.sessionKey, required this.isHost, required this.roomCode});
  @override State<_RoomLobbyPage> createState() => _RoomLobbyPageState();
}

class _RoomLobbyPageState extends State<_RoomLobbyPage> with TickerProviderStateMixin {
  WebSocketChannel? _channel;
  StreamSubscription? _sub;
  String? _roomCode;
  List<Map<String, dynamic>> _players = [];
  bool _isHost = false;
  int _myIndex = 0;
  String _status = 'Menghubungkan...';
  bool _isStarting = false;
  late AnimationController _pulseCtrl;

  PlayerRole _mapRole(String r) {
    switch (r.toLowerCase()) {
      case 'owner': return PlayerRole.owner;
      case 'admin': return PlayerRole.admin;
      case 'vip':   return PlayerRole.vip;
      case 'member':return PlayerRole.member;
      default:      return PlayerRole.guest;
    }
  }

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _connect();
  }

  void _connect() async {
    try {
      _channel = WebSocketChannel.connect(Uri.parse(_wsUrl));
      _sub = _channel!.stream.listen(_onMessage, onError: _onError, onDone: _onDone);
      await Future.delayed(const Duration(milliseconds: 400));

      // Kirim validate dulu agar server tidak close koneksi
      String androidId = 'device_unknown';
      try {
        final deviceInfo = DeviceInfoPlugin();
        if (Theme.of(context).platform == TargetPlatform.android) {
          final info = await deviceInfo.androidInfo;
          androidId = info.id;
        } else if (Theme.of(context).platform == TargetPlatform.iOS) {
          final info = await deviceInfo.iosInfo;
          androidId = info.identifierForVendor ?? 'ios_unknown';
        }
      } catch (_) {}

      _channel?.sink.add(jsonEncode({
        'type': 'validate',
        'key': widget.sessionKey,
        'androidId': androidId,
      }));

      await Future.delayed(const Duration(milliseconds: 300));

      if (widget.isHost) {
        _send('create_room', {'name': widget.username, 'role': widget.userRole, 'pawnColor': 'red', 'sessionKey': widget.sessionKey, 'maxPlayers': 4});
      } else {
        _send('join_room', {'roomCode': widget.roomCode, 'name': widget.username, 'role': widget.userRole, 'sessionKey': widget.sessionKey});
      }
      setState(() => _status = 'Terhubung!');
    } catch (e) {
      setState(() => _status = 'Gagal terhubung: $e');
    }
  }

  void _send(String type, Map<String, dynamic> payload) =>
      _channel?.sink.add(jsonEncode({'type': type, 'payload': payload}));

  void _onMessage(dynamic raw) {
    final msg = jsonDecode(raw as String);
    final type = msg['type'] as String;

    // game_started harus di luar setState karena ada Navigator
    if (type == 'game_started') {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _navigateToGame(msg);
      });
      return;
    }

    setState(() {
      switch (type) {
        case 'room_created':
          _roomCode = msg['roomCode']; _myIndex = msg['playerIndex'] ?? 0; _isHost = true;
          _players = List<Map<String, dynamic>>.from((msg['roomInfo'] as Map)['players'] ?? []);
          _status = 'Room dibuat! Share kode ke teman.'; break;
        case 'room_joined':
          _roomCode = msg['roomCode']; _myIndex = msg['playerIndex'] ?? 0; _isHost = false;
          _players = List<Map<String, dynamic>>.from((msg['roomInfo'] as Map)['players'] ?? []);
          _status = 'Berhasil join! Tunggu host mulai.'; break;
        case 'player_joined':
          _players = List<Map<String, dynamic>>.from((msg['roomInfo'] as Map)['players'] ?? []);
          _status = '${msg['newPlayer']['name']} bergabung!';
          _Sfx.play('ludo_turn'); break;
        case 'player_left':
          _players = List<Map<String, dynamic>>.from((msg['roomInfo'] as Map)['players'] ?? []);
          _status = '${msg['playerName']} keluar.'; break;
        case 'you_are_host':
          _isHost = true; _status = 'Kamu jadi host!'; break;
        case 'error':
          _status = '� ${msg['message']}'; break;
        case 'myInfo': // response dari validate - abaikan saja
          break;
        case 'forceLogout': // server paksa logout
          _status = '� Session tidak valid!';
          _channel?.sink.close();
          break;
      }
    });
  }

  void _onError(dynamic e) { if (mounted) setState(() => _status = '� Error: $e'); }
  void _onDone() { if (mounted) setState(() => _status = '️ Koneksi terputus.'); }

  void _navigateToGame(Map<String, dynamic> msg) {
    final channel = _channel!;

    // Ambil gameState dari server (berisi posisi awal tiap pemain)
    final gameState = msg['gameState'] as Map<String, dynamic>? ?? {};
    final gsStatePlayers = gameState['players'] as List? ?? [];

    final gsPlayers = (msg['players'] as List? ?? []).asMap().entries.map((e) {
      final p = e.value as Map;
      final player = SnakeLadderPlayer(
        name: p['name'] ?? 'Pemain ${e.key+1}',
        pawnColor: PawnColor.values[e.key % PawnColor.values.length],
        role: PlayerRole.guest, isBot: false,
        pawnSkin: PawnSkin.circle,
        playerIndex: e.key,
      );
      // Set posisi awal dari gameState agar board langsung ter-render
      if (e.key < gsStatePlayers.length) {
        final sp = gsStatePlayers[e.key] as Map? ?? {};
        player.position = (sp['position'] as int?) ?? 0;
      }
      return player;
    }).toList().cast<SnakeLadderPlayer>();

    Navigator.pushReplacement(context, _slideRoute(_GamePage(
      players: gsPlayers, isOnline: true, myIndex: _myIndex,
      channel: channel, roomCode: _roomCode ?? '',
      onGameOver: (winner, all) => Navigator.push(context, _slideRoute(
        _ResultPage(winnerName: winner.name, players: all,
          username: widget.username, userRole: widget.userRole))),
    )));
  }

  void _startGame() {
    if (!_isHost || _players.length < 2) return;
    setState(() => _isStarting = true);
    _Sfx.play('ludo_dice');
    _send('start_game', {});
  }

  @override
  void dispose() { _pulseCtrl.dispose(); _sub?.cancel(); _channel?.sink.close(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final primary = theme.primaryColor;
    final accent = theme.colorScheme.secondary;

    return Scaffold(
      backgroundColor: const Color(0xFF060B14),
      body: SafeArea(child: Column(children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(children: [
            _IconBtn(icon: Icons.arrow_back, accent: accent, onTap: () { _send('leave_room', {}); Navigator.pop(context); }),
            const Spacer(),
            Text('🎮 ROOM LOBBY', style: TextStyle(fontFamily: 'Orbitron', fontSize: 14, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 2, shadows: [Shadow(color: accent, blurRadius: 8)])),
            const Spacer(), const SizedBox(width: 40),
          ]),
        ),

        if (_roomCode != null) Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          child: AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, child) => Container(
              width: double.infinity, padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                gradient: LinearGradient(colors: [primary.withValues(alpha: 0.3), accent.withValues(alpha: 0.2)]),
                border: Border.all(color: accent.withValues(alpha: 0.3 + _pulseCtrl.value * 0.4), width: 1.5 + _pulseCtrl.value),
                boxShadow: [BoxShadow(color: accent.withValues(alpha: 0.1 + _pulseCtrl.value * 0.15), blurRadius: 20)]),
              child: child,
            ),
            child: Column(children: [
              Text('KODE ROOM', style: TextStyle(color: Colors.white38, fontFamily: 'Orbitron', fontSize: 10, letterSpacing: 4)),
              const SizedBox(height: 8),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text(_roomCode!, style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 36, fontWeight: FontWeight.w900, letterSpacing: 8, shadows: [Shadow(color: accent, blurRadius: 20)])),
                const SizedBox(width: 12),
                GestureDetector(
                  onTap: () {
                    Clipboard.setData(ClipboardData(text: _roomCode!));
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Kode disalin!'), backgroundColor: Colors.green, duration: Duration(seconds: 1)));
                  },
                  child: Container(padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(color: accent.withValues(alpha: 0.2), borderRadius: BorderRadius.circular(8)),
                    child: Icon(Icons.copy, color: accent, size: 18)),
                ),
              ]),
              const SizedBox(height: 4),
              const Text('Share ke teman untuk join', style: TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 10)),
            ]),
          ),
        ),

        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 300),
            child: Container(
              key: ValueKey(_status), width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.05), borderRadius: BorderRadius.circular(10)),
              child: Text(_status, style: const TextStyle(color: Colors.white54, fontFamily: 'ShareTechMono', fontSize: 11), textAlign: TextAlign.center),
            ),
          ),
        ),

        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
          child: Row(children: [
            Text('PEMAIN (${_players.length}/4)', style: const TextStyle(color: Colors.white38, fontFamily: 'Orbitron', fontSize: 10, letterSpacing: 2)),
          ]),
        ),

        Expanded(child: ListView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: 4,
          itemBuilder: (_, i) {
            if (i < _players.length) {
              final p = _players[i];
              final role = _mapRole(p['role'] ?? 'guest');
              final isMe = i == _myIndex;
              final c = _kColors[i];
              return TweenAnimationBuilder<double>(
                tween: Tween(begin: 0.0, end: 1.0),
                duration: const Duration(milliseconds: 400),
                curve: Curves.easeOut,
                builder: (_, v, child) => Opacity(opacity: v, child: Transform.translate(offset: Offset(20*(1-v), 0), child: child)),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: isMe ? c.withValues(alpha: 0.8) : Colors.white12, width: isMe ? 2 : 1),
                    color: isMe ? c.withValues(alpha: 0.12) : Colors.white.withValues(alpha: 0.04),
                    boxShadow: isMe ? [BoxShadow(color: c.withValues(alpha: 0.2), blurRadius: 12)] : []),
                  child: Row(children: [
                    Text(_kEmojis[i], style: const TextStyle(fontSize: 24)),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        Text(p['name'] ?? '', style: TextStyle(color: isMe ? Colors.white : Colors.white70,
                            fontWeight: FontWeight.bold, fontFamily: 'Orbitron', fontSize: 12)),
                        if (isMe) ...[const SizedBox(width: 6), Container(padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                          decoration: BoxDecoration(color: Colors.blue.withValues(alpha: 0.2), borderRadius: BorderRadius.circular(4)),
                          child: const Text('KAMU', style: TextStyle(color: Colors.lightBlue, fontSize: 8, fontWeight: FontWeight.bold)))],
                        if (i == 0) ...[const SizedBox(width: 6), Container(padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                          decoration: BoxDecoration(color: Colors.amber.withValues(alpha: 0.2), borderRadius: BorderRadius.circular(4)),
                          child: const Text('HOST', style: TextStyle(color: Colors.amber, fontSize: 8, fontWeight: FontWeight.bold)))],
                      ]),
                      const SizedBox(height: 3),
                      Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                        decoration: BoxDecoration(color: role.badgeColor.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(4), border: Border.all(color: role.badgeColor.withValues(alpha: 0.4))),
                        child: Text(role.label, style: TextStyle(color: role.badgeColor, fontSize: 8))),
                    ])),
                    Container(width: 8, height: 8, decoration: BoxDecoration(color: Colors.green, shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: Colors.green.withValues(alpha: 0.5), blurRadius: 6)])),
                  ]),
                ),
              );
            } else {
              return Container(
                margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white12), color: Colors.white.withValues(alpha: 0.02)),
                child: Row(children: [
                  Text(_kEmojis[i], style: TextStyle(fontSize: 24, color: Colors.white.withValues(alpha: 0.2))),
                  const SizedBox(width: 12),
                  const Text('Menunggu pemain...', style: TextStyle(color: Colors.white24, fontFamily: 'ShareTechMono', fontSize: 11)),
                  const Spacer(),
                  SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 1.5, color: Colors.white.withValues(alpha: 0.15))),
                ]),
              );
            }
          },
        )),

        Padding(
          padding: const EdgeInsets.all(16),
          child: _isHost
              ? SizedBox(width: double.infinity, height: 54,
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: _players.length >= 2 && !_isStarting
                          ? LinearGradient(colors: [primary, accent])
                          : const LinearGradient(colors: [Colors.grey, Colors.grey]),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: _players.length >= 2 ? [BoxShadow(color: accent.withValues(alpha: 0.4), blurRadius: 18)] : []),
                    child: ElevatedButton(
                      onPressed: _players.length >= 2 && !_isStarting ? _startGame : null,
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, shadowColor: Colors.transparent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                      child: _isStarting
                          ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                          : Text(_players.length >= 2 ? '� MULAI GAME (${_players.length} pemain)' : 'Tunggu minimal 2 pemain...',
                              style: const TextStyle(fontFamily: 'Orbitron', fontSize: 13, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 1)),
                    ),
                  ))
              : Container(
                  width: double.infinity, height: 54, alignment: Alignment.center,
                  decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.05), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white12)),
                  child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white38)),
                    const SizedBox(width: 10),
                    const Text('�� Menunggu host memulai...', style: TextStyle(color: Colors.white38, fontFamily: 'Orbitron', fontSize: 11)),
                  ])),
        ),
      ])),
    );
  }
}

// 
// SHARED WIDGETS
// 

class _PlayerInfoCard extends StatelessWidget {
  final String username; final PlayerRole role; final Color primary, accent;
  const _PlayerInfoCard({required this.username, required this.role, required this.primary, required this.accent});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: accent.withValues(alpha: 0.3)),
        color: accent.withValues(alpha: 0.08)),
      child: Row(children: [
        Container(width: 44, height: 44,
          decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [primary, accent])),
          child: const Icon(Icons.person, color: Colors.white, size: 22)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(username, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'Orbitron', fontSize: 13)),
          const SizedBox(height: 3),
          Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(color: role.badgeColor.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(5), border: Border.all(color: role.badgeColor.withValues(alpha: 0.4))),
            child: Text(role.label, style: TextStyle(color: role.badgeColor, fontSize: 9, fontWeight: FontWeight.bold))),
        ])),
      ]),
    );
  }
}

class _ModeBtn extends StatefulWidget {
  final IconData icon; final String title, subtitle; final Gradient gradient; final VoidCallback onTap;
  const _ModeBtn({required this.icon, required this.title, required this.subtitle, required this.gradient, required this.onTap});
  @override State<_ModeBtn> createState() => _ModeBtnState();
}

class _ModeBtnState extends State<_ModeBtn> with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _scale;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 100), lowerBound: 0, upperBound: 0.04);
    _scale = Tween(begin: 1.0, end: 0.96).animate(_c);
  }
  @override void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _c.forward(),
      onTapUp: (_) { _c.reverse(); widget.onTap(); },
      onTapCancel: () => _c.reverse(),
      child: AnimatedBuilder(
        animation: _scale,
        builder: (_, child) => Transform.scale(scale: _scale.value, child: child),
        child: Container(
          width: double.infinity, padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(gradient: widget.gradient, borderRadius: BorderRadius.circular(18),
            boxShadow: [const BoxShadow(color: Colors.black38, blurRadius: 14)]),
          child: Row(children: [
            Container(padding: const EdgeInsets.all(11),
              decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.2), shape: BoxShape.circle),
              child: Icon(widget.icon, color: Colors.white, size: 24)),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(widget.title, style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 15, letterSpacing: 1)),
              const SizedBox(height: 3),
              Text(widget.subtitle, style: TextStyle(color: Colors.white.withValues(alpha: 0.75), fontFamily: 'ShareTechMono', fontSize: 11)),
            ])),
            const Icon(Icons.arrow_forward_ios, color: Colors.white54, size: 15),
          ]),
        ),
      ),
    );
  }
}

class _GradientBtn extends StatelessWidget {
  final String label; final Gradient gradient; final VoidCallback onTap;
  const _GradientBtn({required this.label, required this.gradient, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 54,
        decoration: BoxDecoration(gradient: gradient, borderRadius: BorderRadius.circular(14),
          boxShadow: [const BoxShadow(color: Colors.black38, blurRadius: 14)]),
        alignment: Alignment.center,
        child: Text(label, style: const TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 14, color: Colors.white, letterSpacing: 1)),
      ),
    );
  }
}

class _IconBtn extends StatelessWidget {
  final IconData icon; final Color accent; final VoidCallback onTap;
  const _IconBtn({required this.icon, required this.accent, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(10), border: Border.all(color: accent.withValues(alpha: 0.2))),
        child: Icon(icon, color: Colors.white70, size: 20)),
    );
  }
}

class _Blob extends StatefulWidget {
  final Color color; final double size; final double? top, bottom, left, right; final double delay;
  const _Blob({required this.color, required this.size, this.top, this.bottom, this.left, this.right, this.delay = 0});
  @override State<_Blob> createState() => _BlobState();
}
class _BlobState extends State<_Blob> with SingleTickerProviderStateMixin {
  late AnimationController _c;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat(reverse: true);
  }
  @override void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: widget.top, bottom: widget.bottom, left: widget.left, right: widget.right,
      child: AnimatedBuilder(
        animation: _c,
        builder: (_, __) => Container(
          width: widget.size + _c.value * 30, height: widget.size + _c.value * 30,
          decoration: BoxDecoration(shape: BoxShape.circle, boxShadow: [
            BoxShadow(color: widget.color.withValues(alpha: 0.07 + _c.value * 0.06),
              blurRadius: widget.size * 0.5, spreadRadius: widget.size * 0.25),
          ]),
        ),
      ),
    );
  }
}

class _AnimDelay extends StatefulWidget {
  final Widget child; final int delay;
  const _AnimDelay({required this.child, required this.delay});
  @override State<_AnimDelay> createState() => _AnimDelayState();
}
class _AnimDelayState extends State<_AnimDelay> with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _fade;
  late Animation<Offset> _slide;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 450));
    _fade = CurvedAnimation(parent: _c, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.15), end: Offset.zero)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeOut));
    Future.delayed(Duration(milliseconds: widget.delay), () { if (mounted) _c.forward(); });
  }
  @override void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) =>
      FadeTransition(opacity: _fade, child: SlideTransition(position: _slide, child: widget.child));
}

PageRouteBuilder _slideRoute(Widget page) => PageRouteBuilder(
  pageBuilder: (_, __, ___) => page,
  transitionsBuilder: (_, anim, __, child) => SlideTransition(
    position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
        .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
    child: child,
  ),
  transitionDuration: const Duration(milliseconds: 280),
);

// 
// DAILY BONUS DIALOG
// 
class _DailyBonusDialog extends StatefulWidget {
  final String sessionKey;
  final int bonusAmount;
  final VoidCallback onClaimed;
  const _DailyBonusDialog({
    required this.sessionKey,
    required this.bonusAmount,
    required this.onClaimed,
  });
  @override
  State<_DailyBonusDialog> createState() => _DailyBonusDialogState();
}

class _DailyBonusDialogState extends State<_DailyBonusDialog>
    with SingleTickerProviderStateMixin {
  bool _loading = false;
  bool _claimed = false;
  String _message = '';
  late AnimationController _coinCtrl;
  late Animation<double> _coinAnim;

  @override
  void initState() {
    super.initState();
    _coinCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _coinAnim = CurvedAnimation(parent: _coinCtrl, curve: Curves.elasticOut);
    _coinCtrl.forward();
  }

  @override
  void dispose() {
    _coinCtrl.dispose();
    super.dispose();
  }

  Future<void> _doClaim() async {
    setState(() { _loading = true; });
    final res = await BetApi.claimDaily(widget.sessionKey);
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (res['valid'] == true && res['canClaim'] == true) {
        _claimed = true;
        _message = '+${_formatRupiah(res['bonusAmount'] ?? widget.bonusAmount)} koin!';
        widget.onClaimed();
      } else {
        _message = res['message'] ?? 'Gagal klaim bonus';
      }
    });
    if (_claimed) {
      await Future.delayed(const Duration(seconds: 2));
      if (mounted) Navigator.of(context).pop();
    }
  }

  String _formatRupiah(int n) {
    if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(1)}jt';
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(0)}rb';
    return n.toString();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: ScaleTransition(
        scale: _coinAnim,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF1A1A2E), Color(0xFF16213E)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: Color(0xFFFFD700).withValues(alpha: 0.5), width: 1.5),
            boxShadow: [
              BoxShadow(color: Color(0xFFFFD700).withValues(alpha: 0.2), blurRadius: 20, spreadRadius: 2),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Icon koin animasi
              Container(
                width: 80, height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const RadialGradient(colors: [Color(0xFFFFD700), Color(0xFFFF8C00)]),
                  boxShadow: [BoxShadow(color: Color(0xFFFFD700).withValues(alpha: 0.5), blurRadius: 20)],
                ),
                child: const Center(child: Text('🪙', style: TextStyle(fontSize: 40))),
              ),
              const SizedBox(height: 16),
              const Text(
                'Bonus Harian!',
                style: TextStyle(color: Color(0xFFFFD700), fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Text(
                'Klaim bonus harian kamu\n+${_formatRupiah(widget.bonusAmount)} koin gratis!',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white.withValues(alpha: 0.8), fontSize: 14),
              ),
              const SizedBox(height: 20),
              if (_message.isNotEmpty)
                AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: _claimed
                        ? Color(0xFF00C853).withValues(alpha: 0.2)
                        : Colors.red.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: _claimed ? const Color(0xFF00C853) : Colors.red,
                    ),
                  ),
                  child: Text(
                    _message,
                    style: TextStyle(
                      color: _claimed ? const Color(0xFF00C853) : Colors.red,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
              if (_message.isEmpty) ...[
                const SizedBox(height: 4),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _loading ? null : _doClaim,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFFD700),
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    child: _loading
                        ? const SizedBox(width: 20, height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                        : const Text('Klaim Sekarang!', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  ),
                ),
                const SizedBox(height: 8),
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: Text('Nanti aja', style: TextStyle(color: Colors.white.withValues(alpha: 0.5))),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
