import 'package:flutter/material.dart';
import 'novel_read_page.dart';

class NovelHomePage extends StatefulWidget {
  const NovelHomePage({super.key});

  @override
  State<NovelHomePage> createState() => _NovelHomePageState();
}

class _NovelHomePageState extends State<NovelHomePage> {
  String _selectedGenre = 'Semua';

  static const List<Map<String, dynamic>> novels = [
    // Horror
    {
      'title': 'Rumah di Ujung Gang',
      'genre': 'Horror',
      'emoji': '🩸',
      'cover': 'https://images.unsplash.com/photo-1520209759809-a9bcb6cb3241?w=400',
      'desc': 'Sebuah rumah tua yang menyimpan rahasia kelam di balik temboknya.',
    },
    {
      'title': 'Bisikan dari Balik Cermin',
      'genre': 'Horror',
      'emoji': '🩸',
      'cover': 'https://images.unsplash.com/photo-1509248961158-e54f6934749c?w=400',
      'desc': 'Bayangan di cermin bergerak lebih lambat dari tubuhnya.',
    },
    {
      'title': 'Malam Ketujuh',
      'genre': 'Horror',
      'emoji': '🩸',
      'cover': 'https://images.unsplash.com/photo-1476231682828-37e571bc172f?w=400',
      'desc': 'Setiap tujuh tahun, satu nyawa harus dibayar.',
    },
    {
      'title': 'Boneka Tanpa Wajah',
      'genre': 'Horror',
      'emoji': '🩸',
      'cover': 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=400',
      'desc': 'Boneka itu selalu ada di mana pun kamu pergi.',
    },
    {
      'title': 'Suara di Lantai Tiga',
      'genre': 'Horror',
      'emoji': '🩸',
      'cover': 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=400',
      'desc': 'Lantai tiga sudah dikunci selama dua puluh tahun.',
    },

    // Romance
    {
      'title': 'Cinta di Musim Hujan',
      'genre': 'Romance',
      'emoji': '💕',
      'cover': 'https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?w=400',
      'desc': 'Dua jiwa bertemu di bawah hujan yang sama.',
    },
    {
      'title': 'Surat yang Tak Pernah Terkirim',
      'genre': 'Romance',
      'emoji': '💕',
      'cover': 'https://images.unsplash.com/photo-1474552226712-ac0f0961a954?w=400',
      'desc': 'Ratusan surat cinta yang disimpan rapi dalam sebuah kotak.',
    },
    {
      'title': 'Antara Jakarta dan Jogja',
      'genre': 'Romance',
      'emoji': '💕',
      'cover': 'https://images.unsplash.com/photo-1530541930197-ff16ac917b0e?w=400',
      'desc': 'Jarak bukan halangan, tapi waktu adalah musuh terbesar.',
    },
    {
      'title': 'Kamu yang Kedua',
      'genre': 'Romance',
      'emoji': '💕',
      'cover': 'https://images.unsplash.com/photo-1529336953128-a85760f58ea5?w=400',
      'desc': 'Belajar mencintai lagi setelah hati pernah hancur.',
    },
    {
      'title': 'Deadline Cinta',
      'genre': 'Romance',
      'emoji': '💕',
      'cover': 'https://images.unsplash.com/photo-1518199266791-5375a83190b7?w=400',
      'desc': 'Editor galak jatuh cinta pada penulis yang ia tolak.',
    },
    {
      'title': 'Salah Kirim Pesan',
      'genre': 'Romance',
      'emoji': '💕',
      'cover': 'https://images.unsplash.com/photo-1546961342-ea5f62d5a27b?w=400',
      'desc': 'Dari salah kirim pesan, tumbuh sesuatu yang tak terduga.',
    },

    // Fantasy
    {
      'title': 'Pedang Sang Dewa',
      'genre': 'Fantasy',
      'emoji': '⚔️',
      'cover': 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=400',
      'desc': 'Hanya yang terpilih bisa mencabut pedang dari batu keabadian.',
    },
    {
      'title': 'Naga Terakhir Nusantara',
      'genre': 'Fantasy',
      'emoji': '⚔️',
      'cover': 'https://images.unsplash.com/photo-1462275646964-a0e3386b89fa?w=400',
      'desc': 'Naga purba bangkit dari tidurnya setelah seribu tahun.',
    },
    {
      'title': 'Kerajaan di Balik Kabut',
      'genre': 'Fantasy',
      'emoji': '⚔️',
      'cover': 'https://images.unsplash.com/photo-1519677584237-752f8853252e?w=400',
      'desc': 'Sebuah kerajaan tersembunyi yang hanya bisa dilihat saat fajar.',
    },
    {
      'title': 'Penyihir Kota Tua',
      'genre': 'Fantasy',
      'emoji': '⚔️',
      'cover': 'https://images.unsplash.com/photo-1528360983277-13d401cdc186?w=400',
      'desc': 'Penyihir terakhir hidup di antara manusia biasa.',
    },
    {
      'title': 'Mahkota Darah Bulan',
      'genre': 'Fantasy',
      'emoji': '⚔️',
      'cover': 'https://images.unsplash.com/photo-1504333638930-c8787321eee0?w=400',
      'desc': 'Siapa yang mengenakan mahkota ini akan membayar dengan darah.',
    },

    // Mystery
    {
      'title': 'Tanda Tangan Misterius',
      'genre': 'Mystery',
      'emoji': '🔍',
      'cover': 'https://images.unsplash.com/photo-1494548162494-384bba4ab999?w=400',
      'desc': 'Setiap korban meninggalkan tanda tangan yang sama.',
    },
    {
      'title': 'Kamar 404',
      'genre': 'Mystery',
      'emoji': '🔍',
      'cover': 'https://images.unsplash.com/photo-1445991842772-097fea258e7b?w=400',
      'desc': 'Hotel itu punya kamar yang tidak ada di denah manapun.',
    },
    {
      'title': 'Detektif Tanpa Nama',
      'genre': 'Mystery',
      'emoji': '🔍',
      'cover': 'https://images.unsplash.com/photo-1509343256512-d77a5cb3791b?w=400',
      'desc': 'Ia memecahkan setiap kasus, namun identitasnya tetap misteri.',
    },
    {
      'title': 'Hilang di Malam Minggu',
      'genre': 'Mystery',
      'emoji': '🔍',
      'cover': 'https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?w=400',
      'desc': 'Gadis itu menghilang tepat pukul tengah malam.',
    },
    {
      'title': 'Warisan Berdarah',
      'genre': 'Mystery',
      'emoji': '🔍',
      'cover': 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=400',
      'desc': 'Siapa yang paling berhak atas warisan itu, paling berbahaya.',
    },

    // Sci-Fi
    {
      'title': 'Koloni Terakhir',
      'genre': 'Sci-Fi',
      'emoji': '🌌',
      'cover': 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=400',
      'desc': 'Manusia terakhir bertahan di planet yang sekarat.',
    },
    {
      'title': 'Android Bernama Raya',
      'genre': 'Sci-Fi',
      'emoji': '🌌',
      'cover': 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=400',
      'desc': 'Android itu mulai bermimpi tentang hal-hal yang tidak seharusnya.',
    },
    {
      'title': 'Tahun 2187',
      'genre': 'Sci-Fi',
      'emoji': '🌌',
      'cover': 'https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=400',
      'desc': 'Bumi sudah ditinggalkan, tapi seseorang memilih kembali.',
    },
    {
      'title': 'Sinyal dari Bintang Mati',
      'genre': 'Sci-Fi',
      'emoji': '🌌',
      'cover': 'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=400',
      'desc': 'Sinyal dari bintang yang sudah padam jutaan tahun lalu.',
    },
    {
      'title': 'Mesin Waktu Rusak',
      'genre': 'Sci-Fi',
      'emoji': '🌌',
      'cover': 'https://images.unsplash.com/photo-1506318137071-a8e063b4bec0?w=400',
      'desc': 'Terjebak di antara dua masa yang berbeda.',
    },

    // Adventure
    {
      'title': 'Peta Hutan Terlarang',
      'genre': 'Adventure',
      'emoji': '🗺️',
      'cover': 'https://images.unsplash.com/photo-1448375240586-882707db888b?w=400',
      'desc': 'Hutan itu ada di peta, tapi tidak ada di dunia nyata.',
    },
    {
      'title': 'Jejak di Pegunungan Utara',
      'genre': 'Adventure',
      'emoji': '🗺️',
      'cover': 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=400',
      'desc': 'Ekspedisi berbahaya menuju puncak yang belum pernah dijejak.',
    },
    {
      'title': 'Kapal Bajak Laut Terakhir',
      'genre': 'Adventure',
      'emoji': '🗺️',
      'cover': 'https://images.unsplash.com/photo-1505118380757-91f5f5632de0?w=400',
      'desc': 'Bajak laut terakhir di era modern yang mengejar harta karun.',
    },
    {
      'title': 'Lembah yang Terlupakan',
      'genre': 'Adventure',
      'emoji': '🗺️',
      'cover': 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400',
      'desc': 'Di balik pegunungan tersembunyi, ada peradaban yang hilang.',
    },
    {
      'title': 'Survivor Pulau Hantu',
      'genre': 'Adventure',
      'emoji': '🗺️',
      'cover': 'https://images.unsplash.com/photo-1559128010-7c1ad6e1b6a5?w=400',
      'desc': 'Terdampar di pulau yang katanya tidak berpenghuni.',
    },

    // Thriller
    {
      'title': 'Penumpang Terakhir',
      'genre': 'Thriller',
      'emoji': '⚡',
      'cover': 'https://images.unsplash.com/photo-1474487548417-781cb71495f3?w=400',
      'desc': 'Kereta malam itu seharusnya sudah kosong pukul dua belas.',
    },
    {
      'title': 'Bom Waktu',
      'genre': 'Thriller',
      'emoji': '⚡',
      'cover': 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=400',
      'desc': 'Dua puluh empat jam untuk menghentikan bencana terbesar.',
    },
    {
      'title': 'Saksi Mata',
      'genre': 'Thriller',
      'emoji': '⚡',
      'cover': 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?w=400',
      'desc': 'Ia melihat sesuatu yang tidak seharusnya ia lihat.',
    },
    {
      'title': 'Identitas Palsu',
      'genre': 'Thriller',
      'emoji': '⚡',
      'cover': 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=400',
      'desc': 'Hidup dengan nama orang lain sampai kebenaran terkuak.',
    },
    {
      'title': 'Konspirasi Tingkat Tinggi',
      'genre': 'Thriller',
      'emoji': '⚡',
      'cover': 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=400',
      'desc': 'Satu dokumen bisa mengguncang pemerintahan.',
    },

    // Drama
    {
      'title': 'Keluarga yang Tersisa',
      'genre': 'Drama',
      'emoji': '🎭',
      'cover': 'https://images.unsplash.com/photo-1511895426328-dc8714191011?w=400',
      'desc': 'Setelah tragedi, empat bersaudara belajar saling memaafkan.',
    },
    {
      'title': 'Ibu Kedua',
      'genre': 'Drama',
      'emoji': '🎭',
      'cover': 'https://images.unsplash.com/photo-1491013516836-7db643ee125a?w=400',
      'desc': 'Wanita itu merawat anak orang lain seperti anaknya sendiri.',
    },
    {
      'title': 'Mimpi yang Tertunda',
      'genre': 'Drama',
      'emoji': '🎭',
      'cover': 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=400',
      'desc': 'Impian yang dikorbankan demi keluarga, bangkit kembali.',
    },
    {
      'title': 'Dua Dunia Berbeda',
      'genre': 'Drama',
      'emoji': '🎭',
      'cover': 'https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?w=400',
      'desc': 'Kaya dan miskin, tapi takdir mempertemukan mereka.',
    },

    // Supernatural
    {
      'title': 'Penjaga Gerbang',
      'genre': 'Supernatural',
      'emoji': '👁️',
      'cover': 'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=400',
      'desc': 'Ada penjaga di setiap pintu yang kamu buka.',
    },
    {
      'title': 'Roh yang Belum Pergi',
      'genre': 'Supernatural',
      'emoji': '👁️',
      'cover': 'https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?w=400',
      'desc': 'Roh itu tidak tahu bahwa dirinya sudah mati.',
    },
    {
      'title': 'Dimensi Ketiga',
      'genre': 'Supernatural',
      'emoji': '👁️',
      'cover': 'https://images.unsplash.com/photo-1462332420958-a05d1e002413?w=400',
      'desc': 'Di antara dunia nyata dan alam gaib, ada ruang ketiga.',
    },
    {
      'title': 'Manusia Bayangan',
      'genre': 'Supernatural',
      'emoji': '👁️',
      'cover': 'https://images.unsplash.com/photo-1504701954957-2010ec3bcec1?w=400',
      'desc': 'Bayangannya bergerak sendiri saat tidak ada yang melihat.',
    },

    // Comedy
    {
      'title': 'Kos-Kosan Aneh',
      'genre': 'Comedy',
      'emoji': '😂',
      'cover': 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=400',
      'desc': 'Penghuni kos paling random se-Indonesia ngumpul di satu tempat.',
    },
    {
      'title': 'Salah Masuk Grup',
      'genre': 'Comedy',
      'emoji': '😂',
      'cover': 'https://images.unsplash.com/photo-1543269664-56d93c1b41a6?w=400',
      'desc': 'Masuk grup WA keluarga besar pacar secara tidak sengaja.',
    },
    {
      'title': 'Bos yang Absurd',
      'genre': 'Comedy',
      'emoji': '😂',
      'cover': 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=400',
      'desc': 'Bos paling aneh se-dunia, tapi entah kenapa sukses terus.',
    },
    {
      'title': 'Misi Mustahil: Lulus Kuliah',
      'genre': 'Comedy',
      'emoji': '😂',
      'cover': 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=400',
      'desc': 'Empat tahun kuliah penuh drama, receh, dan deadline.',
    },
    {
      'title': 'Ojek Online Ketua RT',
      'genre': 'Comedy',
      'emoji': '😂',
      'cover': 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400',
      'desc': 'Pak RT nekat jadi driver ojol demi renovasi posyandu.',
    },
    {
      'title': 'Chef Dadakan',
      'genre': 'Comedy',
      'emoji': '😂',
      'cover': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400',
      'desc': 'Pria yang tidak bisa masak tiba-tiba buka warung makan.',
    },
  ];

  static const List<String> genreFilters = [
    'Semua', 'Horror', 'Romance', 'Fantasy', 'Mystery',
    'Sci-Fi', 'Adventure', 'Thriller', 'Drama', 'Supernatural', 'Comedy',
  ];

  static const Map<String, Color> genreColors = {
    'Horror': Color(0xFF8B0000),
    'Romance': Color(0xFFB5006E),
    'Fantasy': Color(0xFF4A00B0),
    'Mystery': Color(0xFF00506B),
    'Sci-Fi': Color(0xFF003D6B),
    'Adventure': Color(0xFF1A5C00),
    'Thriller': Color(0xFF5C3800),
    'Drama': Color(0xFF5C0050),
    'Supernatural': Color(0xFF2D006B),
    'Comedy': Color(0xFF8B6200),
  };

  List<Map<String, dynamic>> get _filteredNovels {
    if (_selectedGenre == 'Semua') return novels;
    return novels.where((n) => n['genre'] == _selectedGenre).toList();
  }

  Color _genreColor(String genre) =>
      genreColors[genre] ?? const Color(0xFF333355);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0F),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 8,
                        height: 8,
                        decoration: const BoxDecoration(
                          color: Color(0xFF7B61FF),
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 8),
                      const Text(
                        'NOVEL AI',
                        style: TextStyle(
                          color: Color(0xFF7B61FF),
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 3,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      const Text(
                        'Pilih Novel',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 32,
                          fontWeight: FontWeight.w900,
                          height: 1.1,
                        ),
                      ),
                      Text(
                        '${_filteredNovels.length} cerita',
                        style: const TextStyle(
                          color: Colors.white38,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // Genre Filter
            SizedBox(
              height: 36,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: genreFilters.length,
                itemBuilder: (ctx, i) {
                  final g = genreFilters[i];
                  final selected = _selectedGenre == g;
                  return GestureDetector(
                    onTap: () => setState(() => _selectedGenre = g),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: const EdgeInsets.only(right: 8),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        color: selected
                            ? const Color(0xFF7B61FF)
                            : const Color(0xFF1A1A2E),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: selected
                              ? const Color(0xFF7B61FF)
                              : Colors.white12,
                        ),
                      ),
                      child: Text(
                        g,
                        style: TextStyle(
                          color: selected ? Colors.white : Colors.white54,
                          fontSize: 12,
                          fontWeight: selected
                              ? FontWeight.bold
                              : FontWeight.normal,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),

            const SizedBox(height: 16),

            // Novel Grid
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 0.65,
                ),
                itemCount: _filteredNovels.length,
                itemBuilder: (ctx, i) {
                  final novel = _filteredNovels[i];
                  return _NovelCard(
                    novel: novel,
                    color: _genreColor(novel['genre']),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _NovelCard extends StatefulWidget {
  final Map<String, dynamic> novel;
  final Color color;
  const _NovelCard({required this.novel, required this.color});

  @override
  State<_NovelCard> createState() => _NovelCardState();
}

class _NovelCardState extends State<_NovelCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => NovelReadPage(novel: widget.novel),
          ),
        );
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.95 : 1.0,
        duration: const Duration(milliseconds: 100),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            color: const Color(0xFF12121F),
            border: Border.all(color: widget.color.withOpacity(0.3), width: 1),
          ),
          clipBehavior: Clip.hardEdge,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Cover Image
              Expanded(
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.network(
                      widget.novel['cover'],
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        color: widget.color.withOpacity(0.3),
                        child: Center(
                          child: Text(
                            widget.novel['emoji'],
                            style: const TextStyle(fontSize: 40),
                          ),
                        ),
                      ),
                    ),
                    // Gradient overlay
                    Positioned(
                      bottom: 0,
                      left: 0,
                      right: 0,
                      child: Container(
                        height: 60,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                            colors: [
                              const Color(0xFF12121F),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    ),
                    // Genre badge
                    Positioned(
                      top: 8,
                      left: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: widget.color.withOpacity(0.85),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          widget.novel['genre'],
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // Info
              Padding(
                padding: const EdgeInsets.all(10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.novel['title'],
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                        height: 1.3,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      widget.novel['desc'],
                      style: const TextStyle(
                        color: Colors.white38,
                        fontSize: 10,
                        height: 1.3,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
