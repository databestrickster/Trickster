import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Manga Search',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFFF6B35),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const MangaSearchPage(),
    );
  }
}

// ─── Models ───────────────────────────────────────────────────────────────────

class Manga {
  final String id;
  final String title;
  final String? description;
  final String? coverId;
  final String? status;
  final List<String> tags;

  const Manga({
    required this.id,
    required this.title,
    this.description,
    this.coverId,
    this.status,
    required this.tags,
  });

  String? get coverUrl => coverId != null
      ? 'https://uploads.mangadex.org/covers/$id/$coverId.256.jpg'
      : null;

  factory Manga.fromJson(Map<String, dynamic> json) {
    final attrs = json['attributes'] as Map<String, dynamic>;

    final titlesMap = (attrs['title'] as Map<String, dynamic>?) ?? {};
    final title = titlesMap['en'] ??
        titlesMap['ja-ro'] ??
        titlesMap.values.firstOrNull ??
        'Unknown Title';

    final descMap = (attrs['description'] as Map<String, dynamic>?) ?? {};
    final description = descMap['en'] ?? descMap.values.firstOrNull;

    final rels = (json['relationships'] as List<dynamic>?) ?? [];
    final coverRel = rels.firstWhere(
      (r) => r['type'] == 'cover_art',
      orElse: () => null,
    );
    final coverId = coverRel?['attributes']?['fileName'] as String?;

    final tagList = (attrs['tags'] as List<dynamic>?) ?? [];
    final tags = tagList
        .map((t) {
          final tagAttrs = t['attributes'] as Map<String, dynamic>?;
          final tagName = tagAttrs?['name'] as Map<String, dynamic>?;
          return tagName?['en'] as String?;
        })
        .whereType<String>()
        .toList();

    return Manga(
      id: json['id'] as String,
      title: title as String,
      description: description as String?,
      coverId: coverId,
      status: attrs['status'] as String?,
      tags: tags,
    );
  }
}

class Chapter {
  final String id;
  final String? chapterNumber;
  final String? title;
  final String? volume;
  final String translatedLanguage;
  final int pageCount;
  final DateTime? publishAt;

  const Chapter({
    required this.id,
    this.chapterNumber,
    this.title,
    this.volume,
    required this.translatedLanguage,
    required this.pageCount,
    this.publishAt,
  });

  String get displayTitle {
    final ch = chapterNumber != null ? 'Ch. $chapterNumber' : 'Oneshot';
    final t = (title != null && title!.isNotEmpty) ? ' — $title' : '';
    return '$ch$t';
  }

  factory Chapter.fromJson(Map<String, dynamic> json) {
    final attrs = json['attributes'] as Map<String, dynamic>;
    DateTime? publishAt;
    try {
      final dateStr = attrs['publishAt'] as String?;
      if (dateStr != null) publishAt = DateTime.parse(dateStr);
    } catch (_) {}

    return Chapter(
      id: json['id'] as String,
      chapterNumber: attrs['chapter'] as String?,
      title: attrs['title'] as String?,
      volume: attrs['volume'] as String?,
      translatedLanguage: attrs['translatedLanguage'] as String? ?? 'en',
      pageCount: attrs['pages'] as int? ?? 0,
      publishAt: publishAt,
    );
  }
}

// ─── Service ─────────────────────────────────────────────────────────────────

class MangaDexService {
  static const _base = 'https://api.mangadex.org';
  static const _headers = {'User-Agent': 'MangaSearchApp/1.0'};

  Future<List<Manga>> searchManga(String query, {int limit = 20}) async {
    final uri = Uri.parse('$_base/manga').replace(queryParameters: {
      'title': query,
      'limit': limit.toString(),
      'includes[]': 'cover_art',
      'order[relevance]': 'desc',
    });
    final response = await http.get(uri, headers: _headers);
    if (response.statusCode != 200) {
      throw Exception('Gagal fetch manga: ${response.statusCode}');
    }
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final results = (data['data'] as List<dynamic>?) ?? [];
    return results
        .map((e) => Manga.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<List<Chapter>> fetchChapters(String mangaId,
      {int limit = 100, int offset = 0}) async {
    final uri =
        Uri.parse('$_base/manga/$mangaId/feed').replace(queryParameters: {
      'limit': limit.toString(),
      'offset': offset.toString(),
      'translatedLanguage[]': 'en',
      'order[chapter]': 'asc',
      'order[volume]': 'asc',
    });
    final response = await http.get(uri, headers: _headers);
    if (response.statusCode != 200) {
      throw Exception('Gagal fetch chapter: ${response.statusCode}');
    }
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final results = (data['data'] as List<dynamic>?) ?? [];
    return results
        .map((e) => Chapter.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<List<String>> fetchChapterPages(String chapterId) async {
    final uri = Uri.parse('$_base/at-home/server/$chapterId');
    final response = await http.get(uri, headers: _headers);
    if (response.statusCode != 200) {
      throw Exception('Gagal fetch pages: ${response.statusCode}');
    }
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final baseUrl = data['baseUrl'] as String;
    final chapterData = data['chapter'] as Map<String, dynamic>;
    final hash = chapterData['hash'] as String;

    // Coba 'data' dulu, kalau kosong pakai 'dataSaver'
    final pageList = (chapterData['data'] as List<dynamic>?)?.isNotEmpty == true
        ? chapterData['data'] as List<dynamic>
        : (chapterData['dataSaver'] as List<dynamic>?) ?? [];

    final folder = (chapterData['data'] as List<dynamic>?)?.isNotEmpty == true
        ? 'data'
        : 'data-saver';

    final pages = pageList.map((e) => '$baseUrl/$folder/$hash/$e').toList();
    return pages;
  }
}

// ─── MangaSearch Page ─────────────────────────────────────────────────────────

class MangaSearchPage extends StatefulWidget {
  const MangaSearchPage({super.key});

  @override
  State<MangaSearchPage> createState() => _MangaSearchPageState();
}

class _MangaSearchPageState extends State<MangaSearchPage> {
  final _service = MangaDexService();
  final _controller = TextEditingController();
  final _scrollController = ScrollController();

  List<Manga> _results = [];
  bool _loading = false;
  String? _error;
  bool _hasSearched = false;

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _search() async {
    final query = _controller.text.trim();
    if (query.isEmpty) return;

    setState(() {
      _loading = true;
      _error = null;
      _hasSearched = true;
    });

    try {
      final results = await _service.searchManga(query);
      setState(() {
        _results = results;
        _loading = false;
      });
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          0,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1E1E1E),
        elevation: 0,
        title: const Row(
          children: [
            Icon(Icons.menu_book_rounded, color: Color(0xFFFF6B35), size: 28),
            SizedBox(width: 10),
            Text(
              'Manga Search',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 22,
              ),
            ),
          ],
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(70),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: _SearchBar(
              controller: _controller,
              onSearch: _search,
            ),
          ),
        ),
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(color: Color(0xFFFF6B35)),
            SizedBox(height: 16),
            Text('Mencari manga...', style: TextStyle(color: Colors.white54)),
          ],
        ),
      );
    }

    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.wifi_off_rounded,
                  color: Colors.redAccent, size: 64),
              const SizedBox(height: 16),
              Text(
                'Gagal memuat data',
                style: Theme.of(context)
                    .textTheme
                    .titleLarge
                    ?.copyWith(color: Colors.white),
              ),
              const SizedBox(height: 8),
              Text(
                _error!,
                style: const TextStyle(color: Colors.white38, fontSize: 12),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: _search,
                icon: const Icon(Icons.refresh),
                label: const Text('Coba Lagi'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFF6B35),
                ),
              ),
            ],
          ),
        ),
      );
    }

    if (!_hasSearched) {
      return _buildEmptyState(
        icon: Icons.search_rounded,
        message: 'Cari manga favoritmu!',
        subtitle: 'Ketik judul manga di atas lalu tekan search',
      );
    }

    if (_results.isEmpty) {
      return _buildEmptyState(
        icon: Icons.sentiment_dissatisfied_rounded,
        message: 'Manga tidak ditemukan',
        subtitle: 'Coba kata kunci yang berbeda',
      );
    }

    return GridView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.all(12),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 0.58,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemCount: _results.length,
      itemBuilder: (context, index) => _MangaCard(
        manga: _results[index],
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => MangaDetailPage(manga: _results[index]),
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState({
    required IconData icon,
    required String message,
    required String subtitle,
  }) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: const Color(0xFFFF6B35), size: 72),
          const SizedBox(height: 16),
          Text(
            message,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(subtitle, style: const TextStyle(color: Colors.white38)),
        ],
      ),
    );
  }
}

// ─── Search Bar ──────────────────────────────────────────────────────────────

class _SearchBar extends StatelessWidget {
  final TextEditingController controller;
  final VoidCallback onSearch;

  const _SearchBar({required this.controller, required this.onSearch});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: TextField(
            controller: controller,
            style: const TextStyle(color: Colors.white),
            textInputAction: TextInputAction.search,
            onSubmitted: (_) => onSearch(),
            decoration: InputDecoration(
              hintText: 'Cari manga... (contoh: Naruto)',
              hintStyle: const TextStyle(color: Colors.white38),
              prefixIcon:
                  const Icon(Icons.search, color: Colors.white38),
              filled: true,
              fillColor: const Color(0xFF2C2C2C),
              contentPadding: const EdgeInsets.symmetric(vertical: 12),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide:
                    const BorderSide(color: Color(0xFFFF6B35), width: 1.5),
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        Material(
          color: const Color(0xFFFF6B35),
          borderRadius: BorderRadius.circular(12),
          child: InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: onSearch,
            child: const Padding(
              padding: EdgeInsets.all(14),
              child: Icon(Icons.search_rounded, color: Colors.white),
            ),
          ),
        ),
      ],
    );
  }
}

// ─── Manga Card ──────────────────────────────────────────────────────────────

class _MangaCard extends StatelessWidget {
  final Manga manga;
  final VoidCallback onTap;

  const _MangaCard({required this.manga, required this.onTap});

  Color _statusColor(String? status) {
    switch (status) {
      case 'ongoing':
        return Colors.greenAccent;
      case 'completed':
        return Colors.blueAccent;
      case 'hiatus':
        return Colors.orangeAccent;
      case 'cancelled':
        return Colors.redAccent;
      default:
        return Colors.white38;
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF1E1E1E),
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.4),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        clipBehavior: Clip.hardEdge,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 7,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  manga.coverUrl != null
                      ? Image.network(
                          manga.coverUrl!,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => _placeholder(),
                          loadingBuilder: (_, child, progress) {
                            if (progress == null) return child;
                            return Container(
                              color: const Color(0xFF2C2C2C),
                              child: const Center(
                                child: CircularProgressIndicator(
                                  color: Color(0xFFFF6B35),
                                  strokeWidth: 2,
                                ),
                              ),
                            );
                          },
                        )
                      : _placeholder(),
                  if (manga.status != null)
                    Positioned(
                      top: 8,
                      left: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.75),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(
                            color: _statusColor(manga.status),
                            width: 1,
                          ),
                        ),
                        child: Text(
                          manga.status!.toUpperCase(),
                          style: TextStyle(
                            color: _statusColor(manga.status),
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            Expanded(
              flex: 3,
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      manga.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                        height: 1.3,
                      ),
                    ),
                    const SizedBox(height: 4),
                    if (manga.tags.isNotEmpty)
                      Text(
                        manga.tags.take(2).join(' · '),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Color(0xFFFF6B35),
                          fontSize: 10,
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _placeholder() {
    return Container(
      color: const Color(0xFF2C2C2C),
      child: const Center(
        child:
            Icon(Icons.menu_book_rounded, color: Colors.white24, size: 48),
      ),
    );
  }
}

// ─── Manga Detail Page ───────────────────────────────────────────────────────

class MangaDetailPage extends StatefulWidget {
  final Manga manga;

  const MangaDetailPage({super.key, required this.manga});

  @override
  State<MangaDetailPage> createState() => _MangaDetailPageState();
}

class _MangaDetailPageState extends State<MangaDetailPage> {
  final _service = MangaDexService();

  List<Chapter> _chapters = [];
  bool _loadingChapters = true;
  String? _chapterError;
  bool _synopsisExpanded = false;

  @override
  void initState() {
    super.initState();
    _loadChapters();
  }

  Future<void> _loadChapters() async {
    try {
      final chapters = await _service.fetchChapters(widget.manga.id);
      setState(() {
        _chapters = chapters;
        _loadingChapters = false;
      });
    } catch (e) {
      setState(() {
        _chapterError = e.toString();
        _loadingChapters = false;
      });
    }
  }

  Color _statusColor(String? status) {
    switch (status) {
      case 'ongoing':
        return Colors.greenAccent;
      case 'completed':
        return Colors.blueAccent;
      case 'hiatus':
        return Colors.orangeAccent;
      case 'cancelled':
        return Colors.redAccent;
      default:
        return Colors.white38;
    }
  }

  @override
  Widget build(BuildContext context) {
    final manga = widget.manga;

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      body: CustomScrollView(
        slivers: [
          // ── AppBar dengan cover sebagai background ──
          SliverAppBar(
            expandedHeight: 300,
            pinned: true,
            backgroundColor: const Color(0xFF1E1E1E),
            leading: IconButton(
              icon: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(Icons.arrow_back_ios_new,
                    color: Colors.white, size: 18),
              ),
              onPressed: () => Navigator.pop(context),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  // Background blur cover
                  if (manga.coverUrl != null)
                    Image.network(
                      manga.coverUrl!,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        color: const Color(0xFF2C2C2C),
                      ),
                    )
                  else
                    Container(color: const Color(0xFF2C2C2C)),
                  // Gradient overlay
                  Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.transparent,
                          Color(0xCC000000),
                          Color(0xFF121212),
                        ],
                        stops: [0.3, 0.7, 1.0],
                      ),
                    ),
                  ),
                  // Cover + info bawah
                  Positioned(
                    bottom: 16,
                    left: 16,
                    right: 16,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        // Cover kecil
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: manga.coverUrl != null
                              ? Image.network(
                                  manga.coverUrl!,
                                  width: 90,
                                  height: 130,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) =>
                                      Container(
                                    width: 90,
                                    height: 130,
                                    color: const Color(0xFF2C2C2C),
                                  ),
                                )
                              : Container(
                                  width: 90,
                                  height: 130,
                                  color: const Color(0xFF2C2C2C),
                                  child: const Icon(
                                      Icons.menu_book_rounded,
                                      color: Colors.white24,
                                      size: 40),
                                ),
                        ),
                        const SizedBox(width: 14),
                        // Judul + status + tags
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                manga.title,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  height: 1.3,
                                ),
                                maxLines: 3,
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 6),
                              if (manga.status != null)
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 3),
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                        color: _statusColor(manga.status),
                                        width: 1),
                                    borderRadius: BorderRadius.circular(6),
                                    color: Colors.black38,
                                  ),
                                  child: Text(
                                    manga.status!.toUpperCase(),
                                    style: TextStyle(
                                      color: _statusColor(manga.status),
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              const SizedBox(height: 8),
                              if (manga.tags.isNotEmpty)
                                Wrap(
                                  spacing: 6,
                                  runSpacing: 4,
                                  children: manga.tags
                                      .take(4)
                                      .map(
                                        (tag) => Container(
                                          padding:
                                              const EdgeInsets.symmetric(
                                                  horizontal: 7,
                                                  vertical: 3),
                                          decoration: BoxDecoration(
                                            color: const Color(0xFF2C2C2C),
                                            borderRadius:
                                                BorderRadius.circular(6),
                                          ),
                                          child: Text(
                                            tag,
                                            style: const TextStyle(
                                              color: Color(0xFFFF6B35),
                                              fontSize: 10,
                                            ),
                                          ),
                                        ),
                                      )
                                      .toList(),
                                ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          // ── Sinopsis ──
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Sinopsis',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  if (manga.description != null &&
                      manga.description!.isNotEmpty)
                    GestureDetector(
                      onTap: () => setState(
                          () => _synopsisExpanded = !_synopsisExpanded),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            manga.description!,
                            maxLines: _synopsisExpanded ? null : 4,
                            overflow: _synopsisExpanded
                                ? TextOverflow.visible
                                : TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white70,
                              fontSize: 13,
                              height: 1.6,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            _synopsisExpanded
                                ? 'Tampilkan lebih sedikit'
                                : 'Tampilkan lebih banyak',
                            style: const TextStyle(
                              color: Color(0xFFFF6B35),
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    )
                  else
                    const Text(
                      'Tidak ada sinopsis.',
                      style: TextStyle(color: Colors.white38, fontSize: 13),
                    ),
                  const SizedBox(height: 24),
                  // Header chapter
                  Row(
                    children: [
                      const Text(
                        'Daftar Chapter',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const Spacer(),
                      if (!_loadingChapters && _chapterError == null)
                        Text(
                          '${_chapters.length} chapter',
                          style: const TextStyle(
                            color: Colors.white38,
                            fontSize: 12,
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 12),
                ],
              ),
            ),
          ),

          // ── Chapter List ──
          if (_loadingChapters)
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Center(
                  child: CircularProgressIndicator(
                      color: Color(0xFFFF6B35)),
                ),
              ),
            )
          else if (_chapterError != null)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    const Icon(Icons.error_outline,
                        color: Colors.redAccent, size: 48),
                    const SizedBox(height: 12),
                    Text(
                      _chapterError!,
                      style: const TextStyle(
                          color: Colors.white38, fontSize: 12),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton(
                      onPressed: () {
                        setState(() {
                          _loadingChapters = true;
                          _chapterError = null;
                        });
                        _loadChapters();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFFF6B35),
                      ),
                      child: const Text('Coba Lagi'),
                    ),
                  ],
                ),
              ),
            )
          else if (_chapters.isEmpty)
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Center(
                  child: Text(
                    'Belum ada chapter tersedia (EN).',
                    style: TextStyle(color: Colors.white38),
                  ),
                ),
              ),
            )
          else
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final chapter = _chapters[index];
                  return _ChapterTile(
                    chapter: chapter,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => MangaReaderPage(
                          chapter: chapter,
                          service: _service,
                        ),
                      ),
                    ),
                  );
                },
                childCount: _chapters.length,
              ),
            ),

          const SliverToBoxAdapter(child: SizedBox(height: 32)),
        ],
      ),
    );
  }
}

// ─── Chapter Tile ─────────────────────────────────────────────────────────────

class _ChapterTile extends StatelessWidget {
  final Chapter chapter;
  final VoidCallback onTap;

  const _ChapterTile({required this.chapter, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final dateStr = chapter.publishAt != null
        ? '${chapter.publishAt!.day}/${chapter.publishAt!.month}/${chapter.publishAt!.year}'
        : null;

    return InkWell(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF1E1E1E),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: const Color(0xFF2C2C2C),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.article_outlined,
                  color: Color(0xFFFF6B35), size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    chapter.displayTitle,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  if (dateStr != null || chapter.pageCount > 0) ...[
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        if (dateStr != null)
                          Text(
                            dateStr,
                            style: const TextStyle(
                                color: Colors.white38, fontSize: 11),
                          ),
                        if (dateStr != null && chapter.pageCount > 0)
                          const Text(' · ',
                              style: TextStyle(
                                  color: Colors.white38, fontSize: 11)),
                        if (chapter.pageCount > 0)
                          Text(
                            '${chapter.pageCount} halaman',
                            style: const TextStyle(
                                color: Colors.white38, fontSize: 11),
                          ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
            const Icon(Icons.chevron_right,
                color: Colors.white24, size: 20),
          ],
        ),
      ),
    );
  }
}

// ─── Manga Reader Page ───────────────────────────────────────────────────────

class MangaReaderPage extends StatefulWidget {
  final Chapter chapter;
  final MangaDexService service;

  const MangaReaderPage(
      {super.key, required this.chapter, required this.service});

  @override
  State<MangaReaderPage> createState() => _MangaReaderPageState();
}

class _MangaReaderPageState extends State<MangaReaderPage> {
  List<String> _pages = [];
  bool _loading = true;
  String? _error;
  bool _showUI = true;

  @override
  void initState() {
    super.initState();
    _loadPages();
  }

  Future<void> _loadPages() async {
    try {
      final pages =
          await widget.service.fetchChapterPages(widget.chapter.id);
      setState(() {
        _pages = pages;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTap: () => setState(() => _showUI = !_showUI),
        child: Stack(
          children: [
            // ── Content ──
            if (_loading)
              const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(color: Color(0xFFFF6B35)),
                    SizedBox(height: 16),
                    Text('Memuat halaman...',
                        style: TextStyle(color: Colors.white54)),
                  ],
                ),
              )
            else if (_error != null)
              Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.broken_image_outlined,
                          color: Colors.redAccent, size: 64),
                      const SizedBox(height: 16),
                      const Text('Gagal memuat halaman',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      Text(_error!,
                          style: const TextStyle(
                              color: Colors.white38, fontSize: 12),
                          textAlign: TextAlign.center),
                      const SizedBox(height: 20),
                      ElevatedButton.icon(
                        onPressed: () {
                          setState(() {
                            _loading = true;
                            _error = null;
                          });
                          _loadPages();
                        },
                        icon: const Icon(Icons.refresh),
                        label: const Text('Coba Lagi'),
                        style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFFF6B35)),
                      ),
                    ],
                  ),
                ),
              )
            else if (_pages.isEmpty)
              const Center(
                child: Text('Tidak ada halaman tersedia',
                    style: TextStyle(color: Colors.white54)),
              )
            else
              ListView.builder(
                itemCount: _pages.length,
                itemBuilder: (context, index) => Image.network(
                  _pages[index],
                  fit: BoxFit.fitWidth,
                  width: double.infinity,
                  headers: const {
                    'User-Agent': 'Mozilla/5.0',
                    'Referer': 'https://mangadex.org/',
                  },
                  loadingBuilder: (_, child, progress) {
                    if (progress == null) return child;
                    return Container(
                      height: 300,
                      color: const Color(0xFF1A1A1A),
                      child: Center(
                        child: CircularProgressIndicator(
                          value: progress.expectedTotalBytes != null
                              ? progress.cumulativeBytesLoaded /
                                  progress.expectedTotalBytes!
                              : null,
                          color: const Color(0xFFFF6B35),
                          strokeWidth: 2,
                        ),
                      ),
                    );
                  },
                  errorBuilder: (_, __, ___) => Container(
                    height: 200,
                    color: const Color(0xFF1A1A1A),
                    child: const Center(
                      child: Icon(Icons.broken_image_outlined,
                          color: Colors.white24, size: 48),
                    ),
                  ),
                ),
              ),

            // ── Top Bar (toggle) ──
            AnimatedPositioned(
              duration: const Duration(milliseconds: 200),
              top: _showUI ? 0 : -100,
              left: 0,
              right: 0,
              child: Container(
                padding: EdgeInsets.only(
                  top: MediaQuery.of(context).padding.top + 8,
                  bottom: 12,
                  left: 8,
                  right: 16,
                ),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.black87, Colors.transparent],
                  ),
                ),
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back_ios_new,
                          color: Colors.white),
                      onPressed: () => Navigator.pop(context),
                    ),
                    Expanded(
                      child: Text(
                        widget.chapter.displayTitle,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (_pages.isNotEmpty)
                      Text(
                        '${_pages.length} hal',
                        style: const TextStyle(
                            color: Colors.white54, fontSize: 12),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
