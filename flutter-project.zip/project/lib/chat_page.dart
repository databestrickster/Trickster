import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter_sound/flutter_sound.dart' hide PlayerState;
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'config_service.dart';
import 'theme_provider.dart';
import 'chat_theme.dart';
import 'story_page.dart';
import 'profile_photo.dart';

// ─────────────────────────────────────────────
// MODEL
// ─────────────────────────────────────────────
class ChatMessage {
  final String id;
  final String from;
  final String to;
  final String message;
  final int timestamp;
  final bool isRead;
  final bool fromMe;
  final String? voiceUrl;   // null = teks biasa, non-null = voice note
  final int? voiceDuration; // detik

  ChatMessage({
    required this.id,
    required this.from,
    required this.to,
    required this.message,
    required this.timestamp,
    required this.isRead,
    required this.fromMe,
    this.voiceUrl,
    this.voiceDuration,
  });

  factory ChatMessage.fromJson(Map<String, dynamic> j, String myUsername) =>
      ChatMessage(
        id: j['id'] ?? '',
        from: j['from'] ?? '',
        to: j['to'] ?? '',
        message: j['message'] ?? '',
        timestamp: j['timestamp'] ?? 0,
        isRead: j['isRead'] == true,
        fromMe: (j['from'] ?? '') == myUsername,
        voiceUrl: j['voiceUrl'],
        voiceDuration: j['voiceDuration'] is int ? j['voiceDuration'] : null,
      );

  bool get isVoice => voiceUrl != null && voiceUrl!.isNotEmpty;
}

class InboxItem {
  final String username;
  final String role;
  final String? photoUrl;
  final String lastMessage;
  final int lastTime;
  final int unread;

  InboxItem({
    required this.username,
    required this.role,
    this.photoUrl,
    required this.lastMessage,
    required this.lastTime,
    required this.unread,
  });

  factory InboxItem.fromJson(Map<String, dynamic> j) => InboxItem(
        username: j['username'] ?? '',
        role: j['role'] ?? 'member',
        photoUrl: j['photoUrl'],
        lastMessage: j['lastMessage'] ?? '',
        lastTime: j['lastTime'] ?? 0,
        unread: j['unread'] ?? 0,
      );
}

// ─────────────────────────────────────────────
// CONTACT USER MODEL
// ─────────────────────────────────────────────
class ContactUser {
  final String username;
  final String role;
  final String? photoUrl;

  ContactUser({required this.username, required this.role, this.photoUrl});

  factory ContactUser.fromJson(Map<String, dynamic> j) => ContactUser(
        username: j['username'] ?? '',
        role: j['role'] ?? 'member',
        photoUrl: j['photoUrl'],
      );
}

// ─────────────────────────────────────────────
// THEME HELPER
// ─────────────────────────────────────────────
class _T {
  final Color primary;
  final Color accent;
  final bool dark;
  const _T({required this.primary, required this.accent, required this.dark});
  Color get bg => dark ? const Color(0xFF060D18) : const Color(0xFFEEF2F7);
  Color get card => dark ? const Color(0xFF0D1B2A) : Colors.white;
  Color get textPrimary => dark ? Colors.white : const Color(0xFF0D1B2A);
  Color get textSub =>
      dark ? Colors.white.withAlpha(102) : Colors.black.withAlpha(102);
  factory _T.of(BuildContext context) {
    final tp = Provider.of<ThemeProvider>(context, listen: true);
    return _T(primary: tp.primaryColor, accent: tp.accentColor, dark: tp.isDarkMode);
  }
}

// ─────────────────────────────────────────────
// CHAT LIST PAGE (Inbox)
// ─────────────────────────────────────────────
class ChatListPage extends StatefulWidget {
  final String sessionKey;
  final String myUsername;
  final String role;
  final String? myPhotoUrl;

  const ChatListPage({
    super.key,
    required this.sessionKey,
    required this.myUsername,
    required this.role,
    this.myPhotoUrl,
  });

  @override
  State<ChatListPage> createState() => _ChatListPageState();
}

class _ChatListPageState extends State<ChatListPage> {
  List<InboxItem> _inbox = [];
  bool _loading = true;
  Timer? _pollTimer;

  @override
  void initState() {
    super.initState();
    _fetchInbox();
    _pollTimer = Timer.periodic(const Duration(seconds: 10), (_) => _fetchInbox());
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }

  Future<void> _fetchInbox() async {
    try {
      final res = await http.get(
        Uri.parse('${ConfigService.baseUrl}/chatInbox'),
        headers: {'x-session-key': widget.sessionKey},
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && mounted) {
        setState(() {
          _inbox = (data['inbox'] as List? ?? [])
              .map((e) => InboxItem.fromJson(e))
              .toList();
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _showContacts() async {
    final t = _T.of(context);
    List<ContactUser> contacts = [];
    bool loading = true;
    String search = '';

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: t.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setSheet) {
            if (loading) {
              http.get(
                Uri.parse('${ConfigService.baseUrl}/listUsers'),
                headers: {'x-session-key': widget.sessionKey},
              ).timeout(const Duration(seconds: 10)).then((res) {
                final data = jsonDecode(res.body);
                if (data['valid'] == true) {
                  setSheet(() {
                    contacts = (data['users'] as List? ?? [])
                        .map((e) => ContactUser.fromJson(e))
                        .where((u) => u.username != widget.myUsername)
                        .toList();
                    loading = false;
                  });
                } else {
                  setSheet(() => loading = false);
                }
              }).catchError((_) => setSheet(() => loading = false));
            }

            final filtered = contacts
                .where((u) => u.username
                    .toLowerCase()
                    .contains(search.toLowerCase()))
                .toList();

            return DraggableScrollableSheet(
              expand: false,
              initialChildSize: 0.7,
              maxChildSize: 0.95,
              minChildSize: 0.4,
              builder: (_, scrollCtrl) => Column(
                children: [
                  Container(
                    margin: const EdgeInsets.only(top: 10, bottom: 6),
                    width: 36,
                    height: 4,
                    decoration: BoxDecoration(
                      color: t.textSub.withAlpha(80),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Row(
                      children: [
                        Text(
                          'Kontak',
                          style: TextStyle(
                            color: t.textPrimary,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                          ),
                        ),
                        const Spacer(),
                        if (!loading)
                          Text(
                            '${contacts.length} user',
                            style:
                                TextStyle(color: t.textSub, fontSize: 12),
                          ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 4),
                    child: TextField(
                      onChanged: (v) => setSheet(() => search = v),
                      style:
                          TextStyle(color: t.textPrimary, fontSize: 13),
                      decoration: InputDecoration(
                        hintText: 'Cari username...',
                        hintStyle: TextStyle(color: t.textSub),
                        prefixIcon:
                            Icon(Icons.search_rounded, color: t.textSub, size: 18),
                        filled: true,
                        fillColor: t.bg,
                        contentPadding:
                            const EdgeInsets.symmetric(vertical: 8),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Expanded(
                    child: loading
                        ? Center(
                            child: CircularProgressIndicator(
                                color: t.primary))
                        : filtered.isEmpty
                            ? Center(
                                child: Text('Tidak ada user',
                                    style: TextStyle(
                                        color: t.textSub, fontSize: 13)),
                              )
                            : ListView.builder(
                                controller: scrollCtrl,
                                itemCount: filtered.length,
                                itemBuilder: (_, i) {
                                  final u = filtered[i];
                                  return ListTile(
                                    onTap: () {
                                      Navigator.pop(ctx);
                                      _openChat(u.username);
                                    },
                                    contentPadding:
                                        const EdgeInsets.symmetric(
                                            horizontal: 16, vertical: 2),
                                    leading: CircleAvatar(
                                      radius: 20,
                                      backgroundColor: t.primary.withAlpha(40),
                                      backgroundImage: u.photoUrl != null
                                          ? NetworkImage(u.photoUrl!)
                                          : null,
                                      child: u.photoUrl == null
                                          ? Text(
                                              u.username[0].toUpperCase(),
                                              style: TextStyle(
                                                color: t.primary,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 13,
                                              ),
                                            )
                                          : null,
                                    ),
                                    title: Text(
                                      u.username,
                                      style: TextStyle(
                                        color: t.textPrimary,
                                        fontWeight: FontWeight.w500,
                                        fontSize: 14,
                                      ),
                                    ),
                                    subtitle: Text(
                                      u.role,
                                      style: TextStyle(
                                          color: t.textSub, fontSize: 11),
                                    ),
                                    trailing: Icon(
                                        Icons.chat_bubble_outline_rounded,
                                        color: t.primary,
                                        size: 18),
                                  );
                                },
                              ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _openChat(String targetUsername) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ChatRoomPage(
          sessionKey: widget.sessionKey,
          myUsername: widget.myUsername,
          targetUsername: targetUsername,
          role: widget.role,
        ),
      ),
    ).then((_) => _fetchInbox());
  }

  String _timeAgo(int ts) {
    if (ts == 0) return '';
    final diff = DateTime.now()
        .difference(DateTime.fromMillisecondsSinceEpoch(ts));
    if (diff.inMinutes < 1) return 'Baru saja';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m';
    if (diff.inHours < 24) return '${diff.inHours}j';
    return '${diff.inDays}h';
  }

  @override
  Widget build(BuildContext context) {
    final t = _T.of(context);

    return Scaffold(
      backgroundColor: t.bg,
      appBar: AppBar(
        backgroundColor: t.card,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: t.accent, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Chat',
          style: TextStyle(
            color: t.textPrimary,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.people_alt_rounded, color: t.accent),
            tooltip: 'Kontak',
            onPressed: _showContacts,
          ),
          IconButton(
            icon: Icon(Icons.auto_stories_rounded, color: t.accent),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => StoryListPage(
                  sessionKey: widget.sessionKey,
                  myUsername: widget.myUsername,
                  role: widget.role,
                ),
              ),
            ),
          ),
          IconButton(
            icon: Icon(Icons.refresh_rounded, color: t.accent),
            onPressed: _fetchInbox,
          ),
        ],
      ),
      body: Column(
        children: [
          _StoryBar(
            sessionKey: widget.sessionKey,
            myUsername: widget.myUsername,
            role: widget.role,
            myPhotoUrl: widget.myPhotoUrl,
          ),
          const Divider(height: 1, thickness: 0.5),
          Expanded(
            child: _loading
                ? Center(child: CircularProgressIndicator(color: t.primary))
                : RefreshIndicator(
                    color: t.primary,
                    onRefresh: _fetchInbox,
                    child: _inbox.isEmpty
                        ? ListView(
                            children: [
                              SizedBox(height: MediaQuery.of(context).size.height * 0.3),
                              Column(
                                children: [
                                  Icon(Icons.chat_bubble_outline_rounded,
                                      color: t.textSub, size: 48),
                                  const SizedBox(height: 12),
                                  Text('Belum ada chat',
                                      style: TextStyle(color: t.textSub, fontSize: 14)),
                                  const SizedBox(height: 6),
                                  Text('Mulai ngobrol dari halaman profil user',
                                      style: TextStyle(color: t.textSub, fontSize: 12)),
                                ],
                              ),
                            ],
                          )
                        : ListView.builder(
                            padding: const EdgeInsets.symmetric(vertical: 6),
                            itemCount: _inbox.length,
                            itemBuilder: (_, i) {
                              final item = _inbox[i];
                              return ListTile(
                                onTap: () => _openChat(item.username),
                                contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 4),
                                leading: Stack(
                                  children: [
                                    CircleAvatar(
                                      radius: 24,
                                      backgroundColor: t.primary.withAlpha(40),
                                      backgroundImage: item.photoUrl != null
                                          ? NetworkImage(item.photoUrl!)
                                          : null,
                                      child: item.photoUrl == null
                                          ? Text(
                                              item.username[0].toUpperCase(),
                                              style: TextStyle(
                                                color: t.primary,
                                                fontWeight: FontWeight.bold,
                                                fontFamily: 'Orbitron',
                                              ),
                                            )
                                          : null,
                                    ),
                                    if (item.unread > 0)
                                      Positioned(
                                        right: 0,
                                        top: 0,
                                        child: Container(
                                          padding: const EdgeInsets.all(4),
                                          decoration: BoxDecoration(
                                            color: t.primary,
                                            shape: BoxShape.circle,
                                          ),
                                          child: Text(
                                            item.unread > 99
                                                ? '99+'
                                                : '${item.unread}',
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 9,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                      ),
                                  ],
                                ),
                                title: Text(
                                  item.username,
                                  style: TextStyle(
                                    color: t.textPrimary,
                                    fontWeight: item.unread > 0
                                        ? FontWeight.bold
                                        : FontWeight.w500,
                                    fontSize: 14,
                                  ),
                                ),
                                subtitle: Text(
                                  item.lastMessage,
                                  style: TextStyle(
                                    color: item.unread > 0
                                        ? t.textPrimary
                                        : t.textSub,
                                    fontSize: 12,
                                    fontWeight: item.unread > 0
                                        ? FontWeight.w500
                                        : FontWeight.normal,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                trailing: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Text(
                                      _timeAgo(item.lastTime),
                                      style: TextStyle(
                                          color: t.textSub, fontSize: 11),
                                    ),
                                    const SizedBox(height: 4),
                                    Icon(Icons.chevron_right_rounded,
                                        color: t.textSub, size: 16),
                                  ],
                                ),
                              );
                            },
                          ),
                  ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
// STORY BAR
// ─────────────────────────────────────────────
class _StoryBar extends StatefulWidget {
  final String sessionKey;
  final String myUsername;
  final String role;
  final String? myPhotoUrl;

  const _StoryBar({
    required this.sessionKey,
    required this.myUsername,
    required this.role,
    this.myPhotoUrl,
  });

  @override
  State<_StoryBar> createState() => _StoryBarState();
}

class _StoryBarState extends State<_StoryBar> {
  String? _resolvedPhotoUrl;

  @override
  void initState() {
    super.initState();
    _resolvedPhotoUrl = widget.myPhotoUrl;
    if (_resolvedPhotoUrl == null) _fetchPhoto();
  }

  Future<void> _fetchPhoto() async {
    try {
      final res = await http.get(
        Uri.parse('${ConfigService.baseUrl}/getProfile'),
        headers: {'x-session-key': widget.sessionKey},
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final url = data['photoUrl'];
        if (url != null && url.toString().isNotEmpty && mounted) {
          setState(() => _resolvedPhotoUrl = url.toString());
        }
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final t = _T.of(context);
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => StoryListPage(
            sessionKey: widget.sessionKey,
            myUsername: widget.myUsername,
            role: widget.role,
          ),
        ),
      ),
      child: Container(
        height: 86,
        color: t.card,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Row(
          children: [
            Stack(
              children: [
                CircleAvatar(
                  radius: 26,
                  backgroundColor: t.primary.withAlpha(40),
                  backgroundImage: _resolvedPhotoUrl != null
                      ? NetworkImage(_resolvedPhotoUrl!)
                      : null,
                  child: _resolvedPhotoUrl == null
                      ? Text(
                          widget.myUsername[0].toUpperCase(),
                          style: TextStyle(
                            color: t.primary,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                            fontSize: 16,
                          ),
                        )
                      : null,
                ),
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      color: t.primary,
                      shape: BoxShape.circle,
                      border: Border.all(color: t.card, width: 1.5),
                    ),
                    child: const Icon(Icons.add, color: Colors.white, size: 10),
                  ),
                ),
              ],
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Story Saya',
                  style: TextStyle(
                    color: t.textPrimary,
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                  ),
                ),
                Text(
                  'Lihat atau tambah story',
                  style: TextStyle(color: t.textSub, fontSize: 11),
                ),
              ],
            ),
            const Spacer(),
            Icon(Icons.chevron_right_rounded, color: t.textSub),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
// CHAT ROOM PAGE
// ─────────────────────────────────────────────
class ChatRoomPage extends StatefulWidget {
  final String sessionKey;
  final String myUsername;
  final String targetUsername;
  final String role;

  const ChatRoomPage({
    super.key,
    required this.sessionKey,
    required this.myUsername,
    required this.targetUsername,
    required this.role,
  });

  @override
  State<ChatRoomPage> createState() => _ChatRoomPageState();
}

class _ChatRoomPageState extends State<ChatRoomPage> {
  final List<ChatMessage> _messages = [];
  final _inputCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  bool _loading = true;
  bool _sending = false;
  Timer? _pollTimer;
  File? _wallpaper;

  // ── Voice note state ──
  final FlutterSoundRecorder _recorder = FlutterSoundRecorder();
  bool _recorderReady = false;
  bool _isRecording = false;
  bool _sendingVoice = false;
  String? _recordingPath;
  int _recordSeconds = 0;
  Timer? _recordTimer;

  @override
  void initState() {
    super.initState();
    _fetchMessages();
    _markRead();
    _loadWallpaper();
    _pollTimer = Timer.periodic(const Duration(seconds: 3), (_) => _fetchMessages());
    _initRecorder();
  }

  Future<void> _initRecorder() async {
    await _recorder.openRecorder();
    if (mounted) setState(() => _recorderReady = true);
  }

  Future<void> _loadWallpaper() async {
    final prefs = await SharedPreferences.getInstance();
    final path = prefs.getString('wallpaper_${widget.myUsername}_${widget.targetUsername}');
    if (path != null && File(path).existsSync() && mounted) {
      setState(() => _wallpaper = File(path));
    }
  }

  Future<void> _pickWallpaper() async {
    final picker = ImagePicker();
    final file = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (file == null) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('wallpaper_${widget.myUsername}_${widget.targetUsername}', file.path);
    if (mounted) setState(() => _wallpaper = File(file.path));
  }

  Future<void> _removeWallpaper() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('wallpaper_${widget.myUsername}_${widget.targetUsername}');
    if (mounted) setState(() => _wallpaper = null);
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _recordTimer?.cancel();
    _inputCtrl.dispose();
    _scrollCtrl.dispose();
    _recorder.closeRecorder();
    super.dispose();
  }

  Future<void> _fetchMessages() async {
    try {
      final res = await http.get(
        Uri.parse(
            '${ConfigService.baseUrl}/getChat?peer=${widget.targetUsername}'),
        headers: {'x-session-key': widget.sessionKey},
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && mounted) {
        final list = (data['messages'] as List? ?? [])
            .map((e) => ChatMessage.fromJson(e, widget.myUsername))
            .toList();
        setState(() {
          _messages.clear();
          _messages.addAll(list);
          _loading = false;
        });
        _scrollToBottom();
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _markRead() async {
    try {
      await http.post(
        Uri.parse('${ConfigService.baseUrl}/markChatRead'),
        headers: {
          'x-session-key': widget.sessionKey,
          'Content-Type': 'application/json',
        },
        body: jsonEncode({'peer': widget.targetUsername}),
      );
    } catch (_) {}
  }

  Future<void> _sendMessage() async {
    final text = _inputCtrl.text.trim();
    if (text.isEmpty || text.length > 250 || _sending) return;

    setState(() => _sending = true);
    _inputCtrl.clear();

    try {
      final res = await http.post(
        Uri.parse('${ConfigService.baseUrl}/sendChat'),
        headers: {
          'x-session-key': widget.sessionKey,
          'Content-Type': 'application/json',
        },
        body: jsonEncode({'to': widget.targetUsername, 'message': text}),
      ).timeout(const Duration(seconds: 10));

      final data = jsonDecode(res.body);
      if (data['valid'] == true && mounted) {
        final msg = ChatMessage.fromJson(data['message'], widget.myUsername);
        setState(() => _messages.add(msg));
        _scrollToBottom();
      }
    } catch (_) {
      if (mounted) _inputCtrl.text = text;
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  // ── Voice note: start recording ──
  Future<void> _startRecording() async {
    if (!_recorderReady) return;
    final perm = await Permission.microphone.request();
    if (!perm.isGranted) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Izin mikrofon ditolak')),
        );
      }
      return;
    }

    final dir = await getTemporaryDirectory();
    final path = '${dir.path}/voice_${DateTime.now().millisecondsSinceEpoch}.aac';

    await _recorder.startRecorder(
      toFile: path,
      codec: Codec.aacADTS,
    );

    _recordSeconds = 0;
    _recordTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _recordSeconds++);
    });

    if (mounted) {
      setState(() {
        _isRecording = true;
        _recordingPath = path;
      });
    }
  }

  // ── Voice note: stop & send ──
  Future<void> _stopAndSendVoice() async {
    _recordTimer?.cancel();
    final path = await _recorder.stopRecorder();
    if (mounted) setState(() => _isRecording = false);

    if (path == null || _recordSeconds < 1) return;

    final duration = _recordSeconds;
    setState(() => _sendingVoice = true);

    try {
      final req = http.MultipartRequest(
        'POST',
        Uri.parse('${ConfigService.baseUrl}/sendVoiceChat'),
      )
        ..headers['x-session-key'] = widget.sessionKey
        ..fields['to'] = widget.targetUsername
        ..fields['duration'] = duration.toString()
        ..files.add(await http.MultipartFile.fromPath(
          'voice',
          path,
          contentType: MediaType('audio', 'aac'),
        ));

      final streamed = await req.send().timeout(const Duration(seconds: 30));
      final res = await http.Response.fromStream(streamed);
      final data = jsonDecode(res.body);

      if (data['valid'] == true && mounted) {
        final msg = ChatMessage.fromJson(data['message'], widget.myUsername);
        setState(() => _messages.add(msg));
        _scrollToBottom();
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Gagal kirim voice note')),
        );
      }
    } finally {
      if (mounted) setState(() => _sendingVoice = false);
      try { File(path).deleteSync(); } catch (_) {}
    }
  }

  // ── Cancel recording ──
  Future<void> _cancelRecording() async {
    _recordTimer?.cancel();
    await _recorder.stopRecorder();
    if (mounted) setState(() { _isRecording = false; _recordSeconds = 0; });
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  String _formatTime(int ts) {
    if (ts == 0) return '';
    final dt = DateTime.fromMillisecondsSinceEpoch(ts).toLocal();
    final h = dt.hour.toString().padLeft(2, '0');
    final m = dt.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }

  String _fmtDur(int s) {
    final m = (s ~/ 60).toString().padLeft(2, '0');
    final sec = (s % 60).toString().padLeft(2, '0');
    return '$m:$sec';
  }

  Future<void> _deleteMessage(String messageId) async {
    try {
      await http.post(
        Uri.parse('${ConfigService.baseUrl}/deleteChat'),
        headers: {
          'x-session-key': widget.sessionKey,
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'peer': widget.targetUsername,
          'messageId': messageId,
        }),
      );
      setState(() => _messages.removeWhere((m) => m.id == messageId));
    } catch (_) {}
  }

  void _showChatThemePicker(BuildContext context, ChatThemeData ct) {
    final t = _T.of(context);
    showModalBottomSheet(
      context: context,
      backgroundColor: t.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) {
        return Consumer<ChatThemeProvider>(
          builder: (ctx, ctp, __) {
            return Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 36, height: 4,
                    decoration: BoxDecoration(
                      color: t.textSub.withAlpha(80),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    'Tema Chat',
                    style: TextStyle(
                      color: t.textPrimary,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ),
                  const SizedBox(height: 16),
                  GridView.count(
                    shrinkWrap: true,
                    crossAxisCount: 3,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                    childAspectRatio: 0.85,
                    children: ChatThemePresets.all.map((theme) {
                      final isActive = ctp.theme.id == theme.id;
                      return GestureDetector(
                        onTap: () {
                          ctp.setTheme(theme);
                          Navigator.pop(context);
                          setState(() {});
                        },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          decoration: BoxDecoration(
                            color: theme.backgroundColor,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: isActive ? theme.sendButtonColor : Colors.transparent,
                              width: 2.5,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withAlpha(40),
                                blurRadius: 6,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              // Mini preview bubble
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 8),
                                child: Column(
                                  children: [
                                    // bubble them (kiri)
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: Container(
                                        width: 40, height: 12,
                                        decoration: BoxDecoration(
                                          color: theme.bubbleThemColor,
                                          borderRadius: theme.bubbleThemRadius,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(height: 5),
                                    // bubble me (kanan)
                                    Align(
                                      alignment: Alignment.centerRight,
                                      child: Container(
                                        width: 40, height: 12,
                                        decoration: BoxDecoration(
                                          color: theme.bubbleMeColor,
                                          borderRadius: theme.bubbleMeRadius,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                theme.emoji,
                                style: const TextStyle(fontSize: 18),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                theme.name,
                                style: TextStyle(
                                  color: theme.bubbleThemTextColor,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w600,
                                ),
                                textAlign: TextAlign.center,
                              ),
                              if (isActive) ...[
                                const SizedBox(height: 4),
                                Icon(Icons.check_circle_rounded,
                                    color: theme.sendButtonColor, size: 14),
                              ],
                            ],
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = _T.of(context);
    final ct = Provider.of<ChatThemeProvider>(context).theme;

    return Scaffold(
      backgroundColor: ct.backgroundColor,
      appBar: AppBar(
        backgroundColor: ct.appBarColor,
        elevation: 0,
        leadingWidth: 40,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: ct.appBarIconColor, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: GestureDetector(
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => UserProfilePage(
                sessionKey: widget.sessionKey,
                myUsername: widget.myUsername,
                targetUsername: widget.targetUsername,
                role: widget.role,
              ),
            ),
          ),
          child: Row(
            children: [
              CircleAvatar(
                radius: 17,
                backgroundColor: ct.bubbleMeColor.withAlpha(60),
                child: Text(
                  widget.targetUsername[0].toUpperCase(),
                  style: TextStyle(
                    color: ct.appBarIconColor,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    fontSize: 13,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.targetUsername,
                    style: TextStyle(
                      color: ct.appBarTextColor,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                    ),
                  ),
                  Text(
                    'Ketuk untuk profil',
                    style: TextStyle(color: ct.appBarTextColor.withAlpha(120), fontSize: 10),
                  ),
                ],
              ),
            ],
          ),
        ),
        actions: [
          PopupMenuButton<String>(
            icon: Icon(Icons.more_vert_rounded, color: ct.appBarIconColor),
            color: ct.inputBarColor,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            onSelected: (val) async {
              if (val == 'profile') {
                Navigator.push(context, MaterialPageRoute(
                  builder: (_) => UserProfilePage(
                    sessionKey: widget.sessionKey,
                    myUsername: widget.myUsername,
                    targetUsername: widget.targetUsername,
                    role: widget.role,
                  ),
                ));
              } else if (val == 'story') {
                Navigator.push(context, MaterialPageRoute(
                  builder: (_) => StoryListPage(
                    sessionKey: widget.sessionKey,
                    myUsername: widget.myUsername,
                    role: widget.role,
                  ),
                ));
              } else if (val == 'wallpaper') {
                await _pickWallpaper();
              } else if (val == 'wallpaper_remove') {
                await _removeWallpaper();
              } else if (val == 'theme') {
                _showChatThemePicker(context, ct);
              }
            },
            itemBuilder: (_) => [
              PopupMenuItem(
                value: 'theme',
                child: Row(children: [
                  Icon(Icons.palette_rounded, color: ct.sendButtonColor, size: 20),
                  const SizedBox(width: 12),
                  Text('Tema Chat', style: TextStyle(color: ct.bubbleThemTextColor, fontSize: 14)),
                ]),
              ),
              PopupMenuItem(
                value: 'profile',
                child: Row(children: [
                  Icon(Icons.account_circle_rounded, color: ct.sendButtonColor, size: 20),
                  const SizedBox(width: 12),
                  Text('Lihat Profil', style: TextStyle(color: ct.bubbleThemTextColor, fontSize: 14)),
                ]),
              ),
              PopupMenuItem(
                value: 'story',
                child: Row(children: [
                  Icon(Icons.auto_stories_rounded, color: ct.sendButtonColor, size: 20),
                  const SizedBox(width: 12),
                  Text('Story', style: TextStyle(color: ct.bubbleThemTextColor, fontSize: 14)),
                ]),
              ),
              PopupMenuItem(
                value: 'wallpaper',
                child: Row(children: [
                  Icon(Icons.wallpaper_rounded, color: ct.sendButtonColor, size: 20),
                  const SizedBox(width: 12),
                  Text('Ganti Wallpaper', style: TextStyle(color: ct.bubbleThemTextColor, fontSize: 14)),
                ]),
              ),
              if (_wallpaper != null)
                PopupMenuItem(
                  value: 'wallpaper_remove',
                  child: const Row(children: [
                    Icon(Icons.hide_image_rounded, color: Colors.redAccent, size: 20),
                    SizedBox(width: 12),
                    Text('Hapus Wallpaper', style: TextStyle(color: Colors.redAccent, fontSize: 14)),
                  ]),
                ),
            ],
          ),
        ],
      ),

      body: Container(
        decoration: _wallpaper != null
            ? BoxDecoration(
                image: DecorationImage(
                  image: FileImage(_wallpaper!),
                  fit: BoxFit.cover,
                  colorFilter: ColorFilter.mode(
                    Colors.black.withAlpha(60),
                    BlendMode.darken,
                  ),
                ),
              )
            : null,
        child: Column(
          children: [
            // ── Pesan ─────────────────────────────────
            Expanded(
              child: _loading
                  ? Center(child: CircularProgressIndicator(color: ct.sendButtonColor))
                  : _messages.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.waving_hand_rounded,
                                  color: ct.sendButtonColor, size: 40),
                              const SizedBox(height: 12),
                              Text(
                                'Hei, mulai chat!',
                                style: TextStyle(
                                    color: ct.inputHintColor, fontSize: 13),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          controller: _scrollCtrl,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 12),
                          itemCount: _messages.length,
                          itemBuilder: (_, i) => _BubbleWidget(
                            msg: _messages[i],
                            t: t,
                            ct: ct,
                            formatTime: _formatTime,
                            onDelete: _deleteMessage,
                          ),
                        ),
            ),

            // ── Input / Recording bar ──────────────────
            _isRecording
                ? _RecordingBar(
                    t: t,
                    ct: ct,
                    seconds: _recordSeconds,
                    fmtDur: _fmtDur,
                    onCancel: _cancelRecording,
                    onSend: _stopAndSendVoice,
                  )
                : Container(
                    padding: EdgeInsets.only(
                      left: 12,
                      right: 8,
                      top: 8,
                      bottom: MediaQuery.of(context).viewInsets.bottom + 8,
                    ),
                    decoration: BoxDecoration(
                      color: ct.inputBarColor,
                      border: Border(
                        top: BorderSide(color: ct.sendButtonColor.withAlpha(30)),
                      ),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _inputCtrl,
                            style: TextStyle(color: ct.inputTextColor, fontSize: 14),
                            maxLength: 250,
                            maxLines: 4,
                            minLines: 1,
                            textInputAction: TextInputAction.newline,
                            decoration: InputDecoration(
                              hintText: 'Ketik pesan...',
                              hintStyle: TextStyle(color: ct.inputHintColor),
                              counterText: '',
                              filled: true,
                              fillColor: ct.inputFieldColor,
                              contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 10),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: BorderSide.none,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 6),
                        // Tombol mic
                        GestureDetector(
                          onTap: _sendingVoice ? null : _startRecording,
                          onLongPressStart: _sendingVoice
                              ? null
                              : (_) => _startRecording(),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 150),
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: _sendingVoice
                                  ? ct.micButtonColor.withAlpha(180)
                                  : ct.micButtonColor,
                              shape: BoxShape.circle,
                            ),
                            child: _sendingVoice
                                ? SizedBox(
                                    width: 18, height: 18,
                                    child: CircularProgressIndicator(
                                      color: ct.micButtonIconColor,
                                      strokeWidth: 2,
                                    ),
                                  )
                                : Icon(Icons.mic_rounded,
                                    color: ct.micButtonIconColor, size: 20),
                          ),
                        ),
                        const SizedBox(width: 6),
                        // Tombol send
                        GestureDetector(
                          onTap: _sending ? null : _sendMessage,
                          child: Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: _sending
                                  ? ct.sendButtonColor.withAlpha(150)
                                  : ct.sendButtonColor,
                              shape: BoxShape.circle,
                            ),
                            child: _sending
                                ? SizedBox(
                                    width: 18, height: 18,
                                    child: CircularProgressIndicator(
                                      color: ct.sendButtonIconColor,
                                      strokeWidth: 2,
                                    ),
                                  )
                                : Icon(Icons.send_rounded,
                                    color: ct.sendButtonIconColor, size: 18),
                          ),
                        ),
                      ],
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
// RECORDING BAR (muncul saat recording)
// ─────────────────────────────────────────────
class _RecordingBar extends StatelessWidget {
  final _T t;
  final ChatThemeData ct;
  final int seconds;
  final String Function(int) fmtDur;
  final VoidCallback onCancel;
  final VoidCallback onSend;

  const _RecordingBar({
    required this.t,
    required this.ct,
    required this.seconds,
    required this.fmtDur,
    required this.onCancel,
    required this.onSend,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: ct.inputBarColor,
        border: Border(top: BorderSide(color: ct.sendButtonColor.withAlpha(30))),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: onCancel,
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.redAccent.withAlpha(30),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.delete_rounded,
                  color: Colors.redAccent, size: 20),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Row(
              children: [
                _PulsingDot(color: Colors.redAccent),
                const SizedBox(width: 8),
                Text(
                  'Recording... \${fmtDur(seconds)}',
                  style: TextStyle(
                    color: ct.inputTextColor,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: onSend,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: ct.sendButtonColor,
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.send_rounded,
                  color: ct.sendButtonIconColor, size: 18),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
// PULSING DOT animasi recording
// ─────────────────────────────────────────────
class _PulsingDot extends StatefulWidget {
  final Color color;
  const _PulsingDot({required this.color});

  @override
  State<_PulsingDot> createState() => _PulsingDotState();
}

class _PulsingDotState extends State<_PulsingDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..repeat(reverse: true);
    _anim = Tween(begin: 0.4, end: 1.0).animate(_ctrl);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _anim,
      child: Container(
        width: 10,
        height: 10,
        decoration: BoxDecoration(
          color: widget.color,
          shape: BoxShape.circle,
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
// BUBBLE CHAT
// ─────────────────────────────────────────────
class _BubbleWidget extends StatelessWidget {
  final ChatMessage msg;
  final _T t;
  final ChatThemeData ct;
  final String Function(int) formatTime;
  final Future<void> Function(String) onDelete;

  const _BubbleWidget({
    required this.msg,
    required this.t,
    required this.ct,
    required this.formatTime,
    required this.onDelete,
  });

  @override
  @override
  Widget build(BuildContext context) {
    final isMe = msg.fromMe;

    return GestureDetector(
      onLongPress: isMe
          ? () => showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  backgroundColor: ct.inputBarColor,
                  title: Text('Hapus pesan?',
                      style: TextStyle(color: ct.bubbleThemTextColor, fontSize: 15)),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: Text('Batal', style: TextStyle(color: ct.inputHintColor)),
                    ),
                    TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                        onDelete(msg.id);
                      },
                      child: const Text('Hapus', style: TextStyle(color: Colors.redAccent)),
                    ),
                  ],
                ),
              )
          : null,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Row(
          mainAxisAlignment:
              isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            if (!isMe) ...[
              CircleAvatar(
                radius: 13,
                backgroundColor: ct.bubbleMeColor.withAlpha(40),
                child: Text(
                  msg.from.isNotEmpty ? msg.from[0].toUpperCase() : '?',
                  style: TextStyle(
                      color: ct.sendButtonColor,
                      fontSize: 10,
                      fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(width: 6),
            ],
            Flexible(
              child: Container(
                padding: msg.isVoice
                    ? const EdgeInsets.symmetric(horizontal: 10, vertical: 8)
                    : const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: isMe ? ct.bubbleMeColor : ct.bubbleThemColor,
                  borderRadius: isMe ? ct.bubbleMeRadius : ct.bubbleThemRadius,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withAlpha(15),
                      blurRadius: 4,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: msg.isVoice
                    ? _VoiceNoteBubble(
                        msg: msg,
                        t: t,
                        ct: ct,
                        formatTime: formatTime,
                        isMe: isMe,
                      )
                    : Column(
                        crossAxisAlignment: isMe
                            ? CrossAxisAlignment.end
                            : CrossAxisAlignment.start,
                        children: [
                          Text(
                            msg.message,
                            style: TextStyle(
                              color: isMe ? ct.bubbleMeTextColor : ct.bubbleThemTextColor,
                              fontSize: 14,
                            ),
                          ),
                          const SizedBox(height: 3),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                formatTime(msg.timestamp),
                                style: TextStyle(
                                  color: isMe ? ct.bubbleMeTimeColor : ct.bubbleThemTimeColor,
                                  fontSize: 10,
                                ),
                              ),
                              if (isMe) ...[
                                const SizedBox(width: 4),
                                Icon(
                                  msg.isRead
                                      ? Icons.done_all_rounded
                                      : Icons.done_rounded,
                                  size: 12,
                                  color: msg.isRead
                                      ? Colors.lightBlueAccent
                                      : ct.bubbleMeTimeColor,
                                ),
                              ],
                            ],
                          ),
                        ],
                      ),
              ),
            ),
            if (isMe) const SizedBox(width: 6),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
// VOICE NOTE BUBBLE (player)
// ─────────────────────────────────────────────
class _VoiceNoteBubble extends StatefulWidget {
  final ChatMessage msg;
  final _T t;
  final ChatThemeData ct;
  final String Function(int) formatTime;
  final bool isMe;

  const _VoiceNoteBubble({
    required this.msg,
    required this.t,
    required this.ct,
    required this.formatTime,
    required this.isMe,
  });

  @override
  State<_VoiceNoteBubble> createState() => _VoiceNoteBubbleState();
}

class _VoiceNoteBubbleState extends State<_VoiceNoteBubble> {
  final AudioPlayer _player = AudioPlayer();
  bool _playing = false;
  int _position = 0;
  int _duration = 0;
  StreamSubscription? _posSub;
  StreamSubscription? _durSub;
  StreamSubscription? _stateSub;

  @override
  void initState() {
    super.initState();
    _duration = widget.msg.voiceDuration ?? 0;

    _posSub = _player.onPositionChanged.listen((pos) {
      if (mounted) setState(() => _position = pos.inSeconds);
    });
    _durSub = _player.onDurationChanged.listen((dur) {
      if (mounted) setState(() => _duration = dur.inSeconds);
    });
    _stateSub = _player.onPlayerStateChanged.listen((state) {
      if (mounted) setState(() => _playing = state == PlayerState.playing);
      if (state == PlayerState.completed && mounted) {
        setState(() { _playing = false; _position = 0; });
      }
    });
  }

  @override
  void dispose() {
    _posSub?.cancel();
    _durSub?.cancel();
    _stateSub?.cancel();
    _player.dispose();
    super.dispose();
  }

  Future<void> _toggle() async {
    if (_playing) {
      await _player.pause();
    } else {
      if (_position > 0 && _position < _duration) {
        await _player.resume();
      } else {
        await _player.play(UrlSource(widget.msg.voiceUrl!));
      }
    }
  }

  String _fmtDur(int s) {
    final m = (s ~/ 60).toString().padLeft(2, '0');
    final sec = (s % 60).toString().padLeft(2, '0');
    return '$m:$sec';
  }

  @override
  Widget build(BuildContext context) {
    final isMe = widget.isMe;
    final ct = widget.ct;
    final total = _duration > 0 ? _duration : 1;
    final progress = (_position / total).clamp(0.0, 1.0);

    return Column(
      crossAxisAlignment:
          isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Play/Pause
            GestureDetector(
              onTap: _toggle,
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: isMe
                      ? ct.bubbleMeTextColor.withAlpha(50)
                      : ct.sendButtonColor.withAlpha(30),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  _playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                  color: isMe ? ct.bubbleMeTextColor : ct.sendButtonColor,
                  size: 22,
                ),
              ),
            ),
            const SizedBox(width: 8),
            SizedBox(
              width: 120,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(3),
                    child: LinearProgressIndicator(
                      value: progress,
                      backgroundColor: isMe
                          ? ct.bubbleMeTextColor.withAlpha(60)
                          : ct.sendButtonColor.withAlpha(40),
                      valueColor: AlwaysStoppedAnimation(
                        isMe ? ct.bubbleMeTextColor : ct.sendButtonColor,
                      ),
                      minHeight: 3,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _playing
                        ? _fmtDur(_position)
                        : _fmtDur(_duration > 0 ? _duration : 0),
                    style: TextStyle(
                      color: isMe ? ct.bubbleMeTimeColor : ct.bubbleThemTimeColor,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Icon(Icons.mic_rounded,
                size: 14,
                color: isMe ? ct.bubbleMeTimeColor : ct.sendButtonColor.withAlpha(180)),
          ],
        ),
        const SizedBox(height: 4),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              widget.formatTime(widget.msg.timestamp),
              style: TextStyle(
                color: isMe ? ct.bubbleMeTimeColor : ct.bubbleThemTimeColor,
                fontSize: 10,
              ),
            ),
            if (isMe) ...[
              const SizedBox(width: 4),
              Icon(
                widget.msg.isRead
                    ? Icons.done_all_rounded
                    : Icons.done_rounded,
                size: 12,
                color: widget.msg.isRead
                    ? Colors.lightBlueAccent
                    : ct.bubbleMeTimeColor,
              ),
            ],
          ],
        ),
      ],
    );
  }
}
