// lib/tebak_gambar_page.dart
// TEBAK EMOJI - Enhanced Edition
// 5 Mode | 800 Stage | Koin Reward | Timer | Streak System

import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'config_service.dart';
import 'package:audioplayers/audioplayers.dart';
import 'music_service.dart';

// ============================================================
// DATA MODEL
// ============================================================
enum TebakMode { film, lagu, peribahasa, frasa, absurd, gambar }

class TebakSoal {
  final String jawaban;
  final String hint;
  final List<String> emojis;
  final List<String> pilihan;
  final int coinReward;
  final TebakMode mode;
  final String? imgUrl;
  const TebakSoal({
    required this.jawaban,
    required this.hint,
    required this.emojis,
    required this.pilihan,
    required this.coinReward,
    required this.mode,
    this.imgUrl,
  });
}


int _timerForStage(int stage) {
  if (stage <= 100) return 25;
  if (stage <= 250) return 20;
  if (stage <= 400) return 15;
  if (stage <= 600) return 12;
  return 10;
}

// ============================================================
// SAVE / LOAD / BACKEND
// ============================================================
Future<int> _loadStage() async =>
    (await SharedPreferences.getInstance()).getInt('tebak_stage') ?? 1;
Future<int> _loadCoins() async =>
    (await SharedPreferences.getInstance()).getInt('tebak_coins') ?? 0;
Future<int> _loadHigh() async =>
    (await SharedPreferences.getInstance()).getInt('tebak_high') ?? 1;

Future<void> _saveStage(int s) async =>
    (await SharedPreferences.getInstance()).setInt('tebak_stage', s);
Future<void> _saveHigh(int s) async {
  final p = await SharedPreferences.getInstance();
  if (s > (p.getInt('tebak_high') ?? 1)) await p.setInt('tebak_high', s);
}
Future<void> _addCoins(int a) async {
  final p = await SharedPreferences.getInstance();
  await p.setInt('tebak_coins', (p.getInt('tebak_coins') ?? 0) + a);
}
Future<void> _saveStreak(int s) async {
  final p = await SharedPreferences.getInstance();
  await p.setInt('tebak_streak', s);
  final best = p.getInt('tebak_best') ?? 0;
  if (s > best) await p.setInt('tebak_best', s);
}
Future<void> _incCorrect() async {
  final p = await SharedPreferences.getInstance();
  await p.setInt('tebak_correct', (p.getInt('tebak_correct') ?? 0) + 1);
}
Future<void> _incWrong() async {
  final p = await SharedPreferences.getInstance();
  await p.setInt('tebak_wrong', (p.getInt('tebak_wrong') ?? 0) + 1);
}

// ============================================================
// ENTRY PAGE
// ============================================================
class TebakGambarPage extends StatefulWidget {
  final String username, sessionKey, role;
  const TebakGambarPage({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.role,
  });

  @override
  State<TebakGambarPage> createState() => _TebakGambarPageState();
}

class _TebakGambarPageState extends State<TebakGambarPage>
    with SingleTickerProviderStateMixin {
  int _stage = 1, _coins = 0, _high = 1;
  bool _loading = true;
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _fadeAnimation = CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeOut,
    );
    _loadData();
  }

  Future<void> _loadData() async {
    final s = await _loadStage();
    final c = await _loadCoins();
    final h = await _loadHigh();
    if (mounted) {
      setState(() {
        _stage = s;
        _coins = c;
        _high = h;
        _loading = false;
      });
      _fadeController.forward();
    }
  }

  @override
  void dispose() {
    _fadeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        backgroundColor: Color(0xFF0A0E27),
        body: Center(
          child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFFF6B35)),
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFF0A0E27),
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: CustomScrollView(
            slivers: [
              // App Bar
              SliverAppBar(
                backgroundColor: Colors.transparent,
                elevation: 0,
                centerTitle: true,
                leading: IconButton(
                  icon: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.arrow_back_ios_new, size: 18),
                  ),
                  onPressed: () => Navigator.pop(context),
                ),
                title: Text(
                  'TEBAK EMOJI',
                  style: TextStyle(
                    fontFamily: 'Orbitron',
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                    foreground: Paint()
                      ..shader = LinearGradient(
                        colors: [Color(0xFFFF6B35), Color(0xFFFFD700)],
                      ).createShader(Rect.fromLTWH(0, 0, 200, 20)),
                  ),
                ),
                actions: [
                  Container(
                    margin: const EdgeInsets.only(right: 16),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFD700).withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: const Color(0xFFFFD700).withValues(alpha: 0.3),
                      ),
                    ),
                    child: Row(
                      children: [
                        const Text('🪙', style: TextStyle(fontSize: 14)),
                        const SizedBox(width: 4),
                        Text(
                          '$_coins',
                          style: const TextStyle(
                            color: Color(0xFFFFD700),
                            fontFamily: 'Orbitron',
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              // Hero Section
              SliverToBoxAdapter(
                child: Container(
                  margin: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        const Color(0xFF1A1A3E),
                        const Color(0xFF0F0F2A),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(
                      color: const Color(0xFFFF6B35).withValues(alpha: 0.3),
                      width: 1.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFFF6B35).withValues(alpha: 0.15),
                        blurRadius: 30,
                        spreadRadius: 5,
                      ),
                    ],
                  ),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      // Decorative emojis
                      Positioned(
                        left: 16,
                        top: 16,
                        child: const Text('🎯', style: TextStyle(fontSize: 40)),
                      ),
                      Positioned(
                        right: 16,
                        bottom: 16,
                        child: const Text('🏆', style: TextStyle(fontSize: 40)),
                      ),
                      // Main content
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 40),
                        child: Column(
                          children: [
                            const Text(
                              '🎮 GUESS THE EMOJI 🎮',
                              style: TextStyle(
                                fontFamily: 'Orbitron',
                                fontSize: 20,
                                fontWeight: FontWeight.w900,
                                color: Colors.white,
                                letterSpacing: 2,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Tebak makna dari kombinasi emoji',
                              style: TextStyle(
                                color: Colors.white.withValues(alpha: 0.5),
                                fontSize: 12,
                                fontFamily: 'ShareTechMono',
                              ),
                            ),
                            const SizedBox(height: 16),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 8,
                              ),
                              decoration: BoxDecoration(
                                color: const Color(0xFFFF6B35).withValues(alpha: 0.2),
                                borderRadius: BorderRadius.circular(30),
                              ),
                              child: const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.timer, size: 14, color: Color(0xFFFF6B35)),
                                  SizedBox(width: 6),
                                  Text(
                                    'Timer makin cepat seiring stage',
                                    style: TextStyle(
                                      color: Color(0xFFFF6B35),
                                      fontSize: 10,
                                      fontFamily: 'ShareTechMono',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // Stats Cards
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    children: [
                      _StatCard(
                        icon: '🎮',
                        label: 'STAGE',
                        value: '$_stage',
                        color: const Color(0xFFFF6B35),
                      ),
                      const SizedBox(width: 12),
                      _StatCard(
                        icon: '🏆',
                        label: 'RECORD',
                        value: '$_high',
                        color: const Color(0xFF9C27B0),
                      ),
                      const SizedBox(width: 12),
                      _StatCard(
                        icon: '⚡',
                        label: 'STREAK',
                        value: '0',
                        color: const Color(0xFF00BCD4),
                      ),
                    ],
                  ),
                ),
              ),

              const SliverToBoxAdapter(child: SizedBox(height: 24)),

              // Mode Chips
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    alignment: WrapAlignment.center,
                    children: [
                      _ModeChip('🎬', 'FILM', Colors.red),
                      _ModeChip('🎵', 'LAGU', Colors.blue),
                      _ModeChip('📖', 'PERIBAHASA', Colors.green),
                      _ModeChip('💬', 'FRASA', Colors.orange),
                      _ModeChip('🤪', 'ABSURD', Colors.purple),
                      _ModeChip('🖼️', 'GAMBAR', Colors.teal),
                    ],
                  ),
                ),
              ),

              const SliverToBoxAdapter(child: SizedBox(height: 24)),

              // Info Banner
              SliverToBoxAdapter(
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 20),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.red.withValues(alpha: 0.1),
                        Colors.red.withValues(alpha: 0.05),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: Colors.red.withValues(alpha: 0.2),
                    ),
                  ),
                  child: Row(
                    children: [
                      const Text('⚠️', style: TextStyle(fontSize: 20)),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'PERINGATAN!',
                              style: TextStyle(
                                color: Colors.redAccent,
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              'Timer makin cepat, koin makin besar!',
                              style: TextStyle(
                                color: Colors.white.withValues(alpha: 0.4),
                                fontSize: 9,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SliverToBoxAdapter(child: SizedBox(height: 32)),

              // Play Button
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: GestureDetector(
                    onTap: () async {
                      await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => _TebakGamePage(
                            startStage: _stage,
                            username: widget.username,
                            sessionKey: widget.sessionKey,
                          ),
                        ),
                      );
                      _loadData();
                    },
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 18),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFFFF6B35), Color(0xFFFFD700)],
                        ),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFFFF6B35).withValues(alpha: 0.4),
                            blurRadius: 20,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            _stage == 1 ? '▶️' : '🔄',
                            style: const TextStyle(fontSize: 18),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            _stage == 1 ? 'MULAI MAIN' : 'LANJUT STAGE $_stage',
                            style: const TextStyle(
                              fontFamily: 'Orbitron',
                              fontWeight: FontWeight.w900,
                              fontSize: 16,
                              color: Colors.black,
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

              if (_stage > 1) ...[
                const SliverToBoxAdapter(child: SizedBox(height: 12)),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: GestureDetector(
                      onTap: () async {
                        await _saveStage(1);
                        _loadData();
                      },
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: Colors.white.withValues(alpha: 0.1),
                          ),
                          color: Colors.white.withValues(alpha: 0.03),
                        ),
                        child: const Center(
                          child: Text(
                            '🔄 Reset ke Stage 1',
                            style: TextStyle(
                              color: Colors.white38,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],

              const SliverToBoxAdapter(child: SizedBox(height: 40)),
            ],
          ),
        ),
      ),
    );
  }
}

// ============================================================
// STAT CARD WIDGET
// ============================================================
class _StatCard extends StatelessWidget {
  final String icon, label, value;
  final Color color;

  const _StatCard({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withValues(alpha: 0.3)),
        ),
        child: Column(
          children: [
            Text(icon, style: const TextStyle(fontSize: 24)),
            const SizedBox(height: 4),
            Text(
              value,
              style: TextStyle(
                color: color,
                fontFamily: 'Orbitron',
                fontSize: 18,
                fontWeight: FontWeight.w900,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                color: Colors.white.withValues(alpha: 0.5),
                fontSize: 10,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// MODE CHIP WIDGET
// ============================================================
class _ModeChip extends StatelessWidget {
  final String emoji, label;
  final Color color;

  const _ModeChip(this.emoji, this.label, this.color);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 14)),
          const SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.7),
              fontSize: 10,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// GAME PAGE
// ============================================================
class _TebakGamePage extends StatefulWidget {
  final int startStage;
  final String username;
  final String sessionKey;

  const _TebakGamePage({
    required this.startStage,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<_TebakGamePage> createState() => _TebakGamePageState();
}

class _TebakGamePageState extends State<_TebakGamePage>
    with TickerProviderStateMixin {
  late int _stage;
  late TebakSoal _soal;
  int _sessionCoins = 0;
  int _streak = 0;
  final List<String> _jawabanHistory = [];
  int _timeLeft = 25;
  bool _answered = false;
  bool _correct = false;
  bool _isLoading = false;
  int? _selectedIdx;
  Timer? _timer;
  int _clueCount = 0;
  List<int> _revealedIdx = [];

  late AnimationController _scaleController;
  late AnimationController _shakeController;
  late AnimationController _bounceController;
  late AnimationController _resultController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _shakeAnimation;
  late Animation<double> _bounceAnimation;
  late Animation<double> _resultAnimation;

  @override
  void initState() {
    super.initState();
    _stage = widget.startStage;
    _setupAnimations();
    _loadSoal();
  }

  void _setupAnimations() {
    _scaleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _scaleAnimation = CurvedAnimation(
      parent: _scaleController,
      curve: Curves.elasticOut,
    );

    _shakeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _shakeAnimation = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0, end: -10), weight: 25),
      TweenSequenceItem(tween: Tween(begin: -10, end: 10), weight: 50),
      TweenSequenceItem(tween: Tween(begin: 10, end: 0), weight: 25),
    ]).animate(_shakeController);

    _bounceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _bounceAnimation = Tween(begin: 1.0, end: 1.15).animate(
      CurvedAnimation(parent: _bounceController, curve: Curves.elasticOut),
    );

    _resultController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _resultAnimation = CurvedAnimation(
      parent: _resultController,
      curve: Curves.easeOut,
    );
  }

  void _loadSoal() {
    _loadSoalFromApi();
  }

  Future<void> _loadSoalFromApi() async {
    _scaleController.reset();
    setState(() {
      _answered = false;
      _correct = false;
      _selectedIdx = null;
      _timeLeft = _timerForStage(_stage);
      _clueCount = 0;
      _revealedIdx = [];
      _isLoading = true;
    });

    // Retry 3x kalau gagal
    for (int i = 0; i < 3; i++) {
      try {
        final uri = Uri.parse(
          'https://api.botcahx.eu.org/api/game/tebakgambar?apikey=Miwa',
        );
        final resp = await http.get(uri).timeout(const Duration(seconds: 10));
        if (resp.statusCode == 200) {
          final data = jsonDecode(resp.body) as Map<String, dynamic>;
          final jawaban = (data['jawaban'] as String? ?? '').toUpperCase();
          final imgUrl = data['img'] as String?;
          final deskripsi = data['deskripsi'] as String? ?? '';
          final rng = Random();
          // Simpan jawaban untuk jadi pilihan salah di soal berikutnya
          _jawabanHistory.add(jawaban);
          if (_jawabanHistory.length > 50) _jawabanHistory.removeAt(0);
          // Ambil 3 pilihan salah dari history, fallback ke list statis
          final candidates = _jawabanHistory
              .where((j) => j != jawaban)
              .toList()..shuffle(rng);
          final fakes = candidates.take(3).toList();
          // Tambahin fallback kalau history kurang
          const staticFakes = ['KUCING', 'MOBIL', 'RUMAH', 'POHON', 'BUNGA',
            'IKAN', 'BURUNG', 'MEJA', 'KURSI', 'LAPTOP', 'SEPEDA', 'GUNUNG'];
          int fi = 0;
          while (fakes.length < 3) {
            final f = staticFakes[fi % staticFakes.length].toUpperCase();
            if (f != jawaban && !fakes.contains(f)) fakes.add(f);
            fi++;
          }
          final pilihan = [jawaban, ...fakes.take(3)]..shuffle(rng);
          setState(() {
            _soal = TebakSoal(
              jawaban: jawaban,
              hint: deskripsi,
              emojis: [],
              pilihan: pilihan,
              coinReward: 15 + (_stage ~/ 50) * 5,
              mode: TebakMode.gambar,
              imgUrl: imgUrl,
            );
            _isLoading = false;
          });
          _scaleController.forward();
          _startTimer();
          return;
        }
      } catch (_) {
        if (i < 2) await Future.delayed(const Duration(seconds: 1));
      }
    }

    // Kalau semua retry gagal, tampil loading state & coba lagi 3 detik
    await Future.delayed(const Duration(seconds: 3));
    if (mounted) _loadSoalFromApi();
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      setState(() {
        _timeLeft--;
      });
      if (_timeLeft <= 0) {
        timer.cancel();
        if (!_answered) _onTimeout();
      }
    });
  }

  void _onTimeout() {
    if (_answered) return;
    _timer?.cancel();
    setState(() {
      _answered = true;
      _correct = false;
      _streak = 0;
    });
    _shakeController.forward();
    _resultController.forward();
    Future.delayed(const Duration(milliseconds: 2000), () {
      if (mounted) _loadSoal();
    });
  }

  void _useClue() {
    if (_answered) return;
    final jawaban = _soal.jawaban;
    final allIdx = List.generate(jawaban.length, (i) => i)
        .where((i) => jawaban[i] != ' ' && !_revealedIdx.contains(i))
        .toList();
    if (allIdx.isEmpty) return;

    final penalty = (5 + (_stage ~/ 50) * 2).clamp(5, 30);
    if (_sessionCoins < penalty && _clueCount > 0) return;

    allIdx.shuffle();
    setState(() {
      _revealedIdx.add(allIdx.first);
      _clueCount++;
      if (_clueCount > 0 && _sessionCoins >= penalty) {
        _sessionCoins -= penalty;
      }
    });
  }

  String _buildRevealString() {
    final j = _soal.jawaban;
    return j.split('').asMap().entries.map((e) {
      if (e.value == ' ') return '  ';
      if (_revealedIdx.contains(e.key)) return e.value.toUpperCase();
      return ' _ ';
    }).join('');
  }

  void _onAnswer(int idx) async {
    if (_answered) return;
    _timer?.cancel();
    final isRight = _soal.pilihan[idx] == _soal.jawaban;

    setState(() {
      _answered = true;
      _correct = isRight;
      _selectedIdx = idx;
    });
    _resultController.forward();

    if (isRight) {
      _streak++;
      final bonus = _streak >= 3 ? (_soal.coinReward * 0.5).round() : 0;
      final earned = _soal.coinReward + bonus;
      _sessionCoins += earned;

      await _saveStage(_stage + 1);
      await _saveHigh(_stage + 1);
      await _saveStreak(_streak);
      await _incCorrect();
      await _addCoins(earned);

      _bounceController.forward();

      Future.delayed(const Duration(milliseconds: 1500), () {
        if (!mounted) return;
        if (_stage >= 800) {
          _showCompletionDialog();
        } else {
          setState(() {
            _stage++;
          });
          _loadSoal();
        }
      });
    } else {
      _streak = 0;
      await _saveStreak(0);
      await _incWrong();
      _shakeController.forward();
      Future.delayed(const Duration(milliseconds: 2000), () {
        if (mounted) _loadSoal();
      });
    }
  }

  void _showCompletionDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A3E),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
        ),
        title: const Column(
          children: [
            Text('🏆', style: TextStyle(fontSize: 48)),
            SizedBox(height: 8),
            Text(
              'LEGEND!',
              style: TextStyle(
                fontFamily: 'Orbitron',
                color: Color(0xFFFFD700),
                fontSize: 24,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Selamat! Kamu telah menyelesaikan semua 800 stage!',
              style: TextStyle(color: Colors.white70),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFFFD700).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('🪙', style: TextStyle(fontSize: 20)),
                  const SizedBox(width: 8),
                  Text(
                    '$_sessionCoins',
                    style: const TextStyle(
                      color: Color(0xFFFFD700),
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFFFD700),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              minimumSize: const Size(double.infinity, 45),
            ),
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text(
              'KEMBALI KE MENU',
              style: TextStyle(
                color: Colors.black,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _scaleController.dispose();
    _shakeController.dispose();
    _bounceController.dispose();
    _resultController.dispose();
    super.dispose();
  }

  Color get _modeColor {
    switch (_soal.mode) {
      case TebakMode.film:
        return Colors.red;
      case TebakMode.lagu:
        return Colors.blue;
      case TebakMode.peribahasa:
        return Colors.green;
      case TebakMode.frasa:
        return Colors.orange;
      case TebakMode.absurd:
        return Colors.purple;
      case TebakMode.gambar:
        return Colors.teal;
    }
  }

  String get _modeLabel {
    switch (_soal.mode) {
      case TebakMode.film:
        return '🎬 FILM & ANIME';
      case TebakMode.lagu:
        return '🎵 TEBAK LAGU';
      case TebakMode.peribahasa:
        return '📖 PERIBAHASA';
      case TebakMode.frasa:
        return '💬 KATA & FRASA';
      case TebakMode.absurd:
        return '🤪 MODE ABSURD';
      case TebakMode.gambar:
        return '🖼️ TEBAK GAMBAR';
    }
  }

  @override
  Widget build(BuildContext context) {
    final modeColor = _modeColor;
    final maxTime = _timerForStage(_stage).toDouble();

    return Scaffold(
      backgroundColor: const Color(0xFF0A0E27),
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.close, size: 20),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: modeColor.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: modeColor.withValues(alpha: 0.3)),
                    ),
                    child: Text(
                      'STAGE $_stage / 800',
                      style: TextStyle(
                        color: modeColor,
                        fontFamily: 'Orbitron',
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const Spacer(),
                  if (_streak >= 2)
                    Container(
                      margin: const EdgeInsets.only(right: 8),
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.orange.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.orange.withValues(alpha: 0.3)),
                      ),
                      child: Row(
                        children: [
                          const Text('🔥', style: TextStyle(fontSize: 12)),
                          const SizedBox(width: 4),
                          Text(
                            '$_streak',
                            style: const TextStyle(
                              color: Colors.orange,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFD700).withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFFFFD700).withValues(alpha: 0.3)),
                    ),
                    child: Row(
                      children: [
                        const Text('🪙', style: TextStyle(fontSize: 12)),
                        const SizedBox(width: 4),
                        Text(
                          '$_sessionCoins',
                          style: const TextStyle(
                            color: Color(0xFFFFD700),
                            fontFamily: 'Orbitron',
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // Mode Label & Timer
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: modeColor.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      _modeLabel,
                      style: TextStyle(
                        color: modeColor,
                        fontSize: 10,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: (_timeLeft <= 6 ? Colors.red : Colors.white)
                          .withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: (_timeLeft <= 6 ? Colors.red : Colors.white)
                            .withValues(alpha: 0.2),
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.timer,
                          size: 14,
                          color: _timeLeft <= 6 ? Colors.red : Colors.white70,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '${_timeLeft}s',
                          style: TextStyle(
                            color: _timeLeft <= 6 ? Colors.red : Colors.white70,
                            fontFamily: 'Orbitron',
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // Timer Bar
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: (_timeLeft / maxTime).clamp(0.0, 1.0),
                  backgroundColor: Colors.white.withValues(alpha: 0.1),
                  valueColor: AlwaysStoppedAnimation(
                    _timeLeft <= 6 ? Colors.red : modeColor,
                  ),
                  minHeight: 4,
                ),
              ),
            ),

            // Emoji Display
            Expanded(
              flex: 5,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: AnimatedBuilder(
                  animation: _scaleAnimation,
                  builder: (context, child) {
                    return Transform.scale(
                      scale: _scaleAnimation.value,
                      child: Container(
                        width: double.infinity,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              modeColor.withValues(alpha: 0.1),
                              modeColor.withValues(alpha: 0.05),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(32),
                          border: Border.all(
                            color: modeColor.withValues(alpha: 0.3),
                            width: 2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: modeColor.withValues(alpha: 0.2),
                              blurRadius: 30,
                            ),
                          ],
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            if (_soal.imgUrl != null)
                              ClipRRect(
                                borderRadius: BorderRadius.circular(12),
                                child: Image.network(
                                  _soal.imgUrl!,
                                  height: 180,
                                  width: double.infinity,
                                  fit: BoxFit.cover,
                                  frameBuilder: (_, child, frame, wasSynchronouslyLoaded) {
                                    if (wasSynchronouslyLoaded || frame != null) {
                                      return child;
                                    }
                                    return Container(
                                      height: 180,
                                      color: const Color(0xFF0A0E27),
                                      child: const Center(
                                        child: CircularProgressIndicator(color: Colors.teal),
                                      ),
                                    );
                                  },
                                  errorBuilder: (_, __, ___) => Container(
                                    height: 180,
                                    color: const Color(0xFF0A0E27),
                                    child: Center(
                                      child: Text(
                                        _soal.hint,
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(
                                          color: Colors.white70,
                                          fontSize: 13,
                                          fontStyle: FontStyle.italic,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            else
                              Container(
                                height: 180,
                                color: const Color(0xFF0A0E27),
                                child: const Center(
                                  child: CircularProgressIndicator(color: Colors.teal),
                                ),
                              ),
                            const SizedBox(height: 20),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: modeColor.withValues(alpha: 0.2),
                                borderRadius: BorderRadius.circular(30),
                              ),
                              child: Text(
                                _modeLabel,
                                style: TextStyle(
                                  color: modeColor,
                                  fontSize: 10,
                                  fontFamily: 'ShareTechMono',
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),

            // Hint & Clue
            if (!_answered)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.05),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        children: [
                          const Text('💡', style: TextStyle(fontSize: 14)),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              _soal.hint,
                              style: TextStyle(
                                color: Colors.white.withValues(alpha: 0.5),
                                fontSize: 11,
                                fontFamily: 'ShareTechMono',
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    if (_revealedIdx.isNotEmpty)
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.amber.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: Colors.amber.withValues(alpha: 0.3),
                          ),
                        ),
                        child: Text(
                          _buildRevealString(),
                          style: const TextStyle(
                            color: Colors.amber,
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                            letterSpacing: 4,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    const SizedBox(height: 8),
                    GestureDetector(
                      onTap: _useClue,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.amber.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: Colors.amber.withValues(alpha: 0.4),
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Text('🔍', style: TextStyle(fontSize: 14)),
                            const SizedBox(width: 8),
                            const Text(
                              'PETUNJUK',
                              style: TextStyle(
                                color: Colors.amber,
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(width: 4),
                            Text(
                              '-${(5 + (_stage ~/ 50) * 2).clamp(5, 30)}🪙',
                              style: TextStyle(
                                color: Colors.amber.withValues(alpha: 0.7),
                                fontSize: 10,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),

            // Result Banner
            if (_answered)
              FadeTransition(
                opacity: _resultAnimation,
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                  decoration: BoxDecoration(
                    color: (_correct ? Colors.green : Colors.red)
                        .withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: (_correct ? Colors.green : Colors.red)
                          .withValues(alpha: 0.4),
                    ),
                  ),
                  child: Row(
                    children: [
                      Text(
                        _correct ? '✅' : '❌',
                        style: const TextStyle(fontSize: 20),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          _correct
                              ? (_streak >= 3
                                  ? 'Benar! +${_soal.coinReward} +${(_soal.coinReward * 0.5).round()} bonus!'
                                  : 'Benar! +${_soal.coinReward} koin')
                              : 'Salah! Jawaban: ${_soal.jawaban}',
                          style: TextStyle(
                            color: _correct ? Colors.greenAccent : Colors.redAccent,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

            // Answer Options
            Expanded(
              flex: 4,
              child: _isLoading
                  ? Container(
                      color: const Color(0xFF0A0E27),
                      child: const Center(
                        child: CircularProgressIndicator(color: Colors.teal),
                      ),
                    )
                  : Container(
                      color: const Color(0xFF0A0E27),
                      child: AnimatedBuilder(
                        animation: _shakeController,
                        builder: (context, child) {
                          return Transform.translate(
                            offset: Offset(
                              _answered && !_correct ? _shakeAnimation.value : 0,
                              0,
                            ),
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                              child: Column(
                                children: [
                                  Row(
                                    children: [
                                      _AnswerButton(
                                        text: _soal.pilihan[0],
                                        index: 0,
                                        selectedIndex: _selectedIdx,
                                        jawaban: _soal.jawaban,
                                        answered: _answered,
                                        onTap: _onAnswer,
                                        bounceController: _bounceController,
                                        bounceAnimation: _bounceAnimation,
                                      ),
                                      const SizedBox(width: 12),
                                      _AnswerButton(
                                        text: _soal.pilihan[1],
                                        index: 1,
                                        selectedIndex: _selectedIdx,
                                        jawaban: _soal.jawaban,
                                        answered: _answered,
                                        onTap: _onAnswer,
                                        bounceController: _bounceController,
                                        bounceAnimation: _bounceAnimation,
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 12),
                                  Row(
                                    children: [
                                      _AnswerButton(
                                        text: _soal.pilihan[2],
                                        index: 2,
                                        selectedIndex: _selectedIdx,
                                        jawaban: _soal.jawaban,
                                        answered: _answered,
                                        onTap: _onAnswer,
                                        bounceController: _bounceController,
                                        bounceAnimation: _bounceAnimation,
                                      ),
                                      const SizedBox(width: 12),
                                      _AnswerButton(
                                        text: _soal.pilihan[3],
                                        index: 3,
                                        selectedIndex: _selectedIdx,
                                        jawaban: _soal.jawaban,
                                        answered: _answered,
                                        onTap: _onAnswer,
                                        bounceController: _bounceController,
                                        bounceAnimation: _bounceAnimation,
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}


// ============================================================
// ANSWER BUTTON WIDGET - DIPERBAIKI
// ============================================================
class _AnswerButton extends StatelessWidget {
  final String text;
  final int index;
  final int? selectedIndex;
  final String jawaban;
  final bool answered;
  final void Function(int) onTap;
  final AnimationController bounceController;
  final Animation<double> bounceAnimation;

  const _AnswerButton({
    required this.text,
    required this.index,
    required this.selectedIndex,
    required this.jawaban,
    required this.answered,
    required this.onTap,
    required this.bounceController,
    required this.bounceAnimation,
  });

  @override
  Widget build(BuildContext context) {
    final isRight = text == jawaban;
    final isSelected = selectedIndex == index;

    // Warna background yang gelap agar teks putih terlihat
    Color backgroundColor = const Color(0xFF1E1E3F); // gelap
    Color borderColor = const Color(0xFF3A3A6A);
    Color textColor = Colors.white;

    if (answered) {
      if (isRight) {
        backgroundColor = Colors.green.withValues(alpha: 0.25);
        borderColor = Colors.green;
        textColor = Colors.greenAccent;
      } else if (isSelected) {
        backgroundColor = Colors.red.withValues(alpha: 0.25);
        borderColor = Colors.red;
        textColor = Colors.redAccent;
      }
    }

    Widget button = Expanded(
      child: GestureDetector(
        onTap: answered ? null : () => onTap(index),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
          decoration: BoxDecoration(
            color: backgroundColor,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: borderColor,
              width: answered && isRight ? 2 : 1,
            ),
          ),
          child: Text(
            text,
            style: TextStyle(
              color: textColor,
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ),
    );

    if (answered && isRight) {
      return AnimatedBuilder(
        animation: bounceController,
        builder: (context, child) => Transform.scale(
          scale: bounceAnimation.value,
          child: child,
        ),
        child: button,
      );
    }

    return button;
  }
}