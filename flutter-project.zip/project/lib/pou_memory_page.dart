import 'package:http/http.dart' as http;
import 'dart:convert';
import 'config_service.dart';
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'asset_service.dart';
import 'package:audioplayers/audioplayers.dart';
import 'music_service.dart';

// Model Kartu
class MemoryCard {
  final int id;
  final String emoji;
  final int pairId;
  bool isFlipped;
  bool isMatched;

  MemoryCard({
    required this.id,
    required this.emoji,
    required this.pairId,
    this.isFlipped = false,
    this.isMatched = false,
  });
}

// Semua emoji yang tersedia
const List<String> _kAllEmojis = [
  '🍎','🍊','🍋','🍇','🍓','🍒','🍑','🍈','🍍','🥥',
  '🎮','🎯','🎪','🎨','🎭','🎲','🎸','🎺','🎻','🥁',
  '⚽','🏀','🏐','🎱','🏓','🏸','🥅','🎳','🏒','🥋',
  '🏅','🏇','🏈','🤿','🎾','🛹','🏉','🥊','🏆','🎖',
];

// Konfigurasi per stage
class StageConfig {
  final int stage;
  final int pairs;
  final int seconds;
  final int cols;
  final String label;

  StageConfig({
    required this.stage,
    required this.pairs,
    required this.seconds,
    required this.cols,
    required this.label,
  });
}

List<StageConfig> _generateStages() {
  final stages = <StageConfig>[];
  for (int i = 1; i <= 20; i++) {
    int pairs;
    int seconds;
    int cols;

    if (i <= 3) {
      pairs = 4 + i; seconds = 90; cols = 3;
    } else if (i <= 7) {
      pairs = 6 + i; seconds = 80; cols = 4;
    } else if (i <= 12) {
      pairs = 8 + i; seconds = 75; cols = 4;
    } else if (i <= 16) {
      pairs = 10 + i; seconds = 70; cols = 5;
    } else {
      pairs = 12 + i; seconds = 60; cols = 5;
    }

    if (pairs > 30) pairs = 30;

    stages.add(StageConfig(
      stage: i,
      pairs: pairs,
      seconds: seconds,
      cols: cols,
      label: i <= 5 ? 'Mudah' : i <= 10 ? 'Sedang' : i <= 15 ? 'Susah' : 'Ekstrem',
    ));
  }
  return stages;
}

final _stages = _generateStages();

Color _stageLabelColor(String label) {
  switch (label) {
    case 'Mudah':   return const Color(0xFF00FF88);
    case 'Sedang':  return const Color(0xFF00D4FF);
    case 'Susah':   return const Color(0xFFFFD700);
    case 'Ekstrem': return const Color(0xFFFF4444);
    default:        return Colors.white;
  }
}

class PouMemoryPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const PouMemoryPage({
    super.key,
    this.username = '',
    this.sessionKey = '',
  });

  @override
  State<PouMemoryPage> createState() => _PouMemoryPageState();
}

class _PouMemoryPageState extends State<PouMemoryPage>
    with TickerProviderStateMixin, WidgetsBindingObserver {

  final AudioPlayer _bgm = AudioPlayer();
  final MusicService _music = MusicService();
  bool _musicWasPlaying = false;

  int _stageIndex = 0;
  int _totalScore = 0;
  List<MemoryCard> _cards = [];
  List<int> _flippedIndexes = [];
  bool _isChecking = false;
  int _stageScore = 0;
  int _moves = 0;
  int _matched = 0;
  int _timeLeft = 90;
  bool _isPaused = false;
  bool _isGameOver = false;
  bool _isWin = false;
  bool _gameStarted = false;
  Timer? _timer;

  late AnimationController _shakeCtrl;
  int? _shakeIndex;

  StageConfig get _currentStage => _stages[_stageIndex];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _shakeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 400));
    _initAudio();
    _buildCards();
  }

  Future<void> _initAudio() async {
    _musicWasPlaying = _music.isPlaying;
    if (_musicWasPlaying) _music.pause();
    await _bgm.setVolume(0.7);
    await _bgm.setReleaseMode(ReleaseMode.loop);
    await _bgm.play(DeviceFileSource(AssetService.audioPathSync('flip_zone.mp3')));
  }

  // SFX pakai instance terpisah supaya BGM tidak berhenti
  void _playSfx(String asset) {
    final sfx = AudioPlayer();
    // asset format: 'audio/ludo_step.wav' → ambil filename aja
    final filename = asset.split('/').last;
    sfx.play(DeviceFileSource(AssetService.audioPathSync(filename)));
    sfx.onPlayerComplete.listen((_) => sfx.dispose());
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _bgm.pause();
      _timer?.cancel();
    } else if (state == AppLifecycleState.resumed && !_isPaused) {
      _bgm.resume();
      if (_gameStarted && !_isGameOver) _startTimer();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _timer?.cancel();
    _bgm.dispose();
    _shakeCtrl.dispose();
    if (_musicWasPlaying) _music.resume();
    super.dispose();
  }

  void _buildCards() {
    final cfg = _currentStage;
    _timeLeft = cfg.seconds;
    _stageScore = 0;
    _moves = 0;
    _matched = 0;
    _flippedIndexes = [];
    _isChecking = false;
    _isGameOver = false;
    _isWin = false;
    _gameStarted = false;
    _timer?.cancel();

    final startIdx = (_stageIndex * 3) % (_kAllEmojis.length - cfg.pairs);
    final emojis = _kAllEmojis.sublist(startIdx, startIdx + cfg.pairs);

    final allCards = <MemoryCard>[];
    for (int i = 0; i < emojis.length; i++) {
      allCards.add(MemoryCard(id: i * 2,     emoji: emojis[i], pairId: i));
      allCards.add(MemoryCard(id: i * 2 + 1, emoji: emojis[i], pairId: i));
    }
    allCards.shuffle(Random());
    setState(() => _cards = allCards);
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_isPaused || !mounted) return;
      setState(() {
        _timeLeft--;
        if (_timeLeft <= 0) {
          _timeLeft = 0;
          _endGame(win: false);
        }
      });
    });
  }

  void _onCardTap(int index) {
    if (_isChecking || _isGameOver || _isPaused) return;
    final card = _cards[index];
    if (card.isFlipped || card.isMatched) return;

    if (!_gameStarted) {
      _gameStarted = true;
      _startTimer();
    }

    _playSfx('audio/ludo_step.wav');
    setState(() {
      card.isFlipped = true;
      _flippedIndexes.add(index);
    });

    if (_flippedIndexes.length == 2) {
      _moves++;
      _isChecking = true;
      _checkMatch();
    }
  }

  void _checkMatch() {
    final a = _cards[_flippedIndexes[0]];
    final b = _cards[_flippedIndexes[1]];

    if (a.pairId == b.pairId) {
      Future.delayed(const Duration(milliseconds: 400), () {
        if (!mounted) return;
        setState(() {
          a.isMatched = true;
          b.isMatched = true;
          _matched++;
          _stageScore += max(10, 100 - (_moves * 2));
          _flippedIndexes = [];
          _isChecking = false;
        });
        _playSfx('audio/ludo_naik.wav');
        if (_matched == _currentStage.pairs) {
          Future.delayed(const Duration(milliseconds: 400), () => _endGame(win: true));
        }
      });
    } else {
      Future.delayed(const Duration(milliseconds: 700), () {
        if (!mounted) return;
        _shakeIndex = _flippedIndexes[1];
        _shakeCtrl.forward(from: 0);
        // Penalti waktu: makin tinggi stage makin besar penalti
        final penalty = 3 + (_stageIndex ~/ 5);
        setState(() {
          _cards[_flippedIndexes[0]].isFlipped = false;
          _cards[_flippedIndexes[1]].isFlipped = false;
          _flippedIndexes = [];
          _isChecking = false;
          _timeLeft = (_timeLeft - penalty).clamp(0, _currentStage.seconds);
          if (_timeLeft <= 0) _endGame(win: false);
        });
        _playSfx('audio/ludo_ular.wav');
      });
    }
  }

  void _endGame({required bool win}) {
    _timer?.cancel();
    if (win) {
      _totalScore += _stageScore + (_timeLeft * 2);
      _playSfx('audio/ludo_win.wav');
    } else {
      _playSfx('audio/lose.mp3');
    }
    setState(() {
      _isGameOver = true;
      _isWin = win;
    });
    _submitToLeaderboard(win: win);
  }

  Future<void> _submitToLeaderboard({required bool win}) async {
    if (widget.username.isEmpty) return;
    try {
      await http.post(
        Uri.parse('${ConfigService.baseUrl}/api/games/leaderboard/submit'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': widget.username,
          'gameName': 'Pou Memory',
          'score': _totalScore,
          'win': win,
          'icon': '🐾',
        }),
      ).timeout(const Duration(seconds: 8));
    } catch (_) {}
  }

  void _nextStage() {
    if (_stageIndex < _stages.length - 1) {
      setState(() => _stageIndex++);
      _buildCards();
    }
  }

  void _togglePause() {
    setState(() => _isPaused = !_isPaused);
    if (_isPaused) {
      _bgm.pause();
    } else {
      _bgm.resume();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF1A1A2E), Color(0xFF16213E), Color(0xFF0F3460)],
          ),
        ),
        child: SafeArea(
          child: Stack(
            children: [
              Column(
                children: [
                  _buildHeader(),
                  _buildInfoBar(),
                  _buildStageBar(),
                  const SizedBox(height: 6),
                  Expanded(child: _buildGrid()),
                  const SizedBox(height: 8),
                ],
              ),
              if (_isPaused) _buildPauseOverlay(),
              if (_isGameOver) _buildResultOverlay(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Row(
        children: [
          _iconBtn(Icons.arrow_back_ios_new, () {
            _timer?.cancel();
            _bgm.stop();
            if (_musicWasPlaying) _music.resume();
            Navigator.of(context).pop();
          }),
          const Spacer(),
          const Text(
            '🃏  POU MEMORY',
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
              shadows: [Shadow(color: Color(0xFF00D4FF), blurRadius: 12)],
            ),
          ),
          const Spacer(),
          _iconBtn(_isPaused ? Icons.play_arrow : Icons.pause, _togglePause),
        ],
      ),
    );
  }

  Widget _iconBtn(IconData icon, VoidCallback cb) {
    return GestureDetector(
      onTap: cb,
      child: Container(
        width: 38, height: 38,
        decoration: BoxDecoration(
          color: Colors.white12,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.white24),
        ),
        child: Icon(icon, color: Colors.white, size: 20),
      ),
    );
  }

  Widget _buildInfoBar() {
    final pct = _timeLeft / _currentStage.seconds;
    final timeColor = _timeLeft <= 10
        ? Colors.red
        : _timeLeft <= 20
            ? Colors.orange
            : const Color(0xFF00D4FF);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _infoChip('TOTAL SKOR', '$_totalScore', const Color(0xFFFFD700)),
              _infoChip('LANGKAH', '$_moves', const Color(0xFF00D4FF)),
              _infoChip('COCOK', '$_matched/${_currentStage.pairs}', const Color(0xFF00FF88)),
              _infoChip('WAKTU', '$_timeLeft', timeColor),
            ],
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: pct.clamp(0.0, 1.0),
              minHeight: 6,
              backgroundColor: Colors.white12,
              valueColor: AlwaysStoppedAnimation<Color>(timeColor),
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoChip(String label, String val, Color color) {
    return Column(
      children: [
        Text(label, style: const TextStyle(color: Colors.white54, fontSize: 9, fontWeight: FontWeight.w700)),
        Text(val, style: TextStyle(
            color: color, fontSize: 16, fontWeight: FontWeight.w900,
            shadows: [Shadow(color: color.withOpacity(0.5), blurRadius: 8)])),
      ],
    );
  }

  Widget _buildStageBar() {
    final stage = _currentStage;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
            decoration: BoxDecoration(
              color: Colors.white10,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFF00D4FF).withOpacity(0.3)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.flag_rounded, color: Color(0xFF00D4FF), size: 14),
                const SizedBox(width: 6),
                Text(
                  'STAGE ${stage.stage} / ${_stages.length}',
                  style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w900, letterSpacing: 1),
                ),
                const SizedBox(width: 10),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: _stageLabelColor(stage.label).withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    stage.label,
                    style: TextStyle(color: _stageLabelColor(stage.label), fontSize: 10, fontWeight: FontWeight.w800),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Flexible(
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: List.generate(
                  _stages.length,
                  (i) => Container(
                    margin: const EdgeInsets.symmetric(horizontal: 1.5),
                    width: i == _stageIndex ? 10 : 6,
                    height: i == _stageIndex ? 10 : 6,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: i < _stageIndex
                          ? const Color(0xFF00FF88)
                          : i == _stageIndex
                              ? const Color(0xFF00D4FF)
                              : Colors.white24,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGrid() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: GridView.builder(
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: _currentStage.cols,
          crossAxisSpacing: 8,
          mainAxisSpacing: 8,
          childAspectRatio: 1,
        ),
        itemCount: _cards.length,
        itemBuilder: (context, i) => _buildCard(i),
      ),
    );
  }

  Widget _buildCard(int index) {
    final card = _cards[index];
    final isShaking = _shakeIndex == index;

    return GestureDetector(
      onTap: () => _onCardTap(index),
      child: AnimatedBuilder(
        animation: _shakeCtrl,
        builder: (_, child) {
          double dx = 0;
          if (isShaking) dx = sin(_shakeCtrl.value * pi * 5) * 6;
          return Transform.translate(offset: Offset(dx, 0), child: child);
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeInOut,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            color: card.isMatched
                ? const Color(0xFF00FF88).withOpacity(0.15)
                : card.isFlipped
                    ? const Color(0xFF00D4FF).withOpacity(0.15)
                    : const Color(0xFF1E2A4A),
            border: Border.all(
              color: card.isMatched
                  ? const Color(0xFF00FF88)
                  : card.isFlipped
                      ? const Color(0xFF00D4FF)
                      : Colors.white24,
              width: card.isMatched || card.isFlipped ? 2 : 1,
            ),
            boxShadow: card.isMatched
                ? [BoxShadow(color: const Color(0xFF00FF88).withOpacity(0.3), blurRadius: 12)]
                : card.isFlipped
                    ? [BoxShadow(color: const Color(0xFF00D4FF).withOpacity(0.3), blurRadius: 10)]
                    : [],
          ),
          child: Center(
            child: card.isFlipped || card.isMatched
                ? Text(card.emoji, style: TextStyle(fontSize: _currentStage.cols >= 5 ? 22 : 28))
                : Icon(Icons.help_outline, color: Colors.white30, size: _currentStage.cols >= 5 ? 22 : 28),
          ),
        ),
      ),
    );
  }

  Widget _buildPauseOverlay() {
    return GestureDetector(
      onTap: _togglePause,
      child: Container(
        color: Colors.black.withOpacity(0.7),
        alignment: Alignment.center,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.pause_circle_filled, color: Color(0xFF00D4FF), size: 80),
            const SizedBox(height: 16),
            const Text('DIJEDA', style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w900, letterSpacing: 4)),
            const SizedBox(height: 8),
            const Text('Ketuk untuk lanjut', style: TextStyle(color: Colors.white54, fontSize: 14)),
          ],
        ),
      ),
    );
  }

  Widget _buildResultOverlay() {
    final isLastStage = _stageIndex >= _stages.length - 1;
    return Container(
      color: Colors.black.withOpacity(0.75),
      alignment: Alignment.center,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 24),
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: const Color(0xFF1A1A2E),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: _isWin ? const Color(0xFF00FF88) : const Color(0xFFFF4444),
            width: 2,
          ),
          boxShadow: [
            BoxShadow(
              color: (_isWin ? const Color(0xFF00FF88) : const Color(0xFFFF4444)).withOpacity(0.3),
              blurRadius: 30,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              _isWin
                  ? isLastStage ? '🏆 SELESAI SEMUA!' : '🎉 STAGE ${_currentStage.stage} CLEAR!'
                  : '⏰ WAKTU HABIS!',
              style: TextStyle(
                color: _isWin ? const Color(0xFF00FF88) : const Color(0xFFFF4444),
                fontSize: 22,
                fontWeight: FontWeight.w900,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 4),
            if (_isWin && !isLastStage)
              Text('Lanjut ke Stage ${_currentStage.stage + 1}',
                  style: const TextStyle(color: Colors.white54, fontSize: 13)),
            const SizedBox(height: 14),
            _resultRow('Stage', '${_currentStage.stage} - ${_currentStage.label}'),
            _resultRow('Skor Stage', '$_stageScore'),
            _resultRow('Total Skor', '$_totalScore'),
            _resultRow('Langkah', '$_moves'),
            _resultRow('Cocok', '$_matched/${_currentStage.pairs}'),
            if (_isWin) _resultRow('Sisa Waktu', '$_timeLeft detik'),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (_isWin && !isLastStage)
                  _overlayBtn('🎯 Stage ${_currentStage.stage + 1}', const Color(0xFF00FF88), _nextStage)
                else if (_isWin && isLastStage)
                  _overlayBtn('🔄 Ulangi', const Color(0xFF00D4FF), () {
                    setState(() { _stageIndex = 0; _totalScore = 0; });
                    _buildCards();
                  })
                else
                  _overlayBtn('🔁 Coba Lagi', const Color(0xFF00D4FF), _buildCards),
                const SizedBox(width: 10),
                _overlayBtn('🏠 Menu', Colors.white24, () {
                  _timer?.cancel();
                  _bgm.stop();
                  if (_musicWasPlaying) _music.resume();
                  Navigator.of(context).pop();
                }),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _resultRow(String label, String val) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: Colors.white54, fontSize: 13)),
          Text(val, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }

  Widget _overlayBtn(String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(14)),
        child: Text(
          label,
          style: TextStyle(
            color: color == Colors.white24 ? Colors.white70 : Colors.black,
            fontWeight: FontWeight.w800,
            fontSize: 13,
          ),
        ),
      ),
    );
  }
}
