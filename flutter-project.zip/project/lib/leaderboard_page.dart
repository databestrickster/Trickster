// lib/leaderboard_page.dart
// Global Leaderboard — semua user, semua game
// Style: NEON ARCADE konsisten dengan existing app

import 'config_service.dart';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// ── Neon palette (konsisten dengan app) ──────────────────────────────────────
const _bg         = Color(0xFF060811);
const _bgCard     = Color(0xFF0D1020);
const _neonGreen  = Color(0xFF00FF88);
const _neonBlue   = Color(0xFF00C8FF);
const _neonYellow = Color(0xFFFFD60A);
const _neonRed    = Color(0xFFFF2D55);
const _neonOrange = Color(0xFFFF6B00);
const _neonPurple = Color(0xFFBF5AF2);
const _neonPink   = Color(0xFFFF2D78);

// ── Sort options ──────────────────────────────────────────────────────────────
enum LbSort { coins, totalScore, totalGames, winRate }

extension LbSortExt on LbSort {
  String get label {
    switch (this) {
      case LbSort.coins:      return 'Koin';
      case LbSort.totalScore: return 'Skor';
      case LbSort.totalGames: return 'Main';
      case LbSort.winRate:    return 'Win%';
    }
  }
  String get param {
    switch (this) {
      case LbSort.coins:      return 'coins';
      case LbSort.totalScore: return 'totalScore';
      case LbSort.totalGames: return 'totalGames';
      case LbSort.winRate:    return 'winRate';
    }
  }
  Color get color {
    switch (this) {
      case LbSort.coins:      return _neonYellow;
      case LbSort.totalScore: return _neonBlue;
      case LbSort.totalGames: return _neonPurple;
      case LbSort.winRate:    return _neonGreen;
    }
  }
  IconData get icon {
    switch (this) {
      case LbSort.coins:      return Icons.monetization_on_rounded;
      case LbSort.totalScore: return Icons.star_rounded;
      case LbSort.totalGames: return Icons.sports_esports_rounded;
      case LbSort.winRate:    return Icons.emoji_events_rounded;
    }
  }
}

// ── API ───────────────────────────────────────────────────────────────────────
class LeaderboardApi {
  static Future<void> submitResult({
    required List<Map<String, dynamic>> players,
    required String winnerName,
    required String roomCode,
    required int duration,
  }) async {
    try {
      await http.post(
        Uri.parse('${ConfigService.baseUrl}/api/ut/leaderboard/submit'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'players': players,
          'winnerName': winnerName,
          'roomCode': roomCode,
          'duration': duration,
        }),
      ).timeout(const Duration(seconds: 10));
    } catch (_) {}
  }
}

class GlobalLeaderboardApi {
  static Future<Map<String, dynamic>> getLeaderboard(String sort) async {
    final r = await http.get(
      Uri.parse('${ConfigService.baseUrl}/api/global/leaderboard?sort=$sort&limit=100'),
    ).timeout(const Duration(seconds: 10));
    return jsonDecode(r.body);
  }

  static Future<Map<String, dynamic>> getMyStats(String key) async {
    final r = await http.get(
      Uri.parse('${ConfigService.baseUrl}/api/global/leaderboard/me?key=${Uri.encodeComponent(key)}'),
    ).timeout(const Duration(seconds: 8));
    return jsonDecode(r.body);
  }
}

// ── Main Page ─────────────────────────────────────────────────────────────────
class LeaderboardPage extends StatefulWidget {
  final String username;
  final String userRole;
  final String? sessionKey;

  const LeaderboardPage({
    super.key,
    required this.username,
    required this.userRole,
    this.sessionKey,
  });

  @override
  State<LeaderboardPage> createState() => _LeaderboardPageState();
}

class _LeaderboardPageState extends State<LeaderboardPage>
    with TickerProviderStateMixin {
  late AnimationController _entryCtrl;
  late AnimationController _pulseCtrl;

  LbSort _sort = LbSort.coins;
  bool _loading = true;
  String? _error;

  List<dynamic> _players = [];
  Map<String, dynamic>? _myStats;
  int? _expandedIndex;

  @override
  void initState() {
    super.initState();
    _entryCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 600))..forward();
    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2000))..repeat(reverse: true);
    _load();
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final futures = [
        GlobalLeaderboardApi.getLeaderboard(_sort.param),
        if (widget.sessionKey != null)
          GlobalLeaderboardApi.getMyStats(widget.sessionKey!),
      ];
      final results = await Future.wait(futures);
      if (!mounted) return;
      setState(() {
        _players  = results[0]['leaderboard'] ?? [];
        _myStats  = widget.sessionKey != null ? results[1] : null;
        _loading  = false;
      });
    } catch (e) {
      if (mounted) setState(() { _error = 'Gagal memuat: $e'; _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: Stack(children: [
        Positioned.fill(child: CustomPaint(painter: _GridPainter())),
        _Blob(color: _neonYellow, size: 280, top: -80, right: -60),
        _Blob(color: _neonBlue,   size: 220, bottom: -50, left: -40, phase: 1.8),
        SafeArea(
          child: FadeTransition(
            opacity: CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOut),
            child: Column(children: [
              _buildHeader(),
              if (_myStats != null && !_loading) _buildMyCard(),
              const SizedBox(height: 8),
              _buildSortBar(),
              const SizedBox(height: 4),
              Expanded(child: _buildBody()),
            ]),
          ),
        ),
      ]),
    );
  }

  // ── Header ────────────────────────────────────────────────────────────────
  Widget _buildHeader() => Padding(
    padding: const EdgeInsets.fromLTRB(14, 12, 14, 0),
    child: Row(children: [
      _NeonBtn(icon: Icons.arrow_back, color: _neonBlue, onTap: () => Navigator.pop(context)),
      const Spacer(),
      Column(children: [
        ShaderMask(
          shaderCallback: (r) => const LinearGradient(
            colors: [_neonYellow, _neonOrange]).createShader(r),
          child: const Text('LEADERBOARD', style: TextStyle(
            fontFamily: 'Orbitron', fontSize: 18,
            fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 2)),
        ),
        const Text('All Games • Global Ranking', style: TextStyle(
          color: Colors.white30, fontFamily: 'ShareTechMono', fontSize: 10)),
      ]),
      const Spacer(),
      _loading
        ? const SizedBox(width: 36, height: 36,
            child: Padding(padding: EdgeInsets.all(8),
              child: CircularProgressIndicator(strokeWidth: 2, color: _neonGreen)))
        : _NeonBtn(icon: Icons.refresh, color: _neonGreen, onTap: _load),
    ]),
  );

  // ── My Card ───────────────────────────────────────────────────────────────
  Widget _buildMyCard() {
    final s = _myStats!;
    final rank  = s['rank']         ?? '-';
    final total = s['totalPlayers'] ?? 0;
    final coins = s['coins']        ?? 0;
    final games = s['totalGames']   ?? 0;
    final wins  = s['totalWins']    ?? 0;
    final wr    = s['winRate']      ?? 0;

    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (_, __) => Container(
        margin: const EdgeInsets.fromLTRB(14, 10, 14, 0),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: _neonGreen.withValues(alpha: 0.3 + _pulseCtrl.value * 0.2),
            width: 1.5),
          color: _neonGreen.withValues(alpha: 0.05),
          boxShadow: [BoxShadow(
            color: _neonGreen.withValues(alpha: 0.1 + _pulseCtrl.value * 0.08),
            blurRadius: 20)],
        ),
        child: Row(children: [
          // Rank circle
          Container(
            width: 52, height: 52,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: _neonGreen, width: 2),
              color: _neonGreen.withValues(alpha: 0.1),
              boxShadow: [BoxShadow(color: _neonGreen.withValues(alpha: 0.4), blurRadius: 16)]),
            child: Center(child: Text('#$rank', style: const TextStyle(
              color: _neonGreen, fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900, fontSize: 14,
              shadows: [Shadow(color: _neonGreen, blurRadius: 8)]))),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Text(widget.username, style: const TextStyle(
                color: Colors.white, fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold, fontSize: 13)),
              const SizedBox(width: 6),
              _GlowBadge('YOU', _neonGreen),
            ]),
            const SizedBox(height: 4),
            Text('dari $total pemain global', style: const TextStyle(
              color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 10)),
          ])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Row(children: [
              const Icon(Icons.monetization_on_rounded, color: _neonYellow, size: 14),
              const SizedBox(width: 3),
              Text('$coins', style: const TextStyle(
                color: _neonYellow, fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold, fontSize: 13,
                shadows: [Shadow(color: _neonYellow, blurRadius: 6)])),
            ]),
            const SizedBox(height: 2),
            Text('$games main • $wins menang • $wr%',
              style: const TextStyle(color: Colors.white30, fontSize: 9,
                fontFamily: 'ShareTechMono')),
          ]),
        ]),
      ),
    );
  }

  // ── Sort bar ──────────────────────────────────────────────────────────────
  Widget _buildSortBar() => SingleChildScrollView(
    scrollDirection: Axis.horizontal,
    padding: const EdgeInsets.symmetric(horizontal: 14),
    child: Row(children: LbSort.values.map((s) {
      final active = _sort == s;
      return GestureDetector(
        onTap: () { setState(() { _sort = s; _expandedIndex = null; }); _load(); },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          margin: const EdgeInsets.only(right: 8),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: active ? s.color.withValues(alpha: 0.15) : Colors.white.withValues(alpha: 0.04),
            border: Border.all(
              color: active ? s.color.withValues(alpha: 0.7) : Colors.white12,
              width: active ? 1.5 : 1),
            boxShadow: active ? [BoxShadow(color: s.color.withValues(alpha: 0.25), blurRadius: 12)] : [],
          ),
          child: Row(children: [
            Icon(s.icon, color: active ? s.color : Colors.white38, size: 14),
            const SizedBox(width: 5),
            Text(s.label, style: TextStyle(
              color: active ? s.color : Colors.white38,
              fontFamily: 'Orbitron', fontSize: 10,
              fontWeight: active ? FontWeight.bold : FontWeight.normal,
              shadows: active ? [Shadow(color: s.color, blurRadius: 6)] : [],
            )),
          ]),
        ),
      );
    }).toList()),
  );

  // ── Body ──────────────────────────────────────────────────────────────────
  Widget _buildBody() {
    if (_loading) return const Center(child: CircularProgressIndicator(color: _neonGreen));
    if (_error != null) return Center(child: Text(_error!, style: const TextStyle(color: _neonRed)));
    if (_players.isEmpty) return const Center(
      child: Text('Belum ada data', style: TextStyle(color: Colors.white38, fontFamily: 'Orbitron')));

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 24),
      itemCount: _players.length,
      itemBuilder: (_, i) => _buildPlayerCard(_players[i], i),
    );
  }

  // ── Player Card ───────────────────────────────────────────────────────────
  Widget _buildPlayerCard(Map<String, dynamic> p, int index) {
    final rank     = p['rank']         ?? index + 1;
    final username = p['username']     ?? '-';
    final coins    = p['coins']        ?? 0;
    final score    = p['totalScore']   ?? 0;
    final games    = p['totalGames']   ?? 0;
    final winRate  = p['winRate']      ?? 0;
    final favGame  = p['favoriteGame'] ?? '-';
    final gamesPlayed = (p['gamesPlayed'] as List?) ?? [];
    final isMe     = username == widget.username;
    final expanded = _expandedIndex == index;

    // Rank colors
    Color rankColor = Colors.white38;
    if (rank == 1) rankColor = _neonYellow;
    else if (rank == 2) rankColor = _neonBlue;
    else if (rank == 3) rankColor = _neonOrange;

    // Current sort value highlight
    String sortValue;
    Color  sortColor;
    switch (_sort) {
      case LbSort.coins:
        sortValue = '$coins 🪙'; sortColor = _neonYellow; break;
      case LbSort.totalScore:
        sortValue = '$score ⭐'; sortColor = _neonBlue; break;
      case LbSort.totalGames:
        sortValue = '$games 🎮'; sortColor = _neonPurple; break;
      case LbSort.winRate:
        sortValue = '$winRate%'; sortColor = _neonGreen; break;
    }

    return GestureDetector(
      onTap: () => setState(() => _expandedIndex = expanded ? null : index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
        margin: const EdgeInsets.only(bottom: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isMe
              ? _neonGreen.withValues(alpha: 0.5)
              : rank <= 3
                ? rankColor.withValues(alpha: 0.4)
                : Colors.white.withValues(alpha: 0.07),
            width: isMe ? 1.5 : 1),
          color: isMe
            ? _neonGreen.withValues(alpha: 0.05)
            : rank <= 3
              ? rankColor.withValues(alpha: 0.04)
              : _bgCard,
          boxShadow: isMe || rank <= 3
            ? [BoxShadow(
                color: (isMe ? _neonGreen : rankColor).withValues(alpha: 0.12),
                blurRadius: 16)]
            : [],
        ),
        child: Column(children: [
          // ── Main row ──────────────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            child: Row(children: [
              // Rank badge
              SizedBox(
                width: 40,
                child: rank <= 3
                  ? _MedalBadge(rank: rank, color: rankColor)
                  : Text('#$rank', style: TextStyle(
                      color: rankColor, fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold, fontSize: 12)),
              ),
              const SizedBox(width: 10),

              // Avatar circle
              Container(
                width: 38, height: 38,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _usernameColor(username).withValues(alpha: 0.15),
                  border: Border.all(color: _usernameColor(username).withValues(alpha: 0.5))),
                child: Center(child: Text(
                  username.isNotEmpty ? username[0].toUpperCase() : '?',
                  style: TextStyle(
                    color: _usernameColor(username),
                    fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 16))),
              ),
              const SizedBox(width: 10),

              // Username + fav game
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Flexible(child: Text(username,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white, fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold, fontSize: 12))),
                  if (isMe) ...[const SizedBox(width: 4), _GlowBadge('YOU', _neonGreen)],
                ]),
                const SizedBox(height: 3),
                Row(children: [
                  Text('Fav: ', style: const TextStyle(color: Colors.white30, fontSize: 9,
                    fontFamily: 'ShareTechMono')),
                  Text(favGame, style: const TextStyle(color: Colors.white54, fontSize: 9,
                    fontFamily: 'ShareTechMono')),
                ]),
              ])),

              // Sort value + expand icon
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text(sortValue, style: TextStyle(
                  color: sortColor, fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold, fontSize: 13,
                  shadows: [Shadow(color: sortColor, blurRadius: 6)])),
                const SizedBox(height: 2),
                Icon(expanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                  color: Colors.white24, size: 14),
              ]),
            ]),
          ),

          // ── Expanded detail ───────────────────────────────────────────────
          if (expanded) _buildExpandedDetail(p, gamesPlayed),
        ]),
      ),
    );
  }

  Widget _buildExpandedDetail(Map<String, dynamic> p, List gamesPlayed) {
    final coins    = p['coins']      ?? 0;
    final score    = p['totalScore'] ?? 0;
    final games    = p['totalGames'] ?? 0;
    final wins     = p['totalWins']  ?? 0;
    final winRate  = p['winRate']    ?? 0;
    final lastActive = p['lastActive'];

    String lastActiveStr = '-';
    if (lastActive != null) {
      try {
        final dt = DateTime.parse(lastActive).toLocal();
        lastActiveStr = '${dt.day}/${dt.month}/${dt.year}';
      } catch (_) {}
    }

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(14, 0, 14, 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: Colors.white.withValues(alpha: 0.03),
        border: Border.all(color: Colors.white.withValues(alpha: 0.06)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Stats row
        Row(children: [
          _MiniStat('KOIN',    '$coins',   _neonYellow),
          _MiniStat('SKOR',    '$score',   _neonBlue),
          _MiniStat('MAIN',    '$games',   _neonPurple),
          _MiniStat('WIN%',    '$winRate%', _neonGreen),
          _MiniStat('MENANG',  '$wins',    _neonOrange),
        ]),
        const SizedBox(height: 10),

        // Per-game list
        if (gamesPlayed.isNotEmpty) ...[
          const Text('GAME DIMAINKAN', style: TextStyle(
            color: Colors.white24, fontFamily: 'Orbitron',
            fontSize: 8, letterSpacing: 1)),
          const SizedBox(height: 6),
          ...gamesPlayed.map((g) => Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Row(children: [
              Text('${g['icon']} ', style: const TextStyle(fontSize: 12)),
              Text(g['game'] ?? '-', style: const TextStyle(
                color: Colors.white70, fontFamily: 'ShareTechMono', fontSize: 10)),
              const Spacer(),
              Text('${g['games']} main', style: const TextStyle(
                color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 9)),
              const SizedBox(width: 8),
              Text('${g['wins']} menang', style: const TextStyle(
                color: _neonGreen, fontFamily: 'ShareTechMono', fontSize: 9)),
            ]),
          )),
          const SizedBox(height: 6),
        ],

        // Last active
        Row(children: [
          const Icon(Icons.access_time, color: Colors.white24, size: 10),
          const SizedBox(width: 4),
          Text('Terakhir main: $lastActiveStr', style: const TextStyle(
            color: Colors.white24, fontFamily: 'ShareTechMono', fontSize: 9)),
        ]),
      ]),
    );
  }

  Color _usernameColor(String username) {
    final colors = [_neonBlue, _neonGreen, _neonPurple, _neonOrange, _neonPink, _neonYellow];
    int hash = 0;
    for (final c in username.codeUnits) hash = (hash * 31 + c) & 0xFFFFFF;
    return colors[hash % colors.length];
  }
}

// ── Components ────────────────────────────────────────────────────────────────

class _MiniStat extends StatelessWidget {
  final String label, value;
  final Color color;
  const _MiniStat(this.label, this.value, this.color);

  @override
  Widget build(BuildContext context) => Expanded(
    child: Column(children: [
      Text(value, style: TextStyle(
        color: color, fontFamily: 'Orbitron',
        fontWeight: FontWeight.bold, fontSize: 12,
        shadows: [Shadow(color: color.withValues(alpha: 0.6), blurRadius: 6)])),
      const SizedBox(height: 2),
      Text(label, style: const TextStyle(
        color: Colors.white24, fontFamily: 'Orbitron',
        fontSize: 7, letterSpacing: 0.5)),
    ]),
  );
}

class _MedalBadge extends StatelessWidget {
  final int rank;
  final Color color;
  const _MedalBadge({required this.rank, required this.color});

  @override
  Widget build(BuildContext context) {
    final medal = rank == 1 ? '🥇' : rank == 2 ? '🥈' : '🥉';
    return Container(
      width: 36, height: 36,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color.withValues(alpha: 0.12),
        border: Border.all(color: color.withValues(alpha: 0.5)),
        boxShadow: [BoxShadow(color: color.withValues(alpha: 0.3), blurRadius: 12)]),
      child: Center(child: Text(medal, style: const TextStyle(fontSize: 16))),
    );
  }
}

class _GlowBadge extends StatelessWidget {
  final String label;
  final Color color;
  const _GlowBadge(this.label, this.color);

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
    decoration: BoxDecoration(
      color: color.withValues(alpha: 0.12),
      borderRadius: BorderRadius.circular(4),
      border: Border.all(color: color.withValues(alpha: 0.5)),
      boxShadow: [BoxShadow(color: color.withValues(alpha: 0.3), blurRadius: 8)]),
    child: Text(label, style: TextStyle(
      color: color, fontSize: 7, fontWeight: FontWeight.bold,
      fontFamily: 'Orbitron', shadows: [Shadow(color: color, blurRadius: 4)])),
  );
}

class _NeonBtn extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _NeonBtn({required this.icon, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withValues(alpha: 0.3)),
        boxShadow: [BoxShadow(color: color.withValues(alpha: 0.15), blurRadius: 10)]),
      child: Icon(icon, color: color.withValues(alpha: 0.8), size: 20)),
  );
}

// ── Background painters ───────────────────────────────────────────────────────
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height),
      Paint()..color = _bg);
    final p = Paint()
      ..color = _neonGreen.withValues(alpha: 0.025)
      ..strokeWidth = 0.5;
    const s = 28.0;
    for (double x = 0; x < size.width; x += s)
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    for (double y = 0; y < size.height; y += s)
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
  }
  @override
  bool shouldRepaint(_GridPainter o) => false;
}

class _Blob extends StatefulWidget {
  final Color color;
  final double size;
  final double? top, bottom, left, right;
  final double phase;
  const _Blob({required this.color, required this.size,
    this.top, this.bottom, this.left, this.right, this.phase = 0});

  @override
  State<_Blob> createState() => _BlobState();
}

class _BlobState extends State<_Blob> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 4000))..repeat(reverse: true);
    if (widget.phase > 0) _ctrl.value = (widget.phase / pi).clamp(0, 1);
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Positioned(
    top: widget.top, bottom: widget.bottom, left: widget.left, right: widget.right,
    child: IgnorePointer(child: AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) => Container(
        width:  widget.size + _ctrl.value * 50,
        height: widget.size + _ctrl.value * 50,
        decoration: BoxDecoration(shape: BoxShape.circle, boxShadow: [
          BoxShadow(
            color: widget.color.withValues(alpha: 0.05 + _ctrl.value * 0.04),
            blurRadius: widget.size * 0.5, spreadRadius: widget.size * 0.18),
        ]),
      ),
    )),
  );
}
