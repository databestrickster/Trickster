import 'config_service.dart';
import 'package:flutter/material.dart';
import 'asset_service.dart';
import 'rating_service.dart';
import 'package:provider/provider.dart';
import 'dart:math';
import 'dart:ui';
import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';
import 'device_cache.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:http/http.dart' as http;
import 'package:dio/dio.dart';
import 'package:geolocator/geolocator.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:video_player/video_player.dart';

import 'iqc_page.dart';
import 'login_page.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'developer_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'adzan_page.dart';
import 'stats_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'info_page.dart';
import 'settings_page.dart';
import 'theme_provider.dart';
import 'slot_machine_page.dart';
import 'ular_tangga_online.dart';
import 'tebak_gambar_page.dart';
import 'leaderboard_page.dart';
import 'music_page.dart';
import 'pou_memory_page.dart';
import 'kisah_nabi_page.dart';
import 'gojo_wa.dart';
import 'shop_module.dart';
import 'bacaan_shalat_page.dart';
import 'pinterest_page.dart';
import 'team_page.dart';
import 'manga_search_page.dart';
import 'donasi.dart';
import 'Remini.dart';
import 'novel_home_page.dart';
import 'otp_store_page.dart';
import 'device_dashboard.dart';
import 'chat_page.dart';
import 'remi_poker_page.dart';
import 'jadi_hitam_page.dart';
import 'chess_page.dart';
import 'snake_page.dart';


final RouteObserver<ModalRoute<void>> dashboardRouteObserver =
    RouteObserver<ModalRoute<void>>();

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin, RouteAware {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  late AnimationController _staggerController;
  late List<Animation<double>> _fadeAnims;
  late List<Animation<Offset>> _slideAnims;

  late AnimationController _pulseCtrl;
  late AnimationController _particleCtrl;
  late AnimationController _avatarRotateCtrl;
  bool _isGlitching = false;
  double _glitchOffX = 0, _glitchOffX2 = 0;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  String androidId = "unknown";
  File? _profileImage;
  File? _backgroundImage;

  int onlineUsers = 0;
  int activeConnections = 0;
  int totalAccounts = 0;
  bool _isFloatingMenuOpen = false;

  int _lastNotifId = 0;
  Timer? _notifTimer;
  Timer? _statsTimer;
  Timer? _clockTimer;
  Timer? _glitchTimer;
  Timer? _weatherTimer;
  Timer? _statsHttpTimer;
  String _currentTime = '';
  String _currentDate = '';
  List<Map<String, dynamic>> _notifHistory = [];
  bool _hasUnread = false;

  // Rating
  double _avgRating = 0.0;
  int _totalRatings = 0;
  int _userRating = 0; // rating yg user ini kasih (0 = belum rating)

  late AnimationController _floatingController;
  late Animation<double> _floatingScaleAnimation;
  late Animation<double> _floatingFadeAnimation;
  late Animation<Offset> _floatingSlideAnimation;

  Offset _floatingButtonPosition = const Offset(20, 100);
  final double _floatingButtonSize = 65;
  bool _isDragging = false;

  final ImagePicker _imagePicker = ImagePicker();

  static AudioPlayer? _staticAudioPlayer;
  bool _isAudioInitialized = false;

  VideoPlayerController? _headerVideoController;
  bool _isVideoReady = false;

  Map<String, dynamic>? _cachedWeather;
  bool _isWeatherLoading = false;

  bool _maintenanceShown = false;
  bool _rulesOverlayShown = false;
  int _rulesCountdown = 7;
  Timer? _rulesCountdownTimer;

  late ScrollController _cardScrollCtrl;
  Timer? _cardAutoScrollTimer;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _controller = AnimationController(
        duration: const Duration(milliseconds: 450), vsync: this);
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _pulseCtrl = AnimationController(
        duration: const Duration(milliseconds: 2000), vsync: this);
    _particleCtrl =
        AnimationController(duration: const Duration(seconds: 8), vsync: this);
    _avatarRotateCtrl =
        AnimationController(duration: const Duration(seconds: 4), vsync: this);
    // Animasi loop ini ditunda sampai frame pertama selesai render,
    // biar gak numpuk bareng kerjaan initState lain pas dashboard baru dibuka.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _pulseCtrl.repeat(reverse: true);
      _particleCtrl.repeat();
      _avatarRotateCtrl.repeat();
    });

    _staggerController = AnimationController(
        duration: const Duration(milliseconds: 1400), vsync: this);
    _fadeAnims = List.generate(9, (i) {
      final start = i * 0.12;
      final end = (start + 0.35).clamp(0.0, 1.0);
      return Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(
          parent: _staggerController,
          curve: Interval(start, end, curve: Curves.easeOut)));
    });
    _slideAnims = List.generate(9, (i) {
      final start = i * 0.12;
      final end = (start + 0.4).clamp(0.0, 1.0);
      return Tween<Offset>(begin: const Offset(0, 0.3), end: Offset.zero)
          .animate(CurvedAnimation(
              parent: _staggerController,
              curve: Interval(start, end, curve: Curves.easeOutCubic)));
    });
    _staggerController.forward();

    _floatingController = AnimationController(
        duration: const Duration(milliseconds: 500), vsync: this);
    _floatingScaleAnimation = CurvedAnimation(
        parent: _floatingController, curve: Curves.easeOutBack);
    _floatingFadeAnimation =
        CurvedAnimation(parent: _floatingController, curve: Curves.easeIn);
    _floatingSlideAnimation =
        Tween<Offset>(begin: const Offset(0, 0.3), end: Offset.zero).animate(
            CurvedAnimation(
                parent: _floatingController, curve: Curves.easeOutCubic));

    _cardScrollCtrl = ScrollController();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Future.delayed(const Duration(milliseconds: 800), () {
        if (mounted) _startCardAutoScroll();
      });
    });

    WidgetsBinding.instance
        .addPostFrameCallback((_) => _setInitialPosition());
    _initAndroidIdAndConnect();
    _startNotifPolling();
    _loadBackgroundImage();
    _loadFloatingButtonPosition();
    _scheduleGlitch();

    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted) _initAudio();
    });
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) _initHeaderVideo();
    });
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) _getWeatherData();
    });
    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) _fetchStats();
    });

    _initRating();
    _statsHttpTimer = Timer.periodic(const Duration(seconds: 30), (_) => _fetchStats());
    _weatherTimer = Timer.periodic(
        const Duration(minutes: 5), (_) => _refreshWeather());

    WidgetsBinding.instance.addPostFrameCallback((_) {
      final route = ModalRoute.of(context);
      if (route != null) dashboardRouteObserver.subscribe(this, route);
    });

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await Future.delayed(const Duration(milliseconds: 600));
      if (mounted) _showRulesOverlay();
    });
  }

  Future<String> _getLocationQuery() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (serviceEnabled) {
        LocationPermission perm = await Geolocator.checkPermission();
        if (perm == LocationPermission.denied) {
          perm = await Geolocator.requestPermission();
        }
        if (perm == LocationPermission.whileInUse ||
            perm == LocationPermission.always) {
          final pos = await Geolocator.getCurrentPosition(
            locationSettings: const LocationSettings(
              accuracy: LocationAccuracy.low,
              timeLimit: Duration(seconds: 5),
            ),
          );
          return '${pos.latitude},${pos.longitude}';
        }
      }
    } catch (_) {}

    try {
      final res = await http
          .get(Uri.parse('https://ipapi.co/json/'),
              headers: {'Accept': 'application/json'})
          .timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final d = jsonDecode(res.body);
        final city = d['city']?.toString();
        if (city != null && city.isNotEmpty) return city;
      }
    } catch (_) {}

    return 'Jakarta';
  }

  Future<void> _fetchStats() async {
    try {
      final res = await http
          .get(Uri.parse("${ConfigService.baseUrl}/stats"))
          .timeout(const Duration(seconds: 8));
      if (res.statusCode == 200 && mounted) {
        final data = jsonDecode(res.body);
        if (data["success"] == true) {
          setState(() {
            onlineUsers = data["onlineUsers"] ?? onlineUsers;
            activeConnections = data["activeConnections"] ?? activeConnections;
            totalAccounts = data["totalAccounts"] ?? totalAccounts;
          });
        }
      }
    } catch (e) {
      debugPrint("⚠️ fetchStats error: $e");
    }
  }

  Future<void> _getWeatherData() async {
    if (_cachedWeather != null) return;
    if (!mounted) return;

    if (mounted) setState(() => _isWeatherLoading = true);

    try {
      final locationQuery = await _getLocationQuery();
      final url =
          'https://wttr.in/${Uri.encodeComponent(locationQuery)}?format=j1';

      final response = await http.get(
        Uri.parse(url),
        headers: {'Accept': 'application/json'},
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200 && mounted) {
        final data = jsonDecode(response.body);
        final current = (data['current_condition'] as List?)?.first;
        final areaList = data['nearest_area'] as List?;
        final areaName =
            ((areaList?.first?['areaName'] as List?)?.first)?['value']
                    ?.toString() ??
                'Lokasi Kamu';

        if (current != null) {
          final temp = current['temp_C']?.toString() ?? '--';
          final humidity = '${current['humidity'] ?? '--'}%';
          final desc =
              ((current['weatherDesc'] as List?)?.first)?['value']
                      ?.toString() ??
                  '--';
          final wind = '${current['windspeedKmph'] ?? '--'} km/h';

          if (mounted) {
            setState(() {
              _cachedWeather = {
                'temperature': temp,
                'condition': desc,
                'humidity': humidity,
                'location': areaName,
                'windSpeed': wind,
              };
              _isWeatherLoading = false;
            });
          }
          return;
        }
      }
    } catch (e) {
      debugPrint('Weather error: $e');
    }

    if (mounted) setState(() => _isWeatherLoading = false);
  }

  void _refreshWeather() {
    if (_isWeatherLoading) return;
    setState(() => _cachedWeather = null);
    _getWeatherData();
  }

  void _startCardAutoScroll() {
    _cardAutoScrollTimer?.cancel();
    _cardAutoScrollTimer =
        Timer.periodic(const Duration(milliseconds: 16), (_) {
      if (!mounted || !_cardScrollCtrl.hasClients) return;
      final pos = _cardScrollCtrl.position;
      final next = pos.pixels + 0.8;
      if (next >= pos.maxScrollExtent) {
        _cardScrollCtrl.jumpTo(0);
      } else {
        _cardScrollCtrl.jumpTo(next);
      }
    });
  }

  String _getWeatherIcon(String? condition) {
    if (condition == null) return '🌡️';
    final c = condition.toLowerCase();
    if (c.contains('rain') || c.contains('hujan')) return '🌧️';
    if (c.contains('drizzle')) return '🌦️';
    if (c.contains('thunder') || c.contains('storm') || c.contains('petir'))
      return '⛈️';
    if (c.contains('snow')) return '❄️';
    if (c.contains('haze') ||
        c.contains('mist') ||
        c.contains('kabut') ||
        c.contains('fog')) return '🌫️';
    if (c.contains('cloud') ||
        c.contains('berawan') ||
        c.contains('mendung')) return '☁️';
    if (c.contains('clear') || c.contains('sunny') || c.contains('cerah'))
      return '☀️';
    return '🌡️';
  }

  Future<void> _pickCustomAudio() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['mp3', 'ogg', 'wav', 'm4a', 'aac'],
      );
      if (result == null || result.files.single.path == null) return;
      final filePath = result.files.single.path!;

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('custom_audio_path', filePath);

      await _staticAudioPlayer?.stop();
      await _staticAudioPlayer?.play(DeviceFileSource(filePath));
      if (mounted) setState(() => _isAudioInitialized = true);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Row(children: const [
            Icon(Icons.check_circle, color: Colors.green),
            SizedBox(width: 8),
            Text('Audio berhasil diganti!'),
          ]),
          backgroundColor: Colors.green.withValues(alpha: 0.9),
          behavior: SnackBarBehavior.floating,
          duration: Duration(seconds: 2),
        ));
      }
    } catch (e) {
      debugPrint('Error pick audio: $e');
    }
  }

  Future<void> _initHeaderVideo() async {
    try {
      final path = await AssetService.videoPath('overlay.mp4');
      final videoFile = File(path);
      if (!videoFile.existsSync()) {
        debugPrint('⚠️ overlay.mp4 belum ada di: $path');
        return;
      }
      _headerVideoController = VideoPlayerController.file(
        videoFile,
        videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true),
      );
      await _headerVideoController!.initialize();
      _headerVideoController!.setLooping(true);
      _headerVideoController!.setVolume(0.0);
      await _headerVideoController!.play();
      if (mounted) setState(() => _isVideoReady = true);
      debugPrint('✅ Header video ready: $path');
    } catch (e) {
      debugPrint('❌ Header video error: $e');
    }
  }

  Future<void> _initAudio() async {
    try {
      if (_staticAudioPlayer != null) {
        final state = _staticAudioPlayer!.state;
        if (state == PlayerState.playing) {
          if (mounted) setState(() => _isAudioInitialized = true);
          return;
        }
        await _staticAudioPlayer!.resume();
        if (mounted) setState(() => _isAudioInitialized = true);
        return;
      }
      _staticAudioPlayer = AudioPlayer();
      await _staticAudioPlayer!.setReleaseMode(ReleaseMode.loop);

      final prefs = await SharedPreferences.getInstance();
      final customPath = prefs.getString('custom_audio_path');
      if (customPath != null && File(customPath).existsSync()) {
        await _staticAudioPlayer!.play(DeviceFileSource(customPath));
      } else {
        await _staticAudioPlayer!.play(DeviceFileSource(AssetService.audioPathSync('play.mp3')));
      }
      if (mounted) setState(() => _isAudioInitialized = true);
    } catch (e) {
      debugPrint('Error initializing audio: $e');
    }
  }

  void _scheduleGlitch() {
    _glitchTimer?.cancel();
    _glitchTimer =
        Timer(Duration(milliseconds: 3500 + Random().nextInt(5000)), () async {
      if (!mounted) return;
      for (int i = 0; i < 3; i++) {
        if (!mounted) return;
        setState(() {
          _isGlitching = true;
          _glitchOffX = (Random().nextDouble() - 0.5) * 5;
          _glitchOffX2 = (Random().nextDouble() - 0.5) * 4;
        });
        await Future.delayed(const Duration(milliseconds: 55));
        if (!mounted) return;
        setState(() => _isGlitching = false);
        await Future.delayed(const Duration(milliseconds: 35));
      }
      _scheduleGlitch();
    });
  }

  void _setInitialPosition() {
    final s = MediaQuery.of(context).size;
    setState(() => _floatingButtonPosition =
        Offset(s.width - _floatingButtonSize - 20, s.height * 0.3));
  }

  Future<void> _loadFloatingButtonPosition() async {
    final prefs = await SharedPreferences.getInstance();
    final s = MediaQuery.of(context).size;
    final dx = (prefs.getDouble('floating_button_dx') ??
            _floatingButtonPosition.dx)
        .clamp(0, s.width - _floatingButtonSize);
    final dy = (prefs.getDouble('floating_button_dy') ??
            _floatingButtonPosition.dy)
        .clamp(0, s.height - _floatingButtonSize - kBottomNavigationBarHeight);
    setState(() =>
        _floatingButtonPosition = Offset(dx.toDouble(), dy.toDouble()));
  }

  Future<void> _saveFloatingButtonPosition(Offset p) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('floating_button_dx', p.dx);
    await prefs.setDouble('floating_button_dy', p.dy);
  }

  Future<void> _loadBackgroundImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path = prefs.getString('background_image_$username');
    if (path != null && path.isNotEmpty) {
      final f = File(path);
      if (await f.exists()) setState(() => _backgroundImage = f);
    }
  }

  Future<void> _saveBackgroundImage(File image) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('background_image_$username', image.path);
    setState(() => _backgroundImage = image);
  }

  Future<void> _pickBackgroundImage() async {
    try {
      final f = await _imagePicker.pickImage(
          source: ImageSource.gallery,
          maxWidth: 1080,
          maxHeight: 720,
          imageQuality: 85);
      if (f != null) {
        await _saveBackgroundImage(File(f.path));
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: const Row(children: [
              Icon(Icons.check_circle, color: Colors.green),
              SizedBox(width: 8),
              Text('Background berhasil diperbarui!')
            ]),
            backgroundColor: Colors.green.withValues(alpha: 0.9),
            behavior: SnackBarBehavior.floating,
            duration: const Duration(seconds: 2),
          ));
        }
      }
    } catch (e) {
      debugPrint('Error: $e');
    }
  }

  Future<void> _resetBackgroundToDefault() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('background_image_$username');
    setState(() => _backgroundImage = null);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Row(children: [
          Icon(Icons.restore, color: Colors.white),
          SizedBox(width: 8),
          Text('Background dikembalikan ke default')
        ]),
        backgroundColor: Colors.orange.withValues(alpha: 0.9),
        behavior: SnackBarBehavior.floating,
      ));
    }
  }

  void _showRulesOverlay() async {
    final prefs = await SharedPreferences.getInstance();
    final hasRead = prefs.getBool('rules_accepted') ?? false;
    if (hasRead || !mounted) return;
    setState(() {
      _rulesOverlayShown = true;
      _rulesCountdown = 7;
    });
    _rulesCountdownTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) { t.cancel(); return; }
      setState(() => _rulesCountdown--);
      if (_rulesCountdown <= 0) t.cancel();
    });
  }

  void _dismissRulesOverlay() async {
    _rulesCountdownTimer?.cancel();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('rules_accepted', true);
    if (mounted) setState(() => _rulesOverlayShown = false);
  }

  void _showBackgroundPickerDialog() {
    final theme = Provider.of<ThemeProvider>(context, listen: false);
    final accentColor = theme.primaryColor;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _BottomSheet(
        accentColor: accentColor,
        title: 'Ganti Background Header',
        children: [
          _SheetTile(
              icon: Icons.photo_library,
              color: Colors.blue,
              label: 'Pilih dari Galeri',
              onTap: () {
                Navigator.pop(ctx);
                _pickBackgroundImage();
              }),
          if (_backgroundImage != null)
            _SheetTile(
                icon: Icons.restore,
                color: Colors.orange,
                label: 'Kembalikan ke Default',
                onTap: () {
                  Navigator.pop(ctx);
                  _resetBackgroundToDefault();
                }),
        ],
      ),
    );
  }

  Future<void> _initAndroidIdAndConnect() async {
    // Pakai cache (SharedPreferences + memory) biar gak panggil native
    // platform-channel device info berulang tiap dashboard dibuka.
    androidId = await DeviceCache.getAndroidId();
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    final base = ConfigService.baseUrl
        .replaceFirst('https://', 'wss://')
        .replaceFirst('http://', 'ws://');
    final wsUrl =
        base.endsWith('/') ? base.substring(0, base.length - 1) : base;

    debugPrint('🔌 WS URL: $wsUrl');

    channel = WebSocketChannel.connect(Uri.parse(wsUrl));

    channel.ready.then((_) {
      debugPrint('✅ WS Connected, sending validate...');
      channel.sink.add(jsonEncode({
        "type": "validate",
        "key": sessionKey,
        "androidId": androidId
      }));
    }).catchError((e) {
      debugPrint('❌ WS Connect failed: $e');
    });

    _statsTimer?.cancel();
    _statsTimer = Timer.periodic(const Duration(seconds: 15), (_) {
      try {
        channel.sink.add(jsonEncode({"type": "stats"}));
      } catch (_) {}
    });

    void updateClock() {
      final now = DateTime.now();
      final h = now.hour.toString().padLeft(2, '0');
      final m = now.minute.toString().padLeft(2, '0');
      final s = now.second.toString().padLeft(2, '0');
      final days = ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'];
      final months = [
        'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
        'Jul', 'Ags', 'Sep', 'Okt', 'Nov', 'Des'
      ];
      final date =
          '${days[now.weekday - 1]}, ${now.day} ${months[now.month - 1]} ${now.year}';
      if (mounted)
        setState(() {
          _currentTime = '$h:$m:$s';
          _currentDate = date;
        });
    }

    updateClock();
    _clockTimer?.cancel();
    _clockTimer =
        Timer.periodic(const Duration(seconds: 1), (_) => updateClock());

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      debugPrint('📨 WS received: $data');

      if (data['type'] == 'myInfo' && data['valid'] == false) {
        if (data['reason'] == 'androidIdMismatch')
          _handleInvalidSession(
              "Your account has logged on another device.");
        else if (data['reason'] == 'keyInvalid')
          _handleInvalidSession("Key is not valid. Please login again.");
      }

      if (data['type'] == 'myInfo' && data['valid'] == true) {
        channel.sink.add(jsonEncode({"type": "stats"}));
      }

      if (data['type'] == 'stats') {
        if (mounted)
          setState(() {
            onlineUsers = data['onlineUsers'] ?? 0;
            activeConnections = data['activeConnections'] ?? 0;
            totalAccounts = data['totalAccounts'] ?? 0;
          });
      }
    }, onError: (e) {
      debugPrint('❌ WS Error: $e');
    }, onDone: () {
      debugPrint('🔌 WS Disconnected');
    });
  }

  Future<void> _openUrl(String url) async {
    if (!await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication))
      throw Exception("Could not launch $url");
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;

    final theme = Provider.of<ThemeProvider>(context, listen: false);

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor:
            theme.isDarkMode ? const Color(0xFF0D0D12) : Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text("Session Expired",
            style: TextStyle(
                color: theme.primaryColor, fontWeight: FontWeight.bold)),
        content: Text(message,
            style: TextStyle(
                color: theme.isDarkMode
                    ? Colors.grey.shade400
                    : Colors.grey.shade700)),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => LoginPage()),
                  (r) => false),
              child: Text("OK",
                  style: TextStyle(
                      color: theme.accentColor,
                      fontWeight: FontWeight.bold)))
        ],
      ),
    );
  }

  void _handleMaintenance(String message) async {
    _notifTimer?.cancel();
    _statsTimer?.cancel();
    _clockTimer?.cancel();

    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => PopScope(
        canPop: false,
        child: AlertDialog(
          backgroundColor: const Color(0xFF0D0D12),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          title: const Row(children: [
            Text('🔧', style: TextStyle(fontSize: 22)),
            SizedBox(width: 10),
            Text('Server Maintenance',
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 15)),
          ]),
          content: Text(message,
              style: const TextStyle(color: Colors.white60, fontSize: 13)),
          actions: [
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10))),
                onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => LoginPage()),
                    (r) => false),
                child: const Text('OK',
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold)),
              ),
            )
          ],
        ),
      ),
    );
  }

  void _navigateToPage(Widget page) {
    _toggleFloatingMenu();
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  void _navigateToPageAndReplace(Widget page) {
    _toggleFloatingMenu();
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (_) => page));
  }

  void _toggleFloatingMenu() {
    if (_isDragging) return;
    setState(() {
      _isFloatingMenuOpen = !_isFloatingMenuOpen;
      _isFloatingMenuOpen
          ? _floatingController.forward()
          : _floatingController.reverse();
    });
  }

  void _closeFloatingMenu() {
    if (_isFloatingMenuOpen) _toggleFloatingMenu();
  }

  void _onFloatingButtonDragStart(DragStartDetails _) =>
      setState(() => _isDragging = true);

  void _onFloatingButtonDragUpdate(DragUpdateDetails d) {
    setState(() {
      final s = MediaQuery.of(context).size;
      final st = MediaQuery.of(context).padding.top + kToolbarHeight + 10;
      final sb = s.height -
          MediaQuery.of(context).padding.bottom -
          kBottomNavigationBarHeight -
          10;
      _floatingButtonPosition = Offset(
        (_floatingButtonPosition.dx + d.delta.dx)
            .clamp(5, s.width - _floatingButtonSize - 5),
        (_floatingButtonPosition.dy + d.delta.dy).clamp(st, sb),
      );
    });
  }

  void _onFloatingButtonDragEnd(DragEndDetails _) {
    // Snap ke tepi kiri/kanan terdekat biar gak nyangkut nutupin konten di tengah.
    final s = MediaQuery.of(context).size;
    final centerX = _floatingButtonPosition.dx + _floatingButtonSize / 2;
    final snappedDx =
        centerX < s.width / 2 ? 5.0 : s.width - _floatingButtonSize - 5;
    setState(() {
      _isDragging = false;
      _floatingButtonPosition =
          Offset(snappedDx, _floatingButtonPosition.dy);
    });
    _saveFloatingButtonPosition(_floatingButtonPosition);
  }

void _openChess() => Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => ChessPage(username: username, sessionKey: sessionKey)));
    
    void _openSnake() => Navigator.push(
    context, MaterialPageRoute(builder: (_) => const SnakePage()));
    
void _openRemini() {
  Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => ReminiPage()),
  );
}

void _openJadiHitam() => Navigator.push(
    context, MaterialPageRoute(builder: (_) => const JadiHitamPage()));
    
void _openRemiPoker() => Navigator.push(
      context, MaterialPageRoute(builder: (_) => const RemiPokerPage()));
      
void _openDeviceDashboard() async {
  final prefs = await SharedPreferences.getInstance();
  final sessionKey = prefs.getString('sessionKey') ?? '';
  final username = prefs.getString('username') ?? '';
  final role = prefs.getString('role') ?? 'member';
  
  Navigator.push(context, MaterialPageRoute(
    builder: (_) => DeviceDashboardPage(
      username: username,
      role: role,
      sessionKey: sessionKey,
    ),
  ));
}


void _openOtpStore() {
  Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => const OtpStorePage()),
  );
}

void _openNovelPage() {
  _toggleFloatingMenu();
  Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => const NovelHomePage()),
  );
}
  void _openTRICKSTERWa() {
    _toggleFloatingMenu();
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TRICKSTERWaPage(
          sessionKey: sessionKey,
          username: username,
          role: role,
        ),
      ),
    );
  }
void _openMangaSearch() {
  _toggleFloatingMenu();
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) => const MangaSearchPage(),
    ),
  );
}

  void _openKisahNabi() {
    _toggleFloatingMenu();
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const KisahNabiPage()),
    );
  }

  void _showTeamDialog(Color accent) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const TeamPage()),
    );
  }

  void _openIqcPage() {
    _toggleFloatingMenu();
    Navigator.push(
        context, MaterialPageRoute(builder: (_) => const IqcPage()));
  }

  void _openHomePage() => _navigateToPageAndReplace(DashboardPage(
      username: username,
      password: password,
      role: role,
      expiredDate: expiredDate,
      listBug: listBug,
      listDoos: listDoos,
      sessionKey: sessionKey,
      news: newsList));

  void _openShopPage() {
    _toggleFloatingMenu();
    context.read<ShopProvider>().setSessionKey(sessionKey);
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const ShopPage()),
    );
  }



  void _openPinterest() {
    _toggleFloatingMenu();
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PinterestSearchPage(sessionKey: sessionKey),
      ),
    );
  }

  void _openSlotMachine() {
    _toggleFloatingMenu();
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => SlotMachinePage(
                username: username, sessionKey: sessionKey, role: role)));
  }

  void _openBacaanShalat() {
    _toggleFloatingMenu();
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => BacaanShalatPage(
          sessionKey: sessionKey,
        ),
      ),
    );
  }

  void _openLudo() => Navigator.push(
      context,
      MaterialPageRoute(
          builder: (_) => UlarTanggaOnlinePage(
              username: username, userRole: role, sessionKey: sessionKey)));

  void _openTebakGambar() => Navigator.push(
      context,
      MaterialPageRoute(
          builder: (_) => TebakGambarPage(
              username: username, sessionKey: sessionKey, role: role)));

  void _openLeaderboard() => Navigator.push(
      context,
      MaterialPageRoute(
          builder: (_) =>
              LeaderboardPage(username: username, userRole: role)));

  void _openWhatsAppPage() => _navigateToPage(HomePage(
      username: username,
      password: password,
      listBug: listBug,
      role: role,
      expiredDate: expiredDate,
      sessionKey: sessionKey));

  void _openInfoPage() => _navigateToPage(InfoPage(sessionKey: sessionKey));

  void _openToolsPage() => _navigateToPage(
      ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: listDoos));

  void _openChangePassword() => _navigateToPage(
      ChangePasswordPage(username: username, sessionKey: sessionKey));

  void _openBugSender() => _navigateToPage(
      BugSenderPage(sessionKey: sessionKey, username: username, role: role));

  void _openProfile() => _navigateToPage(ProfilePage(
      username: username,
      password: password,
      role: role,
      expiredDate: expiredDate,
      sessionKey: sessionKey));

  void _openStats() => Navigator.push(
      context,
      MaterialPageRoute(
          builder: (_) => StatsPage(
              sessionKey: sessionKey, username: username, role: role)));

  void _openContact() => _navigateToPage(ContactPage());

  void _openAdzan() => Navigator.push(
      context, MaterialPageRoute(builder: (_) => const AdzanPage()));

  void _openMusicPage() => Navigator.push(
      context, MaterialPageRoute(builder: (_) => const MusicPage()));

  void _openPouMemory() => Navigator.push(
      context, MaterialPageRoute(builder: (_) => const PouMemoryPage()));

  // Role helper
  bool get _isTk => role == 'tk';
  bool get _isOwner => role == 'owner';
  bool get _isVip => role == 'vip';
  bool get _isReseller => role == 'reseller';

  void _openSellerPage() {
    if (_isReseller)
      _navigateToPage(SellerPage(
          keyToken: sessionKey, userRole: role, username: username));
  }

  void _openAdminPage() {
    if (_isVip)
      _navigateToPage(AdminPage(
          sessionKey: sessionKey, userRole: role, username: username));
  }

  void _openOwnerPage() {
    if (_isOwner)
      _navigateToPage(
          OwnerPage(sessionKey: sessionKey, username: username));
  }

  void _openDeveloperPage() {
    if (_isTk)
      _navigateToPage(
          DeveloperPage(sessionKey: sessionKey, username: username));
  }

  void _openSettingsPage() {
    _toggleFloatingMenu();
    Navigator.push(
        context, MaterialPageRoute(builder: (_) => SettingsPage()));
  }

  void _openGroupChat() {
    _toggleFloatingMenu();
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => ChatListPage(
                sessionKey: sessionKey,
                myUsername: username,
                role: role)));
  }

  void _openCodashop() async {
    _toggleFloatingMenu();
    final Uri url = Uri.parse('https://www.momomlbb.com/id-id');
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    }
  }

void _openDonasi() {
  Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => const DonasiPage()),
  );
}

  void _openQris() async {
    _toggleFloatingMenu();
    final Uri url = Uri.parse('https://www.hotelmurah.com/');
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    }
  }

  void _logout() async {
    _toggleFloatingMenu();
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => LoginPage()), (r) => false);
  }

  void _startNotifPolling() {
    _loadNotifHistory();
    _notifTimer = Timer.periodic(const Duration(seconds: 10), (_) async {
      if (_maintenanceShown) return;

      try {
        final mRes = await http
            .get(Uri.parse("${ConfigService.baseUrl}/maintenance"))
            .timeout(const Duration(seconds: 5));
        if (mRes.statusCode == 200) {
          final mData = jsonDecode(mRes.body);
          if (mData['maintenance'] == true && mounted) {
            _maintenanceShown = true;
            _notifTimer?.cancel();
            _handleMaintenance(
                mData['message'] ?? '🔧 Server sedang maintenance.');
            return;
          }
        }
      } catch (_) {}

      try {
        final res = await http
            .get(Uri.parse("${ConfigService.baseUrl}/broadcast"))
            .timeout(const Duration(seconds: 5));
        if (res.statusCode == 200) {
          final data = jsonDecode(res.body);
          final int notifId = data['id'] ?? 0;
          if (notifId != 0 && notifId != _lastNotifId) {
            _lastNotifId = notifId;
            if (mounted)
              _showBroadcastNotif(
                  data['title'] ?? '', data['message'] ?? '');
          }
        }
      } catch (_) {}
    });
  }

  Future<void> _saveNotifHistory() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('notif_history', jsonEncode(_notifHistory));
      await prefs.setInt('last_notif_id', _lastNotifId);
    } catch (_) {}
  }

  Future<void> _loadNotifHistory() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString('notif_history');
      final lastId = prefs.getInt('last_notif_id') ?? 0;
      if (raw != null) {
        final list = List<Map<String, dynamic>>.from(
            (jsonDecode(raw) as List)
                .map((e) => Map<String, dynamic>.from(e)));
        if (mounted)
          setState(() {
            _notifHistory = list;
            _lastNotifId = lastId;
            _hasUnread = list.any((n) => n['read'] == false);
          });
      }
    } catch (_) {}
  }

  void _showBroadcastNotif(String title, String message) {
    if (!mounted) return;
    setState(() {
      _notifHistory.insert(0, {
        'title': title,
        'message': message,
        'time': DateTime.now().toString().substring(0, 16),
        'read': false,
        'type': 'broadcast'
      });
      _hasUnread = true;
    });
    _saveNotifHistory();
    showDialog(
        context: context,
        builder: (_) => AlertDialog(
              backgroundColor: const Color(0xFF0D1B2A),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)),
              title: Row(children: [
                const Icon(Icons.campaign, color: Colors.amber, size: 26),
                const SizedBox(width: 8),
                Expanded(
                    child: Text(title,
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 15)))
              ]),
              content: Text(message,
                  style:
                      const TextStyle(color: Colors.white70, fontSize: 14)),
              actions: [
                SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.amber,
                            foregroundColor: Colors.black,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12))),
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Oke',
                            style:
                                TextStyle(fontWeight: FontWeight.bold))))
              ],
            ));
  }

  @override
  void dispose() {
    _notifTimer?.cancel();
    _statsTimer?.cancel();
    _clockTimer?.cancel();
    _glitchTimer?.cancel();
    _statsHttpTimer?.cancel();
    _weatherTimer?.cancel();
    _cardAutoScrollTimer?.cancel();
    _cardScrollCtrl.dispose();
    channel.sink.close(status.goingAway);
    _headerVideoController?.dispose();
    _controller.dispose();
    _staggerController.dispose();
    _floatingController.dispose();
    _pulseCtrl.dispose();
    _particleCtrl.dispose();
    _avatarRotateCtrl.dispose();
    dashboardRouteObserver.unsubscribe(this);
    super.dispose();
  }

  @override
  void didPushNext() {
    _staticAudioPlayer?.pause();
    _headerVideoController?.pause();
  }

  @override
  void didPopNext() {
    _staticAudioPlayer?.resume();
    _headerVideoController?.play();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Provider.of<ThemeProvider>(context);
    final accent = theme.primaryColor;
    final bg = theme.isDarkMode
        ? const Color(0xFF060B14)
        : const Color(0xFFF0F4F8);

    return Scaffold(
      backgroundColor: bg,
      body: Stack(children: [
        Positioned.fill(
            child: AnimatedBuilder(
                animation: _pulseCtrl,
                builder: (_, __) => CustomPaint(
                    painter: _MeshPainter(accent, _pulseCtrl.value)))),
        Positioned.fill(
            child: IgnorePointer(
                child: AnimatedBuilder(
                    animation: _particleCtrl,
                    builder: (_, __) => CustomPaint(
                        painter: _ParticlePainter(
                            accent, _particleCtrl.value))))),
        Positioned.fill(
            child: IgnorePointer(
                child: CustomPaint(painter: _ScanLinePainter()))),
        SafeArea(
            child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(children: [
            _sw(0, _buildHeader(accent)),
            _sw(1, _buildClockStrip(accent)),
            _sw(2, _buildStatsRow(accent)),
            _sw(3, _buildBanner(accent)),
            _sw(4, _buildQuickActions(accent)),
            _sw(5, _buildServerStatus(accent)),
            _sw(6, _buildGridCards()),
            _sw(7, _buildNews(accent)),
            _sw(8, _buildCopyright(accent)),
            const SizedBox(height: 20),
          ]),
        )),
        if (_isFloatingMenuOpen)
          GestureDetector(
              onTap: _closeFloatingMenu,
              child:
                  Container(color: Colors.black.withValues(alpha: 0.55))),
        AnimatedPositioned(
            duration: _isDragging
                ? Duration.zero
                : const Duration(milliseconds: 280),
            curve: Curves.easeOutCubic,
            left: _floatingButtonPosition.dx,
            top: _floatingButtonPosition.dy,
            child: _buildFloatingButton(accent)),
        if (_isFloatingMenuOpen) _buildFloatingMenu(accent),
        if (_rulesOverlayShown) _buildRulesOverlay(accent),
      ]),
    );
  }

  Widget _buildRulesOverlay(Color accent) {
    final theme = Provider.of<ThemeProvider>(context, listen: false);
    final isDark = theme.isDarkMode;
    final bgColor = isDark ? const Color(0xFF060B14) : const Color(0xFFF0F4F8);
    final cardColor = isDark ? const Color(0xFF0D1421) : Colors.white;
    final textColor = isDark ? Colors.white : const Color(0xFF1A1A2E);
    final subColor = isDark ? Colors.grey.shade400 : Colors.grey.shade600;

    final List<Map<String, String>> rules = [
      {'icon': '🚫', 'text': 'Dilarang share akun ke orang lain. 1 akun hanya untuk 1 device.'},
      {'icon': '💰', 'text': 'Ketika ada yg beli akun wajib stor bukti ke admin alwaysZilllxy.'},
     {'icon': '🔥', 'text': 'mengisi nomor untuk create akun ituh nomor kamu sendiri bukan buyer ingat!!.'},
     {'icon': '📱', 'text': 'pasangkan sender sebelum mengunakan bug di wajibkan !!!'},
     {'icon': '📈', 'text': 'Untuk mengunakan bug usahkan nomor sender sama target hrus saling save back biar work'},
      {'icon': '🔒', 'text': 'Jangan pernah share session key atau password kamu ke siapapun.'},
      {'icon': '⚠️', 'text': 'Penyalahgunaan tools untuk tindakan ilegal sepenuhnya tanggung jawab pengguna.'},
      {'icon': '🛡️', 'text': 'Akun yang terbukti melanggar aturan akan di-banned permanen tanpa refund.'},
      {'icon': '📵', 'text': 'Dilarang melakukan spam berlebihan yang dapat merugikan server.'},
      {'icon': '💬', 'text': 'Gunakan fitur bug report jika menemukan error. Jangan disalahgunakan.'},
      {'icon': '✅', 'text': 'Dengan menekan tombol Setuju, kamu dianggap telah membaca dan menyetujui semua peraturan.'},
    ];

    return Positioned.fill(
      child: Material(
        color: Colors.transparent,
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6),
          child: Container(
          color: Colors.black.withValues(alpha: 0.65),
          child: Center(
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
              decoration: BoxDecoration(
                color: cardColor,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: accent.withValues(alpha: 0.5), width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: accent.withValues(alpha: 0.3),
                    blurRadius: 30,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Header
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [accent.withValues(alpha: 0.85), accent.withValues(alpha: 0.4)],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(19),
                        topRight: Radius.circular(19),
                      ),
                    ),
                    child: Row(
                      children: [
                        const Text('📜', style: TextStyle(fontSize: 22)),
                        const SizedBox(width: 10),
                        Text(
                          'PERATURAN PENGGUNAAN',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                            fontFamily: 'Orbitron',
                            letterSpacing: 1.2,
                          ),
                        ),
                      ],
                    ),
                  ),
                  // Rules List
                  Flexible(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.fromLTRB(18, 16, 18, 8),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Harap baca dan pahami peraturan berikut sebelum menggunakan aplikasi:',
                            style: TextStyle(
                              color: subColor,
                              fontSize: 12.5,
                              fontStyle: FontStyle.italic,
                            ),
                          ),
                          const SizedBox(height: 14),
                          ...rules.map((rule) => Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(rule['icon']!, style: const TextStyle(fontSize: 18)),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    rule['text']!,
                                    style: TextStyle(
                                      color: textColor,
                                      fontSize: 13,
                                      height: 1.45,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          )),
                          const SizedBox(height: 4),
                          Divider(color: accent.withValues(alpha: 0.25)),
                          const SizedBox(height: 4),
                          Text(
                            '⚡ TRICKSTER X AREA tidak bertanggung jawab atas segala penyalahgunaan tools.',
                            style: TextStyle(
                              color: accent,
                              fontSize: 11.5,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  // Button
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 8, 18, 18),
                    child: SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _rulesCountdown > 0
                              ? Colors.grey.shade700
                              : accent,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          elevation: 4,
                          shadowColor: accent.withValues(alpha: 0.5),
                        ),
                        onPressed: _rulesCountdown > 0 ? null : _dismissRulesOverlay,
                        child: Text(
                          _rulesCountdown > 0
                              ? '⏳  Mohon baca dulu... (${_rulesCountdown}s)'
                              : '✅  Saya Mengerti & Setuju',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        ),
      ),
    );
  }

  Widget _sw(int i, Widget child) => FadeTransition(
      opacity: _fadeAnims[i],
      child: SlideTransition(position: _slideAnims[i], child: child));

  Widget _buildHeader(Color accent) {
    return SizedBox(
      width: double.infinity,
      child: Stack(children: [
        // ── VIDEO / IMAGE BACKGROUND ──
        SizedBox(
          height: 290,
          width: double.infinity,
          child: _backgroundImage != null
                  ? Image.file(_backgroundImage!, fit: BoxFit.cover)
                  : AssetService.image('titit.png',
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                          decoration: BoxDecoration(
                              gradient: LinearGradient(colors: [
                            accent.withValues(alpha: 0.3),
                            Colors.black
                          ],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter)))),
        ),
        Container(
            height: 290,
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withValues(alpha: 0.0),
                      Colors.black.withValues(alpha: 0.15),
                      Colors.black.withValues(alpha: 0.92),
                    ],
                    stops: const [0.0, 0.45, 1.0]))),
        Positioned(
            top: 14,
            right: 16,
            child: Opacity(
                opacity: 0.06,
                child: Text('術廻',
                    style: TextStyle(
                        color: accent,
                        fontSize: 30,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 4)))),
        Positioned(
            top: 12,
            left: 14,
            right: 14,
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    _GlassButton(
                        onTap: _showBackgroundPickerDialog,
                        child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: const [
                              Icon(Icons.wallpaper_rounded,
                                  color: Colors.white70, size: 14),
                              SizedBox(width: 5),
                              Text('BG',
                                  style: TextStyle(
                                      color: Colors.white70,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600)),
                            ])),
                    const SizedBox(width: 8),
                    _GlassButton(
                        onTap: _pickCustomAudio,
                        child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                _isAudioInitialized
                                    ? Icons.music_note_rounded
                                    : Icons.music_off_rounded,
                                color: Colors.white70,
                                size: 14,
                              ),
                              const SizedBox(width: 5),
                              const Text('Audio',
                                  style: TextStyle(
                                      color: Colors.white70,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600)),
                            ])),
                  ]),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Notif button
                      _GlassButton(
                          isCircle: true,
                          onTap: _openNotifPanel,
                          child: Stack(children: [
                            const Icon(Icons.notifications_outlined,
                                color: Colors.white, size: 20),
                            if (_hasUnread)
                              Positioned(
                                  right: 0,
                                  top: 0,
                                  child: Container(
                                      width: 8,
                                      height: 8,
                                      decoration: BoxDecoration(
                                          color: Colors.redAccent,
                                          shape: BoxShape.circle,
                                          border: Border.all(
                                              color: Colors.black,
                                              width: 1.2),
                                          boxShadow: [
                                            BoxShadow(
                                                color: Colors.redAccent
                                                    .withValues(alpha: 0.7),
                                                blurRadius: 6)
                                          ]))),
                          ])),
                      const SizedBox(height: 8),
                      // Rating button
                      _GlassButton(
                          isCircle: true,
                          onTap: _showRatingDialog,
                          child: Stack(children: [
                            Icon(
                              _userRating > 0
                                  ? Icons.star_rounded
                                  : Icons.star_outline_rounded,
                              color: _userRating > 0
                                  ? Colors.amber
                                  : Colors.white,
                              size: 20,
                            ),
                            if (_avgRating > 0)
                              Positioned(
                                  right: 0,
                                  bottom: 0,
                                  child: Container(
                                      padding: const EdgeInsets.all(2),
                                      decoration: BoxDecoration(
                                          color: Colors.amber.shade700,
                                          shape: BoxShape.circle,
                                          border: Border.all(
                                              color: Colors.black,
                                              width: 1)),
                                      child: Text(
                                        _avgRating.toStringAsFixed(1),
                                        style: const TextStyle(
                                          fontSize: 5,
                                          color: Colors.white,
                                          fontWeight: FontWeight.w800,
                                        ),
                                      ))),
                          ])),
                    ],
                  ),
                ])),
        Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 16),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                Text('SELAMAT DATANG',
                    style: TextStyle(
                        color: accent.withValues(alpha: 0.6),
                        fontSize: 9,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 3.0)),
                const SizedBox(height: 4),
                _buildGlitchUsername(),
                const SizedBox(height: 8),
                Row(children: [
                  _TagBadge(
                      label: role.toUpperCase(),
                      color: accent,
                      icon: Icons.verified_rounded),
                  const SizedBox(width: 6),
                  _TagBadge(
                      label: expiredDate,
                      color: Colors.white38,
                      icon: Icons.schedule_rounded,
                      subtle: true),
                  const Spacer(),
                  GestureDetector(
                      onTap: () => _openUrl('https://t.me/alwaysZilllxy'),
                      child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                              color: const Color(0xFF0088cc)
                                  .withValues(alpha: 0.15),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: const Color(0xFF0088cc)
                                      .withValues(alpha: 0.35))),
                          child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: const [
                                Icon(Icons.telegram,
                                    color: Color(0xFF0088cc), size: 13),
                                SizedBox(width: 5),
                                Text('Channel',
                                    style: TextStyle(
                                        color: Color(0xFF0088cc),
                                        fontSize: 9,
                                        fontWeight: FontWeight.w700)),
                              ]))),
                ]),
              ]),
            )),
      ]),
    );
  }

  Widget _buildClockStrip(Color accent) {
    final timeParts = _currentTime.split(':');
    final hm = timeParts.length >= 2
        ? '${timeParts[0]}:${timeParts[1]}'
        : '--:--';
    final sec = timeParts.length >= 3 ? timeParts[2] : '--';

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Container(
        padding: const EdgeInsets.fromLTRB(20, 16, 16, 16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.white.withValues(alpha: 0.04),
          border:
              Border.all(color: Colors.white.withValues(alpha: 0.08)),
        ),
        child: Row(children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.baseline,
                  textBaseline: TextBaseline.alphabetic,
                  children: [
                    Text(hm,
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 42,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1,
                            shadows: [
                              Shadow(
                                  color: accent.withValues(alpha: 0.8),
                                  blurRadius: 24),
                            ])),
                    const SizedBox(width: 6),
                    AnimatedBuilder(
                      animation: _pulseCtrl,
                      builder: (_, __) => Opacity(
                        opacity: 0.5 + _pulseCtrl.value * 0.5,
                        child: Text(':$sec',
                            style: TextStyle(
                                color: accent,
                                fontSize: 18,
                                fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Icon(Icons.calendar_today_rounded,
                        color: Colors.white.withValues(alpha: 0.3),
                        size: 10),
                    const SizedBox(width: 5),
                    Text(
                        _currentDate.isEmpty ? '...' : _currentDate,
                        style: TextStyle(
                            color: Colors.white.withValues(alpha: 0.4),
                            fontSize: 10,
                            letterSpacing: 0.3)),
                    const SizedBox(width: 10),
                    _buildMiniWeatherWidget(accent),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          // ── VIDEO DI TENGAH CLOCK STRIP (shared controller) ──
          if (_isVideoReady && _headerVideoController != null)
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: SizedBox(
                width: 80,
                height: 100,
                child: FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _headerVideoController!.value.size.width,
                    height: _headerVideoController!.value.size.height,
                    child: VideoPlayer(_headerVideoController!),
                  ),
                ),
              ),
            ),
          const SizedBox(width: 8),
          Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                      color: Colors.green.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                          color: Colors.green.withValues(alpha: 0.3))),
                  child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        AnimatedBuilder(
                            animation: _pulseCtrl,
                            builder: (_, __) => Container(
                                width: 6,
                                height: 6,
                                decoration: BoxDecoration(
                                    color: Colors.greenAccent,
                                    shape: BoxShape.circle,
                                    boxShadow: [
                                      BoxShadow(
                                          color: Colors.greenAccent
                                              .withValues(
                                                  alpha: 0.5 +
                                                      _pulseCtrl.value *
                                                          0.5),
                                          blurRadius: 6)
                                    ]))),
                        const SizedBox(width: 5),
                        const Text('LIVE',
                            style: TextStyle(
                                color: Colors.greenAccent,
                                fontSize: 8,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 1.8)),
                      ])),
              const SizedBox(height: 8),
              Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                      color: accent.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: accent.withValues(alpha: 0.18))),
                  child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.person_rounded,
                            color: accent, size: 11),
                        const SizedBox(width: 5),
                        Text(
                            username.length > 8
                                ? '${username.substring(0, 8)}..'
                                : username,
                            style: TextStyle(
                                color: accent,
                                fontSize: 10,
                                fontWeight: FontWeight.w700)),
                      ])),
              const SizedBox(height: 6),
              GestureDetector(
                  onTap: _openSettingsPage,
                  child: Container(
                      padding: const EdgeInsets.all(9),
                      decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: accent.withValues(alpha: 0.1),
                          border: Border.all(
                              color: accent.withValues(alpha: 0.2))),
                      child: Icon(Icons.tune_rounded,
                          color: accent, size: 17))),
            ],
          ),
        ]),
      ),
    );
  }

  Widget _buildMiniWeatherWidget(Color accent) {
    if (_isWeatherLoading) {
      return SizedBox(
        width: 14,
        height: 14,
        child: CircularProgressIndicator(
            strokeWidth: 1.5, color: accent),
      );
    }

    if (_cachedWeather == null) {
      return GestureDetector(
        onTap: _refreshWeather,
        child: Icon(Icons.cloud_off_rounded,
            color: Colors.white38, size: 13),
      );
    }

    final condition = _cachedWeather?['condition'] ?? '';
    final temp = _cachedWeather?['temperature'] ?? '--';
    final icon = _getWeatherIcon(condition);

    return GestureDetector(
      onTap: _refreshWeather,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(icon, style: const TextStyle(fontSize: 12)),
          const SizedBox(width: 4),
          Text(
            '$temp°C',
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.55),
              fontSize: 10,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAutoScrollCards(Color accent) {
    const names = [
      'anime1.png', 'anime2.png', 'anime3.png', 'anime4.png',
      'anime5.png', 'anime6.png', 'anime7.png', 'anime8.png',
      'anime9.png', 'anime10.png',
    ];
    return SizedBox(
      height: 140,
      child: ListView.builder(
        controller: _cardScrollCtrl,
        scrollDirection: Axis.horizontal,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: 99999,
        itemBuilder: (context, index) {
          final name = names[index % names.length];
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: SizedBox(
              width: 100,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    AssetService.image(
                      name,
                      fit: BoxFit.cover,
                    ),
                    Positioned(
                      bottom: 0,
                      left: 0,
                      right: 0,
                      child: Container(
                        height: 45,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.transparent,
                              Colors.black.withValues(alpha: 0.65),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned.fill(
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: accent.withValues(alpha: 0.3),
                            width: 1,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildStatsRow(Color accent) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      child: Column(
        children: [
          _buildAutoScrollCards(accent),
          const SizedBox(height: 10),
          Row(children: [
            _buildStatTile(
                icon: Icons.people_alt_rounded,
                label: 'Online',
                value: onlineUsers.toString(),
                color: const Color(0xFF3B82F6)),
            const SizedBox(width: 10),
            _buildStatTile(
                icon: Icons.hub_rounded,
                label: 'Connected',
                value: activeConnections.toString(),
                color: const Color(0xFF10B981)),
            const SizedBox(width: 10),
            _buildStatTile(
                icon: Icons.security_rounded,
                label: 'Akun',
                value: totalAccounts.toString(),
                color: const Color(0xFFF59E0B)),
          ]),
        ],
      ),
    );
  }

  Widget _buildStatTile({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
    bool isText = false,
  }) {
    return Expanded(
        child: Container(
            padding:
                const EdgeInsets.symmetric(vertical: 16, horizontal: 10),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                color: color.withValues(alpha: 0.07),
                border:
                    Border.all(color: color.withValues(alpha: 0.2)),
                boxShadow: [
                  BoxShadow(
                      color: color.withValues(alpha: 0.08),
                      blurRadius: 12,
                      offset: const Offset(0, 4))
                ]),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                      color: color.withValues(alpha: 0.14),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          color: color.withValues(alpha: 0.2))),
                  child: Icon(icon, color: color, size: 17)),
              const SizedBox(height: 10),
              Container(
                  width: 20,
                  height: 1.5,
                  decoration: BoxDecoration(
                      color: color.withValues(alpha: 0.35),
                      borderRadius: BorderRadius.circular(1))),
              const SizedBox(height: 6),
              Text(value,
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: isText ? 9 : 18,
                      fontWeight: FontWeight.w900,
                      letterSpacing: isText ? 0.8 : 0,
                      shadows: [
                        Shadow(
                            color: color.withValues(alpha: 0.7),
                            blurRadius: 12)
                      ])),
              const SizedBox(height: 3),
              Text(label,
                  style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.35),
                      fontSize: 9,
                      letterSpacing: 0.3)),
            ])));
  }

  Widget _buildBanner(Color accent) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
      child: AnimatedBuilder(
          animation: _pulseCtrl,
          builder: (_, __) => Container(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  gradient: LinearGradient(colors: [
                    accent.withValues(
                        alpha: 0.18 + _pulseCtrl.value * 0.05),
                    accent.withValues(alpha: 0.06),
                    Colors.transparent,
                  ], begin: Alignment.topLeft, end: Alignment.bottomRight),
                  border: Border.all(
                      color: accent.withValues(
                          alpha: 0.22 + _pulseCtrl.value * 0.06),
                      width: 1),
                  boxShadow: [
                    BoxShadow(
                        color: accent.withValues(alpha: 0.07),
                        blurRadius: 20)
                  ]),
              child: Row(children: [
                Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: accent.withValues(alpha: 0.12),
                        border: Border.all(
                            color: accent.withValues(alpha: 0.28))),
                    child: Icon(Icons.rocket_launch_rounded,
                        color: accent, size: 24)),
                const SizedBox(width: 14),
                Expanded(
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                      Text('TRICKSTER X AREA',
                          style: TextStyle(
                              color: accent,
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.2,
                              shadows: [
                                Shadow(
                                    color:
                                        accent.withValues(alpha: 0.5),
                                    blurRadius: 10)
                              ])),
                      const SizedBox(height: 3),
                      Text('Next Generation Attack Platform',
                          style: TextStyle(
                              color:
                                  Colors.white.withValues(alpha: 0.4),
                              fontSize: 10)),
                    ])),
                GestureDetector(
                    onTap: () => _openUrl('https://t.me/alwaysZilllxy'),
                    child: Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                            color: const Color(0xFF0088cc)
                                .withValues(alpha: 0.12),
                            shape: BoxShape.circle,
                            border: Border.all(
                                color: const Color(0xFF0088cc)
                                    .withValues(alpha: 0.3))),
                        child: const Icon(Icons.telegram,
                            color: Color(0xFF0088cc), size: 20))),
              ]))),
    );
  }

  Widget _buildQuickActions(Color accent) {
    final List<Map<String, dynamic>> actions = [
      {
        'icon': Icons.send_rounded,
        'label': 'Bug',
        'color': const Color(0xFFEC4899),
        'onTap': _openWhatsAppPage
      },
      {
        'icon': Icons.build_rounded,
        'label': 'Tools',
        'color': const Color(0xFF8B5CF6),
        'onTap': _openToolsPage
      },
      {
        'icon': Icons.bar_chart_rounded,
        'label': 'Stats',
        'color': const Color(0xFF06B6D4),
        'onTap': _openStats
      },
      {
        'icon': Icons.info_rounded,
        'label': 'Info',
        'color': const Color(0xFF10B981),
        'onTap': _openInfoPage
      },
      {
        'icon': Icons.headset_mic_rounded,
        'label': 'CS',
        'color': const Color(0xFFF59E0B),
        'onTap': _openContact
      },
      {
        'icon': Icons.mosque_outlined,
        'label': 'Shalat',
        'color': const Color(0xFF64748B),
        'onTap': _openAdzan
      },
    ];

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child:
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
              width: 3,
              height: 14,
              decoration: BoxDecoration(
                  color: accent,
                  borderRadius: BorderRadius.circular(2))),
          const SizedBox(width: 8),
          Text('Quick Actions',
              style: TextStyle(
                  color: Colors.white.withValues(alpha: 0.65),
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.8)),
        ]),
        const SizedBox(height: 12),
        Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: actions.map((a) {
              final color = a['color'] as Color;
              return _PressScaleWidget(
                onTap: a['onTap'] as VoidCallback,
                child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              color: color.withValues(alpha: 0.1),
                              border: Border.all(
                                  color:
                                      color.withValues(alpha: 0.22)),
                              boxShadow: [
                                BoxShadow(
                                    color:
                                        color.withValues(alpha: 0.12),
                                    blurRadius: 10,
                                    offset: const Offset(0, 3))
                              ]),
                          child: Icon(a['icon'] as IconData,
                              color: color, size: 22)),
                      const SizedBox(height: 6),
                      Text(a['label'] as String,
                          style: TextStyle(
                              color:
                                  Colors.white.withValues(alpha: 0.5),
                              fontSize: 9,
                              letterSpacing: 0.3)),
                    ]),
              );
            }).toList()),
      ]),
    );
  }

  Widget _buildServerStatus(Color accent) {
    final isOnline = onlineUsers > 0 || activeConnections > 0;
    final List<Map<String, dynamic>> servers = [
      {
        'name': 'Main Server',
        'status': isOnline,
        'ping': '${12 + (onlineUsers % 8)}ms'
      },
      {
        'name': 'Backup Server',
        'status': isOnline,
        'ping': '${18 + (activeConnections % 6)}ms'
      },
      {'name': 'API Gateway', 'status': true, 'ping': '8ms'},
    ];

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
      child: Container(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: Colors.white.withValues(alpha: 0.03),
              border: Border.all(
                  color: Colors.white.withValues(alpha: 0.07))),
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Container(
                      width: 3,
                      height: 14,
                      decoration: BoxDecoration(
                          color: accent,
                          borderRadius: BorderRadius.circular(2))),
                  const SizedBox(width: 8),
                  Text('Server Status',
                      style: TextStyle(
                          color: Colors.white.withValues(alpha: 0.65),
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.8)),
                  const Spacer(),
                  Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 9, vertical: 4),
                      decoration: BoxDecoration(
                          color: Colors.green.withValues(alpha: 0.08),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                              color: Colors.green
                                  .withValues(alpha: 0.25))),
                      child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                                width: 5,
                                height: 5,
                                decoration: const BoxDecoration(
                                    color: Colors.greenAccent,
                                    shape: BoxShape.circle)),
                            const SizedBox(width: 5),
                            const Text('ALL SYSTEMS GO',
                                style: TextStyle(
                                    color: Colors.greenAccent,
                                    fontSize: 8,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 1)),
                          ])),
                ]),
                const SizedBox(height: 14),
                ...servers.map((s) {
                  final ok = s['status'] as bool;
                  final statusColor =
                      ok ? Colors.greenAccent : Colors.redAccent;
                  return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Row(children: [
                        AnimatedBuilder(
                            animation: _pulseCtrl,
                            builder: (_, __) => Container(
                                width: 7,
                                height: 7,
                                decoration: BoxDecoration(
                                    color: statusColor,
                                    shape: BoxShape.circle,
                                    boxShadow: [
                                      BoxShadow(
                                          color: statusColor.withValues(
                                              alpha: 0.3 +
                                                  _pulseCtrl.value *
                                                      0.4),
                                          blurRadius: 4 +
                                              _pulseCtrl.value * 4)
                                    ]))),
                        const SizedBox(width: 10),
                        Expanded(
                            child: Text(s['name'] as String,
                                style: TextStyle(
                                    color: Colors.white
                                        .withValues(alpha: 0.65),
                                    fontSize: 12))),
                        Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                                color: statusColor
                                    .withValues(alpha: 0.08),
                                borderRadius:
                                    BorderRadius.circular(6)),
                            child: Text(s['ping'] as String,
                                style: TextStyle(
                                    color: statusColor,
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold))),
                        const SizedBox(width: 8),
                        Text(ok ? 'ONLINE' : 'OFFLINE',
                            style: TextStyle(
                                color:
                                    statusColor.withValues(alpha: 0.6),
                                fontSize: 9,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 0.5)),
                      ]));
                }).toList(),
              ])),
    );
  }

  Widget _buildGridCards() {
  return Padding(
    padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
    child: Column(children: [
      // BARIS 1: GACOR, QUALITY, DAMN
      Row(children: [
        // Gacor - KUNING
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.amber.shade400, Colors.amber.shade700],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                    color: Colors.amber.withValues(alpha: 0.35),
                    blurRadius: 14,
                    offset: const Offset(0, 6)),
              ],
            ),
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
            child: Column(
              children: [
                Icon(Icons.flash_on_rounded, color: Colors.white, size: 28),
                const SizedBox(height: 4),
                Text('Gacor', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                Text('Fast Bug', style: TextStyle(color: Colors.white70, fontSize: 11)),
              ],
            ),
          ),
        ),
        const SizedBox(width: 10),
        // Quality - HIJAU
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.green.shade400, Colors.green.shade700],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                    color: Colors.green.withValues(alpha: 0.35),
                    blurRadius: 14,
                    offset: const Offset(0, 6)),
              ],
            ),
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
            child: Column(
              children: [
                Icon(Icons.verified_rounded, color: Colors.white, size: 28),
                const SizedBox(height: 4),
                Text('Quality', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                Text('Server Stable', style: TextStyle(color: Colors.white70, fontSize: 11)),
              ],
            ),
          ),
        ),
        const SizedBox(width: 10),
        // Damn - MERAH
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.red.shade400, Colors.red.shade700],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                    color: Colors.red.withValues(alpha: 0.35),
                    blurRadius: 14,
                    offset: const Offset(0, 6)),
              ],
            ),
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
            child: Column(
              children: [
                Icon(Icons.whatshot_rounded, color: Colors.white, size: 28),
                const SizedBox(height: 4),
                Text('Damn', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                Text('Simple', style: TextStyle(color: Colors.white70, fontSize: 11)),
              ],
            ),
          ),
        ),
      ]),
      const SizedBox(height: 14),
      
      // Team TRICKSTER X AREA - GRADIENT MERAH KE BIRU
      _PressScaleWidget(
        onTap: () => _showTeamDialog(Colors.blue.shade700),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Colors.red, Colors.blue], // MERAH KE BIRU TERANG!
            ),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.red.withValues(alpha: 0.3),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: const BoxDecoration(
                  color: Colors.white24,
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.group_rounded, size: 28, color: Colors.white),
              ),
              const SizedBox(width: 14),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Team TRICKSTER X AREA', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: Colors.white)),
                    SizedBox(height: 4),
                    Text('group of friends', style: TextStyle(fontSize: 12, color: Colors.white70)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded, color: Colors.white, size: 24),
            ],
          ),
        ),
      ),
      const SizedBox(height: 14),
      
      // BARIS 3: COMMUNITY & MANAGE BUG
      Row(children: [
        // Community - BIRU
        Expanded(
          child: GestureDetector(
            onTap: () => _openUrl("https://t.me/+0ytVOPXmpFM3MTJl"),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.blue.shade600,
                borderRadius: BorderRadius.circular(16),
              ),
              padding: const EdgeInsets.symmetric(vertical: 14),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Icon(Icons.telegram, color: Colors.white, size: 20),
                  SizedBox(width: 8),
                  Text('Community', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w500)),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),
        // Manage Bug - MERAH
        Expanded(
          child: GestureDetector(
            onTap: _openBugSender,
            child: Container(
              decoration: BoxDecoration(
                color: Colors.red.shade600,
                borderRadius: BorderRadius.circular(16),
              ),
              padding: const EdgeInsets.symmetric(vertical: 14),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Icon(Icons.bug_report_rounded, color: Colors.white, size: 20),
                  SizedBox(width: 8),
                  Text('Manage Bug', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w500)),
                ],
              ),
            ),
          ),
        ),
      ]),
    ]),
  );
}

  Widget _buildNews(Color accent) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(0, 16, 0, 0),
      child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(children: [
                  Container(
                      width: 4,
                      height: 18,
                      decoration: BoxDecoration(
                          color: accent,
                          borderRadius: BorderRadius.circular(2),
                          boxShadow: [
                            BoxShadow(
                                color: accent.withValues(alpha: 0.5),
                                blurRadius: 6)
                          ])),
                  const SizedBox(width: 10),
                  const Text('Latest News',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.bold)),
                  const Spacer(),
                  TextButton(
                      onPressed: () {},
                      child: Text('View All',
                          style:
                              TextStyle(color: accent, fontSize: 11))),
                ])),
            const SizedBox(height: 8),
            SizedBox(
                height: 185,
                child: PageView.builder(
                  controller:
                      PageController(viewportFraction: 0.88),
                  itemCount:
                      newsList.isEmpty ? 1 : newsList.length,
                  itemBuilder: (_, i) => newsList.isEmpty
                      ? _buildEmptyNews()
                      : _buildNewsCard(newsList[i]),
                )),
          ]),
    );
  }

  Widget _buildNewsCard(dynamic item) {
    return Container(
        margin: const EdgeInsets.symmetric(horizontal: 6),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: const Color(0xFF0D1B2A),
            image: item['image'] != null
                ? DecorationImage(
                    image: NetworkImage(item['image']),
                    fit: BoxFit.cover,
                    onError: (e, s) {})
                : null,
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withValues(alpha: 0.4),
                  blurRadius: 16,
                  offset: const Offset(0, 5))
            ]),
        child: Stack(children: [
          Container(
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        Colors.black.withValues(alpha: 0.9)
                      ]))),
          Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item['title'] ?? 'No Title',
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    Text(item['desc'] ?? '',
                        style: TextStyle(
                            color:
                                Colors.white.withValues(alpha: 0.6),
                            fontSize: 11),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis),
                  ])),
        ]));
  }

  Widget _buildEmptyNews() {
    return Container(
        margin: const EdgeInsets.symmetric(horizontal: 6),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: const Color(0xFF0D1B2A),
            border: Border.all(
                color: Colors.white.withValues(alpha: 0.05))),
        child: Center(
            child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
              Icon(Icons.newspaper_rounded,
                  color: Colors.white.withValues(alpha: 0.1),
                  size: 44),
              const SizedBox(height: 8),
              Text('No News',
                  style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.25),
                      fontSize: 12)),
            ])));
  }

  Widget _buildCopyright(Color accent) {
    final year = DateTime.now().year;
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 4),
      padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: Colors.black.withValues(alpha: 0.45),
        border: Border.all(color: accent.withValues(alpha: 0.12), width: 1),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            accent.withValues(alpha: 0.07),
            Colors.black.withValues(alpha: 0.0),
          ],
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(children: [
            Expanded(
                child: Divider(
                    color: accent.withValues(alpha: 0.2), thickness: 0.8)),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Icon(Icons.copyright_rounded,
                  color: accent.withValues(alpha: 0.5), size: 15),
            ),
            Expanded(
                child: Divider(
                    color: accent.withValues(alpha: 0.2), thickness: 0.8)),
          ]),
          const SizedBox(height: 14),
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) => Text(
              'TRICKSTER X AREA',
              style: TextStyle(
                color: accent.withValues(
                    alpha: 0.6 + (_pulseCtrl.value * 0.25)),
                fontSize: 13,
                fontWeight: FontWeight.w800,
                letterSpacing: 4.0,
              ),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            '© $year All Rights Reserved',
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.4),
              fontSize: 11,
              fontWeight: FontWeight.w500,
              letterSpacing: 1.2,
            ),
          ),
          const SizedBox(height: 10),
          GestureDetector(
            onTap: () => _openUrl('https://t.me/alwaysZilllxy'),
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: const Color(0xFF0088cc).withValues(alpha: 0.12),
                border: Border.all(
                    color: const Color(0xFF0088cc).withValues(alpha: 0.3),
                    width: 1),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.telegram,
                      color:
                          const Color(0xFF0088cc).withValues(alpha: 0.8),
                      size: 14),
                  const SizedBox(width: 6),
                  Text(
                    '@alwaysZilllxy',
                    style: TextStyle(
                      color: const Color(0xFF0088cc)
                          .withValues(alpha: 0.85),
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            'Developed with ❤ by TRICKSTER X AREA Team',
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.25),
              fontSize: 10,
              letterSpacing: 0.8,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Unauthorized use is strictly prohibited.',
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.18),
              fontSize: 9,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFloatingButton(Color accent) {
    return GestureDetector(
      onTap: _toggleFloatingMenu,
      onPanStart: _onFloatingButtonDragStart,
      onPanUpdate: _onFloatingButtonDragUpdate,
      onPanEnd: _onFloatingButtonDragEnd,
      child: AnimatedBuilder(
          animation: _pulseCtrl,
          builder: (_, __) => Container(
              width: _floatingButtonSize,
              height: _floatingButtonSize,
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image: DecorationImage(
                      image: AssetService.imageProvider('qb.png'),
                      fit: BoxFit.cover),
                  boxShadow: [
                    BoxShadow(
                        color: accent.withValues(
                            alpha: _isFloatingMenuOpen
                                ? 0.7
                                : 0.3 + _pulseCtrl.value * 0.2),
                        blurRadius: _isFloatingMenuOpen
                            ? 32
                            : 14 + _pulseCtrl.value * 8,
                        spreadRadius: _isFloatingMenuOpen ? 3 : 1),
                  ],
                  border: Border.all(
                      color: Colors.white.withValues(alpha: 0.9),
                      width: 2.5)))),
    );
  }

  Widget _buildFloatingMenu(Color accent) {
    double menuLeft = _floatingButtonPosition.dx - 200;
    double menuTop = _floatingButtonPosition.dy - 50;
    if (menuLeft < 10)
      menuLeft =
          _floatingButtonPosition.dx + _floatingButtonSize + 10;
    if (menuLeft + 240 > MediaQuery.of(context).size.width - 10)
      menuLeft = _floatingButtonPosition.dx - 250;

    return Positioned(
        left: menuLeft,
        top: menuTop,
        child: FadeTransition(
            opacity: _floatingFadeAnimation,
            child: ScaleTransition(
                scale: _floatingScaleAnimation,
                child: SlideTransition(
                    position: _floatingSlideAnimation,
                    child: ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: BackdropFilter(
                            filter: ImageFilter.blur(
                                sigmaX: 20, sigmaY: 20),
                            child: Container(
                                width: 240,
                                constraints: BoxConstraints(
                                    maxHeight:
                                        MediaQuery.of(context)
                                                .size
                                                .height *
                                            0.65),
                                decoration: BoxDecoration(
                                    color: const Color(0xFF0A1520)
                                        .withValues(alpha: 0.95),
                                    borderRadius:
                                        BorderRadius.circular(20),
                                    border: Border.all(
                                        color: accent
                                            .withValues(alpha: 0.18)),
                                    boxShadow: [
                                      BoxShadow(
                                          color: Colors.black
                                              .withValues(alpha: 0.55),
                                          blurRadius: 30,
                                          spreadRadius: 2)
                                    ]),
                                child: SingleChildScrollView(
                                    physics:
                                        const BouncingScrollPhysics(),
                                    child: Column(
                                        children: _buildMenuItems(
                                            accent))))))))));
  }

  List<Widget> _buildMenuItems(Color accent) {
    final sections = [
      {
        'title': 'NAVIGASI',
        'items': [
          {'icon': Icons.home_rounded, 'label': 'Home', 'onTap': _openHomePage},
          // Di section 'NAVIGASI':
                    {'icon': Icons.palette_rounded, 'label': 'Ganti Thema warna TRICKSTER', 'onTap': _openSettingsPage},
{'icon': Icons.phonelink_rounded, 'label': 'Rant', 'onTap': _openDeviceDashboard},
          {'icon': Icons.store_rounded, 'label': 'Shop', 'onTap': _openShopPage},
          {'icon': FontAwesomeIcons.whatsapp, 'label': 'Menu Bug', 'onTap': _openWhatsAppPage},
          {'icon': Icons.bug_report_rounded, 'label': 'Sender', 'onTap': _openBugSender},
           {'icon': Icons.telegram, 'label': 'Whatsap chat TRICKSTER', 'onTap': _openGroupChat},
           {'icon': Icons.manage_accounts_rounded, 'label': 'Foto Profile Wa TRICKSTER', 'onTap': _openProfile},
          {'icon': FontAwesomeIcons.whatsapp, 'label': 'Pairing bot TRICKSTER via wa', 'onTap': _openTRICKSTERWa},
          {'icon': Icons.bar_chart_rounded, 'label': 'Stats', 'onTap': _openStats},
          {'icon': Icons.info_rounded, 'label': 'Info', 'onTap': _openInfoPage},
          {'icon': Icons.build_rounded, 'label': 'Tools', 'onTap': _openToolsPage},
          {'icon': Icons.sim_card_rounded, 'label': 'toko store alwaysZilllxy', 'onTap': _openOtpStore},
        ],
      },
      {
        'title': 'HIBURAN',
        'items': [
        {'icon': Icons.gesture, 'label': 'Snake Nokia', 'onTap': _openSnake},
        {'icon': Icons.grid_on_rounded, 'label': 'catur', 'onTap': _openChess},
        {'icon': Icons.dark_mode_rounded, 'label': 'Jadi Hitam', 'onTap': _openJadiHitam},
        {'icon': Icons.style_rounded, 'label': 'Remi Poker', 'onTap': _openRemiPoker},
          {'icon': Icons.casino_rounded, 'label': 'Kasino', 'onTap': _openSlotMachine},
          {'icon': Icons.sports_esports_rounded, 'label': 'Ular Tangga', 'onTap': _openLudo},
          {'icon': Icons.image_search_rounded, 'label': 'Tebak Gambar', 'onTap': _openTebakGambar},
          {'icon': Icons.style_rounded, 'label': 'Pou Memory', 'onTap': _openPouMemory},
          {'icon': Icons.leaderboard_rounded, 'label': 'Leaderboard', 'onTap': _openLeaderboard},
          {'icon': Icons.music_note_rounded, 'label': 'Music', 'onTap': _openMusicPage},
          {'icon': Icons.image_rounded, 'label': 'Pinterest', 'onTap': _openPinterest},
          {'icon': Icons.menu_book_rounded, 'label': 'komik anime manga', 'onTap': _openMangaSearch},
          {'icon': Icons.auto_fix_high_rounded, 'label': 'Remini HD', 'onTap': _openRemini},
          {'icon': Icons.auto_stories_rounded, 'label': 'Novel AI', 'onTap': _openNovelPage},
        ],
      },
      {
        'title': 'ISLAMI',
        'items': [
          {'icon': Icons.mosque_outlined, 'label': 'Jadwal Shalat', 'onTap': _openAdzan},
          {'icon': Icons.menu_book_rounded, 'label': 'Kisah Nabi', 'onTap': _openKisahNabi},
          {'icon': Icons.record_voice_over_rounded, 'label': 'Bacaan Shalat', 'onTap': _openBacaanShalat},
        ],
      },
      {
        'title': 'LAINNYA',
        'items': [
          {'icon': Icons.gamepad_rounded, 'label': 'Top Up Game', 'onTap': _openCodashop},
          {'icon': Icons.qr_code_rounded, 'label': 'Qris no ktp', 'onTap': _openQris},
          {'icon': Icons.smart_toy_rounded, 'label': 'IQC IPHONE', 'onTap': _openIqcPage},
          {'icon': Icons.lock_rounded, 'label': 'Change Password', 'onTap': _openChangePassword},
          {'icon': Icons.headset_mic_rounded, 'label': 'Contact CS', 'onTap': _openContact},
          {'icon': Icons.favorite_rounded, 'label': 'Donasi', 'onTap': _openDonasi},
        ],
      },
    ];
    final adminItems = <Map<String, dynamic>>[];
    if (_isVip) {
      adminItems.add({'icon': Icons.admin_panel_settings_rounded, 'label': 'Admin Page', 'onTap': _openAdminPage});
    }
    if (_isReseller) {
      adminItems.add({'icon': Icons.store_rounded, 'label': 'Seller Page', 'onTap': _openSellerPage});
    }
    if (_isOwner) {
      adminItems.add({'icon': Icons.star_rounded, 'label': 'Owner Page', 'onTap': _openOwnerPage});
    }
    if (_isTk) {
      adminItems.add({'icon': Icons.developer_mode_rounded, 'label': 'Developer Page', 'onTap': _openDeveloperPage});
    }
    if (adminItems.isNotEmpty) {
      sections.insert(1, {'title': 'ADMIN', 'items': adminItems});
    }
    final widgets = <Widget>[];

    for (final section in sections) {
      widgets.add(Padding(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 6),
        child: Text(section['title'] as String,
            style: TextStyle(
                color: accent.withValues(alpha: 0.5),
                fontSize: 9,
                letterSpacing: 2.5,
                fontWeight: FontWeight.w700)),
      ));

      for (final item in section['items'] as List<Map<String, dynamic>>) {
        widgets.add(InkWell(
          onTap: () => (item['onTap'] as VoidCallback)(),
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            child: Row(children: [
              Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                      color: accent.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          color: accent.withValues(alpha: 0.12))),
                  child: Icon(item['icon'] as IconData,
                      color: accent, size: 16)),
              const SizedBox(width: 10),
              Text(item['label'] as String,
                  style: const TextStyle(
                      color: Colors.white, fontSize: 13)),
            ]),
          ),
        ));
      }

      if (section != sections.last || adminItems.isNotEmpty) {
        widgets.add(Divider(
            color: Colors.white.withValues(alpha: 0.05),
            height: 1,
            indent: 12,
            endIndent: 12));
      }
    }

    widgets.add(const SizedBox(height: 4));
    widgets.add(InkWell(
      onTap: _logout,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 16),
        child: Row(children: [
          Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                  color: Colors.red.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                      color: Colors.red.withValues(alpha: 0.2))),
              child: const Icon(Icons.logout_rounded,
                  color: Colors.redAccent, size: 16)),
          const SizedBox(width: 10),
          const Text('Logout',
              style: TextStyle(
                  color: Colors.redAccent,
                  fontSize: 13,
                  fontWeight: FontWeight.w600)),
        ]),
      ),
    ));

    return widgets;
  }

  void _initRating() async {
    _userRating = await RatingService.getUserRating();
    RatingService.ratingStream().listen((data) {
      if (mounted) {
        setState(() {
          _avgRating = data['averageRating'] ?? 0.0;
          _totalRatings = data['totalRatings'] ?? 0;
        });
      }
    });
  }

  void _showRatingDialog() async {
    int tempRating = _userRating;
    final savedComment = await RatingService.getUserComment();
    final commentCtrl = TextEditingController(text: savedComment);

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) {
        return StatefulBuilder(builder: (ctx, setModalState) {
          return Padding(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(ctx).viewInsets.bottom,
            ),
            child: Container(
              margin: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF1A1A2E),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: Colors.white12, width: 1),
                boxShadow: [
                  BoxShadow(
                    color: Colors.purple.withValues(alpha: 0.3),
                    blurRadius: 30,
                    spreadRadius: 5,
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Handle
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.white24,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  // Rating input section
                  Padding(
                    padding: const EdgeInsets.fromLTRB(24, 20, 24, 0),
                    child: Column(
                      children: [
                        Text(
                          'RATE TRICKSTER X AREA',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 2,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                        const SizedBox(height: 6),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.star_rounded,
                                color: Colors.amber, size: 16),
                            const SizedBox(width: 4),
                            Text(
                              '${_avgRating.toStringAsFixed(1)} · $_totalRatings ulasan',
                              style: const TextStyle(
                                  color: Colors.white54, fontSize: 12),
                            ),
                          ],
                        ),
                        const SizedBox(height: 20),
                        // Stars
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: List.generate(5, (i) {
                            final star = i + 1;
                            return GestureDetector(
                              onTap: () =>
                                  setModalState(() => tempRating = star),
                              child: Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 6),
                                child: AnimatedScale(
                                  scale: tempRating >= star ? 1.2 : 1.0,
                                  duration: const Duration(milliseconds: 150),
                                  child: Icon(
                                    tempRating >= star
                                        ? Icons.star_rounded
                                        : Icons.star_outline_rounded,
                                    color: tempRating >= star
                                        ? Colors.amber
                                        : Colors.white24,
                                    size: 40,
                                  ),
                                ),
                              ),
                            );
                          }),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          tempRating == 0
                              ? 'Pilih bintang'
                              : tempRating == 1
                                  ? 'Sangat Buruk'
                                  : tempRating == 2
                                      ? 'Buruk'
                                      : tempRating == 3
                                          ? 'Cukup'
                                          : tempRating == 4
                                              ? 'Bagus'
                                              : 'Luar Biasa! 🔥',
                          style: TextStyle(
                            color:
                                tempRating == 0 ? Colors.white38 : Colors.amber,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 16),
                        // Comment field
                        TextField(
                          controller: commentCtrl,
                          maxLines: 3,
                          maxLength: 200,
                          style: const TextStyle(
                              color: Colors.white, fontSize: 13),
                          decoration: InputDecoration(
                            hintText: 'Tulis ulasan kamu... (opsional)',
                            hintStyle:
                                const TextStyle(color: Colors.white38, fontSize: 13),
                            filled: true,
                            fillColor: Colors.white.withValues(alpha: 0.06),
                            counterStyle:
                                const TextStyle(color: Colors.white38),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(14),
                              borderSide: BorderSide.none,
                            ),
                            contentPadding: const EdgeInsets.all(14),
                          ),
                        ),
                        const SizedBox(height: 12),
                        // Submit button
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: tempRating == 0
                                ? null
                                : () async {
                                    Navigator.pop(ctx);
                                    final ok = await RatingService.submitRating(
                                      sessionKey: sessionKey,
                                      stars: tempRating,
                                      comment: commentCtrl.text.trim(),
                                    );
                                    if (ok) {
                                      setState(() => _userRating = tempRating);
                                    }
                                    if (mounted) {
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(SnackBar(
                                        content: const Text(
                                          'Rating terkirim! Terima kasih 🙏',
                                          style: TextStyle(color: Colors.white),
                                        ),
                                        backgroundColor: Colors.purple.shade800,
                                        behavior: SnackBarBehavior.floating,
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(12),
                                        ),
                                      ));
                                    }
                                  },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: tempRating == 0
                                  ? Colors.white12
                                  : Colors.purple.shade700,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14),
                              ),
                            ),
                            child: Text(
                              _userRating > 0 ? 'Update Rating' : 'Kirim Rating',
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                                letterSpacing: 1,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),
                      ],
                    ),
                  ),
                  // Divider
                  const Divider(color: Colors.white12, height: 1),
                  // Reviews list
                  SizedBox(
                    height: 200,
                    child: FutureBuilder<Map<String, dynamic>>(
                      future: RatingService.fetchRatings(sessionKey: sessionKey),
                      builder: (ctx, snap) {
                        if (snap.connectionState == ConnectionState.waiting) {
                          return const Center(
                            child: CircularProgressIndicator(
                              color: Colors.purple,
                              strokeWidth: 2,
                            ),
                          );
                        }
                        final reviews = (snap.data?['ratings'] as List? ?? [])
                            .where((r) => (r['comment'] as String? ?? '').isNotEmpty)
                            .toList();
                        if (reviews.isEmpty) {
                          return const Center(
                            child: Text(
                              'Belum ada ulasan',
                              style: TextStyle(color: Colors.white38, fontSize: 13),
                            ),
                          );
                        }
                        return ListView.separated(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          itemCount: reviews.length,
                          separatorBuilder: (_, __) =>
                              const Divider(color: Colors.white10, height: 16),
                          itemBuilder: (ctx, i) {
                            final r = reviews[i] as Map;
                            return Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CircleAvatar(
                                  radius: 16,
                                  backgroundColor: Colors.purple.withValues(alpha: 0.4),
                                  child: Text(
                                    (r['username'] as String? ?? '?')
                                        .substring(0, 1)
                                        .toUpperCase(),
                                    style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 12,
                                        fontWeight: FontWeight.w700),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(children: [
                                        Text(
                                          r['username'] as String? ?? '',
                                          style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 12,
                                              fontWeight: FontWeight.w600),
                                        ),
                                        const SizedBox(width: 6),
                                        Row(
                                          children: List.generate(5, (s) => Icon(
                                            s < (r['stars'] as int? ?? 0)
                                                ? Icons.star_rounded
                                                : Icons.star_outline_rounded,
                                            color: Colors.amber,
                                            size: 11,
                                          )),
                                        ),
                                      ]),
                                      const SizedBox(height: 2),
                                      Text(
                                        r['comment'] as String? ?? '',
                                        style: const TextStyle(
                                            color: Colors.white70, fontSize: 12),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            );
                          },
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 8),
                ],
              ),
            ),
          );
        });
      },
    );
  }

  void _openNotifPanel() {
    setState(() {
      _hasUnread = false;
      for (var n in _notifHistory) n['read'] = true;
    });
    final theme = Provider.of<ThemeProvider>(context, listen: false);
    final accent = theme.primaryColor;

    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        isScrollControlled: true,
        builder: (_) => StatefulBuilder(
            builder: (ctx, setM) => Container(
                height: MediaQuery.of(context).size.height * 0.62,
                decoration: BoxDecoration(
                    color: const Color(0xFF0A1520),
                    borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(28)),
                    border: Border.all(
                        color: accent.withValues(alpha: 0.2))),
                child: Column(children: [
                  Container(
                      margin: const EdgeInsets.only(top: 10),
                      width: 32,
                      height: 3,
                      decoration: BoxDecoration(
                          color: Colors.white24,
                          borderRadius: BorderRadius.circular(2))),
                  Padding(
                      padding:
                          const EdgeInsets.fromLTRB(18, 12, 18, 8),
                      child: Row(children: [
                        Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                                color: accent.withValues(alpha: 0.1),
                                borderRadius:
                                    BorderRadius.circular(10)),
                            child: Icon(
                                Icons.notifications_rounded,
                                color: accent,
                                size: 18)),
                        const SizedBox(width: 10),
                        const Text('Notifikasi',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 15,
                                fontWeight: FontWeight.bold)),
                        const Spacer(),
                        if (_notifHistory.isNotEmpty)
                          GestureDetector(
                              onTap: () async {
                                setState(
                                    () => _notifHistory.clear());
                                setM(() {});
                                final prefs =
                                    await SharedPreferences
                                        .getInstance();
                                await prefs.remove('notif_history');
                              },
                              child: Text('Hapus semua',
                                  style: TextStyle(
                                      color: accent, fontSize: 11))),
                      ])),
                  Divider(
                      color: Colors.white.withValues(alpha: 0.06),
                      height: 1),
                  Expanded(
                      child: _notifHistory.isEmpty
                          ? Center(
                              child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                Icon(
                                    Icons.notifications_none_rounded,
                                    color: Colors.white
                                        .withValues(alpha: 0.12),
                                    size: 50),
                                const SizedBox(height: 10),
                                Text('Belum ada notifikasi',
                                    style: TextStyle(
                                        color: Colors.white
                                            .withValues(alpha: 0.3),
                                        fontSize: 12))
                              ]))
                          : ListView.separated(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 6),
                              itemCount: _notifHistory.length,
                              separatorBuilder: (_, __) => Divider(
                                  color: Colors.white
                                      .withValues(alpha: 0.04),
                                  height: 1),
                              itemBuilder: (_, i) {
                                final n = _notifHistory[i];
                                final isUpdate =
                                    n['type'] == 'update';
                                return ListTile(
                                    leading: Container(
                                        padding:
                                            const EdgeInsets.all(8),
                                        decoration: BoxDecoration(
                                            color: isUpdate
                                                ? const Color(
                                                        0xFFFF2D2D)
                                                    .withValues(
                                                        alpha: 0.1)
                                                : Colors.amber
                                                    .withValues(
                                                        alpha: 0.1),
                                            borderRadius:
                                                BorderRadius.circular(
                                                    10)),
                                        child: Icon(
                                            isUpdate
                                                ? Icons.system_update
                                                : Icons.campaign,
                                            color: isUpdate
                                                ? const Color(
                                                    0xFFFF2D2D)
                                                : Colors.amber,
                                            size: 16)),
                                    title: Text(n['title'],
                                        style: const TextStyle(
                                            color: Colors.white,
                                            fontWeight:
                                                FontWeight.bold,
                                            fontSize: 12)),
                                    subtitle: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          const SizedBox(height: 2),
                                          Text(n['message'] ?? '',
                                              style: const TextStyle(
                                                  color:
                                                      Colors.white60,
                                                  fontSize: 11)),
                                          const SizedBox(height: 3),
                                          Text(n['time'] ?? '',
                                              style: const TextStyle(
                                                  color:
                                                      Colors.white30,
                                                  fontSize: 9)),
                                        ]),
                                    isThreeLine: true);
                              })),
                ]))));
  }

  Widget _buildGlitchUsername() {
    const style = TextStyle(
        color: Colors.white,
        fontSize: 22,
        fontWeight: FontWeight.w900);
    if (!_isGlitching)
      return Text(username,
          style: style, overflow: TextOverflow.ellipsis);
    return Stack(clipBehavior: Clip.none, children: [
      Transform.translate(
          offset: Offset(_glitchOffX, 0),
          child: Text(username,
              overflow: TextOverflow.ellipsis,
              style: style.copyWith(
                  color: const Color(0xFF00FFFF)
                      .withValues(alpha: 0.6),
                  shadows: null))),
      Transform.translate(
          offset: Offset(_glitchOffX2, 0),
          child: Text(username,
              overflow: TextOverflow.ellipsis,
              style: style.copyWith(
                  color: const Color(0xFFFF0040)
                      .withValues(alpha: 0.55),
                  shadows: null))),
      Text(username,
          style: style, overflow: TextOverflow.ellipsis),
    ]);
  }
}

// ═══════════════════════════════════════════════════════════════
// REUSABLE WIDGETS
// ═══════════════════════════════════════════════════════════════

class _GlassButton extends StatelessWidget {
  final Widget child;
  final VoidCallback onTap;
  final bool isCircle;
  const _GlassButton(
      {required this.child,
      required this.onTap,
      this.isCircle = false});

  @override
  Widget build(BuildContext context) => GestureDetector(
      onTap: onTap,
      child: ClipRRect(
          borderRadius:
              BorderRadius.circular(isCircle ? 50 : 20),
          child: BackdropFilter(
              filter:
                  ImageFilter.blur(sigmaX: 12, sigmaY: 12),
              child: Container(
                  padding: isCircle
                      ? const EdgeInsets.all(10)
                      : const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 7),
                  decoration: BoxDecoration(
                      color:
                          Colors.white.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(
                          isCircle ? 50 : 20),
                      border: Border.all(
                          color: Colors.white
                              .withValues(alpha: 0.18))),
                  child: child))));
}

class _TagBadge extends StatelessWidget {
  final String label;
  final Color color;
  final IconData icon;
  final bool subtle;
  const _TagBadge(
      {required this.label,
      required this.color,
      required this.icon,
      this.subtle = false});

  @override
  Widget build(BuildContext context) => Container(
      padding:
          const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
          color: color.withValues(alpha: subtle ? 0.06 : 0.15),
          borderRadius: BorderRadius.circular(7),
          border: subtle
              ? null
              : Border.all(color: color.withValues(alpha: 0.35))),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, color: color, size: 9),
        const SizedBox(width: 4),
        Text(label,
            style: TextStyle(
                color: color,
                fontSize: 9,
                fontWeight: FontWeight.w700,
                letterSpacing: subtle ? 0 : 0.5)),
      ]));
}

class _SimpleCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;

  const _SimpleCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: isDark ? Colors.grey.shade900 : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isDark ? Colors.grey.shade800 : Colors.grey.shade200,
            width: 1,
          ),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 24),
            const SizedBox(height: 6),
            Text(
              title,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: isDark ? Colors.white : Colors.grey.shade900,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              subtitle,
              style: TextStyle(
                fontSize: 10,
                color: isDark ? Colors.white54 : Colors.grey.shade600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SimpleActionCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool isDark;

  const _SimpleActionCard({
    required this.icon,
    required this.label,
    required this.onTap,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    return _PressScaleWidget(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: isDark ? Colors.grey.shade900 : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isDark ? Colors.grey.shade800 : Colors.grey.shade200,
            width: 1,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 18, color: isDark ? Colors.white70 : Colors.grey.shade700),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w500,
                color: isDark ? Colors.white : Colors.grey.shade800,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BottomSheet extends StatelessWidget {
  final Color accentColor;
  final String title;
  final List<Widget> children;
  const _BottomSheet(
      {required this.accentColor,
      required this.title,
      required this.children});

  @override
  Widget build(BuildContext context) => Container(
      decoration: BoxDecoration(
          color: const Color(0xFF0A1520),
          borderRadius:
              const BorderRadius.vertical(top: Radius.circular(24)),
          border: Border.all(
              color: accentColor.withValues(alpha: 0.2))),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(
            margin: const EdgeInsets.only(top: 10),
            width: 32,
            height: 3,
            decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(2))),
        Padding(
            padding: const EdgeInsets.symmetric(
                horizontal: 20, vertical: 12),
            child: Text(title,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.bold))),
        Divider(color: Colors.white.withValues(alpha: 0.07)),
        ...children,
        const SizedBox(height: 20),
      ]));
}

class _SheetTile extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label;
  final VoidCallback onTap;
  const _SheetTile(
      {required this.icon,
      required this.color,
      required this.label,
      required this.onTap});

  @override
  Widget build(BuildContext context) => ListTile(
      leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
              color: color.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(10)),
          child: Icon(icon, color: color, size: 18)),
      title: Text(label,
          style:
              const TextStyle(color: Colors.white, fontSize: 14)),
      onTap: onTap);
}

// ═══════════════════════════════════════════════════════════════
// CUSTOM PAINTERS
// ═══════════════════════════════════════════════════════════════

class _MeshPainter extends CustomPainter {
  final Color accent;
  final double pulse;
  const _MeshPainter(this.accent, this.pulse);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..strokeWidth = 0.5;
    const step = 48.0;
    paint.color = accent.withValues(alpha: 0.03 + pulse * 0.01);
    for (double x = 0; x < size.width; x += step)
      canvas.drawLine(
          Offset(x, 0), Offset(x, size.height), paint);
    for (double y = 0; y < size.height; y += step)
      canvas.drawLine(
          Offset(0, y), Offset(size.width, y), paint);
    paint.style = PaintingStyle.fill;
    paint.color = accent.withValues(alpha: 0.05 + pulse * 0.02);
    for (double x = 0; x < size.width; x += step)
      for (double y = 0; y < size.height; y += step)
        canvas.drawCircle(Offset(x, y), 1.2, paint);
  }

  @override
  bool shouldRepaint(covariant _MeshPainter old) =>
      old.pulse != pulse || old.accent != accent;
}

class _PData {
  final double x, y, sz, sp, dr, ph;
  const _PData(this.x, this.y, this.sz, this.sp, this.dr, this.ph);
}

class _ParticlePainter extends CustomPainter {
  final Color accent;
  final double t;
  static final List<_PData> _pts = List.generate(24, (i) {
    final r = Random(i * 137 + 42);
    return _PData(
        r.nextDouble(),
        r.nextDouble(),
        0.8 + r.nextDouble() * 2.0,
        0.03 + r.nextDouble() * 0.055,
        (r.nextDouble() - 0.5) * 0.035,
        r.nextDouble() * pi * 2);
  });
  const _ParticlePainter(this.accent, this.t);

  @override
  void paint(Canvas canvas, Size size) {
    for (var p in _pts) {
      final prog = (p.y + t * p.sp) % 1.0;
      final op = sin(prog * pi).clamp(0.0, 1.0) * 0.17;
      if (op < 0.01) continue;
      final x =
          (p.x + sin(t * pi * 2 + p.ph) * p.dr) * size.width;
      final y = (1.0 - prog) * size.height;
      canvas.drawCircle(
          Offset(x, y),
          p.sz,
          Paint()
            ..color = accent.withValues(alpha: op)
            ..maskFilter =
                const MaskFilter.blur(BlurStyle.normal, 2.5));
      canvas.drawCircle(Offset(x, y + 5), p.sz * 0.4,
          Paint()..color = accent.withValues(alpha: op * 0.35));
    }
  }

  @override
  bool shouldRepaint(covariant _ParticlePainter o) =>
      o.t != t || o.accent != accent;
}

class _ScanLinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final lp = Paint()
      ..color = Colors.black.withValues(alpha: 0.04)
      ..strokeWidth = 1;
    for (double y = 0; y < size.height; y += 3)
      canvas.drawLine(
          Offset(0, y), Offset(size.width, y), lp);
    canvas.drawRect(
        Rect.fromLTWH(0, 0, size.width, size.height),
        Paint()
          ..shader = RadialGradient(
                  center: Alignment.center,
                  radius: 1.0,
                  colors: [
                    Colors.transparent,
                    Colors.black.withValues(alpha: 0.25)
                  ],
                  stops: const [0.5, 1.0])
              .createShader(
                  Rect.fromLTWH(0, 0, size.width, size.height)));
  }

  @override
  bool shouldRepaint(covariant CustomPainter o) => false;
}

// ═══════════════════════════════════════════════════════════════
// CHAT PAGE
// ═══════════════════════════════════════════════════════════════


class ChatPage extends StatefulWidget {
  final String token;
  final String chatId;
  final String username;
  final String sessionKey;
  const ChatPage(
      {super.key,
      required this.token,
      required this.chatId,
      required this.username,
      required this.sessionKey});

  @override
  _ChatPageState createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> with TickerProviderStateMixin {
  final TextEditingController _msgCtrl = TextEditingController();
  final List<Map<String, dynamic>> _messages = [];
  final ScrollController _scrollCtrl = ScrollController();
  
  // WebSocket real-time
  WebSocketChannel? _chatChannel;
  bool _wsConnected = false;
  bool _isConnecting = false;
  Timer? _reconnectTimer;
  Timer? _pingTimer;

  bool _isSending = false;
  bool _isTyping = false;
  int _memberCount = 0;
  String? _groupPhotoUrl;
  String? _groupTitle;
  int _onlineInChat = 0;

  late AnimationController _headerPulse;
  late AnimationController _sendBtnCtrl;
  late Animation<double> _sendBtnScale;
  late AnimationController _typingCtrl;

  @override
  void initState() {
    super.initState();
    _headerPulse = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2000))
      ..repeat(reverse: true);
    _sendBtnCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 150));
    _sendBtnScale = Tween<double>(begin: 1.0, end: 0.88).animate(
        CurvedAnimation(parent: _sendBtnCtrl, curve: Curves.easeInOut));
    _typingCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600))
      ..repeat(reverse: true);
    _loadGroupInfo();
    _connectWebSocket();
  }

  Future<void> _loadGroupInfo() async {
    try {
      final res = await http.get(Uri.parse(
          'https://api.telegram.org/bot${widget.token}/getChat?chat_id=${widget.chatId}'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['ok'] == true) {
          final chat = data['result'];
          if (mounted) setState(() => _groupTitle = chat['title'] ?? 'Chat Grup');
          final photoId = chat['photo']?['big_file_id'] ?? chat['photo']?['small_file_id'];
          if (photoId != null) {
            final fRes = await http.get(Uri.parse(
                'https://api.telegram.org/bot${widget.token}/getFile?file_id=$photoId'));
            if (fRes.statusCode == 200) {
              final fData = jsonDecode(fRes.body);
              final filePath = fData['result']['file_path'];
              if (filePath != null && mounted) {
                final token = widget.token;
                setState(() => _groupPhotoUrl =
                    'https://api.telegram.org/file/bot$token/$filePath');
              }
            }
          }
        }
      }
      final mRes = await http.get(Uri.parse(
          'https://api.telegram.org/bot${widget.token}/getChatMemberCount?chat_id=${widget.chatId}'));
      if (mRes.statusCode == 200) {
        final mData = jsonDecode(mRes.body);
        if (mData['ok'] == true && mounted)
          setState(() => _memberCount = mData['result'] ?? 0);
      }
    } catch (e) {
      debugPrint('Error load group info: $e');
    }
  }

  void _connectWebSocket() {
    if (_isConnecting || _wsConnected) return;
    _isConnecting = true;

    try {
      final base = ConfigService.baseUrl
          .replaceFirst('https://', 'wss://')
          .replaceFirst('http://', 'ws://');
      final wsUrl = base.endsWith('/') ? base.substring(0, base.length - 1) : base;

      _chatChannel = WebSocketChannel.connect(Uri.parse(wsUrl));
      _chatChannel!.ready.then((_) {
        if (!mounted) return;
        setState(() {
          _wsConnected = true;
          _isConnecting = false;
        });
        // Join chat room
        _chatChannel!.sink.add(jsonEncode({
          'type': 'chat_join',
          'key': widget.sessionKey,
          'username': widget.username,
          'chatId': widget.chatId,
        }));
        // Ping setiap 20 detik biar koneksi tetap hidup
        _pingTimer?.cancel();
        _pingTimer = Timer.periodic(const Duration(seconds: 20), (_) {
          try {
            _chatChannel?.sink.add(jsonEncode({'type': 'chat_ping'}));
          } catch (_) {}
        });
        _chatChannel!.stream.listen(
          _onWsMessage,
          onError: (_) => _onWsDisconnected(),
          onDone: () => _onWsDisconnected(),
        );
      }).catchError((_) {
        _onWsDisconnected();
      });
    } catch (e) {
      _onWsDisconnected();
    }
  }

  void _onWsMessage(dynamic event) {
    if (!mounted) return;
    try {
      final data = jsonDecode(event);
      final type = data['type'];

      if (type == 'chat_message') {
        // Pesan masuk dari user lain real-time
        final sender = data['username'] ?? 'User';
        final isMe = sender == widget.username;
        if (!isMe || data['fromServer'] == true) {
          setState(() => _messages.insert(0, {
                'text': data['text'] ?? '',
                'fromMe': false,
                'sender': sender,
                'time': DateTime.now(),
                'type': 'text',
                'avatar': sender.isNotEmpty ? sender[0].toUpperCase() : '?',
              }));
          _scrollToBottom();
        }
      } else if (type == 'chat_history') {
        // Riwayat chat saat baru join
        final history = data['messages'] as List? ?? [];
        setState(() {
          _messages.clear();
          for (var m in history.reversed) {
            _messages.insert(0, {
              'text': m['text'] ?? '',
              'fromMe': m['username'] == widget.username,
              'sender': m['username'] ?? 'User',
              'time': DateTime.tryParse(m['time'] ?? '') ?? DateTime.now(),
              'type': 'text',
              'avatar': (m['username'] ?? 'U').isNotEmpty
                  ? (m['username'] ?? 'U')[0].toUpperCase()
                  : '?',
            });
          }
        });
        _scrollToBottom();
      } else if (type == 'chat_online') {
        setState(() => _onlineInChat = data['count'] ?? 0);
      } else if (type == 'chat_typing') {
        // typing indicator dari user lain
        final sender = data['username'] ?? '';
        if (sender != widget.username && mounted) {
          setState(() => _isTyping = true);
          Future.delayed(const Duration(seconds: 3), () {
            if (mounted) setState(() => _isTyping = false);
          });
        }
      }
    } catch (_) {}
  }

  void _onWsDisconnected() {
    if (!mounted) return;
    setState(() {
      _wsConnected = false;
      _isConnecting = false;
    });
    _pingTimer?.cancel();
    // Auto reconnect setelah 3 detik
    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(const Duration(seconds: 3), () {
      if (mounted) _connectWebSocket();
    });
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(0,
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOut);
      }
    });
  }

  Future<void> _sendMessage() async {
    final text = _msgCtrl.text.trim();
    if (text.isEmpty || _isSending) return;
    _msgCtrl.clear();
    setState(() {
      _isSending = true;
      _isTyping = false;
    });
    _sendBtnCtrl.forward().then((_) => _sendBtnCtrl.reverse());

    // Tampilkan pesan sendiri langsung (optimistic update)
    setState(() => _messages.insert(0, {
          'text': text,
          'fromMe': true,
          'sender': widget.username,
          'time': DateTime.now(),
          'type': 'text',
          'avatar': widget.username.isNotEmpty
              ? widget.username[0].toUpperCase()
              : 'M',
        }));
    _scrollToBottom();

    try {
      if (_wsConnected && _chatChannel != null) {
        // Kirim lewat WebSocket real-time
        _chatChannel!.sink.add(jsonEncode({
          'type': 'chat_send',
          'key': widget.sessionKey,
          'username': widget.username,
          'chatId': widget.chatId,
          'text': text,
        }));
      }
      // Tetap kirim ke Telegram sebagai backup
      await http.post(
        Uri.parse('https://api.telegram.org/bot${widget.token}/sendMessage'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'chat_id': widget.chatId, 'text': '${widget.username}: $text'}),
      );
    } catch (e) {
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('Gagal kirim: $e'),
            backgroundColor: Colors.red[800],
            behavior: SnackBarBehavior.floating));
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _onTyping() {
    if (_wsConnected && _chatChannel != null) {
      try {
        _chatChannel!.sink.add(jsonEncode({
          'type': 'chat_typing',
          'username': widget.username,
          'chatId': widget.chatId,
        }));
      } catch (_) {}
    }
  }

  Future<void> _sendPhoto() async {
    try {
      final picker = ImagePicker();
      final f = await picker.pickImage(source: ImageSource.gallery, imageQuality: 75);
      if (f == null) return;
      setState(() => _isSending = true);
      final uri = Uri.parse('https://api.telegram.org/bot${widget.token}/sendPhoto');
      final req = http.MultipartRequest('POST', uri)
        ..fields['chat_id'] = widget.chatId
        ..fields['caption'] = '${widget.username} mengirim foto'
        ..files.add(await http.MultipartFile.fromPath('photo', f.path));
      final res = await req.send();
      if (res.statusCode == 200 && mounted) {
        setState(() => _messages.insert(0, {
              'text': '[Foto]',
              'fromMe': true,
              'sender': widget.username,
              'time': DateTime.now(),
              'type': 'photo',
              'local_path': f.path,
              'avatar': widget.username[0].toUpperCase(),
            }));
        _scrollToBottom();
      }
    } catch (e) {
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('Gagal kirim foto: $e'),
            backgroundColor: Colors.red[800],
            behavior: SnackBarBehavior.floating));
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _showAttachMenu(Color accent) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: const Color(0xFF0A1520),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          border: Border.all(color: accent.withValues(alpha: 0.2)),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
              margin: const EdgeInsets.only(bottom: 16),
              width: 32, height: 3,
              decoration: BoxDecoration(
                  color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            _AttachBtn(
                icon: Icons.image_rounded,
                label: 'Foto',
                color: Colors.blue,
                onTap: () { Navigator.pop(context); _sendPhoto(); }),
          ]),
          const SizedBox(height: 16),
        ]),
      ),
    );
  }

  String _formatTime(DateTime t) =>
      '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

  @override
  void dispose() {
    _reconnectTimer?.cancel();
    _pingTimer?.cancel();
    _chatChannel?.sink.close(status.goingAway);
    _msgCtrl.dispose();
    _scrollCtrl.dispose();
    _headerPulse.dispose();
    _sendBtnCtrl.dispose();
    _typingCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Provider.of<ThemeProvider>(context);
    final accent = theme.primaryColor;
    final isDark = theme.isDarkMode;
    final bg = isDark ? const Color(0xFF060D14) : const Color(0xFFF0F4F8);

    return Scaffold(
      backgroundColor: bg,
      body: Stack(children: [
        Positioned.fill(
            child: AnimatedBuilder(
                animation: _headerPulse,
                builder: (_, __) =>
                    CustomPaint(painter: _MeshPainter(accent, _headerPulse.value)))),
        Column(children: [
          _buildChatHeader(accent, isDark),
          // WS status bar
          AnimatedContainer(
            duration: const Duration(milliseconds: 400),
            height: _wsConnected ? 0 : 28,
            color: _isConnecting ? Colors.orange.shade900 : Colors.red.shade900,
            child: _wsConnected
                ? null
                : Center(
                    child: Text(
                      _isConnecting ? '🔄 Menghubungkan...' : '⚠️ Terputus — mencoba ulang...',
                      style: const TextStyle(color: Colors.white70, fontSize: 11),
                    )),
          ),
          Expanded(child: _buildMessageList(accent, isDark)),
          if (_isTyping) _buildTypingIndicator(accent),
          _buildInputBar(accent, isDark),
        ]),
      ]),
    );
  }

  Widget _buildChatHeader(Color accent, bool isDark) {
    return Container(
      padding: const EdgeInsets.only(top: 48, bottom: 12, left: 12, right: 16),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF0A1520) : Colors.white,
        border: Border(bottom: BorderSide(color: accent.withValues(alpha: 0.2))),
      ),
      child: Row(children: [
        IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18),
          color: Colors.white70,
          onPressed: () => Navigator.pop(context),
        ),
        CircleAvatar(
          radius: 20,
          backgroundColor: accent.withValues(alpha: 0.2),
          backgroundImage: _groupPhotoUrl != null ? NetworkImage(_groupPhotoUrl!) : null,
          child: _groupPhotoUrl == null
              ? Text((_groupTitle ?? 'G')[0], style: TextStyle(color: accent, fontWeight: FontWeight.bold))
              : null,
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(_groupTitle ?? 'Chat Grup',
                style: TextStyle(color: accent, fontWeight: FontWeight.bold, fontSize: 15,
                    fontFamily: 'Orbitron')),
            Row(children: [
              Container(width: 7, height: 7,
                  decoration: BoxDecoration(
                    color: _wsConnected ? Colors.greenAccent : Colors.red,
                    shape: BoxShape.circle,
                  )),
              const SizedBox(width: 5),
              Text(
                _wsConnected
                    ? (_onlineInChat > 0 ? '$_onlineInChat online · $_memberCount member' : '$_memberCount member')
                    : 'Offline',
                style: TextStyle(
                  color: _wsConnected ? Colors.greenAccent : Colors.red,
                  fontSize: 11,
                ),
              ),
            ]),
          ]),
        ),
        // WS indicator icon
        AnimatedBuilder(
          animation: _headerPulse,
          builder: (_, __) => Icon(
            _wsConnected ? Icons.bolt_rounded : Icons.wifi_off_rounded,
            color: _wsConnected
                ? Color.lerp(Colors.greenAccent, accent, _headerPulse.value)
                : Colors.red,
            size: 22,
          ),
        ),
      ]),
    );
  }

  Widget _buildMessageList(Color accent, bool isDark) {
    if (_messages.isEmpty) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.chat_bubble_outline_rounded, color: accent.withValues(alpha: 0.3), size: 48),
          const SizedBox(height: 12),
          Text('Belum ada pesan', style: TextStyle(color: Colors.white38, fontSize: 13)),
          const SizedBox(height: 4),
          Text('Jadilah yang pertama ngobrol! 💬',
              style: TextStyle(color: Colors.white24, fontSize: 11)),
        ]),
      );
    }
    return ListView.builder(
      controller: _scrollCtrl,
      reverse: true,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      itemCount: _messages.length,
      itemBuilder: (_, i) => _buildMessageBubble(_messages[i], accent, isDark),
    );
  }

  Widget _buildMessageBubble(Map<String, dynamic> msg, Color accent, bool isDark) {
    final isMe = msg['fromMe'] == true;
    final sender = msg['sender'] ?? 'User';
    final time = msg['time'] is DateTime ? msg['time'] as DateTime : DateTime.now();
    final avatar = msg['avatar'] ?? sender[0].toUpperCase();

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!isMe) ...[
            CircleAvatar(
              radius: 14,
              backgroundColor: accent.withValues(alpha: 0.2),
              child: Text(avatar, style: TextStyle(color: accent, fontSize: 11, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(width: 6),
          ],
          Flexible(
            child: Column(
              crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: [
                if (!isMe)
                  Padding(
                    padding: const EdgeInsets.only(left: 4, bottom: 2),
                    child: Text(sender,
                        style: TextStyle(color: accent, fontSize: 10.5, fontWeight: FontWeight.w600)),
                  ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    gradient: isMe
                        ? LinearGradient(colors: [accent, accent.withValues(alpha: 0.7)])
                        : null,
                    color: isMe ? null : (isDark ? const Color(0xFF0D1E30) : Colors.grey.shade200),
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(16),
                      topRight: const Radius.circular(16),
                      bottomLeft: Radius.circular(isMe ? 16 : 4),
                      bottomRight: Radius.circular(isMe ? 4 : 16),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: isMe ? accent.withValues(alpha: 0.3) : Colors.black26,
                        blurRadius: 8, offset: const Offset(0, 2),
                      )
                    ],
                  ),
                  child: msg['type'] == 'photo' && msg['local_path'] != null
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.file(File(msg['local_path']),
                              width: 200, fit: BoxFit.cover))
                      : Text(msg['text'] ?? '',
                          style: TextStyle(
                              color: isMe ? Colors.white : (isDark ? Color(0xDEFFFFFF) : Colors.black87),
                              fontSize: 13.5)),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 3, left: 4, right: 4),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(_formatTime(time),
                          style: const TextStyle(color: Colors.white38, fontSize: 9.5)),
                      if (isMe) ...[
                        const SizedBox(width: 3),
                        Icon(Icons.done_all_rounded, size: 12,
                            color: _wsConnected ? Colors.greenAccent : Colors.white38),
                      ]
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (isMe) const SizedBox(width: 6),
        ],
      ),
    );
  }

  Widget _buildTypingIndicator(Color accent) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      alignment: Alignment.centerLeft,
      child: AnimatedBuilder(
        animation: _typingCtrl,
        builder: (_, __) => Row(mainAxisSize: MainAxisSize.min, children: [
          Text('sedang mengetik', style: TextStyle(color: accent.withValues(alpha: 0.7), fontSize: 11)),
          const SizedBox(width: 4),
          ...List.generate(3, (i) => Container(
            margin: const EdgeInsets.symmetric(horizontal: 2),
            width: 5, height: 5,
            decoration: BoxDecoration(
              color: accent.withValues(alpha: 0.3 + (i == ((_typingCtrl.value * 3).floor() % 3) ? 0.7 : 0)),
              shape: BoxShape.circle,
            ),
          )),
        ]),
      ),
    );
  }

  Widget _buildInputBar(Color accent, bool isDark) {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 24),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF0A1520) : Colors.white,
        border: Border(top: BorderSide(color: accent.withValues(alpha: 0.15))),
      ),
      child: Row(children: [
        IconButton(
          icon: Icon(Icons.attach_file_rounded, color: accent.withValues(alpha: 0.7)),
          onPressed: () => _showAttachMenu(accent),
        ),
        Expanded(
          child: TextField(
            controller: _msgCtrl,
            style: TextStyle(color: isDark ? Color(0xDEFFFFFF) : Colors.black87, fontSize: 14),
            maxLines: 4,
            minLines: 1,
            onChanged: (_) => _onTyping(),
            decoration: InputDecoration(
              hintText: _wsConnected ? 'Ketik pesan...' : 'Menghubungkan...',
              hintStyle: TextStyle(color: Colors.white38, fontSize: 13),
              filled: true,
              fillColor: isDark ? const Color(0xFF0D1E30) : Colors.grey.shade100,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(24),
                borderSide: BorderSide.none,
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            ),
          ),
        ),
        const SizedBox(width: 6),
        ScaleTransition(
          scale: _sendBtnScale,
          child: GestureDetector(
            onTap: _wsConnected ? _sendMessage : null,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              width: 44, height: 44,
              decoration: BoxDecoration(
                gradient: _wsConnected
                    ? LinearGradient(colors: [accent, accent.withValues(alpha: 0.7)],
                        begin: Alignment.topLeft, end: Alignment.bottomRight)
                    : null,
                color: _wsConnected ? null : Colors.grey.shade800,
                shape: BoxShape.circle,
                boxShadow: _wsConnected
                    ? [BoxShadow(color: accent.withValues(alpha: 0.4), blurRadius: 10)]
                    : [],
              ),
              child: Icon(
                _isSending ? Icons.hourglass_top_rounded : Icons.send_rounded,
                color: Colors.white,
                size: 20,
              ),
            ),
          ),
        ),
      ]),
    );
  }
}

class _AttachBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _AttachBtn(
      {required this.icon,
      required this.color,
      required this.label,
      required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
      onTap: onTap,
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color.withValues(alpha: 0.12),
                border: Border.all(
                    color: color.withValues(alpha: 0.3))),
            child: Icon(icon, color: color, size: 26)),
        const SizedBox(height: 8),
        Text(label,
            style: const TextStyle(
                color: Colors.white70, fontSize: 11)),
      ]));
}

class _PressScaleWidget extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  const _PressScaleWidget(
      {required this.child, required this.onTap});

  @override
  State<_PressScaleWidget> createState() =>
      _PressScaleWidgetState();
}

class _PressScaleWidgetState extends State<_PressScaleWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this,
        duration: const Duration(milliseconds: 100));
    _scale = Tween(begin: 1.0, end: 0.94).animate(
        CurvedAnimation(
            parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) {
        _ctrl.reverse();
        widget.onTap();
      },
      onTapCancel: () => _ctrl.reverse(),
      child: AnimatedBuilder(
          animation: _scale,
          builder: (_, child) =>
              Transform.scale(scale: _scale.value, child: child),
          child: widget.child));
}