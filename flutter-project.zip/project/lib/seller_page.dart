import 'config_service.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:io';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';

class SellerPage extends StatefulWidget {
  final String keyToken;
  final String userRole;
  final String username;

  const SellerPage({
    super.key,
    required this.keyToken,
    required this.userRole,
    required this.username,
  });

  @override
  State<SellerPage> createState() => _SellerPageState();
}

class _SellerPageState extends State<SellerPage>
    with SingleTickerProviderStateMixin {
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = ['tk', 'vip', 'owner', 'reseller', 'member', 'member_permanen'];
  String selectedRole = 'member';
  String newMemberType = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();

  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  bool isLoading = false;
  final waController = TextEditingController();
  final telegramController = TextEditingController();
  File? _buktiFile;
  bool _useWa = false;
  bool _useTelegram = false;

  // Animations
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;
  late AnimationController _shimmerController;
  late Animation<double> _shimmerAnimation;

  @override
  void initState() {
    super.initState();
    _fetchUsers();
    _initAnimations();
  }

  void _initAnimations() {
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.05).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _shimmerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat();
    _shimmerAnimation = Tween<double>(begin: -1.5, end: 2.5).animate(
      CurvedAnimation(parent: _shimmerController, curve: Curves.easeInOut),
    );
  }

  Future<String?> _uploadToCatbox(File file) async {
    try {
      final request = http.MultipartRequest('POST', Uri.parse('https://catbox.moe/user/api.php'));
      request.fields['reqtype'] = 'fileupload';
      final bytes = await file.readAsBytes();
      final filename = file.path.split('/').last;
      request.files.add(http.MultipartFile.fromBytes('fileToUpload', bytes, filename: filename));
      final response = await request.send().timeout(const Duration(seconds: 30));
      final body = await response.stream.bytesToString();
      if (body.startsWith('https://')) return body.trim();
      return null;
    } catch (e) {
      debugPrint('[ERROR Catbox] $e');
      return null;
    }
  }

  Future<void> _sendTelegramNotification(
    String username,
    String role,
    String duration,
    String createdBy, {
    String? waNumber,
    String? telegramId,
    File? buktiFile,
  }) async {
    try {
      String contactInfo = '';
      if (waNumber != null && waNumber.isNotEmpty) {
        contactInfo += '\n📱 WhatsApp: *' + waNumber + '*';
      }
      if (telegramId != null && telegramId.isNotEmpty) {
        contactInfo += '\n💬 ID Telegram: *' + telegramId + '*';
      }

      String buktiText = '';
      if (buktiFile != null) {
        final url = await _uploadToCatbox(buktiFile);
        if (url != null) {
          buktiText = '\n🖼 Bukti: ' + url;
        } else {
          buktiText = '\n(Foto bukti gagal diupload)';
        }
      }

      final now = DateTime.now().toLocal().toString().substring(0, 19);
      final message = '✅ *AKUN BARU DIBUAT!*\n\n'
          '👤 Username: *' + username + '*\n'
          '🎭 Role: *' + role + '*\n'
          '📅 Durasi: ' + duration + ' hari' +
          contactInfo +
          buktiText + '\n' +
          '👑 Dibuat Oleh: *' + createdBy + '*\n' +
          '🕐 Waktu: ' + now;

      await http.post(
        Uri.parse(ConfigService.baseUrl + '/sendTelegramNotif'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'message': message, 'type': 'new_account'}),
      );
    } catch (e) {
      debugPrint('[ERROR notif] $e');
    }
  }

  Future<void> _pickBukti() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (picked != null) {
      setState(() => _buktiFile = File(picked.path));
    }
  }



  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse(
            '${ConfigService.baseUrl}/listUsers?key=${widget.keyToken}'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _showPremiumDialog("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _showPremiumDialog("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList
          .where((u) => u['role'] == selectedRole)
          .toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(
      start,
      end > filteredList.length ? filteredList.length : end,
    );
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = newMemberType == 'member_permanen'
        ? '36500'
        : createDayController.text.trim();

    if (u.isEmpty || p.isEmpty || (newMemberType == 'member' && d.isEmpty)) {
      _showPremiumDialog("Peringatan", "Semua field wajib diisi.");
      return;
    }

    if (_buktiFile == null) {
      _showPremiumDialog("Peringatan", "Harap upload bukti transaksi terlebih dahulu.");
      return;
    }

    if (!_useWa && !_useTelegram) {
      _showPremiumDialog("Peringatan", "Harap isi minimal salah satu kontak (WhatsApp atau Telegram).");
      return;
    }

    if (_useWa && waController.text.trim().isEmpty) {
      _showPremiumDialog("Peringatan", "Nomor WhatsApp tidak boleh kosong.");
      return;
    }

    if (_useTelegram && telegramController.text.trim().isEmpty) {
      _showPremiumDialog("Peringatan", "ID Telegram tidak boleh kosong.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          "${ConfigService.baseUrl}/createAccount?key=${widget.keyToken}&newUser=$u&pass=$p&day=$d&role=$newMemberType"));
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        await _sendTelegramNotification(
          u,
          newMemberType == 'member_permanen' ? 'member_permanen' : 'member',
          newMemberType == 'member_permanen' ? 'Permanen' : d,
          widget.username,
          waNumber: _useWa ? waController.text.trim() : null,
          telegramId: _useTelegram ? telegramController.text.trim() : null,
          buktiFile: _buktiFile,
        );

        _showSuccessDialog();
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        waController.clear();
        telegramController.clear();
        setState(() {
          _buktiFile = null;
          _useWa = false;
          _useTelegram = false;
        });
        _fetchUsers();
      } else {
        // ✅ FIX: pesan error menyebut Reseller/VIP
        String msg = data['message'] ?? 'Gagal membuat akun.';
        if (data['invalidDay'] == true) {
          msg += " (Max 30 hari untuk Reseller/VIP)";
        }
        _showPremiumDialog("Gagal", msg);
      }
    } catch (e) {
      _showPremiumDialog("Error", "Koneksi error: $e");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();

    if (u.isEmpty || d.isEmpty) {
      _showPremiumDialog("Peringatan", "Semua field wajib diisi.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse(
            "${ConfigService.baseUrl}/editUser?key=${widget.keyToken}&username=$u&addDays=$d"),
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);

      if (data['edited'] == true) {
        _showSuccessDialog(icon: Icons.timer, message: "Durasi berhasil diperbarui!");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _showPremiumDialog("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (e) {
      // ✅ FIX: tampilkan error asli bukan disembunyikan
      _showPremiumDialog("Error", "Koneksi error: $e");
    }
    setState(() => isLoading = false);
  }

  // ============================================================
  // 🎨 PREMIUM DIALOGS
  // ============================================================

  void _showPremiumDialog(String title, String message) {
    final theme = Theme.of(context);
    final accentColor = theme.colorScheme.secondary;

    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                theme.scaffoldBackgroundColor,
                theme.cardColor,
              ],
            ),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(
              color: accentColor.withOpacity(0.3),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: accentColor.withOpacity(0.2),
                blurRadius: 20,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 70,
                height: 70,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [
                      title == "Sukses"
                          ? Colors.green
                          : title == "Error"
                              ? Colors.red
                              : Colors.orange,
                      title == "Sukses"
                          ? Colors.green.shade700
                          : title == "Error"
                              ? Colors.red.shade700
                              : Colors.orange.shade700,
                    ],
                  ),
                ),
                child: Icon(
                  title == "Sukses"
                      ? Icons.check_rounded
                      : title == "Error"
                          ? Icons.error_outline
                          : Icons.warning_amber_rounded,
                  color: Colors.white,
                  size: 35,
                ),
              ),
              SizedBox(height: 20),
              Text(
                title,
                style: GoogleFonts.orbitron(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
              SizedBox(height: 12),
              Text(
                message,
                textAlign: TextAlign.center,
                style: GoogleFonts.outfit(
                  color: Colors.white70,
                  fontSize: 14,
                ),
              ),
              SizedBox(height: 24),
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: double.infinity,
                  padding: EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [accentColor, accentColor.withOpacity(0.7)],
                    ),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Center(
                    child: Text(
                      "OK",
                      style: GoogleFonts.outfit(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showSuccessDialog({IconData icon = Icons.verified, String message = "Akun berhasil dibuat!"}) {
    final theme = Theme.of(context);
    final accentColor = theme.colorScheme.secondary;

    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: TweenAnimationBuilder(
          tween: Tween<double>(begin: 0, end: 1),
          duration: Duration(milliseconds: 300),
          builder: (_, double value, __) {
            return Transform.scale(
              scale: value,
              child: Container(
                padding: EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      theme.scaffoldBackgroundColor,
                      theme.cardColor,
                    ],
                  ),
                  borderRadius: BorderRadius.circular(28),
                  border: Border.all(
                    color: accentColor.withOpacity(0.4),
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.green.withOpacity(0.3),
                      blurRadius: 25,
                      spreadRadius: 3,
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AnimatedBuilder(
                      animation: _pulseController,
                      builder: (_, __) => Transform.scale(
                        scale: _pulseAnimation.value,
                        child: Container(
                          width: 80,
                          height: 80,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              colors: [Colors.green, Colors.green.shade700],
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.green.withOpacity(0.5),
                                blurRadius: 15,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                          child: Icon(icon, color: Colors.white, size: 40),
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                    Text(
                      "SUCCESS!",
                      style: GoogleFonts.orbitron(
                        color: Colors.green,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                      ),
                    ),
                    SizedBox(height: 12),
                    Text(
                      message,
                      textAlign: TextAlign.center,
                      style: GoogleFonts.outfit(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                    ),
                    SizedBox(height: 24),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        width: double.infinity,
                        padding: EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Colors.green, Colors.green.shade700],
                          ),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Center(
                          child: Text(
                            "CONTINUE",
                            style: GoogleFonts.outfit(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              letterSpacing: 1,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
    String hint = "",
  }) {
    final theme = Theme.of(context);
    final accentColor = theme.colorScheme.secondary;

    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: GoogleFonts.outfit(color: Colors.white),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          hintStyle: GoogleFonts.outfit(color: Colors.white38),
          labelStyle: GoogleFonts.outfit(color: accentColor),
          prefixIcon: Icon(icon, color: accentColor),
          filled: true,
          fillColor: theme.cardColor.withOpacity(0.3),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(color: accentColor, width: 1.5),
          ),
          contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        ),
      ),
    );
  }

  Widget _buildGlassCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    final theme = Theme.of(context);
    final accentColor = theme.colorScheme.secondary;

    return Container(
      margin: EdgeInsets.only(bottom: 25),
      padding: EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            theme.cardColor.withOpacity(0.4),
            theme.cardColor.withOpacity(0.2),
          ],
        ),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(
          color: accentColor.withOpacity(0.2),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: accentColor.withOpacity(0.1),
            blurRadius: 20,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [accentColor, accentColor.withOpacity(0.5)],
                  ),
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                      color: accentColor.withOpacity(0.3),
                      blurRadius: 8,
                    ),
                  ],
                ),
                child: Icon(icon, color: Colors.white, size: 20),
              ),
              SizedBox(width: 14),
              Text(
                title,
                style: GoogleFonts.orbitron(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          SizedBox(height: 24),
          ...children,
        ],
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    final theme = Theme.of(context);
    final accentColor = theme.colorScheme.secondary;
    final role = user['role'].toString();
    final isPermanent = role == 'member_permanen';

    return AnimatedContainer(
      duration: Duration(milliseconds: 200),
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: [
            theme.cardColor.withOpacity(0.4),
            theme.cardColor.withOpacity(0.2),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isPermanent
              ? Colors.teal.withOpacity(0.5)
              : accentColor.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: isPermanent
                    ? [Colors.teal, Colors.teal.shade700]
                    : [accentColor, accentColor.withOpacity(0.7)],
              ),
              shape: BoxShape.circle,
            ),
            child: Icon(
              isPermanent ? Icons.verified_rounded : Icons.person,
              color: Colors.white,
              size: 18,
            ),
          ),
          SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user['username'],
                  style: GoogleFonts.outfit(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                  ),
                ),
                SizedBox(height: 4),
                Row(
                  children: [
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: isPermanent
                            ? Colors.teal.withOpacity(0.2)
                            : accentColor.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        role.toUpperCase(),
                        style: GoogleFonts.outfit(
                          color: isPermanent ? Colors.teal : accentColor,
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    SizedBox(width: 8),
                    Text(
                      "EXP: ${user['expiredDate']}",
                      style: GoogleFonts.outfit(
                        color: Colors.white54,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          if (isPermanent)
            Container(
              padding: EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: Colors.teal.withOpacity(0.2),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.all_inclusive,
                color: Colors.teal,
                size: 16,
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildPagination() {
    final theme = Theme.of(context);
    final accentColor = theme.colorScheme.secondary;

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        return AnimatedContainer(
          duration: Duration(milliseconds: 200),
          child: ElevatedButton(
            onPressed: () => setState(() => currentPage = page),
            style: ElevatedButton.styleFrom(
              backgroundColor:
                  currentPage == page ? accentColor : Colors.transparent,
              foregroundColor:
                  currentPage == page ? Colors.white : Colors.white54,
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(
                  color: currentPage == page
                      ? accentColor
                      : Colors.white.withOpacity(0.1),
                  width: 1,
                ),
              ),
            ),
            child: Text(
              "$page",
              style: GoogleFonts.outfit(
                fontSize: 12,
                fontWeight: currentPage == page ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final accentColor = theme.colorScheme.secondary;
    final bgColor = theme.scaffoldBackgroundColor;

    return Scaffold(
      backgroundColor: bgColor,
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topRight,
            radius: 1.5,
            colors: [
              accentColor.withOpacity(0.05),
              bgColor,
              bgColor,
            ],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: BouncingScrollPhysics(),
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Header dengan animasi
                AnimatedBuilder(
                  animation: _pulseController,
                  builder: (_, __) => Transform.scale(
                    scale: _pulseAnimation.value,
                    child: Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [accentColor, accentColor.withOpacity(0.5)],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: accentColor.withOpacity(0.4),
                            blurRadius: 20,
                            spreadRadius: 5,
                          ),
                        ],
                      ),
                      child: Icon(
                        Icons.storefront,
                        color: Colors.white,
                        size: 40,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 16),
                Text(
                  "SELLER DASHBOARD",
                  style: GoogleFonts.orbitron(
                    color: Colors.white,
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                    shadows: [
                      Shadow(
                        color: accentColor.withOpacity(0.5),
                        blurRadius: 15,
                      ),
                    ],
                  ),
                ),
                Text(
                  "Manage Your Members",
                  style: GoogleFonts.outfit(
                    color: Colors.white60,
                    fontSize: 14,
                  ),
                ),
                SizedBox(height: 40),

                // CREATE ACCOUNT CARD
                _buildGlassCard(
                  title: "CREATE MEMBER",
                  icon: FontAwesomeIcons.userPlus,
                  children: [
                    // Toggle
                    Container(
                      margin: const EdgeInsets.only(bottom: 16),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: accentColor.withOpacity(0.2),
                        ),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: GestureDetector(
                              onTap: () =>
                                  setState(() => newMemberType = 'member'),
                              child: AnimatedContainer(
                                duration: Duration(milliseconds: 200),
                                padding: const EdgeInsets.symmetric(
                                    vertical: 12),
                                decoration: BoxDecoration(
                                  gradient: newMemberType == 'member'
                                      ? LinearGradient(
                                          colors: [accentColor, accentColor.withOpacity(0.7)])
                                      : null,
                                  borderRadius: BorderRadius.circular(18),
                                ),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.center,
                                  children: [
                                    Icon(Icons.person_outline,
                                        size: 16,
                                        color: newMemberType == 'member'
                                            ? Colors.white
                                            : Colors.white38),
                                    const SizedBox(width: 6),
                                    Text('Member Biasa',
                                        style: GoogleFonts.outfit(
                                            color: newMemberType == 'member'
                                                ? Colors.white
                                                : Colors.white38,
                                            fontSize: 12,
                                            fontWeight: FontWeight.w600)),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            child: GestureDetector(
                              onTap: () => setState(
                                  () => newMemberType = 'member_permanen'),
                              child: AnimatedContainer(
                                duration: Duration(milliseconds: 200),
                                padding: const EdgeInsets.symmetric(
                                    vertical: 12),
                                decoration: BoxDecoration(
                                  gradient: newMemberType == 'member_permanen'
                                      ? const LinearGradient(colors: [
                                          Colors.teal,
                                          Colors.tealAccent
                                        ])
                                      : null,
                                  borderRadius: BorderRadius.circular(18),
                                ),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.center,
                                  children: [
                                    Icon(Icons.verified,
                                        size: 16,
                                        color: newMemberType ==
                                                'member_permanen'
                                            ? Colors.white
                                            : Colors.white38),
                                    const SizedBox(width: 6),
                                    Text('Permanen',
                                        style: GoogleFonts.outfit(
                                            color: newMemberType ==
                                                    'member_permanen'
                                                ? Colors.white
                                                : Colors.white38,
                                            fontSize: 12,
                                            fontWeight: FontWeight.w600)),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    _buildInput(
                      label: "Username",
                      controller: createUsernameController,
                      icon: FontAwesomeIcons.user,
                    ),
                    _buildInput(
                      label: "Password",
                      controller: createPasswordController,
                      icon: FontAwesomeIcons.lock,
                    ),
                    if (newMemberType == 'member')
                      _buildInput(
                        label: "Durasi (Hari)",
                        controller: createDayController,
                        icon: FontAwesomeIcons.calendarDay,
                        type: TextInputType.number,
                        hint: "Max 30 hari",
                      ),
                    if (newMemberType == 'member_permanen')
                      Container(
                        margin: const EdgeInsets.only(bottom: 15),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.teal.withOpacity(0.1),
                              Colors.teal.withOpacity(0.05),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                              color: Colors.teal.withOpacity(0.3)),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.all_inclusive,
                                color: Colors.teal, size: 18),
                            SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                'Akun Permanen - Tidak ada expired date',
                                style: GoogleFonts.outfit(
                                  color: Colors.teal,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    // BUKTI TRANSAKSI
                    GestureDetector(
                      onTap: _pickBukti,
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 15),
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: _buktiFile != null
                                ? Colors.green.withOpacity(0.6)
                                : accentColor.withOpacity(0.3),
                            width: 1.5,
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: _buktiFile != null
                                      ? [Colors.green, Colors.green.shade700]
                                      : [accentColor, accentColor.withOpacity(0.7)],
                                ),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Icon(
                                _buktiFile != null ? Icons.check_circle : Icons.upload_file,
                                color: Colors.white,
                                size: 20,
                              ),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Bukti Transaksi *",
                                    style: GoogleFonts.outfit(
                                      color: _buktiFile != null ? Colors.green : accentColor,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 13,
                                    ),
                                  ),
                                  Text(
                                    _buktiFile != null
                                        ? _buktiFile!.path.split('/').last
                                        : "Tap untuk upload foto bukti",
                                    style: GoogleFonts.outfit(
                                      color: Colors.white54,
                                      fontSize: 11,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                            if (_buktiFile != null)
                              GestureDetector(
                                onTap: () => setState(() => _buktiFile = null),
                                child: Icon(Icons.close, color: Colors.red.shade300, size: 18),
                              ),
                          ],
                        ),
                      ),
                    ),
                    // WHATSAPP CHECKBOX
                    Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: Colors.green.withOpacity(0.2)),
                      ),
                      child: CheckboxListTile(
                        value: _useWa,
                        onChanged: (v) => setState(() => _useWa = v ?? false),
                        title: Text(
                          "Punya WhatsApp",
                          style: GoogleFonts.outfit(color: Colors.white70, fontSize: 13),
                        ),
                        secondary: Icon(Icons.phone_android, color: Colors.green, size: 20),
                        activeColor: Colors.green,
                        controlAffinity: ListTileControlAffinity.trailing,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                        dense: true,
                      ),
                    ),
                    if (_useWa)
                      _buildInput(
                        label: "Nomor WhatsApp",
                        controller: waController,
                        icon: FontAwesomeIcons.whatsapp,
                        type: TextInputType.phone,
                        hint: "Contoh: 08xxxxxxxxx",
                      ),
                    // TELEGRAM CHECKBOX
                    Container(
                      margin: const EdgeInsets.only(bottom: 15),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: Colors.blue.withOpacity(0.2)),
                      ),
                      child: CheckboxListTile(
                        value: _useTelegram,
                        onChanged: (v) => setState(() => _useTelegram = v ?? false),
                        title: Text(
                          "Punya Telegram",
                          style: GoogleFonts.outfit(color: Colors.white70, fontSize: 13),
                        ),
                        secondary: Icon(Icons.send, color: Colors.blue, size: 20),
                        activeColor: Colors.blue,
                        controlAffinity: ListTileControlAffinity.trailing,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                        dense: true,
                      ),
                    ),
                    if (_useTelegram)
                      _buildInput(
                        label: "ID / Username Telegram",
                        controller: telegramController,
                        icon: FontAwesomeIcons.telegram,
                        hint: "Contoh: @username atau 123456789",
                      ),
                    SizedBox(height: 10),
                    GestureDetector(
                      onTap: isLoading ? null : _createAccount,
                      child: Container(
                        height: 52,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [accentColor, accentColor.withOpacity(0.7)],
                          ),
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: accentColor.withOpacity(0.3),
                              blurRadius: 12,
                              offset: Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Center(
                          child: isLoading
                              ? SizedBox(
                                  width: 22,
                                  height: 22,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white,
                                  ),
                                )
                              : Text(
                                  "CREATE ACCOUNT",
                                  style: GoogleFonts.outfit(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15,
                                    letterSpacing: 1,
                                  ),
                                ),
                        ),
                      ),
                    ),
                  ],
                ),

                // EXTEND DURATION CARD
                _buildGlassCard(
                  title: "EXTEND DURATION",
                  icon: FontAwesomeIcons.clock,
                  children: [
                    _buildInput(
                      label: "Username Target",
                      controller: editUsernameController,
                      icon: FontAwesomeIcons.userEdit,
                      hint: "Username member yang ingin diperpanjang",
                    ),
                    _buildInput(
                      label: "Tambah Hari",
                      controller: editDayController,
                      icon: FontAwesomeIcons.calendarPlus,
                      type: TextInputType.number,
                      hint: "Maksimal 30 hari",
                    ),
                    SizedBox(height: 10),
                    GestureDetector(
                      onTap: isLoading ? null : _editUser,
                      child: Container(
                        height: 52,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Colors.blue, Colors.blue.shade700],
                          ),
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.blue.withOpacity(0.3),
                              blurRadius: 12,
                              offset: Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Center(
                          child: isLoading
                              ? SizedBox(
                                  width: 22,
                                  height: 22,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white,
                                  ),
                                )
                              : Text(
                                  "ADD DAYS",
                                  style: GoogleFonts.outfit(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15,
                                    letterSpacing: 1,
                                  ),
                                ),
                        ),
                      ),
                    ),
                  ],
                ),

                // USER LIST CARD
                _buildGlassCard(
                  title: "MEMBER LIST",
                  icon: FontAwesomeIcons.users,
                  children: [
                    // Filter dropdown
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: accentColor.withOpacity(0.2),
                        ),
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: selectedRole,
                          dropdownColor: theme.cardColor,
                          style: GoogleFonts.outfit(
                            color: Colors.white,
                            fontSize: 13,
                          ),
                          items: roleOptions.map((role) {
                            return DropdownMenuItem(
                              value: role,
                              child: Text(role.toUpperCase()),
                            );
                          }).toList(),
                          onChanged: (val) {
                            if (val != null) {
                              selectedRole = val;
                              _filterAndPaginate();
                            }
                          },
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                    isLoading
                        ? Center(
                            child: CircularProgressIndicator(
                              color: accentColor,
                            ),
                          )
                        : Column(
                            children: [
                              ..._getCurrentPageData()
                                  .map((u) => _buildUserItem(u))
                                  .toList(),
                              SizedBox(height: 20),
                              _buildPagination(),
                            ],
                          ),
                  ],
                ),
                SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    waController.dispose();
    telegramController.dispose();
    editUsernameController.dispose();
    editDayController.dispose();
    _pulseController.dispose();
    _shimmerController.dispose();
    super.dispose();
  }
}
