import 'package:device_info_plus/device_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Cache untuk Android Device ID.
/// Android ID nggak berubah-ubah, jadi sekali ambil dari native (DeviceInfoPlugin)
/// langsung disimpan ke SharedPreferences supaya kebuka berikutnya tinggal baca
/// dari disk, nggak perlu panggil platform channel lagi.
class DeviceCache {
  static const String _prefsKey = 'cached_android_id';

  // Cache juga di RAM biar dalam 1 sesi app gak perlu baca SharedPreferences berkali-kali.
  static String? _memoryCache;

  static Future<String> getAndroidId() async {
    // 1. Cek cache di memori dulu (paling cepat)
    if (_memoryCache != null) return _memoryCache!;

    // 2. Cek cache di SharedPreferences (persist antar sesi app)
    final prefs = await SharedPreferences.getInstance();
    final cached = prefs.getString(_prefsKey);
    if (cached != null && cached.isNotEmpty) {
      _memoryCache = cached;
      return cached;
    }

    // 3. Belum ada cache sama sekali → ambil dari native device info (sekali aja)
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    final id = deviceInfo.id;

    _memoryCache = id;
    await prefs.setString(_prefsKey, id);

    return id;
  }

  /// Panggil ini kalau memang butuh refresh paksa (jarang dibutuhkan).
  static Future<void> clearCache() async {
    _memoryCache = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_prefsKey);
  }
}
