import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'theme_provider.dart';

// ─── CATATAN: Tambahkan ke pubspec.yaml ───────────────────────────────────────
// dependencies:
//   flutter_colorpicker: ^1.1.0
// ─────────────────────────────────────────────────────────────────────────────
import 'package:flutter_colorpicker/flutter_colorpicker.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animCtrl;
  late Animation<double> _fadeAnim;
  Color _tempColor = Colors.purple;

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
    _fadeAnim = CurvedAnimation(parent: _animCtrl, curve: Curves.easeOut);
    _animCtrl.forward();
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    super.dispose();
  }

  // ── Warna background & surface sesuai dark/light mode ──────────────────────
  Color _bg(ThemeProvider t) =>
      t.isDarkMode ? const Color(0xFF0A0A0F) : const Color(0xFFF2F2F7);
  Color _surface(ThemeProvider t) =>
      t.isDarkMode ? const Color(0xFF16161E) : Colors.white;
  Color _textColor(ThemeProvider t) =>
      t.isDarkMode ? Colors.white : const Color(0xFF111111);
  Color _subColor(ThemeProvider t) =>
      t.isDarkMode ? Colors.white38 : Colors.black38;

  @override
  Widget build(BuildContext context) {
    final t = context.watch<ThemeProvider>();

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: t.isDarkMode ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark,
      child: Scaffold(
        backgroundColor: _bg(t),
        body: FadeTransition(
          opacity: _fadeAnim,
          child: CustomScrollView(
            physics: const BouncingScrollPhysics(),
            slivers: [
              // ── AppBar ────────────────────────────────────────────────────
              SliverAppBar(
                expandedHeight: 150,
                pinned: true,
                backgroundColor: _bg(t),
                elevation: 0,
                leading: IconButton(
                  icon: Icon(Icons.arrow_back_ios_new_rounded,
                      color: _textColor(t), size: 20),
                  onPressed: () => Navigator.pop(context),
                ),
                actions: [
                  TextButton.icon(
                    onPressed: () => _showResetDialog(context, t),
                    icon: Icon(Icons.refresh_rounded,
                        size: 16, color: t.primaryColor),
                    label: Text('Reset',
                        style: TextStyle(
                            color: t.primaryColor,
                            fontWeight: FontWeight.w600)),
                  ),
                  const SizedBox(width: 8),
                ],
                flexibleSpace: FlexibleSpaceBar(
                  titlePadding: const EdgeInsets.only(left: 20, bottom: 16),
                  title: Text(
                    'Pengaturan Tema',
                    style: TextStyle(
                        color: _textColor(t),
                        fontWeight: FontWeight.w700,
                        fontSize: 20,
                        letterSpacing: -0.5),
                  ),
                  background: Stack(children: [
                    Positioned(
                      top: -30, right: -20,
                      child: Container(
                        width: 180, height: 180,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(colors: [
                            t.primaryColor.withOpacity(0.25),
                            Colors.transparent,
                          ]),
                        ),
                      ),
                    ),
                  ]),
                ),
              ),

              SliverPadding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 40),
                sliver: SliverList(
                  delegate: SliverChildListDelegate([

                    // ── Preview Card ─────────────────────────────────────────
                    _buildPreviewCard(t),
                    const SizedBox(height: 24),

                    // ── Dark Mode ────────────────────────────────────────────
                    _sectionLabel('MODE', t),
                    const SizedBox(height: 10),
                    _buildDarkModeToggle(t),
                    const SizedBox(height: 24),

                    // ── Dashboard Style ───────────────────────────────────────
                    _sectionLabel('DASHBOARD STYLE', t),
                    const SizedBox(height: 10),
                    _buildDashStylePicker(t),
                    const SizedBox(height: 24),

                    // ── Dashboard Theme ───────────────────────────────────────
                    _sectionLabel('DASHBOARD THEME (${ThemeProvider.dashboardThemes.length})', t),
                    const SizedBox(height: 10),
                    _buildDashThemeGrid(t),
                    const SizedBox(height: 24),

                    // ── Preset ───────────────────────────────────────────────
                    _sectionLabel('PRESET WARNA (${ThemeProvider.colorPresets.length})', t),
                    const SizedBox(height: 10),
                    _buildPresetGrid(t),
                    const SizedBox(height: 24),

                    // ── Custom ───────────────────────────────────────────────
                    _sectionLabel('WARNA CUSTOM', t),
                    const SizedBox(height: 10),
                    _buildCustomRow(t),
                    const SizedBox(height: 24),
                  ]),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Section Label ──────────────────────────────────────────────────────────
  Widget _sectionLabel(String label, ThemeProvider t) => Text(
        label,
        style: TextStyle(
            color: _subColor(t),
            fontSize: 11,
            fontWeight: FontWeight.w700,
            letterSpacing: 1.5),
      );

  // ── Preview Card ───────────────────────────────────────────────────────────
  Widget _buildPreviewCard(ThemeProvider t) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 400),
      curve: Curves.easeInOut,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [t.primaryColor, t.accentColor],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: t.primaryColor.withOpacity(0.4),
            blurRadius: 20, offset: const Offset(0, 8),
          ),
        ],
      ),
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const CircleAvatar(
            radius: 18,
            backgroundColor: Colors.white24,
            child: Icon(Icons.palette_rounded, color: Colors.white, size: 18),
          ),
          const SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Preview Tema',
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 14)),
            Text('Begini tampilan app-nya',
                style: TextStyle(
                    color: Colors.white.withOpacity(0.65), fontSize: 11)),
          ]),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Text('LIVE',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.w700)),
          ),
        ]),
        const SizedBox(height: 16),
        Row(children: [
          _chip('Primary'), const SizedBox(width: 6),
          _chip('Accent'), const SizedBox(width: 6),
          _chip('Button'),
        ]),
        const SizedBox(height: 14),
        // Progress bar preview
        Container(
          height: 5,
          decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.25),
              borderRadius: BorderRadius.circular(3)),
          child: FractionallySizedBox(
            alignment: Alignment.centerLeft,
            widthFactor: 0.65,
            child: Container(
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(3)),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _chip(String label) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.2),
            borderRadius: BorderRadius.circular(20)),
        child: Text(label,
            style: const TextStyle(
                color: Colors.white, fontSize: 11, fontWeight: FontWeight.w500)),
      );

  // ── Dark Mode Toggle ───────────────────────────────────────────────────────
  Widget _buildDarkModeToggle(ThemeProvider t) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      decoration: BoxDecoration(
        color: _surface(t),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 10, offset: const Offset(0, 4))
        ],
      ),
      child: ListTile(
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        leading: AnimatedSwitcher(
          duration: const Duration(milliseconds: 300),
          child: Icon(
            t.isDarkMode ? Icons.dark_mode_rounded : Icons.light_mode_rounded,
            key: ValueKey(t.isDarkMode),
            color: t.primaryColor, size: 24,
          ),
        ),
        title: Text(
          t.isDarkMode ? 'Mode Gelap' : 'Mode Terang',
          style: TextStyle(
              color: _textColor(t),
              fontWeight: FontWeight.w600, fontSize: 14),
        ),
        subtitle: Text(
          t.isDarkMode ? 'Tampilan gelap aktif' : 'Tampilan terang aktif',
          style: TextStyle(color: _subColor(t), fontSize: 12),
        ),
        trailing: Switch.adaptive(
          value: t.isDarkMode,
          onChanged: (_) => t.toggleDarkMode(),
          activeColor: t.primaryColor,
        ),
        onTap: () => t.toggleDarkMode(),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    );
  }

  // ── Dashboard Style Picker ────────────────────────────────────────────────
  Widget _buildDashStylePicker(ThemeProvider t) {
    return FutureBuilder<SharedPreferences>(
      future: SharedPreferences.getInstance(),
      builder: (ctx, snap) {
        final prefs = snap.data;
        final current = prefs?.getString('dashboardStyle') ?? 'default';
        return Container(
          decoration: BoxDecoration(
            color: _surface(t),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 10, offset: const Offset(0, 4))],
          ),
          child: Column(children: [
            _dashStyleItem(
              t: t,
              prefs: prefs,
              current: current,
              styleId: 'default',
              label: 'TRICKSTER CLASSIC',
              subtitle: 'Dashboard utama cyberpunk',
              emoji: '⚡',
              isFirst: true,
              isLast: false,
            ),
            _dashStyleItem(
              t: t,
              prefs: prefs,
              current: current,
              styleId: 'loader',
              label: 'LOADER STYLE',
              subtitle: 'Dashboard alternatif dengan video bg',
              emoji: '🎬',
              isFirst: false,
              isLast: true,
            ),
          ]),
        );
      },
    );
  }

  Widget _dashStyleItem({
    required ThemeProvider t,
    required SharedPreferences? prefs,
    required String current,
    required String styleId,
    required String label,
    required String subtitle,
    required String emoji,
    required bool isFirst,
    required bool isLast,
  }) {
    final isActive = current == styleId;
    return StatefulBuilder(
      builder: (ctx, setLocal) {
        return InkWell(
          onTap: () async {
            await prefs?.setString('dashboardStyle', styleId);
            setLocal(() {});
            // ignore: use_build_context_synchronously
            ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
              content: Text('Dashboard style diubah ke $label — berlaku setelah login ulang', style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 12)),
              backgroundColor: t.primaryColor,
              duration: const Duration(seconds: 3),
            ));
          },
          borderRadius: BorderRadius.vertical(
            top: isFirst ? const Radius.circular(20) : Radius.zero,
            bottom: isLast ? const Radius.circular(20) : Radius.zero,
          ),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              color: isActive ? t.primaryColor.withOpacity(0.08) : Colors.transparent,
              border: !isLast ? Border(bottom: BorderSide(color: _bg(t).withOpacity(0.8))) : null,
              borderRadius: BorderRadius.vertical(
                top: isFirst ? const Radius.circular(20) : Radius.zero,
                bottom: isLast ? const Radius.circular(20) : Radius.zero,
              ),
            ),
            child: Row(children: [
              Container(
                width: 42, height: 42,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: isActive ? t.primaryColor.withOpacity(0.15) : _bg(t).withOpacity(0.5),
                  border: Border.all(color: isActive ? t.primaryColor.withOpacity(0.4) : Colors.transparent),
                  boxShadow: isActive ? [BoxShadow(color: t.primaryColor.withOpacity(0.2), blurRadius: 8)] : [],
                ),
                child: Center(child: Text(emoji, style: const TextStyle(fontSize: 20))),
              ),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(label, style: TextStyle(
                  color: isActive ? t.primaryColor : _textColor(t),
                  fontWeight: isActive ? FontWeight.w800 : FontWeight.w600,
                  fontSize: 12,
                  letterSpacing: 1.2,
                )),
                const SizedBox(height: 2),
                Text(subtitle, style: TextStyle(color: _subColor(t), fontSize: 11)),
              ])),
              if (isActive)
                Icon(Icons.check_circle_rounded, color: t.primaryColor, size: 20),
            ]),
          ),
        );
      },
    );
  }

  // ── Dashboard Theme Grid ───────────────────────────────────────────────────
  Widget _buildDashThemeGrid(ThemeProvider t) {
    return Container(
      decoration: BoxDecoration(
        color: _surface(t),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 10, offset: const Offset(0, 4))
        ],
      ),
      child: Column(
        children: ThemeProvider.dashboardThemes.asMap().entries.map((entry) {
          final i = entry.key;
          final theme = entry.value;
          final isActive = t.isActiveDashTheme(theme);
          final isLast = i == ThemeProvider.dashboardThemes.length - 1;
          return InkWell(
            onTap: () => t.applyDashboardTheme(theme),
            borderRadius: BorderRadius.vertical(
              top: i == 0 ? const Radius.circular(20) : Radius.zero,
              bottom: isLast ? const Radius.circular(20) : Radius.zero,
            ),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
              decoration: BoxDecoration(
                color: isActive ? theme.primary.withOpacity(0.08) : Colors.transparent,
                border: !isLast ? Border(bottom: BorderSide(color: _bg(t).withOpacity(0.8))) : null,
                borderRadius: BorderRadius.vertical(
                  top: i == 0 ? const Radius.circular(20) : Radius.zero,
                  bottom: isLast ? const Radius.circular(20) : Radius.zero,
                ),
              ),
              child: Row(children: [
                // Color swatch
                Container(
                  width: 36, height: 36,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    gradient: LinearGradient(
                      colors: [theme.primary, theme.accent],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    boxShadow: isActive
                        ? [BoxShadow(color: theme.primary.withOpacity(0.4), blurRadius: 8)]
                        : [],
                  ),
                  child: Center(
                    child: Text(theme.emoji, style: const TextStyle(fontSize: 16)),
                  ),
                ),
                const SizedBox(width: 14),
                // bg preview mini
                Row(children: [
                  _miniBox(theme.bg),
                  const SizedBox(width: 3),
                  _miniBox(theme.card),
                  const SizedBox(width: 3),
                  _miniBox(theme.primary),
                ]),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    theme.name,
                    style: TextStyle(
                      color: isActive ? theme.primary : _textColor(t),
                      fontWeight: isActive ? FontWeight.w800 : FontWeight.w500,
                      fontSize: 12,
                      letterSpacing: 1.2,
                    ),
                  ),
                ),
                if (isActive)
                  Icon(Icons.check_circle_rounded, color: theme.primary, size: 18),
              ]),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _miniBox(Color color) => Container(
    width: 14, height: 14,
    decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(4)),
  );

  // ── Preset Grid ────────────────────────────────────────────────────────────
  Widget _buildPresetGrid(ThemeProvider t) {
    return Container(
      decoration: BoxDecoration(
        color: _surface(t),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 10, offset: const Offset(0, 4))
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Nama preset aktif
        Text(
          _activeName(t),
          style: TextStyle(
              color: t.primaryColor,
              fontWeight: FontWeight.w700,
              fontSize: 13),
        ),
        const SizedBox(height: 14),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 5,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
          ),
          itemCount: ThemeProvider.colorPresets.length,
          itemBuilder: (_, i) {
            final preset = ThemeProvider.colorPresets[i];
            final isActive = t.isActivePreset(preset);
            return Tooltip(
              message: preset.name,
              child: GestureDetector(
                onTap: () => t.applyPreset(preset),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [preset.primary, preset.accent],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    shape: BoxShape.circle,
                    border: isActive
                        ? Border.all(color: Colors.white, width: 3)
                        : Border.all(color: Colors.transparent, width: 3),
                    boxShadow: [
                      BoxShadow(
                        color: isActive
                            ? preset.primary.withOpacity(0.6)
                            : Colors.black.withOpacity(0.12),
                        blurRadius: isActive ? 14 : 4,
                        spreadRadius: isActive ? 2 : 0,
                      ),
                    ],
                  ),
                  child: isActive
                      ? const Icon(Icons.check_rounded,
                          color: Colors.white, size: 18)
                      : null,
                ),
              ),
            );
          },
        ),
      ]),
    );
  }

  String _activeName(ThemeProvider t) {
    try {
      return ThemeProvider.colorPresets
          .firstWhere((p) => t.isActivePreset(p))
          .name;
    } catch (_) {
      return 'Custom';
    }
  }

  // ── Custom Color Row ───────────────────────────────────────────────────────
  Widget _buildCustomRow(ThemeProvider t) {
    return Row(children: [
      Expanded(child: _colorBtn(t, isPrimary: true)),
      const SizedBox(width: 12),
      Expanded(child: _colorBtn(t, isPrimary: false)),
    ]);
  }

  Widget _colorBtn(ThemeProvider t, {required bool isPrimary}) {
    final color = isPrimary ? t.primaryColor : t.accentColor;
    final label = isPrimary ? 'Primary' : 'Accent';
    final hex = '#${color.value.toRadixString(16).substring(2).toUpperCase()}';

    return GestureDetector(
      onTap: () => _openPicker(context, t, isPrimary: isPrimary),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: _surface(t),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.06),
                blurRadius: 10, offset: const Offset(0, 4))
          ],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              width: 34, height: 34,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                      color: color.withOpacity(0.5),
                      blurRadius: 10, spreadRadius: 1)
                ],
              ),
            ),
            const Spacer(),
            Icon(Icons.edit_rounded, color: _subColor(t), size: 15),
          ]),
          const SizedBox(height: 10),
          Text(label,
              style: TextStyle(
                  color: _textColor(t),
                  fontWeight: FontWeight.w600, fontSize: 13)),
          const SizedBox(height: 2),
          Text(hex,
              style: TextStyle(
                  color: _subColor(t),
                  fontSize: 11,
                  fontFamily: 'monospace')),
        ]),
      ),
    );
  }

  // ── Color Picker Bottom Sheet ──────────────────────────────────────────────
  void _openPicker(BuildContext context, ThemeProvider t,
      {required bool isPrimary}) {
    _tempColor = isPrimary ? t.primaryColor : t.accentColor;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => StatefulBuilder(builder: (ctx, setSt) {
        final bg = t.isDarkMode ? const Color(0xFF1A1A26) : Colors.white;
        final textColor = t.isDarkMode ? Colors.white : const Color(0xFF111111);

        return Container(
          height: MediaQuery.of(context).size.height * 0.78,
          decoration: BoxDecoration(
            color: bg,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
          ),
          child: Column(children: [
            Container(
              margin: const EdgeInsets.only(top: 10),
              width: 36, height: 4,
              decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(2)),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 6),
              child: Row(children: [
                Text(
                  isPrimary ? 'Pilih Warna Primary' : 'Pilih Warna Accent',
                  style: TextStyle(
                      color: textColor,
                      fontSize: 17,
                      fontWeight: FontWeight.w700),
                ),
                const Spacer(),
                AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 30, height: 30,
                  decoration: BoxDecoration(
                    color: _tempColor,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                          color: _tempColor.withOpacity(0.5),
                          blurRadius: 10, spreadRadius: 2)
                    ],
                  ),
                ),
              ]),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: ColorPicker(
                  pickerColor: _tempColor,
                  onColorChanged: (c) => setSt(() => _tempColor = c),
                  pickerAreaHeightPercent: 0.5,
                  enableAlpha: false,
                  displayThumbColor: true,
                  labelTypes: const [],
                  pickerAreaBorderRadius: BorderRadius.circular(14),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
              child: Row(children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(ctx),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      side: const BorderSide(color: Colors.white24),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    child: const Text('Batal'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 2,
                  child: ElevatedButton(
                    onPressed: () {
                      isPrimary
                          ? t.setPrimaryColor(_tempColor)
                          : t.setAccentColor(_tempColor);
                      Navigator.pop(ctx);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _tempColor,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    child: const Text('Terapkan',
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700)),
                  ),
                ),
              ]),
            ),
          ]),
        );
      }),
    );
  }

  // ── Reset Dialog ───────────────────────────────────────────────────────────
  void _showResetDialog(BuildContext context, ThemeProvider t) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _surface(t),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('Reset Tema?',
            style: TextStyle(fontWeight: FontWeight.w700)),
        content:
            const Text('Semua warna akan kembali ke default (Purple Dark).'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal')),
          ElevatedButton(
            onPressed: () {
              t.resetToDefault();
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
            child: const Text('Reset',
                style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}
