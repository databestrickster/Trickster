import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ─────────────────────────────────────────────────────────────
// CHAT THEME MODEL
// ─────────────────────────────────────────────────────────────
class ChatThemeData {
  final String id;
  final String name;
  final String emoji;

  // Bubble sent (dari gw)
  final Color bubbleMeColor;
  final Color bubbleMeTextColor;
  final Color bubbleMeTimeColor;

  // Bubble received (dari orang lain)
  final Color bubbleThemColor;
  final Color bubbleThemTextColor;
  final Color bubbleThemTimeColor;

  // Background
  final Color backgroundColor;
  final Color? backgroundPatternColor; // null = polos

  // Input bar
  final Color inputBarColor;
  final Color inputFieldColor;
  final Color inputTextColor;
  final Color inputHintColor;
  final Color sendButtonColor;
  final Color sendButtonIconColor;
  final Color micButtonColor;
  final Color micButtonIconColor;

  // AppBar
  final Color appBarColor;
  final Color appBarTextColor;
  final Color appBarIconColor;

  // Misc
  final bool darkStatusBar;
  final BorderRadius bubbleMeRadius;
  final BorderRadius bubbleThemRadius;

  const ChatThemeData({
    required this.id,
    required this.name,
    required this.emoji,
    required this.bubbleMeColor,
    required this.bubbleMeTextColor,
    required this.bubbleMeTimeColor,
    required this.bubbleThemColor,
    required this.bubbleThemTextColor,
    required this.bubbleThemTimeColor,
    required this.backgroundColor,
    this.backgroundPatternColor,
    required this.inputBarColor,
    required this.inputFieldColor,
    required this.inputTextColor,
    required this.inputHintColor,
    required this.sendButtonColor,
    required this.sendButtonIconColor,
    required this.micButtonColor,
    required this.micButtonIconColor,
    required this.appBarColor,
    required this.appBarTextColor,
    required this.appBarIconColor,
    this.darkStatusBar = true,
    this.bubbleMeRadius = const BorderRadius.only(
      topLeft: Radius.circular(16),
      topRight: Radius.circular(16),
      bottomLeft: Radius.circular(16),
      bottomRight: Radius.circular(3),
    ),
    this.bubbleThemRadius = const BorderRadius.only(
      topLeft: Radius.circular(16),
      topRight: Radius.circular(16),
      bottomLeft: Radius.circular(3),
      bottomRight: Radius.circular(16),
    ),
  });
}

// ─────────────────────────────────────────────────────────────
// PRESET THEMES
// ─────────────────────────────────────────────────────────────
class ChatThemePresets {
  static const List<ChatThemeData> all = [
    // 1. TRICKSTER Dark (default)
    ChatThemeData(
      id: 'TRICKSTER_dark',
      name: 'TRICKSTER Dark',
      emoji: '🌑',
      bubbleMeColor: Color(0xFF7B2FBE),
      bubbleMeTextColor: Colors.white,
      bubbleMeTimeColor: Color(0xAAFFFFFF),
      bubbleThemColor: Color(0xFF0D1B2A),
      bubbleThemTextColor: Colors.white,
      bubbleThemTimeColor: Color(0x99FFFFFF),
      backgroundColor: Color(0xFF060D18),
      inputBarColor: Color(0xFF0D1B2A),
      inputFieldColor: Color(0xFF060D18),
      inputTextColor: Colors.white,
      inputHintColor: Color(0x66FFFFFF),
      sendButtonColor: Color(0xFF7B2FBE),
      sendButtonIconColor: Colors.white,
      micButtonColor: Color(0x307B2FBE),
      micButtonIconColor: Color(0xFF7B2FBE),
      appBarColor: Color(0xFF0D1B2A),
      appBarTextColor: Colors.white,
      appBarIconColor: Color(0xFFB47AEA),
      darkStatusBar: true,
    ),

    // 2. iPhone iMessage
    ChatThemeData(
      id: 'iphone',
      name: 'iMessage',
      emoji: '🍎',
      bubbleMeColor: Color(0xFF34AADC),
      bubbleMeTextColor: Colors.white,
      bubbleMeTimeColor: Color(0xCCFFFFFF),
      bubbleThemColor: Color(0xFFE9E9EB),
      bubbleThemTextColor: Color(0xFF1C1C1E),
      bubbleThemTimeColor: Color(0x99000000),
      backgroundColor: Color(0xFFFFFFFF),
      inputBarColor: Color(0xFFF2F2F7),
      inputFieldColor: Color(0xFFFFFFFF),
      inputTextColor: Color(0xFF1C1C1E),
      inputHintColor: Color(0xFF8E8E93),
      sendButtonColor: Color(0xFF34AADC),
      sendButtonIconColor: Colors.white,
      micButtonColor: Color(0xFFE9E9EB),
      micButtonIconColor: Color(0xFF8E8E93),
      appBarColor: Color(0xFFF9F9F9),
      appBarTextColor: Color(0xFF1C1C1E),
      appBarIconColor: Color(0xFF34AADC),
      darkStatusBar: false,
      bubbleMeRadius: BorderRadius.only(
        topLeft: Radius.circular(18),
        topRight: Radius.circular(18),
        bottomLeft: Radius.circular(18),
        bottomRight: Radius.circular(4),
      ),
      bubbleThemRadius: BorderRadius.only(
        topLeft: Radius.circular(18),
        topRight: Radius.circular(18),
        bottomLeft: Radius.circular(4),
        bottomRight: Radius.circular(18),
      ),
    ),

    // 3. WhatsApp Green
    ChatThemeData(
      id: 'whatsapp',
      name: 'WhatsApp',
      emoji: '💚',
      bubbleMeColor: Color(0xFFDCF8C6),
      bubbleMeTextColor: Color(0xFF111B21),
      bubbleMeTimeColor: Color(0xFF667781),
      bubbleThemColor: Color(0xFFFFFFFF),
      bubbleThemTextColor: Color(0xFF111B21),
      bubbleThemTimeColor: Color(0xFF667781),
      backgroundColor: Color(0xFFEAE3D8),
      inputBarColor: Color(0xFFF0F2F5),
      inputFieldColor: Color(0xFFFFFFFF),
      inputTextColor: Color(0xFF111B21),
      inputHintColor: Color(0xFF8696A0),
      sendButtonColor: Color(0xFF00A884),
      sendButtonIconColor: Colors.white,
      micButtonColor: Color(0xFFE9EDEF),
      micButtonIconColor: Color(0xFF8696A0),
      appBarColor: Color(0xFF1F2C34),
      appBarTextColor: Colors.white,
      appBarIconColor: Color(0xFFAAB8C1),
      darkStatusBar: true,
    ),

    // 4. Light Classic
    ChatThemeData(
      id: 'light',
      name: 'Light',
      emoji: '☀️',
      bubbleMeColor: Color(0xFF6C63FF),
      bubbleMeTextColor: Colors.white,
      bubbleMeTimeColor: Color(0xCCFFFFFF),
      bubbleThemColor: Color(0xFFFFFFFF),
      bubbleThemTextColor: Color(0xFF1A1A2E),
      bubbleThemTimeColor: Color(0x88000000),
      backgroundColor: Color(0xFFEEF2F7),
      inputBarColor: Color(0xFFFFFFFF),
      inputFieldColor: Color(0xFFF0F0F5),
      inputTextColor: Color(0xFF1A1A2E),
      inputHintColor: Color(0xFF999999),
      sendButtonColor: Color(0xFF6C63FF),
      sendButtonIconColor: Colors.white,
      micButtonColor: Color(0xFFEEEEFF),
      micButtonIconColor: Color(0xFF6C63FF),
      appBarColor: Color(0xFFFFFFFF),
      appBarTextColor: Color(0xFF1A1A2E),
      appBarIconColor: Color(0xFF6C63FF),
      darkStatusBar: false,
    ),

    // 5. Midnight Purple (cyberpunk)
    ChatThemeData(
      id: 'midnight',
      name: 'Midnight',
      emoji: '🔮',
      bubbleMeColor: Color(0xFF9D4EDD),
      bubbleMeTextColor: Colors.white,
      bubbleMeTimeColor: Color(0xAAFFFFFF),
      bubbleThemColor: Color(0xFF1A0533),
      bubbleThemTextColor: Color(0xFFE0AAFF),
      bubbleThemTimeColor: Color(0x88E0AAFF),
      backgroundColor: Color(0xFF10002B),
      inputBarColor: Color(0xFF1A0533),
      inputFieldColor: Color(0xFF10002B),
      inputTextColor: Color(0xFFE0AAFF),
      inputHintColor: Color(0x66E0AAFF),
      sendButtonColor: Color(0xFF9D4EDD),
      sendButtonIconColor: Colors.white,
      micButtonColor: Color(0x309D4EDD),
      micButtonIconColor: Color(0xFFE0AAFF),
      appBarColor: Color(0xFF1A0533),
      appBarTextColor: Color(0xFFE0AAFF),
      appBarIconColor: Color(0xFFFF79C6),
      darkStatusBar: true,
    ),

    // 6. Aero Pink
    ChatThemeData(
      id: 'aero',
      name: 'Aero Pink',
      emoji: '🌸',
      bubbleMeColor: Color(0xFFFF6B9D),
      bubbleMeTextColor: Colors.white,
      bubbleMeTimeColor: Color(0xCCFFFFFF),
      bubbleThemColor: Color(0xFFFFF0F5),
      bubbleThemTextColor: Color(0xFF2D1B23),
      bubbleThemTimeColor: Color(0x88FF6B9D),
      backgroundColor: Color(0xFFFAE8F0),
      inputBarColor: Color(0xFFFFFFFF),
      inputFieldColor: Color(0xFFFFF0F7),
      inputTextColor: Color(0xFF2D1B23),
      inputHintColor: Color(0xAAFF6B9D),
      sendButtonColor: Color(0xFFFF6B9D),
      sendButtonIconColor: Colors.white,
      micButtonColor: Color(0xFFFFE0EE),
      micButtonIconColor: Color(0xFFFF6B9D),
      appBarColor: Color(0xFFFF6B9D),
      appBarTextColor: Colors.white,
      appBarIconColor: Colors.white,
      darkStatusBar: false,
    ),
  ];

  static ChatThemeData getById(String id) {
    return all.firstWhere((t) => t.id == id, orElse: () => all.first);
  }
}

// ─────────────────────────────────────────────────────────────
// CHAT THEME PROVIDER
// ─────────────────────────────────────────────────────────────
class ChatThemeProvider extends ChangeNotifier {
  static const String _key = 'chat_theme_id';
  ChatThemeData _theme = ChatThemePresets.all.first;

  ChatThemeProvider() {
    _load();
  }

  ChatThemeData get theme => _theme;

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final id = prefs.getString(_key) ?? 'TRICKSTER_dark';
    _theme = ChatThemePresets.getById(id);
    notifyListeners();
  }

  Future<void> setTheme(ChatThemeData t) async {
    _theme = t;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, t.id);
    notifyListeners();
  }
}
