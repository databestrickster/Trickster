// ============================================================
// auto_update.dart  lib/auto_update.dart
// Cek update otomatis berdasarkan role user
// BOLEH download: owner, reseller, vip, member_permanen
// TIDAK BOLEH: member biasa
// ============================================================

import 'config_service.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:package_info_plus/package_info_plus.dart';
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';



Future<void> checkForUpdate(
  BuildContext context, {
  required String username,
  required String password,
  required String role,
}) async {
  try {
    // 1. Ambil versi app yang terinstall
    final info = await PackageInfo.fromPlatform();
    final currentVersion = info.version;

    // 2. Fetch versi terbaru dari server
    final versionRes = await http
        .get(Uri.parse('${ConfigService.baseUrl}/version'))
        .timeout(const Duration(seconds: 10));

    if (versionRes.statusCode != 200) return;

    final versionData = jsonDecode(versionRes.body);
    final latestVersion = versionData['latest_version'] as String? ?? '';
    final apkUrl = versionData['apk_url'] as String? ?? '';
    final changelog = versionData['changelog'] as String? ?? '';
    final forceUpdate = versionData['force_update'] as bool? ?? false;

    // 3. Kalau versi sama / lebih lama, tidak perlu lanjut
    if (!_isNewerVersion(latestVersion, currentVersion)) return;

    // 4. Cek role  member biasa langsung skip
    final roleLower = role.toLowerCase();
    const allowedRoles = ['owner', 'reseller', 'vip', 'member_permanen'];

    if (!allowedRoles.contains(roleLower)) {
      // Member biasa  kalau force update tampilkan info tidak bisa download
      if (forceUpdate && context.mounted) {
        await _showBlockedDialog(context,
            reason:
                'Member biasa tidak memiliki akses download update.\nUpgrade ke Member Permanen atau VIP.');
      }
      return;
    }

    // 5. Validasi ke server (cek expired dll)
    final accessRes = await http
        .post(
          Uri.parse('${ConfigService.baseUrl}/check-update-access'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'username': username, 'password': password}),
        )
        .timeout(const Duration(seconds: 10));

    final accessData = jsonDecode(accessRes.body);
    final allowed = accessData['allowed'] as bool? ?? false;

    if (!context.mounted) return;

    if (!allowed) {
      if (forceUpdate) {
        await _showBlockedDialog(context,
            reason: accessData['reason'] ?? 'Akses ditolak.');
      }
      return;
    }

    // 6. Akses OK �� tampilkan dialog download
    await _showUpdateDialog(
      context,
      latestVersion: latestVersion,
      apkUrl: apkUrl,
      changelog: changelog,
      forceUpdate: forceUpdate,
      role: roleLower,
    );
  } catch (e) {
    debugPrint('[Update] Error: $e');
  }
}

// Bandingkan versi semver
bool _isNewerVersion(String latest, String current) {
  try {
    final l = latest.split('.').map(int.parse).toList();
    final c = current.split('.').map(int.parse).toList();
    for (var i = 0; i < 3; i++) {
      if (l[i] > c[i]) return true;
      if (l[i] < c[i]) return false;
    }
    return false;
  } catch (_) {
    return false;
  }
}

// ============================================================
// Dialog UPDATE  untuk user yang BOLEH download
// ============================================================
Future<void> _showUpdateDialog(
  BuildContext context, {
  required String latestVersion,
  required String apkUrl,
  required String changelog,
  required bool forceUpdate,
  required String role,
}) {
  return showDialog(
    context: context,
    barrierDismissible: !forceUpdate,
    builder: (_) => PopScope(
      canPop: !forceUpdate,
      child: AlertDialog(
        backgroundColor: const Color(0xFF111111),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: Color(0xFFFF2D2D), width: 1),
        ),
        title: Row(
          children: [
            const Text('� '),
            Expanded(
              child: Text(
                'Update v$latestVersion',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Badge role
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: _roleColor(role).withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: _roleColor(role).withValues(alpha: 0.5)),
              ),
              child: Text(
                _roleLabel(role),
                style: TextStyle(
                  color: _roleColor(role),
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              changelog,
              style: const TextStyle(color: Color(0xFF888888), fontSize: 13),
            ),
            if (forceUpdate) ...[
              const SizedBox(height: 12),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: Color(0xFFFFD600).withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                      color: Color(0xFFFFD600).withValues(alpha: 0.4)),
                ),
                child: const Text(
                  '️ Update ini wajib. Kamu tidak bisa skip.',
                  style: TextStyle(color: Color(0xFFFFD600), fontSize: 12),
                ),
              ),
            ],
          ],
        ),
        actions: [
          if (!forceUpdate)
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Nanti',
                  style: TextStyle(color: Color(0xFF555555))),
            ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFFF2D2D),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8)),
              padding:
                  const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            ),
            onPressed: () async {
              final uri = Uri.parse(apkUrl);
              if (await canLaunchUrl(uri)) {
                launchUrl(uri, mode: LaunchMode.externalApplication);
              }
            },
            child: const Text(
              '�️ Download Sekarang',
              style: TextStyle(
                  color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    ),
  );
}

// ============================================================
// Dialog BLOCKED  untuk user yang tidak boleh download
// ============================================================
Future<void> _showBlockedDialog(
  BuildContext context, {
  required String reason,
}) {
  return showDialog(
    context: context,
    barrierDismissible: false,
    builder: (_) => PopScope(
      canPop: false,
      child: AlertDialog(
        backgroundColor: const Color(0xFF111111),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: Color(0xFF444444), width: 1),
        ),
        title: const Text(
          '� Akses Dibatasi',
          style: TextStyle(
              color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(reason,
                style:
                    const TextStyle(color: Color(0xFF888888), fontSize: 13)),
            const SizedBox(height: 12),
            const Text(
              'Hubungi owner untuk upgrade akun kamu.',
              style: TextStyle(color: Color(0xFFFFD600), fontSize: 12),
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF2a2a2a),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8)),
            ),
            onPressed: () => Navigator.pop(context),
            child:
                const Text('Tutup', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    ),
  );
}

Color _roleColor(String role) {
  switch (role) {
    case 'owner':            return const Color(0xFFFF2D2D);
    case 'reseller':         return const Color(0xFFFF9100);
    case 'vip':              return const Color(0xFFFFD600);
    case 'member_permanen':  return const Color(0xFF00E676);
    default:                 return const Color(0xFF555555);
  }
}

String _roleLabel(String role) {
  switch (role) {
    case 'owner':            return '� OWNER';
    case 'reseller':         return '💼 RESELLER';
    case 'vip':              return '� VIP';
    case 'member_permanen':  return '�� MEMBER PERMANEN';
    default:                 return role.toUpperCase();
  }
}
