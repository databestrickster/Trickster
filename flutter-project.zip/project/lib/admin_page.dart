import 'config_service.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:io';
import 'theme_provider.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';

class AdminPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final String username;

  const AdminPage({super.key, required this.sessionKey, required this.userRole, required this.username});

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];
  
  Map<String, dynamic>? currentUser;
  String currentUserRole = 'unknown';
  String currentUsername = '';

  final List<String> roleOptions = ['tk', 'owner', 'reseller', 'vip', 'member_permanen', 'member'];
  String selectedRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 20;

  final deleteController = TextEditingController();
  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  
  String newUserRole = 'member';
  List<String> creatableRoles = [];
  List<String> parentOptions = ['SYSTEM'];
  String selectedParent = 'SYSTEM';
  List<Map<String, dynamic>> availableParents = [];

  bool isLoading = false;
  File? _buktiFile;
  bool _useWa = false;
  bool _useTelegram = false;
  final waController = TextEditingController();
  final telegramController = TextEditingController();

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    currentUserRole = widget.userRole;
    currentUsername = widget.username;
    _setCreatableRoles();
    _fetchUsers();
  }

  void _setCreatableRoles() {
    switch (currentUserRole) {
      case 'tk':
        creatableRoles = ['vip', 'owner', 'reseller', 'member_permanen', 'member'];
        break;
      case 'vip':
        creatableRoles = ['owner', 'reseller', 'member_permanen', 'member'];
        break;
      case 'owner':
        creatableRoles = ['reseller', 'member_permanen', 'member'];
        break;
      case 'reseller':
        creatableRoles = ['member_permanen', 'member'];
        break;
      default:
        creatableRoles = [];
    }
    
    if (creatableRoles.isNotEmpty) {
      newUserRole = creatableRoles.first;
    }
    
    _updateParentOptions();
  }

  Future<String?> _uploadToCatbox(File file) async {
    try {
      final request = http.MultipartRequest('POST', Uri.parse('https://catbox.moe/user/api.php'));
      request.fields['reqtype'] = 'fileupload';
      final bytes = await file.readAsBytes();
      final filename = file.path.split('/').last;
      request.files.add(http.MultipartFile.fromBytes('fileToUpload', bytes, filename: filename));
      final response = await request.send().timeout(const Duration(seconds: 30));
      final body = await response.stream.bytesToString();
      if (body.startsWith('https://')) return body.trim();
      return null;
    } catch (e) {
      debugPrint('[ERROR Catbox] $e');
      return null;
    }
  }

  Future<void> _sendTelegramNotification(
    String username,
    String role,
    String duration,
    String createdBy, {
    String? waNumber,
    String? telegramId,
    File? buktiFile,
  }) async {
    try {
      String contactInfo = '';
      if (waNumber != null && waNumber.isNotEmpty) {
        contactInfo += '\n📱 WhatsApp: *' + waNumber + '*';
      }
      if (telegramId != null && telegramId.isNotEmpty) {
        contactInfo += '\n💬 ID Telegram: *' + telegramId + '*';
      }

      String buktiText = '';
      if (buktiFile != null) {
        final url = await _uploadToCatbox(buktiFile);
        if (url != null) {
          buktiText = '\n🖼 Bukti: ' + url;
        } else {
          buktiText = '\n(Foto bukti gagal diupload)';
        }
      }

      final now = DateTime.now().toLocal().toString().substring(0, 19);
      final message = '✅ *AKUN BARU DIBUAT!*\n\n'
          '👤 Username: *' + username + '*\n'
          '🎭 Role: *' + role + '*\n'
          '📅 Durasi: ' + duration + ' hari' +
          contactInfo +
          buktiText + '\n' +
          '👑 Dibuat Oleh: *' + createdBy + '*\n' +
          '🕐 Waktu: ' + now;

      await http.post(
        Uri.parse(ConfigService.baseUrl + '/sendTelegramNotif'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'message': message, 'type': 'new_account'}),
      );
    } catch (e) {
      debugPrint('[ERROR notif] $e');
    }
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('${ConfigService.baseUrl}/listUsers?key=$sessionKey'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _updateParentOptions();
        _filterAndPaginate();
      } else {
        _alert("Error", data['message'] ?? 'Tidak diizinkan melihat daftar user.');
      }
    } catch (_) {
      _alert("Error", "Gagal memuat user list.");
    }
    setState(() => isLoading = false);
  }

  void _updateParentOptions() {
    availableParents = [];
    
    if (newUserRole == 'tk' || newUserRole == 'vip') {
      availableParents = fullUserList
          .where((u) => u['role'] == 'tk' || u['role'] == 'vip')
          .map((u) => {'username': u['username'], 'role': u['role']})
          .toList();
      parentOptions = ['SYSTEM', ...availableParents.map((p) => p['username'].toString())];
    }
    else if (newUserRole == 'owner') {
      availableParents = fullUserList
          .where((u) => u['role'] == 'tk' || u['role'] == 'vip')
          .map((u) => {'username': u['username'], 'role': u['role']})
          .toList();
      parentOptions = ['SYSTEM', ...availableParents.map((p) => p['username'].toString())];
    }
    else if (newUserRole == 'reseller') {
      availableParents = fullUserList
          .where((u) => u['role'] == 'tk' || u['role'] == 'vip' || u['role'] == 'owner' || u['role'] == 'reseller')
          .map((u) => {'username': u['username'], 'role': u['role']})
          .toList();
      parentOptions = ['SYSTEM', ...availableParents.map((p) => p['username'].toString())];
    }
    else if (newUserRole == 'member' || newUserRole == 'member_permanen') {
      availableParents = fullUserList
          .where((u) => u['role'] == 'tk' || u['role'] == 'vip' || u['role'] == 'owner' || u['role'] == 'reseller' || u['role'] == 'member' || u['role'] == 'member_permanen')
          .map((u) => {'username': u['username'], 'role': u['role']})
          .toList();
      parentOptions = ['SYSTEM', ...availableParents.map((p) => p['username'].toString())];
    }
    
    if (parentOptions.isNotEmpty) {
      selectedParent = parentOptions.first;
    }
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList
          .where((u) => u['role'] == selectedRole)
          .toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(
      start,
      end > filteredList.length ? filteredList.length : end,
    );
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser(String username) async {
    if (username.isEmpty) return;

    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('${ConfigService.baseUrl}/deleteUser?key=$sessionKey&username=$username'),
      );
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert("Berhasil", "User '${data['user']['username']}' telah dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Tidak dapat menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _pickBukti() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (picked != null) {
      setState(() => _buktiFile = File(picked.path));
    }
  }



    Future<void> _createAccount() async {
    final username = createUsernameController.text.trim();
    final password = createPasswordController.text.trim();
    final day = createDayController.text.trim();

    final effectiveDay = newUserRole == 'member_permanen' ? '36500' : day;
    if (username.isEmpty || password.isEmpty || (newUserRole != 'member_permanen' && day.isEmpty)) {
      _alert("Error", "Semua field wajib diisi.");
      return;
    }

    if (newUserRole != 'member_permanen' && int.tryParse(day) == null) {
      _alert("Error", "Durasi harus berupa angka.");
      return;
    }

    if (!creatableRoles.contains(newUserRole)) {
      _alert("Tidak Diizinkan", "Anda sebagai $currentUserRole tidak diizinkan membuat akun $newUserRole.");
      return;
    }

    if (_buktiFile == null) {
      _alert("Peringatan", "Harap upload bukti transaksi terlebih dahulu.");
      return;
    }

    if (!_useWa && !_useTelegram) {
      _alert("Peringatan", "Harap isi minimal salah satu kontak (WhatsApp atau Telegram).");
      return;
    }

    if (_useWa && waController.text.trim().isEmpty) {
      _alert("Peringatan", "Nomor WhatsApp tidak boleh kosong.");
      return;
    }

    if (_useTelegram && telegramController.text.trim().isEmpty) {
      _alert("Peringatan", "ID Telegram tidak boleh kosong.");
      return;
    }

    setState(() => isLoading = true);
    try {
      String url;
      if (newUserRole == 'member' || newUserRole == 'member_permanen') {
        url = '${ConfigService.baseUrl}/createAccount?key=$sessionKey&newUser=$username&pass=$password&day=$effectiveDay&role=$newUserRole';
      } else if (selectedParent != 'SYSTEM') {
        url = '${ConfigService.baseUrl}/userAdd?key=$sessionKey&username=$username&password=$password&day=$effectiveDay&role=$newUserRole&parent=$selectedParent';
      } else {
        url = '${ConfigService.baseUrl}/userAdd?key=$sessionKey&username=$username&password=$password&day=$effectiveDay&role=$newUserRole';
      }

      final res = await http.get(Uri.parse(url));
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        final roleLabel = newUserRole.toUpperCase();
        final parentLabel = data['user']?['parent'] ?? 'SYSTEM';
        await _sendTelegramNotification(
          username,
          roleLabel,
          effectiveDay == '36500' ? 'Permanen' : effectiveDay,
          currentUsername,
          waNumber: _useWa ? waController.text.trim() : null,
          telegramId: _useTelegram ? telegramController.text.trim() : null,
          buktiFile: _buktiFile,
        );
        _alert("Sukses", "Akun $roleLabel '$username' berhasil dibuat.\nParent: $parentLabel");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        waController.clear();
        telegramController.clear();
        setState(() {
          _buktiFile = null;
          _useWa = false;
          _useTelegram = false;
        });
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    final theme = Theme.of(context);
    final accentColor = theme.colorScheme.secondary;
    
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: theme.scaffoldBackgroundColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: accentColor.withValues(alpha: 0.3)),
        ),
        title: Row(
          children: [
            Icon(
              title == "Berhasil" ? Icons.check_circle : 
              title == "Error" ? Icons.error : 
              Icons.info_outline,
              color: title == "Berhasil" ? Colors.green : 
                     title == "Error" ? Colors.red : accentColor,
            ),
            const SizedBox(width: 10),
            Text(title, style: TextStyle(color: Colors.white)),
          ],
        ),
        content: Text(message, style: TextStyle(color: Colors.white70)),
        actions: [
          Center(
            child: ElevatedButton(
              onPressed: () => Navigator.pop(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: accentColor,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text("OK", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

  Color _getRoleColor(String role) {
    switch (role) {
      case 'tk': return Colors.red;
      case 'vip': return Colors.amber;
      case 'owner': return Colors.purple;
      case 'reseller': return Colors.blue;
      case 'member_permanen': return Colors.teal;
      case 'member': return Colors.green;
      default: return Colors.grey;
    }
  }

  IconData _getRoleIcon(String role) {
    switch (role) {
      case 'tk': return Icons.security;
      case 'vip': return Icons.star;
      case 'owner': return Icons.admin_panel_settings;
      case 'reseller': return Icons.storefront;
      case 'member_permanen': return Icons.verified;
      case 'member': return Icons.person;
      default: return Icons.person_outline;
    }
  }

  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
    bool obscureText = false,
    String hint = "",
  }) {
    final theme = Theme.of(context);
    final accentColor = theme.colorScheme.secondary;
    
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextField(
        controller: controller,
        keyboardType: type,
        obscureText: obscureText,
        style: TextStyle(color: Colors.white),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint.isNotEmpty ? hint : null,
          hintStyle: const TextStyle(color: Colors.white30, fontSize: 12),
          labelStyle: TextStyle(color: accentColor),
          prefixIcon: Icon(icon, color: accentColor, size: 20),
          filled: true,
          fillColor: theme.cardColor.withValues(alpha: 0.2),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: accentColor, width: 1.5),
          ),
        ),
      ),
    );
  }

  Widget _buildGlassCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
    Color? headerColor,
  }) {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = headerColor ?? theme.colorScheme.secondary;
    
    return Container(
      margin: const EdgeInsets.only(bottom: 24),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            theme.cardColor.withValues(alpha: 0.4),
            theme.cardColor.withValues(alpha: 0.2),
          ],
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
        boxShadow: [
          BoxShadow(
            color: primaryColor.withValues(alpha: 0.08),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [accentColor, accentColor.withValues(alpha: 0.6)]),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: Colors.white, size: 20),
              ),
              const SizedBox(width: 14),
              Text(
                title,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          ...children,
        ],
      ),
    );
  }

  Widget _buildRoleSelector() {
    if (creatableRoles.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.red.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.red.withValues(alpha: 0.3)),
        ),
        child: const Center(
          child: Text(
            "Tidak memiliki izin untuk membuat akun",
            style: TextStyle(color: Colors.white70),
          ),
        ),
      );
    }

    final theme = Theme.of(context);
    final accentColor = theme.colorScheme.secondary;
    
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: theme.cardColor.withValues(alpha: 0.2),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withValues(alpha: 0.1)),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: newUserRole,
          isExpanded: true,
          dropdownColor: theme.cardColor,
          style: const TextStyle(color: Colors.white),
          icon: Icon(Icons.arrow_drop_down, color: accentColor),
          items: creatableRoles.map((role) {
            Color roleColor = _getRoleColor(role);
            IconData roleIcon = _getRoleIcon(role);
            
            return DropdownMenuItem(
              value: role,
              child: Row(
                children: [
                  Icon(roleIcon, color: roleColor, size: 18),
                  const SizedBox(width: 10),
                  Text(role.toUpperCase(), style: TextStyle(color: roleColor, fontWeight: FontWeight.w600)),
                ],
              ),
            );
          }).toList(),
          onChanged: (value) {
            setState(() {
              newUserRole = value!;
              _updateParentOptions();
            });
          },
        ),
      ),
    );
  }

  Widget _buildParentSelector() {
    if (parentOptions.isEmpty || parentOptions.length == 1) {
      return const SizedBox.shrink();
    }

    final theme = Theme.of(context);
    final accentColor = theme.colorScheme.secondary;
    
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: theme.cardColor.withValues(alpha: 0.2),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withValues(alpha: 0.1)),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: selectedParent,
          isExpanded: true,
          dropdownColor: theme.cardColor,
          style: const TextStyle(color: Colors.white),
          icon: Icon(Icons.arrow_drop_down, color: accentColor),
          items: parentOptions.map((parent) {
            String? parentRole;
            Color parentColor = Colors.white70;
            IconData parentIcon = Icons.computer;
            
            if (parent != 'SYSTEM') {
              final parentData = availableParents.firstWhere(
                (p) => p['username'] == parent,
                orElse: () => {},
              );
              parentRole = parentData['role'];
              parentColor = _getRoleColor(parentRole ?? '');
              parentIcon = _getRoleIcon(parentRole ?? '');
            }

            return DropdownMenuItem(
              value: parent,
              child: Row(
                children: [
                  Icon(parentIcon, color: parentColor, size: 16),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      parent == 'SYSTEM' ? 'SYSTEM' : '$parent',
                      style: TextStyle(color: parentColor),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  if (parentRole != null)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: parentColor.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        parentRole.toUpperCase(),
                        style: TextStyle(color: parentColor, fontSize: 9),
                      ),
                    ),
                ],
              ),
            );
          }).toList(),
          onChanged: (value) {
            setState(() {
              selectedParent = value!;
            });
          },
        ),
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    final theme = Theme.of(context);
    final accentColor = theme.colorScheme.secondary;
    
    String userRole = user['role'] ?? 'member';
    Color roleColor = _getRoleColor(userRole);
    IconData roleIcon = _getRoleIcon(userRole);
    
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: theme.cardColor.withValues(alpha: 0.2),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: roleColor.withValues(alpha: 0.2)),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [roleColor, roleColor.withValues(alpha: 0.5)]),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Icon(roleIcon, color: Colors.white, size: 22),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        user['username'],
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: roleColor.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        userRole.toUpperCase(),
                        style: TextStyle(
                          color: roleColor,
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Icon(Icons.calendar_today, size: 10, color: Colors.white54),
                    const SizedBox(width: 4),
                    Text(
                      "Exp: ${user['expiredDate']}",
                      style: const TextStyle(color: Colors.white54, fontSize: 11),
                    ),
                    const SizedBox(width: 12),
                    Icon(Icons.account_tree, size: 10, color: Colors.white54),
                    const SizedBox(width: 4),
                    Text(
                      "Parent: ${user['parent'] ?? 'SYSTEM'}",
                      style: const TextStyle(color: Colors.white54, fontSize: 11),
                    ),
                  ],
                ),
              ],
            ),
          ),
          if (_canDeleteUser(userRole))
            Container(
              decoration: BoxDecoration(
                color: Colors.red.withValues(alpha: 0.15),
                shape: BoxShape.circle,
              ),
              child: IconButton(
                icon: const Icon(Icons.delete_outline, color: Colors.redAccent, size: 20),
                onPressed: () async {
                  final confirm = await showDialog<bool>(
                    context: context,
                    builder: (_) => AlertDialog(
                      backgroundColor: theme.scaffoldBackgroundColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                        side: BorderSide(color: accentColor.withValues(alpha: 0.3)),
                      ),
                      title: const Row(
                        children: [
                          Icon(Icons.warning, color: Colors.red),
                          SizedBox(width: 10),
                          Text("Konfirmasi Hapus", style: TextStyle(color: Colors.white)),
                        ],
                      ),
                      content: Text(
                        "Yakin ingin menghapus user ini?",
                        style: const TextStyle(color: Colors.white70),
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context, false),
                          child: const Text("Batal", style: TextStyle(color: Colors.white70)),
                        ),
                        ElevatedButton(
                          onPressed: () => Navigator.pop(context, true),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red,
                          ),
                          child: const Text("Hapus"),
                        ),
                      ],
                    ),
                  );

                  if (confirm == true) {
                    _deleteUser(user['username']);
                  }
                },
              ),
            ),
        ],
      ),
    );
  }

  bool _canDeleteUser(String targetRole) {
    Map<String, int> roleLevel = {
      'tk': 6,
      'vip': 5,
      'owner': 4,
      'reseller': 3,
      'member_permanen': 2,
      'member': 1,
    };
    
    int currentLevel = roleLevel[currentUserRole] ?? 0;
    int targetLevel = roleLevel[targetRole] ?? 0;
    
    return currentLevel > targetLevel;
  }

  Widget _buildPagination() {
    final theme = Theme.of(context);
    final accentColor = theme.colorScheme.secondary;
    
    if (totalPages <= 1) return const SizedBox.shrink();
    
    return Container(
      margin: const EdgeInsets.only(top: 16),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        alignment: WrapAlignment.center,
        children: List.generate(totalPages, (index) {
          final page = index + 1;
          final isActive = currentPage == page;
          return GestureDetector(
            onTap: () => setState(() => currentPage = page),
            child: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                gradient: isActive
                    ? LinearGradient(colors: [accentColor, accentColor.withValues(alpha: 0.7)])
                    : null,
                color: isActive ? null : theme.cardColor.withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: isActive ? accentColor : Colors.white.withValues(alpha: 0.1),
                ),
              ),
              child: Center(
                child: Text(
                  "$page",
                  style: TextStyle(
                    color: isActive ? Colors.white : Colors.white54,
                    fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                  ),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildFilterRow() {
    final filters = [
      {'role': 'tk', 'icon': Icons.security, 'color': Colors.red, 'label': 'TK'},
      {'role': 'vip', 'icon': Icons.star, 'color': Colors.amber, 'label': 'VIP'},
      {'role': 'owner', 'icon': Icons.admin_panel_settings, 'color': Colors.purple, 'label': 'OWNER'},
      {'role': 'reseller', 'icon': Icons.storefront, 'color': Colors.blue, 'label': 'RESELLER'},
      {'role': 'member_permanen', 'icon': Icons.verified, 'color': Colors.teal, 'label': 'PERMANEN'},
      {'role': 'member', 'icon': Icons.person, 'color': Colors.green, 'label': 'MEMBER'},
    ];
    
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: filters.map((filter) {
          final isSelected = selectedRole == filter['role'];
          final color = filter['color'] as Color;
          
          return Padding(
            padding: const EdgeInsets.only(right: 10),
            child: FilterChip(
              label: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(filter['icon'] as IconData, size: 14, color: isSelected ? Colors.white : color),
                  const SizedBox(width: 6),
                  Text(filter['label'] as String),
                ],
              ),
              selected: isSelected,
              onSelected: (selected) {
                setState(() {
                  selectedRole = filter['role'] as String;
                  _filterAndPaginate();
                });
              },
              backgroundColor: Colors.transparent,
              selectedColor: color,
              checkmarkColor: Colors.white,
              labelStyle: TextStyle(
                color: isSelected ? Colors.white : Colors.white70,
                fontSize: 12,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              ),
              side: BorderSide(color: isSelected ? color : Colors.white.withValues(alpha: 0.2)),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildInfoBanner() {
    if (creatableRoles.isEmpty) return const SizedBox.shrink();
    
    final theme = Theme.of(context);
    final accentColor = theme.colorScheme.secondary;
    
    final roleLabels = creatableRoles.map((r) {
      switch(r) {
        case 'tk': return 'TK';
        case 'vip': return 'VIP';
        case 'owner': return 'OWNER';
        case 'reseller': return 'RESELLER';
        case 'member_permanen': return 'MEMBER PERMANEN';
        case 'member': return 'MEMBER';
        default: return r.toUpperCase();
      }
    }).join(' • ');
    
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 16),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [accentColor.withValues(alpha: 0.15), accentColor.withValues(alpha: 0.05)],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: accentColor.withValues(alpha: 0.3)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: accentColor.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(Icons.add_circle_outline, color: accentColor, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Dapat Membuat",
                  style: TextStyle(color: accentColor, fontSize: 11, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 2),
                Text(
                  roleLabels,
                  style: const TextStyle(color: Colors.white70, fontSize: 12),
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;
    final accentColor = theme.colorScheme.secondary;
    final bgColor = theme.scaffoldBackgroundColor;
    
    Color userRoleColor = _getRoleColor(currentUserRole);
    
    return Scaffold(
      backgroundColor: bgColor,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgColor, primaryColor.withValues(alpha: 0.05), bgColor],
          ),
        ),
        child: SafeArea(
          child: isLoading
              ? Center(
                  child: CircularProgressIndicator(color: accentColor),
                )
              : SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // HEADER
                      Center(
                        child: Column(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(colors: [accentColor, primaryColor]),
                                shape: BoxShape.circle,
                              ),
                              child: Icon(Icons.admin_panel_settings, color: Colors.white, size: 36),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              "ADMIN DASHBOARD",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 2,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                              decoration: BoxDecoration(
                                color: userRoleColor.withValues(alpha: 0.15),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: userRoleColor.withValues(alpha: 0.5)),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(_getRoleIcon(currentUserRole), color: userRoleColor, size: 14),
                                  const SizedBox(width: 6),
                                  Text(
                                    currentUserRole.toUpperCase(),
                                    style: TextStyle(
                                      color: userRoleColor,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      const SizedBox(height: 24),
                      
                      // INFO BANNER
                      _buildInfoBanner(),
                      
                      // DELETE USER SECTION
                      _buildGlassCard(
                        title: "DELETE USER",
                        icon: Icons.delete_outline,
                        headerColor: Colors.red,
                        children: [
                          _buildInput(
                            label: "Username Target",
                            controller: deleteController,
                            icon: Icons.person_outline,
                          ),
                          const SizedBox(height: 8),
                          SizedBox(
                            width: double.infinity,
                            height: 48,
                            child: ElevatedButton(
                              onPressed: isLoading ? null : () {
                                if (deleteController.text.isNotEmpty) {
                                  _deleteUser(deleteController.text);
                                } else {
                                  _alert("Error", "Masukkan username!");
                                }
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.redAccent,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              ),
                              child: const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(Icons.delete, size: 18),
                                  SizedBox(width: 8),
                                  Text("DELETE ACCOUNT", style: TextStyle(fontWeight: FontWeight.bold)),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),

                      // CREATE ACCOUNT SECTION
                      if (creatableRoles.isNotEmpty)
                      _buildGlassCard(
                        title: "CREATE ACCOUNT",
                        icon: Icons.person_add,
                        headerColor: Colors.green,
                        children: [
                          _buildInput(
                            label: "Username",
                            controller: createUsernameController,
                            icon: Icons.person_outline,
                          ),
                          _buildInput(
                            label: "Password",
                            controller: createPasswordController,
                            icon: Icons.lock_outline,
                            obscureText: true,
                          ),
                          _buildInput(
                            label: "Durasi (Hari)",
                            controller: createDayController,
                            icon: Icons.calendar_today,
                            type: TextInputType.number,
                          ),
                          
                          _buildRoleSelector(),
                          _buildParentSelector(),

                          const SizedBox(height: 12),
                          // BUKTI TRANSAKSI
                          GestureDetector(
                            onTap: _pickBukti,
                            child: Container(
                              margin: const EdgeInsets.only(bottom: 12),
                              padding: const EdgeInsets.all(14),
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(
                                  color: _buktiFile != null
                                      ? Colors.green.withOpacity(0.6)
                                      : Colors.white.withOpacity(0.2),
                                  width: 1.5,
                                ),
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(8),
                                    decoration: BoxDecoration(
                                      color: _buktiFile != null
                                          ? Colors.green.withOpacity(0.8)
                                          : Colors.white24,
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Icon(
                                      _buktiFile != null ? Icons.check_circle : Icons.upload_file,
                                      color: Colors.white,
                                      size: 18,
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Bukti Transaksi *",
                                          style: TextStyle(
                                            color: _buktiFile != null ? Colors.green : Colors.white70,
                                            fontWeight: FontWeight.w600,
                                            fontSize: 13,
                                          ),
                                        ),
                                        Text(
                                          _buktiFile != null
                                              ? _buktiFile!.path.split('/').last
                                              : "Tap untuk upload foto bukti",
                                          style: const TextStyle(color: Colors.white38, fontSize: 11),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ],
                                    ),
                                  ),
                                  if (_buktiFile != null)
                                    GestureDetector(
                                      onTap: () => setState(() => _buktiFile = null),
                                      child: Icon(Icons.close, color: Colors.red.shade300, size: 18),
                                    ),
                                ],
                              ),
                            ),
                          ),
                          // WHATSAPP CHECKBOX
                          Container(
                            margin: const EdgeInsets.only(bottom: 6),
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: Colors.green.withOpacity(0.2)),
                            ),
                            child: CheckboxListTile(
                              value: _useWa,
                              onChanged: (v) => setState(() => _useWa = v ?? false),
                              title: const Text("Punya WhatsApp", style: TextStyle(color: Colors.white70, fontSize: 13)),
                              secondary: const Icon(Icons.phone_android, color: Colors.green, size: 20),
                              activeColor: Colors.green,
                              controlAffinity: ListTileControlAffinity.trailing,
                              contentPadding: const EdgeInsets.symmetric(horizontal: 10),
                              dense: true,
                            ),
                          ),
                          if (_useWa)
                            _buildInput(
                              label: "Nomor WhatsApp",
                              controller: waController,
                              icon: Icons.phone,
                              type: TextInputType.phone,
                              hint: "08xxxxxxxxx",
                            ),
                          // TELEGRAM CHECKBOX
                          Container(
                            margin: const EdgeInsets.only(bottom: 12),
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: Colors.blue.withOpacity(0.2)),
                            ),
                            child: CheckboxListTile(
                              value: _useTelegram,
                              onChanged: (v) => setState(() => _useTelegram = v ?? false),
                              title: const Text("Punya Telegram", style: TextStyle(color: Colors.white70, fontSize: 13)),
                              secondary: const Icon(Icons.send, color: Colors.blue, size: 20),
                              activeColor: Colors.blue,
                              controlAffinity: ListTileControlAffinity.trailing,
                              contentPadding: const EdgeInsets.symmetric(horizontal: 10),
                              dense: true,
                            ),
                          ),
                          if (_useTelegram)
                            _buildInput(
                              label: "ID / Username Telegram",
                              controller: telegramController,
                              icon: Icons.send,
                              hint: "@username atau 123456789",
                            ),

                          const SizedBox(height: 8),
                          SizedBox(
                            width: double.infinity,
                            height: 48,
                            child: ElevatedButton(
                              onPressed: isLoading ? null : _createAccount,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              ),
                              child: isLoading
                                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                                  : const Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(Icons.add, size: 18),
                                        SizedBox(width: 8),
                                        Text("CREATE ACCOUNT", style: TextStyle(fontWeight: FontWeight.bold)),
                                      ],
                                    ),
                            ),
                          ),
                        ],
                      ),

                      // USER MANAGEMENT SECTION
                      _buildGlassCard(
                        title: "USER MANAGEMENT",
                        icon: Icons.people_outline,
                        children: [
                          _buildFilterRow(),
                          const SizedBox(height: 16),
                          if (filteredList.isEmpty)
                            Center(
                              child: Padding(
                                padding: const EdgeInsets.symmetric(vertical: 40),
                                child: Column(
                                  children: [
                                    Icon(Icons.people_outline, size: 48, color: Colors.white24),
                                    const SizedBox(height: 12),
                                    Text(
                                      "Tidak ada user dengan role ini",
                                      style: TextStyle(color: Colors.white38),
                                    ),
                                  ],
                                ),
                              ),
                            )
                          else
                            Column(
                              children: [
                                ..._getCurrentPageData().map((u) => _buildUserItem(u)).toList(),
                                _buildPagination(),
                              ],
                            ),
                        ],
                      ),
                      
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
        ),
      ),
    );
  }
}