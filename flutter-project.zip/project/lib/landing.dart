import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:audioplayers/audioplayers.dart';
import 'package:dio/dio.dart';
import 'package:open_filex/open_filex.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:android_id/android_id.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'config_service.dart';
import 'asset_service.dart';
import 'download_assets_dialog.dart';
import 'splash.dart';

// ─────────────────────────────────────────────
// CONSTANTS
// ─────────────────────────────────────────────

const Color _cPrimary  = Color(0xFF8B5CF6);
const Color _cPrimary2 = Color(0xFFA78BFA);
const Color _cAccent   = Color(0xFF22D3EE);
const Color _cBg       = Color(0xFF080810);
const Color _cSurface1 = Color(0xFF0E0E1A);
const Color _cSurface2 = Color(0xFF13131F);
const Color _cText1    = Color(0xFFFFFFFF);
const Color _cText2    = Color(0x80FFFFFF);
const Color _cText3    = Color(0x33FFFFFF);
const Color _cLine     = Color(0x0FFFFFFF);
const Color _cGreen    = Color(0xFF4ADE80);

// ─────────────────────────────────────────────
// MODEL
// ─────────────────────────────────────────────
class UpdateInfo {
  final String latestVersion;
  final String apkUrl;
  final String changelog;
  final bool forceUpdate;

  const UpdateInfo({
    required this.latestVersion,
    required this.apkUrl,
    required this.changelog,
    required this.forceUpdate,
  });

  factory UpdateInfo.fromJson(Map<String, dynamic> json) => UpdateInfo(
        latestVersion: json['latest_version'] ?? '0.0.0',
        apkUrl:        json['apk_url']         ?? '',
        changelog:     json['changelog']        ?? '',
        forceUpdate:   json['force_update']     ?? false,
      );
}

bool _isNewer(String latest, String current) {
  try {
    final l = latest.split('.').map(int.parse).toList();
    final c = current.split('.').map(int.parse).toList();
    for (int i = 0; i < 3; i++) {
      final lv = i < l.length ? l[i] : 0;
      final cv = i < c.length ? c[i] : 0;
      if (lv > cv) return true;
      if (lv < cv) return false;
    }
    return false;
  } catch (_) {
    return false;
  }
}

// ─────────────────────────────────────────────
// LANDING PAGE
// ─────────────────────────────────────────────
class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> with TickerProviderStateMixin, WidgetsBindingObserver {

  // Video
  late VideoPlayerController _video;
  VideoPlayerController? _bgVideo;
  bool _bgVideoReady = false;

  // Animations
  late AnimationController _fadeCtrl;
  late AnimationController _orbitCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _shimmerCtrl;
  late AnimationController _blink1Ctrl;
  late AnimationController _blink2Ctrl;

  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;
  late Animation<double> _orbitAnim;
  late Animation<double> _pulseAnim;
  late Animation<double> _shimmerAnim;
  late Animation<double> _blink1Anim;
  late Animation<double> _blink2Anim;

  // State
  bool   _isProcessing   = false;
  bool   _btnPressed     = false;
  bool   _checkingUpdate = true;
  bool   _hasUpdate      = false;
  bool   _isDownloading  = false;
  bool   _forceUpdate    = false;
  double _dlProgress     = 0.0;
  String _dlStatus       = '';
  String _dlMb           = '';
  UpdateInfo? _updateInfo;
  String _currentVersion = '';

  // Status koneksi & server
  bool _isOnline     = true;
  bool _serverOnline = false;
  bool _serverBusy   = false;
  Timer? _statusTimer;

  // Jam realtime
  String _timeStr = '';
  Timer? _timer;

  // ── Welcome Overlay ──
  bool _showWelcomeOverlay = true;
  int _welcomeStep = 0;
  late AnimationController _welcomeCtrl;
  late Animation<double> _welcomeFadeAnim;
  late AnimationController _colorCtrl;
  late Animation<double> _colorAnim;

  // ── INIT ──────────────────────────────────
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initAnimations();
    _initVideo();
    _initStartup();
    _updateTime();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _updateTime());
    _checkConnectivity();
    _checkServer();
    _statusTimer = Timer.periodic(const Duration(seconds: 30), (_) async {
      _checkConnectivity();
      await ConfigService.refresh();
      _checkServer();
    });

    _welcomeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _welcomeFadeAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _welcomeCtrl, curve: Curves.easeInOut),
    );
    _runWelcomeSequence();
  }

  void _updateTime() {
    final now = DateTime.now();
    final h = now.hour.toString().padLeft(2, '0');
    final m = now.minute.toString().padLeft(2, '0');
    final s = now.second.toString().padLeft(2, '0');
    if (mounted) setState(() => _timeStr = '$h:$m:$s');
  }

  Future<void> _checkConnectivity() async {
    try {
      final result = await InternetAddress.lookup('google.com')
          .timeout(const Duration(seconds: 5));
      if (mounted) setState(() => _isOnline = result.isNotEmpty && result[0].rawAddress.isNotEmpty);
    } catch (_) {
      if (mounted) setState(() => _isOnline = false);
    }
  }

  Future<void> _checkServer() async {
    try {
      final res = await http.get(Uri.parse('${ConfigService.baseUrl}/ping'))
          .timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final cpu = double.tryParse(data['cpu'].toString()) ?? 0;
        final isBusy = cpu > 100;
        if (mounted) setState(() {
          _serverOnline = true;
          _serverBusy = isBusy;
        });
      } else {
        if (mounted) setState(() { _serverOnline = false; _serverBusy = false; });
      }
    } catch (_) {
      if (mounted) setState(() { _serverOnline = false; _serverBusy = false; });
    }
  }

  void _initAnimations() {
    _fadeCtrl = AnimationController(
        duration: const Duration(milliseconds: 700), vsync: this);
    _orbitCtrl = AnimationController(
        duration: const Duration(seconds: 12), vsync: this)..repeat();
    _pulseCtrl = AnimationController(
        duration: const Duration(milliseconds: 2400), vsync: this)
      ..repeat(reverse: true);
    _shimmerCtrl = AnimationController(
        duration: const Duration(milliseconds: 2500), vsync: this)..repeat();
    _blink1Ctrl = AnimationController(
        duration: const Duration(milliseconds: 1800), vsync: this)
      ..repeat(reverse: true);
    _blink2Ctrl = AnimationController(
        duration: const Duration(milliseconds: 1200), vsync: this)
      ..repeat(reverse: true);
    _colorCtrl = AnimationController(
        duration: const Duration(seconds: 8), vsync: this)
      ..repeat();
    _colorAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(parent: _colorCtrl, curve: Curves.linear));

    _fadeAnim = Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut));
    _slideAnim = Tween<Offset>(begin: const Offset(0, 0.04), end: Offset.zero)
        .animate(CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOutCubic));
    _orbitAnim = Tween<double>(begin: 0, end: 2 * math.pi).animate(_orbitCtrl);
    _pulseAnim = Tween<double>(begin: 0.97, end: 1.03).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
    _shimmerAnim = Tween<double>(begin: -1.5, end: 2.5).animate(
        CurvedAnimation(parent: _shimmerCtrl, curve: Curves.easeInOut));
    _blink1Anim = Tween<double>(begin: 1, end: 0.2).animate(
        CurvedAnimation(parent: _blink1Ctrl, curve: Curves.easeInOut));
    _blink2Anim = Tween<double>(begin: 1, end: 0.15).animate(
        CurvedAnimation(parent: _blink2Ctrl, curve: Curves.easeInOut));

    Future.delayed(const Duration(milliseconds: 150), () {
      if (mounted) _fadeCtrl.forward();
    });
  }

  void _initVideo() {
    _initVideoAsync();
    _initBgVideoAsync();
  }

  Future<void> _initBgVideoAsync() async {
    try {
      final videoFile = File(AssetService.videoPathSync('background.mp4'));
      if (!videoFile.existsSync()) {
        debugPrint('background.mp4 belum ada');
        return;
      }
      _bgVideo = VideoPlayerController.file(
        videoFile,
        videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true),
      );
      await _bgVideo!.initialize();
      if (mounted) {
        _bgVideo!.setLooping(true);
        _bgVideo!.setVolume(0.0);
        await _bgVideo!.play();
        setState(() => _bgVideoReady = true);
      }
    } catch (e) {
      debugPrint('BG video error: $e');
    }
  }

  Future<void> _initVideoAsync() async {
    try {
      final videoFile = File(AssetService.videoPathSync('kontol.mp4'));
      if (!videoFile.existsSync()) {
        debugPrint('Video landing belum didownload');
        return;
      }
      _video = VideoPlayerController.file(videoFile);
      await _video.initialize();
      if (mounted) {
        setState(() {});
        _video.setLooping(true);
        _video.setVolume(1.0);
        _video.play();
      }
    } catch (e) {
      debugPrint('Video error landing: $e');
    }
  }

  Future<void> _initStartup() async {
    await _loadVersion();
    await _checkUpdate();
    await _checkJustUpdated();
    await _checkPendingRequest();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final needs = await AssetService.needsDownload();
      if (needs && mounted) {
        await Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => DownloadAssetsDialog(
              onComplete: () {
                Navigator.of(context).pop();
                _initVideoAsync();
              },
            ),
          ),
        );
      }
    });
  }

  Future<void> _loadVersion() async {
    try {
      final info = await PackageInfo.fromPlatform();
      if (mounted) setState(() => _currentVersion = info.version);
    } catch (_) {
      _currentVersion = '0.0.0';
    }
  }

  Future<void> _checkJustUpdated() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (prefs.getBool('just_updated') ?? false) {
        await prefs.setBool('just_updated', false);
        if (mounted) _showSnack('✓ Berhasil diperbarui ke versi $_currentVersion');
      }
    } catch (_) {}
  }

  Future<void> _checkPendingRequest() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final reqId    = prefs.getString('pending_req_id') ?? '';
      final username = prefs.getString('pending_req_username') ?? '';
      final password = prefs.getString('pending_req_password') ?? '';
      final type     = prefs.getString('pending_req_type') ?? 'beli';
      if (reqId.isEmpty) return;

      final endpoint = type == 'perpanjang'
          ? '/api/perpanjang-qris/status/$reqId'
          : '/api/beli-akses/status/$reqId';

      final res = await http.get(
        Uri.parse('${ConfigService.baseUrl}$endpoint'),
      ).timeout(const Duration(seconds: 8));

      final d = jsonDecode(res.body);
      if (d['success'] == true && d['status'] == 'approved') {
        final expiredDate = d['expiredDate'] ?? '';
        await prefs.remove('pending_req_id');
        await prefs.remove('pending_req_username');
        await prefs.remove('pending_req_password');
        await prefs.remove('pending_req_type');

        if (!mounted) return;
        WidgetsBinding.instance.addPostFrameCallback((_) {
          _showKonfirmasiOverlay(
            username: username,
            password: password,
            expiredDate: expiredDate,
            type: type,
          );
        });
      }
    } catch (_) {}
  }

  void _showKonfirmasiOverlay({
    required String username,
    required String type,
    String password = '',
    String expiredDate = '',
  }) {
    if (!mounted) return;
    bool obscurePass = true;
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => StatefulBuilder(
        builder: (ctx, setDlg) => Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: _cSurface1,
              borderRadius: const BorderRadius.all(Radius.circular(20)),
              border: Border.all(color: _cGreen.withOpacity(0.4), width: 1.5),
              boxShadow: [BoxShadow(color: _cGreen.withOpacity(0.15), blurRadius: 40)],
            ),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Container(
                width: 60, height: 60,
                decoration: BoxDecoration(
                  color: _cGreen.withOpacity(0.15), shape: BoxShape.circle,
                  border: Border.all(color: _cGreen.withOpacity(0.4), width: 1.5),
                ),
                child: const Center(child: Text('✅', style: TextStyle(fontSize: 28))),
              ),
              const SizedBox(height: 14),
              Text(
                type == 'perpanjang' ? 'PERPANJANG BERHASIL!' : 'AKUN SIAP DIGUNAKAN!',
                style: const TextStyle(fontFamily: 'Outfit', fontSize: 15,
                    fontWeight: FontWeight.w900, color: _cGreen, letterSpacing: 1),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 4),
              Text(
                type == 'perpanjang'
                    ? 'Akun $username sudah diperpanjang oleh admin.'
                    : 'Akun $username sudah dikonfirmasi admin.',
                textAlign: TextAlign.center,
                style: const TextStyle(fontFamily: 'Outfit', fontSize: 12, color: _cText3, height: 1.5),
              ),
              if (type != 'perpanjang' && (username.isNotEmpty || password.isNotEmpty)) ...[
                const SizedBox(height: 16),
                Container(
                  width: double.infinity, padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: _cSurface2,
                    borderRadius: const BorderRadius.all(Radius.circular(12)),
                    border: Border.all(color: _cLine),
                  ),
                  child: Column(children: [
                    Row(children: [
                      const Icon(Icons.person_outline_rounded, color: _cPrimary, size: 15),
                      const SizedBox(width: 8),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('USERNAME', style: TextStyle(fontFamily: 'Outfit', fontSize: 9, color: _cText3, letterSpacing: 1)),
                        Text(username, style: const TextStyle(fontFamily: 'Outfit', fontSize: 14, fontWeight: FontWeight.w900, color: _cPrimary2)),
                      ])),
                      GestureDetector(
                        onTap: () {
                          Clipboard.setData(ClipboardData(text: username));
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                            content: Text('Username disalin!', style: TextStyle(color: Colors.white, fontFamily: 'Outfit', fontSize: 12)),
                            backgroundColor: _cGreen, behavior: SnackBarBehavior.floating,
                            duration: Duration(seconds: 1),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10))),
                            margin: EdgeInsets.all(16),
                          ));
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: _cPrimary2.withOpacity(0.12),
                            borderRadius: const BorderRadius.all(Radius.circular(7)),
                            border: Border.all(color: _cPrimary2.withOpacity(0.25)),
                          ),
                          child: const Row(mainAxisSize: MainAxisSize.min, children: [
                            Icon(Icons.copy_rounded, size: 11, color: _cPrimary2),
                            SizedBox(width: 4),
                            Text('Salin', style: TextStyle(fontFamily: 'Outfit', fontSize: 9, fontWeight: FontWeight.w700, color: _cPrimary2)),
                          ]),
                        ),
                      ),
                    ]),
                    if (password.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      Row(children: [
                        const Icon(Icons.lock_outline_rounded, color: _cPrimary, size: 15),
                        const SizedBox(width: 8),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          const Text('PASSWORD', style: TextStyle(fontFamily: 'Outfit', fontSize: 9, color: _cText3, letterSpacing: 1)),
                          Text(
                            obscurePass ? '●' * password.length.clamp(0, 14) : password,
                            style: const TextStyle(fontFamily: 'Outfit', fontSize: 14, fontWeight: FontWeight.w900, color: _cPrimary2),
                          ),
                        ])),
                        GestureDetector(
                          onTap: () => setDlg(() => obscurePass = !obscurePass),
                          child: Icon(obscurePass ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                              color: _cText3, size: 16),
                        ),
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: () {
                            Clipboard.setData(ClipboardData(text: password));
                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                              content: Text('Password disalin!', style: TextStyle(color: Colors.white, fontFamily: 'Outfit', fontSize: 12)),
                              backgroundColor: _cGreen, behavior: SnackBarBehavior.floating,
                              duration: Duration(seconds: 1),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10))),
                              margin: EdgeInsets.all(16),
                            ));
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: _cPrimary2.withOpacity(0.12),
                              borderRadius: const BorderRadius.all(Radius.circular(7)),
                              border: Border.all(color: _cPrimary2.withOpacity(0.25)),
                            ),
                            child: const Row(mainAxisSize: MainAxisSize.min, children: [
                              Icon(Icons.copy_rounded, size: 11, color: _cPrimary2),
                              SizedBox(width: 4),
                              Text('Salin', style: TextStyle(fontFamily: 'Outfit', fontSize: 9, fontWeight: FontWeight.w700, color: _cPrimary2)),
                            ]),
                          ),
                        ),
                      ]),
                    ],
                    if (expiredDate.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      Row(children: [
                        const Icon(Icons.schedule_rounded, color: _cAccent, size: 15),
                        const SizedBox(width: 8),
                        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          const Text('EXPIRED', style: TextStyle(fontFamily: 'Outfit', fontSize: 9, color: _cText3, letterSpacing: 1)),
                          Text(expiredDate, style: const TextStyle(fontFamily: 'Outfit', fontSize: 14, fontWeight: FontWeight.w900, color: _cAccent)),
                        ]),
                      ]),
                    ],
                  ]),
                ),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFBBF24).withOpacity(0.07),
                    borderRadius: const BorderRadius.all(Radius.circular(10)),
                    border: Border.all(color: const Color(0xFFFBBF24).withOpacity(0.2)),
                  ),
                  child: const Row(children: [
                    Text('⚠️', style: TextStyle(fontSize: 12)),
                    SizedBox(width: 7),
                    Expanded(child: Text('Screenshot sekarang! Data ini tidak bisa dilihat lagi.',
                        style: TextStyle(fontFamily: 'Outfit', fontSize: 10, color: Color(0xFFFBBF24), height: 1.4))),
                  ]),
                ),
              ],
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity, height: 46,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    Navigator.of(context).pushReplacementNamed('/login');
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _cGreen, foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: const BorderRadius.all(Radius.circular(12))),
                    elevation: 0,
                  ),
                  child: const Text('LOGIN SEKARANG',
                      style: TextStyle(fontFamily: 'Outfit', fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  Future<void> _checkUpdate() async {
    setState(() => _checkingUpdate = true);
    try {
      final res = await http.get(Uri.parse('${ConfigService.baseUrl}/version'))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final info = UpdateInfo.fromJson(jsonDecode(res.body));
        final needs = _isNewer(info.latestVersion, _currentVersion);
        if (mounted) {
          setState(() {
            _updateInfo    = info;
            _hasUpdate     = needs;
            _forceUpdate   = needs && info.forceUpdate;
            _checkingUpdate = false;
          });
          if (needs && info.forceUpdate) {
            WidgetsBinding.instance.addPostFrameCallback((_) => _showForceSheet());
          }
        }
      } else {
        if (mounted) setState(() => _checkingUpdate = false);
      }
    } catch (_) {
      if (mounted) setState(() => _checkingUpdate = false);
    }
  }

  Future<void> _startDownload() async {
    if (_updateInfo == null || _isDownloading) return;

    if (!await Permission.requestInstallPackages.isGranted) {
      final status = await Permission.requestInstallPackages.request();
      if (!status.isGranted) {
        _showDialog('Izin Diperlukan',
            'Izin install APK diperlukan.\nSilakan izinkan di pengaturan.');
        await openAppSettings();
        return;
      }
    }

    setState(() {
      _isDownloading = true;
      _dlProgress    = 0;
      _dlStatus      = 'Memulai...';
      _dlMb          = '';
    });

    try {
      Directory dir;
      try {
        dir = (await getExternalStorageDirectory()) ??
              (await getApplicationCacheDirectory());
      } catch (_) {
        dir = await getApplicationCacheDirectory();
      }

      final savePath = '${dir.path}/TRICKSTER_update.apk';
      final old = File(savePath);
      if (await old.exists()) await old.delete();

      String downloadUrl = _updateInfo!.apkUrl;
      if (downloadUrl.contains('drive.google.com')) {
        if (mounted) setState(() => _dlStatus = 'Connecting...');
        downloadUrl = _buildGDriveUrl(downloadUrl);
      }

      await Dio().download(
        downloadUrl,
        savePath,
        onReceiveProgress: (recv, total) {
          if (total > 0 && mounted) {
            final p      = recv / total;
            final recvMb = (recv / 1024 / 1024).toStringAsFixed(1);
            final totMb  = (total / 1024 / 1024).toStringAsFixed(1);
            setState(() {
              _dlProgress = p;
              _dlStatus   = '${(p * 100).toInt()}%';
              _dlMb       = '$recvMb / $totMb MB';
            });
          }
        },
        options: Options(
          receiveTimeout:  const Duration(minutes: 15),
          sendTimeout:     const Duration(seconds: 30),
          followRedirects: true,
          maxRedirects:    10,
          headers: {
            'Accept':     '*/*',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36',
          },
        ),
      );

      if (mounted) setState(() { _dlStatus = 'Selesai!'; _dlProgress = 1.0; });

      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('just_updated', true);
      await Future.delayed(const Duration(milliseconds: 800));
      await OpenFilex.open(savePath);

    } on DioException catch (e) {
      debugPrint('DioException: ${e.type} | ${e.message} | ${e.response?.statusCode}');
      if (mounted) {
        setState(() { _isDownloading = false; _dlStatus = ''; });
        _showDialog('Download Gagal',
            'Gagal mendownload update.\nPastikan koneksi internet stabil.');
      }
    } catch (e) {
      debugPrint('Download error: $e');
      if (mounted) {
        setState(() { _isDownloading = false; _dlStatus = ''; });
        _showDialog('Download Gagal',
            'Gagal mendownload update.\nPastikan koneksi internet stabil.');
      }
    }
  }

  String _buildGDriveUrl(String url) {
    final patterns = [
      RegExp(r'drive\.google\.com/file/d/([a-zA-Z0-9_-]+)'),
      RegExp(r'drive\.google\.com/open\?id=([a-zA-Z0-9_-]+)'),
      RegExp(r'[?&]id=([a-zA-Z0-9_-]+)'),
    ];
    for (final p in patterns) {
      final m = p.firstMatch(url);
      if (m != null) {
        final fileId = m.group(1)!;
        return 'https://drive.usercontent.google.com/download?id=$fileId&export=download&confirm=t';
      }
    }
    return url;
  }

  Future<void> _masuk() async {
    if (_isProcessing) return;
    if (_forceUpdate && _hasUpdate) { _showForceSheet(); return; }
    setState(() => _isProcessing = true);

    try {
      final prefs = await SharedPreferences.getInstance();
      final isLoggedIn = prefs.getBool('isLoggedIn') ?? false;

      if (!mounted) return;

      if (isLoggedIn) {
        final username = prefs.getString('username') ?? '';
        final password = prefs.getString('password') ?? '';
        final role = prefs.getString('role') ?? '';
        final sessionKey = prefs.getString('sessionKey') ?? '';
        final expiredDate = prefs.getString('expiredDate') ?? '';
        final listBug = List<Map<String, dynamic>>.from(
            (jsonDecode(prefs.getString('listBug') ?? '[]') as List)
                .map((e) => Map<String, dynamic>.from(e)));
        final listDoos = List<Map<String, dynamic>>.from(
            (jsonDecode(prefs.getString('listDoos') ?? '[]') as List)
                .map((e) => Map<String, dynamic>.from(e)));
        final news = List<Map<String, dynamic>>.from(
            (jsonDecode(prefs.getString('news') ?? '[]') as List)
                .map((e) => Map<String, dynamic>.from(e)));

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => SplashScreen(
              username: username,
              password: password,
              role: role,
              sessionKey: sessionKey,
              expiredDate: expiredDate,
              listBug: listBug,
              listDoos: listDoos,
              news: news,
            ),
          ),
        );
      } else {
        Navigator.pushReplacementNamed(context, '/login');
      }
    } catch (_) {
      if (mounted) Navigator.pushReplacementNamed(context, '/login');
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }

  Future<void> _openUrl(String url) async {
    try {
      if (!await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication)) {
        throw Exception('Could not launch $url');
      }
    } catch (e) { debugPrint('URL error: $e'); }
  }

  void _showForceSheet() {
    if (!mounted || _updateInfo == null) return;
    _showUpdateSheet(force: true);
  }

  void _showUpdateSheet({bool force = false}) {
    if (!mounted || _updateInfo == null) return;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      isDismissible: !force,
      enableDrag: !force,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.6),
      builder: (_) => _UpdateSheet(
        info:        _updateInfo!,
        force:       force,
        onUpdate:    () { Navigator.pop(context); _startDownload(); },
        onDismiss:   force ? null : () => Navigator.pop(context),
      ),
    );
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg,
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
      backgroundColor: _cGreen,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: const BorderRadius.all(Radius.circular(12))),
      margin: const EdgeInsets.all(16),
    ));
  }

  void _showDialog(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          decoration: BoxDecoration(
            color: _cSurface1,
            borderRadius: const BorderRadius.all(Radius.circular(20)),
            border: Border.all(color: _cPrimary.withOpacity(0.2)),
          ),
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.info_outline_rounded, color: _cPrimary, size: 36),
            const SizedBox(height: 12),
            Text(title,
                style: const TextStyle(color: _cText1, fontWeight: FontWeight.w800, fontSize: 17)),
            const SizedBox(height: 8),
            Text(msg,
                textAlign: TextAlign.center,
                style: const TextStyle(color: _cText2, height: 1.5)),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: _cPrimary,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: const BorderRadius.all(Radius.circular(12))),
                    padding: const EdgeInsets.symmetric(vertical: 14)),
                onPressed: () => Navigator.pop(context),
                child: const Text('OK',
                    style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      ConfigService.refresh().then((_) => _checkServer());
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _timer?.cancel();
    _statusTimer?.cancel();
    _video.dispose();
    _bgVideo?.dispose();
    _fadeCtrl.dispose();
    _orbitCtrl.dispose();
    _pulseCtrl.dispose();
    _shimmerCtrl.dispose();
    _blink1Ctrl.dispose();
    _blink2Ctrl.dispose();
    _colorCtrl.dispose();
    _welcomeCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _cBg,
      body: Stack(children: [
        Positioned.fill(
          child: AnimatedBuilder(
            animation: _orbitAnim,
            builder: (_, __) => CustomPaint(
              painter: _BgPainter(orbit: _orbitAnim.value),
            ),
          ),
        ),

        if (_bgVideoReady && _bgVideo != null)
          Positioned.fill(
            child: FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _bgVideo!.value.size.width,
                height: _bgVideo!.value.size.height,
                child: VideoPlayer(_bgVideo!),
              ),
            ),
          ),

        if (_bgVideoReady && _bgVideo != null)
          Positioned.fill(
            child: Container(
              color: const Color(0xFF080810).withOpacity(0.55),
            ),
          ),

        SafeArea(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: Column(children: [
              _buildTopbar(),
              if (!_isOnline)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 7),
                  color: const Color(0xFFF87171).withOpacity(0.12),
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('📵', style: TextStyle(fontSize: 11)),
                      SizedBox(width: 6),
                      Text('Tidak ada koneksi internet',
                          style: TextStyle(
                              fontFamily: 'Outfit',
                              fontSize: 11, fontWeight: FontWeight.w600,
                              color: Color(0xFFF87171))),
                    ],
                  ),
                ),
              const _Divider(),
              Expanded(
                child: SlideTransition(
                  position: _slideAnim,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 22),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const SizedBox(height: 18),
                        _buildUpdateStrip(),
                        if (_isDownloading) ...[
                          const SizedBox(height: 10),
                          _buildDownloadCard(),
                        ],
                        _buildVideoCard(),
                        _buildHero(),
                        _buildCta(),
                        _buildStats(),
                        const SizedBox(height: 14),
                      ],
                    ),
                  ),
                ),
              ),

            ]),
          ),
        ),

        if (_serverOnline && _serverBusy) _buildServerBusyOverlay(),

        if (_showWelcomeOverlay) _buildWelcomeOverlay(),

      ]),
    );
  }

  Future<void> _runWelcomeSequence() async {
    if (!mounted) return;
    setState(() => _welcomeStep = 0);
    await _welcomeCtrl.forward(from: 0);
    await Future.delayed(const Duration(milliseconds: 900));
    await _welcomeCtrl.reverse();
    await Future.delayed(const Duration(milliseconds: 200));

    if (!mounted) return;
    setState(() => _welcomeStep = 1);
    await _welcomeCtrl.forward(from: 0);
    await Future.delayed(const Duration(milliseconds: 1100));
    await _welcomeCtrl.reverse();
    await Future.delayed(const Duration(milliseconds: 200));

    if (!mounted) return;
    setState(() => _welcomeStep = 2);
    await _welcomeCtrl.forward(from: 0);
    await Future.delayed(const Duration(milliseconds: 900));
    await _welcomeCtrl.reverse();
    await Future.delayed(const Duration(milliseconds: 100));

    if (mounted) setState(() => _showWelcomeOverlay = false);
  }

  Widget _buildServerBusyOverlay() {
    return Positioned.fill(
      child: Container(
        color: const Color(0xFF080810).withOpacity(0.88),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 72, height: 72,
              decoration: BoxDecoration(
                color: const Color(0xFFFBBF24).withOpacity(0.12),
                shape: BoxShape.circle,
                border: Border.all(color: const Color(0xFFFBBF24).withOpacity(0.4), width: 1.5),
              ),
              child: const Center(child: Text('⚡', style: TextStyle(fontSize: 30))),
            ),
            const SizedBox(height: 18),
            const Text('SERVER SEDANG SIBUK',
                style: TextStyle(
                    fontFamily: 'Outfit', fontSize: 17, fontWeight: FontWeight.w900,
                    color: Color(0xFFFBBF24), letterSpacing: 1.5)),
            const SizedBox(height: 8),
            const Text('Server sedang menangani banyak request.',
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontFamily: 'Outfit', fontSize: 13,
                    color: Color(0xFF94A3B8), height: 1.5)),
            const SizedBox(height: 6),
            const Text('Kamu tetap bisa lanjut, atau tunggu sebentar.',
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontFamily: 'Outfit', fontSize: 12,
                    color: Color(0xFF64748B))),
            const SizedBox(height: 28),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              ElevatedButton.icon(
                onPressed: () {
                  if (mounted) setState(() => _serverBusy = false);
                },
                icon: const Icon(Icons.arrow_forward_rounded, size: 16, color: Colors.black),
                label: const Text('Lanjut Aja',
                    style: TextStyle(fontFamily: 'Outfit', fontSize: 13,
                        fontWeight: FontWeight.w700, color: Colors.black)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFBBF24),
                  padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 11),
                  shape: RoundedRectangleBorder(borderRadius: const BorderRadius.all(Radius.circular(10))),
                  elevation: 0,
                ),
              ),
              const SizedBox(width: 12),
              OutlinedButton.icon(
                onPressed: _checkServer,
                icon: const Icon(Icons.refresh_rounded, size: 16, color: Color(0xFFFBBF24)),
                label: const Text('Refresh',
                    style: TextStyle(fontFamily: 'Outfit', fontSize: 13,
                        fontWeight: FontWeight.w600, color: Color(0xFFFBBF24))),
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: Color(0xFFFBBF24), width: 1),
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
                  shape: RoundedRectangleBorder(borderRadius: const BorderRadius.all(Radius.circular(10))),
                ),
              ),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _buildWelcomeOverlay() {
    return AnimatedBuilder(
      animation: _welcomeFadeAnim,
      builder: (context, _) {
        Widget child;

        if (_welcomeStep == 0) {
          child = Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '— Welcome to —',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.5),
                  fontSize: 14,
                  letterSpacing: 6,
                  fontWeight: FontWeight.w200,
                  fontFamily: 'Orbitron',
                ),
              ),
            ],
          );
        } else if (_welcomeStep == 1) {
          child = ShaderMask(
            shaderCallback: (bounds) => const LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFB794FF)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ).createShader(bounds),
            child: const Text(
              'TRICKSTER X AREA',
              style: TextStyle(
                fontSize: 34,
                fontWeight: FontWeight.w900,
                color: Colors.white,
                letterSpacing: 7,
                fontFamily: 'Orbitron',
              ),
            ),
          );
        } else {
          child = Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Developer',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.3),
                  fontSize: 10,
                  letterSpacing: 4,
                  fontWeight: FontWeight.w300,
                  fontFamily: 'Orbitron',
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'alwaysZillxy',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.7),
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 4,
                  fontFamily: 'Orbitron',
                ),
              ),
            ],
          );
        }

        return IgnorePointer(
          child: Container(
            color: Colors.black,
            child: Center(
              child: FadeTransition(
                opacity: _welcomeFadeAnim,
                child: child,
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildTopbar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 18, 22, 14),
      child: Row(children: [
        Container(
          width: 40, height: 40,
          decoration: BoxDecoration(
            color: _cSurface2,
            borderRadius: const BorderRadius.all(Radius.circular(11)),
            border: Border.all(color: _cPrimary.withOpacity(0.35)),
            boxShadow: [
              BoxShadow(color: _cPrimary.withOpacity(0.07),
                  blurRadius: 0, spreadRadius: 3),
            ],
          ),
          child: ClipRRect(
            borderRadius: const BorderRadius.all(Radius.circular(10)),
            child: Stack(alignment: Alignment.center, children: [
              Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0x2E8B5CF6), Colors.transparent],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
              ),
              AssetService.image('logo.jpg', fit: BoxFit.cover),
            ]),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('TRICKSTER X AREA ',
                style: TextStyle(
                    fontFamily: 'Outfit',
                    fontSize: 14, fontWeight: FontWeight.w900,
                    color: _cText1, letterSpacing: 1.0)),
            const SizedBox(height: 3),
            const Text('Premium · Secure · Fast',
                style: TextStyle(
                    fontFamily: 'Outfit',
                    fontSize: 10, fontWeight: FontWeight.w500,
                    color: _cText3, letterSpacing: 1.0)),
          ],
        )),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: _cSurface2,
            borderRadius: const BorderRadius.all(Radius.circular(99)),
            border: Border.all(color: _cLine),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            AnimatedBuilder(
              animation: _blink1Anim,
              builder: (_, __) => Opacity(
                opacity: _serverOnline ? _blink1Anim.value : 1.0,
                child: Container(
                  width: 5, height: 5,
                  decoration: BoxDecoration(
                    color: _serverOnline ? _cGreen : const Color(0xFFF87171),
                    shape: BoxShape.circle,
                    boxShadow: [BoxShadow(
                      color: (_serverOnline ? _cGreen : const Color(0xFFF87171))
                          .withOpacity(0.8),
                      blurRadius: 5,
                    )],
                  ),
                ),
              ),
            ),
            const SizedBox(width: 5),
            Text(
              _serverOnline ? 'ON' : 'OFF',
              style: TextStyle(
                  fontFamily: 'Outfit',
                  fontSize: 10, fontWeight: FontWeight.w700,
                  color: _serverOnline ? _cGreen : const Color(0xFFF87171)),
            ),
          ]),
        ),
        const SizedBox(width: 6),
        if (_currentVersion.isNotEmpty)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: _cSurface2,
              borderRadius: const BorderRadius.all(Radius.circular(99)),
              border: Border.all(color: _cLine),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              AnimatedBuilder(
                animation: _blink1Anim,
                builder: (_, __) => Opacity(
                  opacity: _blink1Anim.value,
                  child: Container(
                    width: 5, height: 5,
                    decoration: BoxDecoration(
                      color: _cGreen, shape: BoxShape.circle,
                      boxShadow: [BoxShadow(
                          color: _cGreen.withOpacity(0.8), blurRadius: 5)],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 5),
              Text('v$_currentVersion',
                  style: const TextStyle(
                      fontFamily: 'Outfit',
                      fontSize: 10, fontWeight: FontWeight.w700,
                      color: _cText3)),
            ]),
          ),
      ]),
    );
  }

  Widget _buildUpdateStrip() {
    if (_checkingUpdate) {
      return AnimatedBuilder(
        animation: _shimmerAnim,
        builder: (_, __) => Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          decoration: BoxDecoration(
            color: _cSurface1,
            borderRadius: const BorderRadius.all(Radius.circular(11)),
            border: Border.all(color: _cLine),
          ),
          child: ShaderMask(
            shaderCallback: (bounds) => LinearGradient(
              colors: [_cSurface1, _cSurface2, _cSurface1],
              stops: const [0.0, 0.5, 1.0],
              begin: Alignment(_shimmerAnim.value - 1, 0),
              end: Alignment(_shimmerAnim.value + 1, 0),
            ).createShader(bounds),
            child: Row(children: [
              Container(
                width: 6, height: 6,
                decoration: const BoxDecoration(
                  color: Colors.white, shape: BoxShape.circle),
              ),
              const SizedBox(width: 10),
              Container(
                height: 10, width: 160,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: const BorderRadius.all(Radius.circular(99)),
                ),
              ),
              const Spacer(),
              Container(
                height: 10, width: 40,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: const BorderRadius.all(Radius.circular(99)),
                ),
              ),
            ]),
          ),
        ),
      );
    }
    if (!_hasUpdate || _isDownloading) return const SizedBox.shrink();
    return GestureDetector(
      onTap: () => _showUpdateSheet(force: _forceUpdate),
      child: AnimatedBuilder(
        animation: _pulseAnim,
        builder: (_, child) => Transform.scale(
          scale: _forceUpdate ? _pulseAnim.value : 1.0,
          child: child,
        ),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: _cAccent.withOpacity(0.06),
            borderRadius: const BorderRadius.all(Radius.circular(11)),
            border: Border.all(color: _cAccent.withOpacity(0.18)),
          ),
          child: Row(children: [
            AnimatedBuilder(
              animation: _blink1Anim,
              builder: (_, __) => Opacity(
                opacity: _blink1Anim.value,
                child: Container(
                  width: 6, height: 6,
                  decoration: BoxDecoration(
                    color: _cAccent, shape: BoxShape.circle,
                    boxShadow: [BoxShadow(
                        color: _cAccent.withOpacity(0.8), blurRadius: 7)],
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                'Update tersedia — v${_updateInfo?.latestVersion ?? ''}',
                style: const TextStyle(
                    fontFamily: 'Outfit',
                    fontSize: 12, fontWeight: FontWeight.w700,
                    color: _cAccent),
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: _cAccent.withOpacity(0.1),
                borderRadius: const BorderRadius.all(Radius.circular(99)),
              ),
              child: const Text('Baru',
                  style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700,
                      color: _cAccent, letterSpacing: 0.3)),
            ),
            const SizedBox(width: 6),
            Text('›', style: TextStyle(fontSize: 16,
                color: _cAccent.withOpacity(0.4))),
          ]),
        ),
      ),
    );
  }

  Widget _buildDownloadCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _cSurface1,
        borderRadius: const BorderRadius.all(Radius.circular(14)),
        border: Border.all(color: _cPrimary.withOpacity(0.2)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          SizedBox(
            width: 16, height: 16,
            child: CircularProgressIndicator(
              color: _cPrimary, strokeWidth: 2,
              backgroundColor: _cPrimary.withOpacity(0.2),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text('Mengunduh update',
                style: const TextStyle(
                    fontFamily: 'Outfit',
                    fontSize: 12, fontWeight: FontWeight.w600,
                    color: _cText2)),
          ),
          Text(_dlStatus,
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800,
                  color: _cPrimary2)),
        ]),
        const SizedBox(height: 10),
        ClipRRect(
          borderRadius: const BorderRadius.all(Radius.circular(99)),
          child: LinearProgressIndicator(
            value: _dlProgress,
            minHeight: 3,
            backgroundColor: Colors.white.withOpacity(0.06),
            valueColor: const AlwaysStoppedAnimation<Color>(_cPrimary),
          ),
        ),
        const SizedBox(height: 6),
        Text(_dlMb,
            style: const TextStyle(
                fontFamily: 'Outfit',
                fontSize: 10, fontWeight: FontWeight.w500,
                color: _cText3)),
      ]),
    );
  }

  Widget _buildVideoCard() {
    return AspectRatio(
      aspectRatio: 16 / 8,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: const BorderRadius.all(Radius.circular(20)),
          gradient: LinearGradient(
            colors: [_cPrimary.withOpacity(0.5), _cAccent.withOpacity(0.3)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(color: _cPrimary.withOpacity(0.18),
                blurRadius: 32, offset: const Offset(0, 12)),
          ],
        ),
        padding: const EdgeInsets.all(1.5),
        child: Container(
          decoration: BoxDecoration(
            color: _cSurface1,
            borderRadius: const BorderRadius.all(Radius.circular(19)),
          ),
          clipBehavior: Clip.antiAlias,
          child: Stack(fit: StackFit.expand, children: [
            _video.value.isInitialized
                ? FittedBox(fit: BoxFit.cover,
                    child: SizedBox(
                      width:  _video.value.size.width,
                      height: _video.value.size.height,
                      child:  VideoPlayer(_video),
                    ))
                : const _VideoPlaceholder(),

            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter, end: Alignment.bottomCenter,
                  colors: [Colors.transparent, Color(0x60080810), Color(0xCC080810)],
                  stops: [0.3, 0.7, 1.0],
                ),
              ),
            ),

            Positioned(
              top: 10, left: 10,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.55),
                  borderRadius: const BorderRadius.all(Radius.circular(6)),
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  AnimatedBuilder(
                    animation: _blink2Anim,
                    builder: (_, __) => Opacity(
                      opacity: _blink2Anim.value,
                      child: Container(
                        width: 5, height: 5,
                        decoration: const BoxDecoration(
                          color: Color(0xFFF87171), shape: BoxShape.circle),
                      ),
                    ),
                  ),
                  const SizedBox(width: 5),
                  const Text('LIVE',
                      style: TextStyle(
                          fontFamily: 'Outfit',
                          fontSize: 9, fontWeight: FontWeight.w800,
                          color: Colors.white, letterSpacing: 2.0)),
                ]),
              ),
            ),

            Positioned(
              bottom: 10, left: 10, right: 10,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.5),
                      borderRadius: const BorderRadius.all(Radius.circular(5)),
                      border: Border.all(color: _cPrimary.withOpacity(0.5), width: 0.8),
                    ),
                    child: const Text('PREVIEW',
                        style: TextStyle(
                            fontFamily: 'Outfit',
                            fontSize: 8, fontWeight: FontWeight.w800,
                            color: _cPrimary2, letterSpacing: 2.0)),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.4),
                      borderRadius: const BorderRadius.all(Radius.circular(5)),
                    ),
                    child: Text('HD',
                        style: TextStyle(
                            fontFamily: 'Outfit',
                            fontSize: 8, fontWeight: FontWeight.w700,
                            color: Colors.white.withOpacity(0.4), letterSpacing: 1.5)),
                  ),
                ],
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _buildHero() {
    return Column(children: [
      AnimatedBuilder(
        animation: _shimmerAnim,
        builder: (_, __) => ShaderMask(
          shaderCallback: (bounds) => LinearGradient(
            colors: const [Color(0xFFC4B5FD), _cPrimary, _cAccent, Color(0xFFC4B5FD)],
            stops: const [0.0, 0.35, 0.65, 1.0],
            begin: Alignment(_shimmerAnim.value - 1.2, 0),
            end:   Alignment(_shimmerAnim.value + 1.2, 0),
          ).createShader(bounds),
          child: const Text('TRXAREA',
              style: TextStyle(
                  fontFamily: 'Outfit',
                  fontSize: 72, fontWeight: FontWeight.w900,
                  color: Colors.white, letterSpacing: 3, height: 1)),
        ),
      ),
      const SizedBox(height: 2),
      Row(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 20, height: 1,
            color: _cPrimary.withOpacity(0.4)),
        const SizedBox(width: 8),
        const Text('TRICKSTER X AREA',
            style: TextStyle(
                fontFamily: 'Outfit',
                fontSize: 11, fontWeight: FontWeight.w600,
                color: _cText3, letterSpacing: 9)),
        const SizedBox(width: 8),
        Container(width: 20, height: 1,
            color: _cAccent.withOpacity(0.4)),
      ]),
      const SizedBox(height: 6),
      AnimatedBuilder(
        animation: _pulseCtrl,
        builder: (_, __) => Text(
          _timeStr,
          style: TextStyle(
            fontFamily: 'Outfit',
            fontSize: 11,
            fontWeight: FontWeight.w500,
            color: Colors.white.withValues(alpha: 0.3 + _pulseCtrl.value * 0.7),
            letterSpacing: 3.0,
          ),
        ),
      ),
    ]);
  }

  Color _cycleColor(double t, int offset) {
    final palette = [
      const Color(0xFF8B5CF6),
      const Color(0xFF22D3EE),
      const Color(0xFF4ADE80),
      const Color(0xFFFBBF24),
      const Color(0xFFF472B6),
      const Color(0xFF60A5FA),
    ];
    final total = palette.length;
    final shifted = (t + offset / total) % 1.0;
    final idx = (shifted * total).floor();
    final next = (idx + 1) % total;
    final frac = (shifted * total) - idx;
    return Color.lerp(palette[idx], palette[next], frac)!;
  }

  Widget _buildCta() {
    final isLocked = _isProcessing || _isDownloading;
    final isForced = _forceUpdate && _hasUpdate;

    return AnimatedBuilder(
      animation: _colorAnim,
      builder: (_, __) {
        final t = _colorAnim.value;
        final c0 = _cycleColor(t, 0);
        final c1 = _cycleColor(t, 1);
        final c2 = _cycleColor(t, 2);
        final c3 = _cycleColor(t, 3);

        return Column(children: [
          GestureDetector(
            onTapDown:  (_) => setState(() => _btnPressed = true),
            onTapUp:    (_) => setState(() => _btnPressed = false),
            onTapCancel:()  => setState(() => _btnPressed = false),
            onTap: isLocked ? null : _masuk,
            child: AnimatedScale(
              scale: _btnPressed ? 0.97 : 1.0,
              duration: const Duration(milliseconds: 120),
              child: Container(
                width: double.infinity, height: 56,
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.all(Radius.circular(14)),
                  gradient: isForced
                      ? LinearGradient(colors: [Colors.grey.shade800, Colors.grey.shade700])
                      : LinearGradient(
                          colors: [c0, c1],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                  boxShadow: [
                    BoxShadow(
                      color: (isForced ? Colors.grey : c0).withOpacity(_btnPressed ? 0.15 : 0.35),
                      blurRadius: _btnPressed ? 8 : 22,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                clipBehavior: Clip.antiAlias,
                child: Stack(alignment: Alignment.center, children: [
                  Positioned(
                    top: 0, left: 0, right: 0,
                    child: Container(
                      height: 28,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter, end: Alignment.bottomCenter,
                          colors: [Colors.white.withOpacity(0.08), Colors.transparent],
                        ),
                      ),
                    ),
                  ),
                  if (!isForced && !isLocked)
                    AnimatedBuilder(
                      animation: _shimmerAnim,
                      builder: (_, __) => ShaderMask(
                        shaderCallback: (r) => LinearGradient(
                          begin: Alignment(_shimmerAnim.value - 0.8, 0),
                          end:   Alignment(_shimmerAnim.value + 0.8, 0),
                          colors: [Colors.transparent, Colors.white.withOpacity(0.10), Colors.transparent],
                        ).createShader(r),
                        child: Container(color: Colors.white),
                      ),
                    ),
                  _isProcessing
                      ? const SizedBox(width: 22, height: 22,
                          child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                      : Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Text(isForced ? '🔒' : '⚡', style: const TextStyle(fontSize: 16)),
                          const SizedBox(width: 10),
                          Text(isForced ? 'UPDATE DULU' : 'MASUK',
                              style: const TextStyle(
                                  fontFamily: 'Outfit', fontSize: 16, fontWeight: FontWeight.w800,
                                  color: Colors.white, letterSpacing: 2.5)),
                        ]),
                ]),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Container(width: 14, height: 1, color: _cText3.withOpacity(0.3)),
            const SizedBox(width: 8),
            Text(
              isForced ? 'Update dulu sebelum melanjutkan' : 'Masuk untuk akses fitur premium',
              style: const TextStyle(fontFamily: 'Outfit', fontSize: 10,
                  fontWeight: FontWeight.w500, color: _cText3, letterSpacing: 0.5),
            ),
            const SizedBox(width: 8),
            Container(width: 14, height: 1, color: _cText3.withOpacity(0.3)),
          ]),
          const SizedBox(height: 10),
          GestureDetector(
            onTap: _showRegisterSheet,
            child: Container(
              width: double.infinity, height: 48,
              decoration: BoxDecoration(
                borderRadius: const BorderRadius.all(Radius.circular(14)),
                color: _cSurface1,
                border: Border.all(color: c1.withOpacity(0.6), width: 1.4),
                boxShadow: [BoxShadow(color: c1.withOpacity(0.08), blurRadius: 12)],
              ),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Text('🛒', style: TextStyle(fontSize: 15)),
                const SizedBox(width: 8),
                Text('DAFTAR / BELI AKSES',
                    style: TextStyle(fontFamily: 'Outfit', fontSize: 13,
                        fontWeight: FontWeight.w800, color: c1, letterSpacing: 1.5)),
              ]),
            ),
          ),
          const SizedBox(height: 8),
          GestureDetector(
            onTap: _showPerpanjangSheet,
            child: Container(
              width: double.infinity, height: 44,
              decoration: BoxDecoration(
                borderRadius: const BorderRadius.all(Radius.circular(14)),
                color: _cSurface1,
                border: Border.all(color: c2.withOpacity(0.6), width: 1.4),
                boxShadow: [BoxShadow(color: c2.withOpacity(0.08), blurRadius: 12)],
              ),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Text('🔄', style: TextStyle(fontSize: 14)),
                const SizedBox(width: 8),
                Text('PERPANJANG AKUN',
                    style: TextStyle(fontFamily: 'Outfit', fontSize: 13,
                        fontWeight: FontWeight.w800, color: c2, letterSpacing: 1.5)),
              ]),
            ),
          ),
          const SizedBox(height: 8),
          GestureDetector(
            onTap: _claimUjiCoba,
            child: Container(
              width: double.infinity, height: 44,
              decoration: BoxDecoration(
                borderRadius: const BorderRadius.all(Radius.circular(14)),
                color: _cSurface1,
                border: Border.all(color: c3.withOpacity(0.6), width: 1.4),
                boxShadow: [BoxShadow(color: c3.withOpacity(0.08), blurRadius: 12)],
                gradient: LinearGradient(
                  colors: [c3.withOpacity(0.08), c0.withOpacity(0.05)],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
              ),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Text('🎁', style: TextStyle(fontSize: 14)),
                const SizedBox(width: 8),
                Text('FREE UJI COBA',
                    style: TextStyle(fontFamily: 'Outfit', fontSize: 13,
                        fontWeight: FontWeight.w800, color: c3, letterSpacing: 1.5)),
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: c3.withOpacity(0.15),
                    borderRadius: const BorderRadius.all(Radius.circular(99)),
                    border: Border.all(color: c3.withOpacity(0.3)),
                  ),
                  child: Text('1 HARI',
                      style: TextStyle(fontFamily: 'Outfit', fontSize: 8,
                          fontWeight: FontWeight.w800, color: c3, letterSpacing: 1)),
                ),
              ]),
            ),
          ),
        ]);
      },
    );
  }

  bool _claimingUjiCoba = false;

  Future<Map<String, String>> _getDeviceInfo() async {
    try {
      final plugin = DeviceInfoPlugin();
      if (Platform.isAndroid) {
        final info = await plugin.androidInfo;
        String androidId = info.serialNumber.isNotEmpty && info.serialNumber != 'unknown'
            ? info.serialNumber
            : '${info.brand}_${info.model}_${info.id}'.replaceAll(' ', '_');
        return {
          'androidId':   androidId,
          'deviceBrand': '${info.brand} ${info.model}',
        };
      } else if (Platform.isIOS) {
        final info = await plugin.iosInfo;
        return {
          'androidId':   info.identifierForVendor ?? 'ios_unknown',
          'deviceBrand': '${info.name} (iOS)',
        };
      }
    } catch (_) {}
    return {'androidId': 'unknown_device', 'deviceBrand': 'unknown'};
  }

  Future<void> _claimUjiCoba() async {
    if (_claimingUjiCoba) return;
    setState(() => _claimingUjiCoba = true);
    try {
      final deviceInfo = await _getDeviceInfo();

      if (deviceInfo['androidId'] == 'unknown_device') {
        if (mounted) _showSnack('❌ Gagal membaca ID perangkat, coba restart app');
        return;
      }

      final res = await http.post(
        Uri.parse('${ConfigService.baseUrl}/api/uji-coba'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(deviceInfo),
      ).timeout(const Duration(seconds: 10));

      final d = jsonDecode(res.body);
      if (d['success'] == true) {
        final username = d['username']    ?? '';
        final password = d['password']    ?? '';
        final expired  = d['expiredDate'] ?? '1 hari';
        if (mounted) _showUjiCobaDialog(username: username, password: password, expired: expired);
      } else if (d['alreadyUsed'] == true) {
        if (mounted) _showAlreadyUsedDialog();
      } else {
        final msg = d['message'] ?? 'Gagal mendapatkan akun uji coba';
        if (mounted) _showSnack('❌ $msg');
      }
    } catch (_) {
      if (mounted) _showSnack('❌ Gagal terhubung ke server');
    } finally {
      if (mounted) setState(() => _claimingUjiCoba = false);
    }
  }

  void _showAlreadyUsedDialog() {
    if (!mounted) return;
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: const Color(0xFF0E0E1A),
            borderRadius: const BorderRadius.all(Radius.circular(22)),
            border: Border.all(color: const Color(0xFFF87171).withOpacity(0.35), width: 1.5),
            boxShadow: [BoxShadow(color: const Color(0xFFF87171).withOpacity(0.08), blurRadius: 40)],
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 64, height: 64,
              decoration: BoxDecoration(
                color: const Color(0xFFF87171).withOpacity(0.12),
                shape: BoxShape.circle,
                border: Border.all(color: const Color(0xFFF87171).withOpacity(0.35), width: 1.5),
              ),
              child: const Center(child: Text('🚫', style: TextStyle(fontSize: 28))),
            ),
            const SizedBox(height: 14),
            const Text('SUDAH PERNAH DIGUNAKAN',
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontFamily: 'Outfit', fontSize: 14, fontWeight: FontWeight.w900,
                    color: Color(0xFFF87171), letterSpacing: 0.8)),
            const SizedBox(height: 10),
            const Text(
              'Perangkat ini sudah pernah menggunakan uji coba gratis.\nSilakan beli akses untuk melanjutkan.',
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontFamily: 'Outfit', fontSize: 12,
                  color: Color(0xFF94A3B8), height: 1.6),
            ),
            const SizedBox(height: 22),
            Row(children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => Navigator.pop(context),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Color(0x1FFFFFFF)),
                    foregroundColor: const Color(0x80FFFFFF),
                    shape: RoundedRectangleBorder(borderRadius: const BorderRadius.all(Radius.circular(12))),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                  child: const Text('Tutup', style: TextStyle(fontFamily: 'Outfit', fontSize: 13, fontWeight: FontWeight.w600)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                flex: 2,
                child: ElevatedButton(
                  onPressed: () { Navigator.pop(context); _showRegisterSheet(); },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF8B5CF6),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: const BorderRadius.all(Radius.circular(12))),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    elevation: 0,
                  ),
                  child: const Text('BELI AKSES',
                      style: TextStyle(fontFamily: 'Outfit', fontSize: 13,
                          fontWeight: FontWeight.w900, letterSpacing: 1)),
                ),
              ),
            ]),
          ]),
        ),
      ),
    );
  }

  void _showUjiCobaDialog({
    required String username,
    required String password,
    required String expired,
  }) {
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.85),
      builder: (_) => _UjiCobaDialog(
        username: username,
        password: password,
        expired: expired,
        onLogin: () {
          Navigator.of(context).pop();
          Navigator.of(context).pushReplacementNamed('/login');
        },
      ),
    );
  }

  void _showRegisterSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (_) => const _RegisterSheet(),
    );
  }

  void _showPerpanjangSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (_) => const _PerpanjangSheet(),
    );
  }

  Widget _buildStats() {
    return Column(children: [
      Row(children: [
        _StatCard(icon: '🛡️', value: '100%', label: 'AMAN',
            accentColor: _cGreen),
        const SizedBox(width: 8),
        _StatCard(icon: '⚡', value: 'Ultra', label: 'CEPAT',
            accentColor: _cPrimary2),
        const SizedBox(width: 8),
        _StatCard(icon: '⭐', value: '5.0', label: 'RATING',
            accentColor: _cAccent),
      ]),
      const SizedBox(height: 10),
      Row(children: [
        _SocialCard(
          asset: 'assets/tiktok.png',
          label: 'TikTok',
          color: const Color(0xFFEE1D52),
          onTap: () => _openUrl('https://www.tiktok.com/@alwayszillxyofficialshop'),
        ),
        const SizedBox(width: 8),
        _SocialCard(
          asset: 'assets/whatsapp.png',
          label: 'WhatsApp',
          color: const Color(0xFF25D366),
          onTap: () => _openUrl('https://wa.me/6282221520070'),
        ),
        const SizedBox(width: 8),
        _SocialCard(
          asset: 'assets/instagram.png',
          label: 'Instagram',
          color: const Color(0xFFE1306C),
          onTap: () => _openUrl('https://instagram.com/'),
        ),
        const SizedBox(width: 8),
        _SocialCard(
          asset: 'assets/telegram.png',
          label: 'Telegram',
          color: const Color(0xFF229ED9),
          onTap: () => _openUrl('https://t.me/alwaysZilllxy'),
        ),
      ]),
    ]);
  }

}

// ══════════════════════════════════════════════
// SUB-WIDGETS (LANJUTAN DARI KODE ANDA)
// ══════════════════════════════════════════════

// ... (sisa kode widget lainnya seperti _Divider, _UjiCobaDialog, _PlayIcon, dll)
// Pastikan semua BorderRadius.circular(angka) diubah menjadi const BorderRadius.circular(angka)

class _Divider extends StatelessWidget {
  const _Divider();
  @override
  Widget build(BuildContext context) =>
      Container(height: 1, color: _cLine, margin: EdgeInsets.zero);
}

// ══════════════════════════════════════════════
// UJI COBA DIALOG
// ══════════════════════════════════════════════
class _UjiCobaDialog extends StatefulWidget {
  final String username;
  final String password;
  final String expired;
  final VoidCallback onLogin;

  const _UjiCobaDialog({
    required this.username,
    required this.password,
    required this.expired,
    required this.onLogin,
  });

  @override
  State<_UjiCobaDialog> createState() => _UjiCobaDialogState();
}

class _UjiCobaDialogState extends State<_UjiCobaDialog> {
  bool _obscurePass = true;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: _cSurface1,
          borderRadius: const BorderRadius.all(Radius.circular(22)),
          border: Border.all(color: _cGreen.withOpacity(0.35), width: 1.5),
          boxShadow: [
            BoxShadow(color: _cGreen.withOpacity(0.1), blurRadius: 40),
          ],
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 60, height: 60,
            decoration: BoxDecoration(
              color: _cGreen.withOpacity(0.12),
              shape: BoxShape.circle,
              border: Border.all(color: _cGreen.withOpacity(0.35), width: 1.5),
            ),
            child: const Center(child: Text('🎁', style: TextStyle(fontSize: 28))),
          ),
          const SizedBox(height: 14),
          const Text('AKUN UJI COBA SIAP!',
              style: TextStyle(
                  fontFamily: 'Outfit',
                  fontSize: 15, fontWeight: FontWeight.w900,
                  color: _cGreen, letterSpacing: 1)),
          const SizedBox(height: 4),
          const Text('Akun aktif selama 1 hari — login sekarang!',
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontFamily: 'Outfit', fontSize: 11,
                  color: _cText3, height: 1.5)),
          const SizedBox(height: 18),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _cSurface2,
              borderRadius: const BorderRadius.all(Radius.circular(14)),
              border: Border.all(color: _cLine),
            ),
            child: Column(children: [
              _credRow(
                icon: Icons.person_outline_rounded,
                label: 'USERNAME',
                value: widget.username,
                color: _cPrimary2,
              ),
              const SizedBox(height: 10),
              Row(children: [
                const Icon(Icons.lock_outline_rounded, color: _cPrimary, size: 15),
                const SizedBox(width: 10),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('PASSWORD',
                      style: TextStyle(fontFamily: 'Outfit', fontSize: 9,
                          color: _cText3, letterSpacing: 1)),
                  Text(
                    _obscurePass
                        ? '●' * widget.password.length.clamp(0, 14)
                        : widget.password,
                    style: const TextStyle(fontFamily: 'Outfit',
                        fontSize: 14, fontWeight: FontWeight.w900,
                        color: _cPrimary2),
                  ),
                ])),
                GestureDetector(
                  onTap: () => setState(() => _obscurePass = !_obscurePass),
                  child: Icon(
                    _obscurePass ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                    color: _cText3, size: 16,
                  ),
                ),
              ]),
              const SizedBox(height: 10),
              _credRow(
                icon: Icons.schedule_rounded,
                label: 'EXPIRED',
                value: widget.expired,
                color: const Color(0xFFFBBF24),
              ),
            ]),
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFFFBBF24).withOpacity(0.07),
              borderRadius: const BorderRadius.all(Radius.circular(10)),
              border: Border.all(color: const Color(0xFFFBBF24).withOpacity(0.2)),
            ),
            child: const Row(children: [
              Text('⚠️', style: TextStyle(fontSize: 12)),
              SizedBox(width: 7),
              Expanded(child: Text(
                'Screenshot sekarang! Data ini tidak bisa dilihat lagi.',
                style: TextStyle(fontFamily: 'Outfit', fontSize: 10,
                    color: Color(0xFFFBBF24), height: 1.4),
              )),
            ]),
          ),
          const SizedBox(height: 18),
          Row(children: [
            Expanded(
              child: OutlinedButton(
                onPressed: () => Navigator.of(context).pop(),
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: _cLine),
                  foregroundColor: _cText3,
                  shape: RoundedRectangleBorder(borderRadius: const BorderRadius.all(Radius.circular(12))),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
                child: const Text('Nanti',
                    style: TextStyle(fontFamily: 'Outfit', fontSize: 13,
                        fontWeight: FontWeight.w600)),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              flex: 2,
              child: ElevatedButton(
                onPressed: widget.onLogin,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _cGreen,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: const BorderRadius.all(Radius.circular(12))),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  elevation: 0,
                ),
                child: const Text('LOGIN SEKARANG',
                    style: TextStyle(fontFamily: 'Outfit', fontSize: 13,
                        fontWeight: FontWeight.w900, letterSpacing: 1)),
              ),
            ),
          ]),
        ]),
      ),
    );
  }

  Widget _credRow({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Row(children: [
      Icon(icon, color: _cPrimary, size: 15),
      const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontFamily: 'Outfit',
            fontSize: 9, color: _cText3, letterSpacing: 1)),
        Text(value, style: TextStyle(fontFamily: 'Outfit',
            fontSize: 14, fontWeight: FontWeight.w900, color: color)),
      ])),
      GestureDetector(
        onTap: () {
          Clipboard.setData(ClipboardData(text: value));
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('$label disalin!',
                style: const TextStyle(color: Colors.white, fontFamily: 'Outfit', fontSize: 12)),
            backgroundColor: _cGreen,
            behavior: SnackBarBehavior.floating,
            duration: const Duration(seconds: 1),
            shape: RoundedRectangleBorder(borderRadius: const BorderRadius.all(Radius.circular(10))),
            margin: const EdgeInsets.all(16),
          ));
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: color.withOpacity(0.12),
            borderRadius: const BorderRadius.all(Radius.circular(7)),
            border: Border.all(color: color.withOpacity(0.25)),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.copy_rounded, size: 11, color: color),
            const SizedBox(width: 4),
            Text('Salin', style: TextStyle(fontFamily: 'Outfit',
                fontSize: 9, fontWeight: FontWeight.w700, color: color)),
          ]),
        ),
      ),
    ]);
  }
}

class _PlayIcon extends StatelessWidget {
  const _PlayIcon();
  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: const Size(18, 18),
      painter: _PlayPainter(),
    );
  }
}

class _PlayPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white.withOpacity(0.85);
    final path = Path()
      ..moveTo(size.width * 0.25, size.height * 0.1)
      ..lineTo(size.width * 0.95, size.height * 0.5)
      ..lineTo(size.width * 0.25, size.height * 0.9)
      ..close();
    canvas.drawPath(path, paint);
  }
  @override
  bool shouldRepaint(_) => false;
}

class _VideoPlaceholder extends StatelessWidget {
  const _VideoPlaceholder();
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: RadialGradient(
          center: Alignment(-0.3, -0.2),
          radius: 1.2,
          colors: [Color(0x478B5CF6), Color(0x2522D3EE), Color(0xFF0A0A16)],
          stops: [0.0, 0.55, 1.0],
        ),
      ),
      child: CustomPaint(painter: _GridPainter()),
    );
  }
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.022)
      ..strokeWidth = 1;
    const step = 36.0;
    for (double x = 0; x <= size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y <= size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }
  @override
  bool shouldRepaint(_) => false;
}

class _StatCard extends StatelessWidget {
  final String icon, value, label;
  final Color accentColor;
  const _StatCard({
    required this.icon, required this.value,
    required this.label, required this.accentColor,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.fromLTRB(0, 14, 0, 12),
        decoration: BoxDecoration(
          color: _cSurface1,
          borderRadius: const BorderRadius.all(Radius.circular(14)),
          border: Border.all(color: _cLine),
        ),
        child: Column(children: [
          Container(
            width: 34, height: 34,
            decoration: BoxDecoration(
              color: accentColor.withOpacity(0.08),
              shape: BoxShape.circle,
              border: Border.all(color: accentColor.withOpacity(0.15)),
            ),
            child: Center(
              child: Text(icon, style: const TextStyle(fontSize: 15)),
            ),
          ),
          const SizedBox(height: 8),
          Text(value,
              style: TextStyle(
                  fontFamily: 'Outfit',
                  fontSize: 15, fontWeight: FontWeight.w900,
                  color: accentColor, letterSpacing: 0.3)),
          const SizedBox(height: 3),
          Text(label,
              style: const TextStyle(
                  fontFamily: 'Outfit',
                  fontSize: 8, fontWeight: FontWeight.w700,
                  color: _cText3, letterSpacing: 1.8)),
        ]),
      ),
    );
  }
}

class _SocialBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _SocialBtn({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: _cSurface1,
          borderRadius: const BorderRadius.all(Radius.circular(9)),
          border: Border.all(color: _cLine),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          FaIcon(icon, color: _cPrimary, size: 13),
          const SizedBox(width: 7),
          Text(label,
              style: const TextStyle(
                  fontFamily: 'Outfit',
                  fontSize: 12, fontWeight: FontWeight.w600,
                  color: _cText2)),
        ]),
      ),
    );
  }
}

// ══════════════════════════════════════════════
// SOCIAL CARD (gambar icon + label)
// ══════════════════════════════════════════════
class _SocialCard extends StatelessWidget {
  final String asset;
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _SocialCard({
    required this.asset,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: _cSurface1,
            borderRadius: const BorderRadius.all(Radius.circular(12)),
            border: Border.all(color: color.withOpacity(0.25)),
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Image.asset(asset, width: 22, height: 22),
            const SizedBox(height: 5),
            Text(label,
                style: TextStyle(
                    fontFamily: 'Outfit',
                    fontSize: 9, fontWeight: FontWeight.w700,
                    color: color, letterSpacing: 0.5)),
          ]),
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════
// UPDATE BOTTOM SHEET
// ══════════════════════════════════════════════
class _UpdateSheet extends StatelessWidget {
  final UpdateInfo info;
  final bool force;
  final VoidCallback onUpdate;
  final VoidCallback? onDismiss;

  const _UpdateSheet({
    required this.info,
    required this.force,
    required this.onUpdate,
    this.onDismiss,
  });

  @override
  Widget build(BuildContext context) {
    final lines = info.changelog.isNotEmpty
        ? info.changelog.split('\n').where((l) => l.trim().isNotEmpty).toList()
        : <String>[];

    return Container(
      decoration: const BoxDecoration(
        color: _cSurface1,
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
        border: Border(
          top:   BorderSide(color: _cLine),
          left:  BorderSide(color: _cLine),
          right: BorderSide(color: _cLine),
        ),
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(
          width: 34, height: 4,
          margin: const EdgeInsets.only(top: 12),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.1),
            borderRadius: const BorderRadius.all(Radius.circular(99)),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(22, 18, 22, 14),
          child: Row(children: [
            Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                color: _cPrimary.withOpacity(0.1),
                borderRadius: const BorderRadius.all(Radius.circular(11)),
                border: Border.all(color: _cPrimary.withOpacity(0.2)),
              ),
              child: const Center(
                child: Text('🔄', style: TextStyle(fontSize: 19)),
              ),
            ),
            const SizedBox(width: 12),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Update Tersedia',
                  style: TextStyle(fontFamily: 'Outfit',
                      fontSize: 17, fontWeight: FontWeight.w900,
                      color: _cText1)),
              Text('Versi ${info.latestVersion} siap diinstall',
                  style: const TextStyle(
                      fontFamily: 'Outfit',
                      fontSize: 12, color: _cText2, fontWeight: FontWeight.w500)),
            ]),
          ]),
        ),
        Container(height: 1, color: _cLine, margin: const EdgeInsets.symmetric(horizontal: 22)),
        Padding(
          padding: const EdgeInsets.fromLTRB(22, 18, 22, 24),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(
              force
                  ? 'Kamu harus update untuk melanjutkan menggunakan aplikasi.'
                  : 'Update ini membawa peningkatan performa signifikan dan perbaikan bug.',
              style: const TextStyle(fontSize: 13, color: _cText2, height: 1.65),
            ),
            if (lines.isNotEmpty) ...[
              const SizedBox(height: 14),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: _cSurface2,
                  borderRadius: const BorderRadius.all(Radius.circular(11)),
                  border: Border.all(color: _cLine),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Container(width: 4, height: 4,
                        decoration: const BoxDecoration(
                            color: _cPrimary, shape: BoxShape.circle)),
                    const SizedBox(width: 6),
                    const Text('CHANGELOG',
                        style: TextStyle(
                            fontFamily: 'Outfit',
                            fontSize: 10, fontWeight: FontWeight.w700,
                            letterSpacing: 1.5, color: _cText3)),
                  ]),
                  const SizedBox(height: 9),
                  ...lines.map((l) => Padding(
                    padding: const EdgeInsets.only(bottom: 5),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('›  ', style: TextStyle(
                            color: _cPrimary2, fontSize: 13,
                            fontWeight: FontWeight.w600)),
                        Expanded(child: Text(l,
                            style: const TextStyle(fontSize: 13,
                                color: _cText2, height: 1.5))),
                      ],
                    ),
                  )),
                ]),
              ),
            ],
            const SizedBox(height: 18),
            Row(children: [
              if (!force) ...[
                Expanded(
                  child: SizedBox(
                    height: 46,
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: _cLine),
                        shape: RoundedRectangleBorder(
                            borderRadius: const BorderRadius.all(Radius.circular(11))),
                        foregroundColor: _cText3,
                      ),
                      onPressed: onDismiss,
                      child: const Text('Nanti',
                          style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
              ],
              Expanded(
                flex: 2,
                child: SizedBox(
                  height: 46,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _cPrimary,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shadowColor: Colors.transparent,
                      shape: RoundedRectangleBorder(
                          borderRadius: const BorderRadius.all(Radius.circular(11))),
                    ),
                    icon: const Text('⬇ ', style: TextStyle(fontSize: 14)),
                    label: const Text('Update Sekarang',
                        style: TextStyle(fontFamily: 'Outfit',
                            fontSize: 15, fontWeight: FontWeight.w900,
                            letterSpacing: 0.5)),
                    onPressed: onUpdate,
                  ),
                ),
              ),
            ]),
          ]),
        ),
      ]),
    );
  }
}

// ══════════════════════════════════════════════
// MODEL PAKET HARGA
// ══════════════════════════════════════════════
class _PaketHarga {
  final String id;
  final String nama;
  final String durasi;
  final int harga;
  final String emoji;
  final bool isPopuler;

  const _PaketHarga({
    required this.id,
    required this.nama,
    required this.durasi,
    required this.harga,
    required this.emoji,
    this.isPopuler = false,
  });

  String get hargaFmt {
    final s = harga.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return 'Rp${buf.toString()}';
  }

  factory _PaketHarga.fromJson(Map<String, dynamic> j) => _PaketHarga(
        id:       j['id']?.toString()    ?? '',
        nama:     j['nama']?.toString()  ?? j['name']?.toString() ?? '',
        durasi:   j['durasi']?.toString() ?? j['duration']?.toString() ?? '',
        harga:    ((j['harga'] ?? j['price'] ?? 0) as num).toInt(),
        emoji:    j['emoji']?.toString()  ?? '📦',
        isPopuler: j['is_popular'] == true || j['populer'] == true,
      );
}

// ══════════════════════════════════════════════
// REGISTER SHEET — pilih paket harga
// ══════════════════════════════════════════════
class _RegisterSheet extends StatefulWidget {
  const _RegisterSheet();

  @override
  State<_RegisterSheet> createState() => _RegisterSheetState();
}

class _RegisterSheetState extends State<_RegisterSheet> {

  List<_PaketHarga> _pakets = [];
  bool _loading = true;
  String _err = '';

  @override
  void initState() {
    super.initState();
    _loadPakets();
  }

  Future<void> _loadPakets() async {
    if (mounted) setState(() { _loading = true; _err = ''; });
    try {
      final res = await http.get(
        Uri.parse('${ConfigService.baseUrl}/api/paket-harga'),
        headers: {'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 8));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final List raw = data['data'] ?? data['pakets'] ?? data ?? [];
        final list = raw.map((e) => _PaketHarga.fromJson(e as Map<String, dynamic>)).toList();
        if (mounted) setState(() { _pakets = list; _loading = false; });
      } else {
        if (mounted) setState(() { _err = 'Gagal memuat paket (${res.statusCode})'; _loading = false; });
      }
    } catch (_) {
      if (mounted) setState(() { _err = 'Koneksi gagal. Coba lagi.'; _loading = false; });
    }
  }

  void _pilihPaket(_PaketHarga p) {
    Navigator.pop(context);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (_) => _BeliAksesSheet(paket: p),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.70,
      minChildSize: 0.4,
      maxChildSize: 0.92,
      builder: (_, ctrl) => Container(
        decoration: const BoxDecoration(
          color: _cSurface1,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          border: Border(
            top:   BorderSide(color: _cLine),
            left:  BorderSide(color: _cLine),
            right: BorderSide(color: _cLine),
          ),
        ),
        child: Column(children: [
          Container(
            width: 36, height: 4,
            margin: const EdgeInsets.only(top: 12, bottom: 6),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.12),
              borderRadius: const BorderRadius.all(Radius.circular(99)),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 14),
            child: Row(children: [
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  color: _cPrimary.withOpacity(0.12),
                  borderRadius: const BorderRadius.all(Radius.circular(11)),
                  border: Border.all(color: _cPrimary.withOpacity(0.3)),
                ),
                child: const Center(child: Text('🛒', style: TextStyle(fontSize: 18))),
              ),
              const SizedBox(width: 12),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('BELI AKSES',
                    style: TextStyle(fontFamily: 'Outfit',
                        fontSize: 17, fontWeight: FontWeight.w900, color: _cText1)),
                Text('Pilih paket yang sesuai kebutuhanmu',
                    style: const TextStyle(fontFamily: 'Outfit',
                        fontSize: 11, color: _cText3)),
              ]),
            ]),
          ),
          Container(height: 1, color: _cLine, margin: const EdgeInsets.symmetric(horizontal: 20)),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(color: _cPrimary, strokeWidth: 2))
                : _err.isNotEmpty
                    ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                        const Text('😕', style: TextStyle(fontSize: 32)),
                        const SizedBox(height: 10),
                        Text(_err, style: const TextStyle(fontFamily: 'Outfit',
                            fontSize: 13, color: _cText3)),
                        const SizedBox(height: 14),
                        GestureDetector(
                          onTap: _loadPakets,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                            decoration: BoxDecoration(
                              color: _cPrimary.withOpacity(0.12),
                              borderRadius: const BorderRadius.all(Radius.circular(10)),
                              border: Border.all(color: _cPrimary.withOpacity(0.3)),
                            ),
                            child: const Text('Coba Lagi', style: TextStyle(
                                fontFamily: 'Outfit', fontSize: 13,
                                fontWeight: FontWeight.w700, color: _cPrimary2)),
                          ),
                        ),
                      ]))
                    : ListView.separated(
                        controller: ctrl,
                        padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
                        itemCount: _pakets.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 10),
                        itemBuilder: (_, i) => _PaketCard(
                          paket: _pakets[i],
                          onTap: () => _pilihPaket(_pakets[i]),
                        ),
                      ),
          ),
        ]),
      ),
    );
  }
}

// ── Paket Card ────────────────────────────────
class _PaketCard extends StatelessWidget {
  final _PaketHarga paket;
  final VoidCallback onTap;
  const _PaketCard({required this.paket, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _cSurface2,
          borderRadius: const BorderRadius.all(Radius.circular(16)),
          border: Border.all(
            color: paket.isPopuler ? _cPrimary.withOpacity(0.5) : _cLine,
            width: paket.isPopuler ? 1.4 : 1,
          ),
          boxShadow: paket.isPopuler ? [
            BoxShadow(color: _cPrimary.withOpacity(0.12), blurRadius: 18),
          ] : [],
        ),
        child: Row(children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              color: _cPrimary.withOpacity(0.08),
              borderRadius: const BorderRadius.all(Radius.circular(12)),
              border: Border.all(color: _cPrimary.withOpacity(0.15)),
            ),
            child: Center(child: Text(paket.emoji, style: const TextStyle(fontSize: 22))),
          ),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Text(paket.nama,
                  style: const TextStyle(fontFamily: 'Outfit',
                      fontSize: 14, fontWeight: FontWeight.w900, color: _cText1)),
              if (paket.isPopuler) ...[ 
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                  decoration: BoxDecoration(
                    color: _cPrimary.withOpacity(0.15),
                    borderRadius: const BorderRadius.all(Radius.circular(99)),
                    border: Border.all(color: _cPrimary.withOpacity(0.3)),
                  ),
                  child: const Text('POPULER',
                      style: TextStyle(fontFamily: 'Outfit',
                          fontSize: 8, fontWeight: FontWeight.w800,
                          color: _cPrimary2, letterSpacing: 1)),
                ),
              ],
            ]),
            const SizedBox(height: 3),
            Text(paket.durasi,
                style: const TextStyle(fontFamily: 'Outfit',
                    fontSize: 11, color: _cText3, fontWeight: FontWeight.w500)),
          ])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(paket.hargaFmt,
                style: const TextStyle(fontFamily: 'Outfit',
                    fontSize: 16, fontWeight: FontWeight.w900, color: _cPrimary2)),
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [_cPrimary, Color(0xFF7C3AED)],
                ),
                borderRadius: BorderRadius.all(Radius.circular(9)),
              ),
              child: const Text('PILIH',
                  style: TextStyle(fontFamily: 'Outfit',
                      fontSize: 11, fontWeight: FontWeight.w800,
                      color: Colors.white, letterSpacing: 1)),
            ),
          ]),
        ]),
      ),
    );
  }
}


// ══════════════════════════════════════════════
// BELI AKSES SHEET — QRIS Statis + Upload Bukti
// ══════════════════════════════════════════════
class _BeliAksesSheet extends StatefulWidget {
  final _PaketHarga paket;
  const _BeliAksesSheet({required this.paket});
  @override
  State<_BeliAksesSheet> createState() => _BeliAksesSheetState();
}

class _BeliAksesSheetState extends State<_BeliAksesSheet> {

  String _step = 'form';
  final TextEditingController _usernameCtrl = TextEditingController();
  final TextEditingController _passwordCtrl = TextEditingController();
  bool _obscurePass = true;
  File? _buktiFile;
  bool _loadingUpload = false;
  String _reqId = '';
  Timer? _pollTimer;
  bool   _polling = false;
  String _pollStatus = 'Menunggu konfirmasi owner...';
  String _doneExpiredDate = '';
  String _donePassword = '';
  bool _obscureDonePass = true;

  @override
  void initState() {
    super.initState();
    _checkPendingBeli();
  }

  Future<void> _checkPendingBeli() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final reqId = prefs.getString('pending_req_id') ?? '';
      final type  = prefs.getString('pending_req_type') ?? '';
      final uname = prefs.getString('pending_req_username') ?? '';
      final pass  = prefs.getString('pending_req_password') ?? '';
      if (reqId.isNotEmpty && type == 'beli') {
        if (mounted) {
          setState(() {
            _reqId = reqId;
            _usernameCtrl.text = uname;
            _passwordCtrl.text = pass;
            _step = 'tunggu';
          });
          _startPolling();
        }
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _usernameCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  void _lanjutKeQris() {
    final username = _usernameCtrl.text.trim();
    final password = _passwordCtrl.text.trim();
    if (username.isEmpty) { _snack('Masukkan username dulu!'); return; }
    if (username.length < 4) { _snack('Username minimal 4 karakter!'); return; }
    if (password.isEmpty) { _snack('Masukkan password dulu!'); return; }
    if (password.length < 6) { _snack('Password minimal 6 karakter!'); return; }
    setState(() => _step = 'qris');
  }

  Future<void> _pickBukti() async {
    final picked = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      imageQuality: 70,
      maxWidth: 1080,
    );
    if (picked == null) return;
    setState(() { _buktiFile = File(picked.path); _step = 'bukti'; });
  }

  Future<void> _kirimBukti() async {
    if (_buktiFile == null) return;
    setState(() => _loadingUpload = true);
    if (ConfigService.baseUrl.isEmpty) await ConfigService.init();

    try {
      final bytes = await _buktiFile!.readAsBytes();
      final base64Str = base64Encode(bytes);
      final mime = _buktiFile!.path.toLowerCase().endsWith('.png')
          ? 'image/png' : 'image/jpeg';

      final res = await http.post(
        Uri.parse('${ConfigService.baseUrl}/api/beli-akses'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username':    _usernameCtrl.text.trim(),
          'password':    _passwordCtrl.text.trim(),
          'paketId':     widget.paket.id,
          'buktiBase64': base64Str,
          'buktiMime':   mime,
        }),
      ).timeout(const Duration(seconds: 30));

      final d = jsonDecode(res.body);
      if (d['success'] == true) {
        final reqId = d['reqId'] ?? '';
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('pending_req_id', reqId);
        await prefs.setString('pending_req_username', _usernameCtrl.text.trim());
        await prefs.setString('pending_req_password', _passwordCtrl.text.trim());
        await prefs.setString('pending_req_type', 'beli');
        setState(() {
          _reqId = reqId;
          _loadingUpload = false;
          _step = 'tunggu';
        });
        _startPolling();
      } else {
        setState(() => _loadingUpload = false);
        _snack(d['message'] ?? 'Gagal kirim bukti');
      }
    } catch (e) {
      setState(() => _loadingUpload = false);
      _snack('Error: ' + e.toString().split('\n').first);
    }
  }

  void _startPolling() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) => _cekStatus());
  }

  Future<void> _cekStatus() async {
    if (_polling || _reqId.isEmpty) return;
    _polling = true;
    try {
      final res = await http.get(
        Uri.parse('${ConfigService.baseUrl}/api/beli-akses/status/$_reqId'),
      ).timeout(const Duration(seconds: 10));
      final d = jsonDecode(res.body);
      if (d['success'] == true) {
        final status = d['status'] ?? 'pending';
        if (status == 'approved') {
          _pollTimer?.cancel();
          final prefs = await SharedPreferences.getInstance();
          await prefs.remove('pending_req_id');
          await prefs.remove('pending_req_username');
          await prefs.remove('pending_req_password');
          await prefs.remove('pending_req_type');
          setState(() {
            _doneExpiredDate = d['expiredDate'] ?? '';
            _donePassword = d['password'] ?? _passwordCtrl.text.trim();
            _step = 'done';
          });
        } else if (status == 'rejected') {
          _pollTimer?.cancel();
          setState(() => _pollStatus = 'Ditolak oleh owner.');
          _snack('❌ Request ditolak. Hubungi owner.');
        } else {
          setState(() => _pollStatus = 'Menunggu konfirmasi owner...');
        }
      }
    } catch (_) {}
    _polling = false;
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(color: Colors.white)),
      backgroundColor: _cPrimary,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: const BorderRadius.all(Radius.circular(12))),
      margin: const EdgeInsets.all(16),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: _cBg,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        border: Border.all(color: _cPrimary.withOpacity(0.18)),
      ),
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(22, 20, 22, 32),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(child: Container(width: 40, height: 4,
              decoration: BoxDecoration(color: _cLine, borderRadius: const BorderRadius.all(Radius.circular(2))))),
          const SizedBox(height: 16),
          Row(children: [
            Container(
              width: 38, height: 38,
              decoration: BoxDecoration(
                color: _cPrimary.withOpacity(0.12),
                borderRadius: const BorderRadius.all(Radius.circular(10)),
                border: Border.all(color: _cPrimary.withOpacity(0.3)),
              ),
              child: const Center(child: Text('🛒', style: TextStyle(fontSize: 18))),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('BELI AKSES · ${widget.paket.nama}',
                  style: const TextStyle(fontFamily: 'Outfit',
                      fontSize: 15, fontWeight: FontWeight.w900,
                      color: _cText1, letterSpacing: 1.2)),
              Text('${widget.paket.durasi} · ${widget.paket.hargaFmt}',
                  style: const TextStyle(fontFamily: 'Outfit', fontSize: 11, color: _cText3)),
            ])),
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: const Icon(Icons.close_rounded, color: _cText3, size: 22),
            ),
          ]),
          const SizedBox(height: 16),
          Divider(color: _cLine, height: 1),
          const SizedBox(height: 18),

          if (_step == 'form')   _buildFormStep(),
          if (_step == 'qris')   _buildQrisStep(),
          if (_step == 'bukti')  _buildBuktiStep(),
          if (_step == 'tunggu') _buildTungguStep(),
          if (_step == 'done')   _buildDoneStep(),
        ]),
      ),
    );
  }

  Widget _buildFormStep() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Text('Buat Akun Baru',
        style: TextStyle(fontFamily: 'Outfit', fontSize: 13, fontWeight: FontWeight.w900, color: _cText1)),
    const SizedBox(height: 6),
    Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _cPrimary.withOpacity(0.06),
        borderRadius: const BorderRadius.all(Radius.circular(12)),
        border: Border.all(color: _cPrimary.withOpacity(0.2)),
      ),
      child: const Row(children: [
        Text('💡', style: TextStyle(fontSize: 13)),
        SizedBox(width: 8),
        Expanded(child: Text(
          'Username & password ini yang kamu pakai untuk login setelah pembayaran dikonfirmasi owner.',
          style: TextStyle(fontFamily: 'Outfit', fontSize: 11, color: _cText2, height: 1.5),
        )),
      ]),
    ),
    const SizedBox(height: 14),
    TextField(
      controller: _usernameCtrl,
      style: const TextStyle(fontFamily: 'Outfit', color: _cText1, fontSize: 14),
      decoration: InputDecoration(
        labelText: 'Username',
        hintText: 'cth. miwa123 (min. 4 karakter)',
        hintStyle: const TextStyle(color: _cText3, fontFamily: 'Outfit', fontSize: 12),
        labelStyle: const TextStyle(color: _cText3, fontSize: 13),
        prefixIcon: const Icon(Icons.person_outline_rounded, color: _cPrimary, size: 18),
        filled: true, fillColor: _cSurface1,
        border: OutlineInputBorder(borderRadius: const BorderRadius.all(Radius.circular(12)), borderSide: BorderSide(color: _cLine)),
        enabledBorder: OutlineInputBorder(borderRadius: const BorderRadius.all(Radius.circular(12)), borderSide: BorderSide(color: _cLine)),
        focusedBorder: OutlineInputBorder(borderRadius: const BorderRadius.all(Radius.circular(12)), borderSide: BorderSide(color: _cPrimary.withOpacity(0.5), width: 1.4)),
      ),
    ),
    const SizedBox(height: 10),
    TextField(
      controller: _passwordCtrl,
      obscureText: _obscurePass,
      style: const TextStyle(fontFamily: 'Outfit', color: _cText1, fontSize: 14),
      decoration: InputDecoration(
        labelText: 'Password',
        hintText: 'Min. 6 karakter',
        hintStyle: const TextStyle(color: _cText3, fontFamily: 'Outfit', fontSize: 12),
        labelStyle: const TextStyle(color: _cText3, fontSize: 13),
        prefixIcon: const Icon(Icons.lock_outline_rounded, color: _cPrimary, size: 18),
        suffixIcon: GestureDetector(
          onTap: () => setState(() => _obscurePass = !_obscurePass),
          child: Icon(_obscurePass ? Icons.visibility_off_outlined : Icons.visibility_outlined,
              color: _cText3, size: 18),
        ),
        filled: true, fillColor: _cSurface1,
        border: OutlineInputBorder(borderRadius: const BorderRadius.all(Radius.circular(12)), borderSide: BorderSide(color: _cLine)),
        enabledBorder: OutlineInputBorder(borderRadius: const BorderRadius.all(Radius.circular(12)), borderSide: BorderSide(color: _cLine)),
        focusedBorder: OutlineInputBorder(borderRadius: const BorderRadius.all(Radius.circular(12)), borderSide: BorderSide(color: _cPrimary.withOpacity(0.5), width: 1.4)),
      ),
    ),
    const SizedBox(height: 18),
    SizedBox(
      width: double.infinity, height: 48,
      child: ElevatedButton(
        onPressed: _lanjutKeQris,
        style: ElevatedButton.styleFrom(
          backgroundColor: _cPrimary, foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: const BorderRadius.all(Radius.circular(13))), elevation: 0,
        ),
        child: const Text('LANJUT → LIHAT QRIS',
            style: TextStyle(fontFamily: 'Outfit', fontSize: 13, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
      ),
    ),
  ]);

  Widget _buildQrisStep() {
    final hargaFmt = widget.paket.hargaFmt;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        GestureDetector(onTap: () => setState(() => _step = 'form'),
            child: const Icon(Icons.arrow_back_rounded, color: _cText3, size: 20)),
        const SizedBox(width: 8),
        Expanded(child: Text('${widget.paket.nama} · ${hargaFmt}',
            style: const TextStyle(fontFamily: 'Outfit', fontSize: 12, fontWeight: FontWeight.w700, color: _cPrimary2))),
      ]),
      const SizedBox(height: 16),
      Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: _cPrimary.withOpacity(0.08),
          borderRadius: const BorderRadius.all(Radius.circular(12)),
          border: Border.all(color: _cPrimary.withOpacity(0.25)),
        ),
        child: Column(children: [
          const Text('Transfer tepat nominal:',
              style: TextStyle(fontFamily: 'Outfit', fontSize: 11, color: _cText3)),
          const SizedBox(height: 4),
          Text(hargaFmt,
              style: const TextStyle(fontFamily: 'Outfit', fontSize: 22, fontWeight: FontWeight.w900, color: _cPrimary2)),
        ]),
      ),
      const SizedBox(height: 14),
      Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: const BorderRadius.all(Radius.circular(16)),
          border: Border.all(color: _cLine),
        ),
        padding: const EdgeInsets.all(12),
        child: Image.asset(
          'assets/qris.png', fit: BoxFit.contain, height: 240,
        ),
      ),
      const SizedBox(height: 8),
      const Center(child: Text('MARKET OMZILLXY, GROSIR · NMID: ID1025408222129',
          style: TextStyle(fontFamily: 'Outfit', fontSize: 10, color: _cText3, letterSpacing: 0.5))),
      const SizedBox(height: 16),
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: _cSurface1,
          borderRadius: const BorderRadius.all(Radius.circular(12)),
          border: Border.all(color: _cLine),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('📋 Ringkasan Pesanan',
              style: TextStyle(fontFamily: 'Outfit', fontSize: 11, fontWeight: FontWeight.w700, color: _cPrimary2)),
          const SizedBox(height: 8),
          Row(children: [
            const Text('Username : ', style: TextStyle(fontFamily: 'Outfit', fontSize: 11, color: _cText3)),
            Text(_usernameCtrl.text.trim(),
                style: const TextStyle(fontFamily: 'Outfit', fontSize: 12, fontWeight: FontWeight.w700, color: _cText1)),
          ]),
          const SizedBox(height: 4),
          Row(children: [
            const Text('Paket    : ', style: TextStyle(fontFamily: 'Outfit', fontSize: 11, color: _cText3)),
            Text('${widget.paket.nama} (${widget.paket.durasi})',
                style: const TextStyle(fontFamily: 'Outfit', fontSize: 12, fontWeight: FontWeight.w700, color: _cText1)),
          ]),
        ]),
      ),
      const SizedBox(height: 14),
      SizedBox(
        width: double.infinity, height: 48,
        child: ElevatedButton.icon(
          onPressed: _pickBukti,
          icon: const Icon(Icons.upload_rounded, size: 18),
          label: const Text('UPLOAD BUKTI BAYAR',
              style: TextStyle(fontFamily: 'Outfit', fontSize: 13, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
          style: ElevatedButton.styleFrom(
            backgroundColor: _cPrimary, foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: const BorderRadius.all(Radius.circular(13))), elevation: 0,
          ),
        ),
      ),
    ]);
  }

  Widget _buildBuktiStep() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [
      GestureDetector(onTap: () => setState(() { _buktiFile = null; _step = 'qris'; }),
          child: const Icon(Icons.arrow_back_rounded, color: _cText3, size: 20)),
      const SizedBox(width: 8),
      const Text('Preview Bukti Bayar',
          style: TextStyle(fontFamily: 'Outfit', fontSize: 13, fontWeight: FontWeight.w800, color: _cText1)),
    ]),
    const SizedBox(height: 14),
    if (_buktiFile != null)
      ClipRRect(
        borderRadius: const BorderRadius.all(Radius.circular(14)),
        child: Image.file(_buktiFile!, width: double.infinity, height: 220, fit: BoxFit.cover),
      ),
    const SizedBox(height: 10),
    Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _cSurface1,
        borderRadius: const BorderRadius.all(Radius.circular(12)),
        border: Border.all(color: _cLine),
      ),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(_usernameCtrl.text.trim(),
              style: const TextStyle(fontFamily: 'Outfit', fontSize: 13, fontWeight: FontWeight.w900, color: _cText1)),
          Text('${widget.paket.nama} · ${widget.paket.durasi}',
              style: const TextStyle(fontFamily: 'Outfit', fontSize: 11, color: _cText3)),
        ]),
        Text(widget.paket.hargaFmt,
            style: const TextStyle(fontFamily: 'Outfit', fontSize: 15, fontWeight: FontWeight.w900, color: _cPrimary2)),
      ]),
    ),
    const SizedBox(height: 14),
    Row(children: [
      Expanded(
        child: GestureDetector(
          onTap: () => setState(() { _buktiFile = null; _step = 'qris'; }),
          child: Container(
            height: 44,
            decoration: BoxDecoration(
              color: _cSurface1,
              borderRadius: const BorderRadius.all(Radius.circular(12)),
              border: Border.all(color: _cLine),
            ),
            child: const Center(child: Text('Ganti Foto',
                style: TextStyle(fontFamily: 'Outfit', fontSize: 13, fontWeight: FontWeight.w700, color: _cText2))),
          ),
        ),
      ),
      const SizedBox(width: 10),
      Expanded(
        flex: 2,
        child: SizedBox(
          height: 44,
          child: ElevatedButton(
            onPressed: _loadingUpload ? null : _kirimBukti,
            style: ElevatedButton.styleFrom(
              backgroundColor: _cPrimary, foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: const BorderRadius.all(Radius.circular(12))), elevation: 0,
            ),
            child: _loadingUpload
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : const Text('KIRIM BUKTI', style: TextStyle(fontFamily: 'Outfit', fontSize: 13, fontWeight: FontWeight.w800)),
          ),
        ),
      ),
    ]),
  ]);

  Widget _buildTungguStep() => Column(children: [
    const SizedBox(height: 12),
    Center(child: Column(children: [
      Container(
        width: 60, height: 60,
        decoration: BoxDecoration(
          color: _cPrimary.withOpacity(0.12),
          shape: BoxShape.circle,
          border: Border.all(color: _cPrimary.withOpacity(0.3), width: 1.5),
        ),
        child: const Center(child: Text('⏳', style: TextStyle(fontSize: 28))),
      ),
      const SizedBox(height: 14),
      const Text('BUKTI TERKIRIM!',
          style: TextStyle(fontFamily: 'Outfit', fontSize: 15, fontWeight: FontWeight.w900, color: _cText1, letterSpacing: 1)),
      const SizedBox(height: 6),
      const Text('Menunggu konfirmasi owner...',
          style: TextStyle(fontFamily: 'Outfit', fontSize: 12, color: _cText3)),
    ])),
    const SizedBox(height: 20),
    Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _cSurface1,
        borderRadius: const BorderRadius.all(Radius.circular(12)),
        border: Border.all(color: _cLine),
      ),
      child: Row(children: [
        const SizedBox(width: 14, height: 14,
            child: CircularProgressIndicator(color: _cPrimary, strokeWidth: 2)),
        const SizedBox(width: 10),
        Expanded(child: Text(_pollStatus,
            style: const TextStyle(fontFamily: 'Outfit', fontSize: 12, color: _cText2))),
      ]),
    ),
    const SizedBox(height: 12),
    const Text('Halaman ini otomatis update setelah owner konfirmasi',
        style: TextStyle(fontFamily: 'Outfit', fontSize: 10, color: _cText3),
        textAlign: TextAlign.center),
    const SizedBox(height: 16),
    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      OutlinedButton.icon(
        onPressed: () => launchUrl(Uri.parse('https://wa.me/6282221520070'), mode: LaunchMode.externalApplication),
        icon: Image.asset('assets/whatsapp.png', width: 16, height: 16),
        label: const Text('WhatsApp',
            style: TextStyle(fontFamily: 'Outfit', fontSize: 12,
                fontWeight: FontWeight.w600, color: Color(0xFF25D366))),
        style: OutlinedButton.styleFrom(
          side: const BorderSide(color: Color(0xFF25D366), width: 1),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          shape: RoundedRectangleBorder(borderRadius: const BorderRadius.all(Radius.circular(10))),
        ),
      ),
      const SizedBox(width: 10),
      OutlinedButton.icon(
        onPressed: () => launchUrl(Uri.parse('https://t.me/alwaysZilllxy'), mode: LaunchMode.externalApplication),
        icon: Image.asset('assets/telegram.png', width: 16, height: 16),
        label: const Text('Telegram',
            style: TextStyle(fontFamily: 'Outfit', fontSize: 12,
                fontWeight: FontWeight.w600, color: Color(0xFF229ED9))),
        style: OutlinedButton.styleFrom(
          side: const BorderSide(color: Color(0xFF229ED9), width: 1),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          shape: RoundedRectangleBorder(borderRadius: const BorderRadius.all(Radius.circular(10))),
        ),
      ),
    ]),
  ]);

  Widget _buildDoneStep() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Center(child: Column(children: [
      Container(
        width: 64, height: 64,
        decoration: BoxDecoration(
          color: _cGreen.withOpacity(0.15),
          shape: BoxShape.circle,
          border: Border.all(color: _cGreen.withOpacity(0.4), width: 1.5),
        ),
        child: const Center(child: Text('✅', style: TextStyle(fontSize: 30))),
      ),
      const SizedBox(height: 12),
      const Text('AKUN BERHASIL DIBUAT!',
          style: TextStyle(fontFamily: 'Outfit', fontSize: 16, fontWeight: FontWeight.w900,
              color: _cGreen, letterSpacing: 1.2)),
      const SizedBox(height: 4),
      const Text('Owner sudah konfirmasi pembayaranmu',
          style: TextStyle(fontFamily: 'Outfit', fontSize: 12, color: _cText3)),
    ])),
    const SizedBox(height: 20),
    Container(
      width: double.infinity, padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _cSurface1,
        borderRadius: const BorderRadius.all(Radius.circular(14)),
        border: Border.all(color: _cGreen.withOpacity(0.25)),
      ),
      child: Column(children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: _cSurface2,
            borderRadius: const BorderRadius.all(Radius.circular(10)),
            border: Border.all(color: _cLine),
          ),
          child: Row(children: [
            const Icon(Icons.person_outline, color: _cPrimary, size: 16),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('USERNAME',
                  style: TextStyle(fontFamily: 'Outfit', fontSize: 9, color: _cText3, letterSpacing: 1)),
              Text(_usernameCtrl.text.trim(),
                  style: const TextStyle(fontFamily: 'Outfit', fontSize: 15, fontWeight: FontWeight.w900, color: _cText1)),
            ])),
            GestureDetector(
              onTap: () {
                Clipboard.setData(ClipboardData(text: _usernameCtrl.text.trim()));
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                  content: Text('Username disalin!', style: TextStyle(color: Colors.white, fontFamily: 'Outfit', fontSize: 12)),
                  backgroundColor: _cGreen, behavior: SnackBarBehavior.floating,
                  duration: Duration(seconds: 1),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10))),
                  margin: EdgeInsets.all(16),
                ));
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: _cPrimary2.withOpacity(0.12),
                  borderRadius: const BorderRadius.all(Radius.circular(7)),
                  border: Border.all(color: _cPrimary2.withOpacity(0.25)),
                ),
                child: const Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.copy_rounded, size: 11, color: _cPrimary2),
                  SizedBox(width: 4),
                  Text('Salin', style: TextStyle(fontFamily: 'Outfit', fontSize: 9, fontWeight: FontWeight.w700, color: _cPrimary2)),
                ]),
              ),
            ),
          ]),
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: _cSurface2,
            borderRadius: const BorderRadius.all(Radius.circular(10)),
            border: Border.all(color: _cLine),
          ),
          child: Row(children: [
            const Icon(Icons.lock_outline, color: _cPrimary, size: 16),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('PASSWORD',
                  style: TextStyle(fontFamily: 'Outfit', fontSize: 9, color: _cText3, letterSpacing: 1)),
              Text(
                _obscureDonePass
                    ? '●' * (_donePassword.isNotEmpty ? _donePassword : _passwordCtrl.text.trim()).length.clamp(0, 16)
                    : (_donePassword.isNotEmpty ? _donePassword : _passwordCtrl.text.trim()),
                style: const TextStyle(fontFamily: 'Outfit', fontSize: 15, fontWeight: FontWeight.w900, color: _cText1),
              ),
            ])),
            GestureDetector(
              onTap: () => setState(() => _obscureDonePass = !_obscureDonePass),
              child: Icon(_obscureDonePass ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                  color: _cText3, size: 18),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: () {
                final pass = _donePassword.isNotEmpty ? _donePassword : _passwordCtrl.text.trim();
                Clipboard.setData(ClipboardData(text: pass));
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                  content: Text('Password disalin!', style: TextStyle(color: Colors.white, fontFamily: 'Outfit', fontSize: 12)),
                  backgroundColor: _cGreen, behavior: SnackBarBehavior.floating,
                  duration: Duration(seconds: 1),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10))),
                  margin: EdgeInsets.all(16),
                ));
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: _cPrimary2.withOpacity(0.12),
                  borderRadius: const BorderRadius.all(Radius.circular(7)),
                  border: Border.all(color: _cPrimary2.withOpacity(0.25)),
                ),
                child: const Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.copy_rounded, size: 11, color: _cPrimary2),
                  SizedBox(width: 4),
                  Text('Salin', style: TextStyle(fontFamily: 'Outfit', fontSize: 9, fontWeight: FontWeight.w700, color: _cPrimary2)),
                ]),
              ),
            ),
          ]),
        ),
        if (_doneExpiredDate.isNotEmpty) ...[
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _cSurface2,
              borderRadius: const BorderRadius.all(Radius.circular(10)),
              border: Border.all(color: _cLine),
            ),
            child: Row(children: [
              const Icon(Icons.calendar_today_outlined, color: _cAccent, size: 16),
              const SizedBox(width: 10),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('EXPIRED',
                    style: TextStyle(fontFamily: 'Outfit', fontSize: 9, color: _cText3, letterSpacing: 1)),
                Text(_doneExpiredDate,
                    style: const TextStyle(fontFamily: 'Outfit', fontSize: 15, fontWeight: FontWeight.w900, color: _cAccent)),
              ]),
            ]),
          ),
        ],
      ]),
    ),
    const SizedBox(height: 12),
    Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF87171).withOpacity(0.07),
        borderRadius: const BorderRadius.all(Radius.circular(10)),
        border: Border.all(color: const Color(0xFFF87171).withOpacity(0.2)),
      ),
      child: const Row(children: [
        Text('⚠️', style: TextStyle(fontSize: 13)),
        SizedBox(width: 8),
        Expanded(child: Text(
          'Screenshot data login ini sekarang! Password tidak bisa dilihat lagi setelah kamu tutup halaman ini.',
          style: TextStyle(fontFamily: 'Outfit', fontSize: 10, color: Color(0xFFF87171), height: 1.5),
        )),
      ]),
    ),
    const SizedBox(height: 20),
    SizedBox(
      width: double.infinity, height: 48,
      child: ElevatedButton(
        onPressed: () => Navigator.pop(context),
        style: ElevatedButton.styleFrom(
          backgroundColor: _cPrimary, foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: const BorderRadius.all(Radius.circular(13))), elevation: 0,
        ),
        child: const Text('TUTUP & LOGIN',
            style: TextStyle(fontFamily: 'Outfit', fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
      ),
    ),
  ]);
}

// ══════════════════════════════════════════════
// PERPANJANG SHEET — QRIS Statis + Upload Bukti
// ══════════════════════════════════════════════
class _PerpanjangSheet extends StatefulWidget {
  const _PerpanjangSheet();
  @override
  State<_PerpanjangSheet> createState() => _PerpanjangSheetState();
}

class _PerpanjangSheetState extends State<_PerpanjangSheet> {

  String _step = 'username';
  final TextEditingController _usernameCtrl = TextEditingController();
  bool _loadingPaket = false;
  List<_PaketHarga> _pakets = [];
  _PaketHarga? _selectedPaket;
  File? _buktiFile;
  bool _loadingUpload = false;
  String _reqId = '';
  Timer? _pollTimer;
  bool   _polling = false;
  String _pollStatus = 'Menunggu konfirmasi owner...';
  String _newExpiredDate = '';

  @override
  void dispose() {
    _pollTimer?.cancel();
    _usernameCtrl.dispose();
    super.dispose();
  }

  Future<void> _lanjutKePaket() async {
    final username = _usernameCtrl.text.trim();
    if (username.isEmpty) { _snack('Masukkan username dulu!'); return; }
    setState(() => _loadingPaket = true);
    if (ConfigService.baseUrl.isEmpty) await ConfigService.init();
    try {
      final res = await http.get(
        Uri.parse('${ConfigService.baseUrl}/api/paket-harga'),
      ).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      final List raw = data['data'] ?? data['pakets'] ?? data ?? [];
      final list = raw.map((e) => _PaketHarga.fromJson(e as Map<String, dynamic>)).toList();
      if (list.isEmpty) { setState(() => _loadingPaket = false); _snack('Paket tidak tersedia'); return; }
      setState(() { _pakets = list; _loadingPaket = false; _step = 'paket'; });
    } catch (e) {
      setState(() => _loadingPaket = false);
      _snack('Error: ' + e.toString().split('\n').first);
    }
  }

  void _pilihPaket(_PaketHarga p) {
    setState(() { _selectedPaket = p; _step = 'qris'; });
  }

  Future<void> _pickBukti() async {
    final picked = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      imageQuality: 70,
      maxWidth: 1080,
    );
    if (picked == null) return;
    setState(() { _buktiFile = File(picked.path); _step = 'bukti'; });
  }

  Future<void> _kirimBukti() async {
    if (_buktiFile == null || _selectedPaket == null) return;
    setState(() => _loadingUpload = true);

    try {
      final bytes = await _buktiFile!.readAsBytes();
      final base64Str = base64Encode(bytes);
      final mime = _buktiFile!.path.toLowerCase().endsWith('.png')
          ? 'image/png' : 'image/jpeg';

      final res = await http.post(
        Uri.parse('${ConfigService.baseUrl}/api/perpanjang-qris'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username':    _usernameCtrl.text.trim(),
          'paketId':     _selectedPaket!.id,
          'buktiBase64': base64Str,
          'buktiMime':   mime,
        }),
      ).timeout(const Duration(seconds: 30));

      final d = jsonDecode(res.body);
      if (d['success'] == true) {
        final reqId = d['reqId'] ?? '';
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('pending_req_id', reqId);
        await prefs.setString('pending_req_username', _usernameCtrl.text.trim());
        await prefs.setString('pending_req_type', 'perpanjang');
        setState(() {
          _reqId = reqId;
          _loadingUpload = false;
          _step = 'tunggu';
        });
        _startPolling();
      } else {
        setState(() => _loadingUpload = false);
        _snack(d['message'] ?? 'Gagal kirim bukti');
      }
    } catch (e) {
      setState(() => _loadingUpload = false);
      _snack('Error: ' + e.toString().split('\n').first);
    }
  }

  void _startPolling() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) => _cekStatus());
  }

  Future<void> _cekStatus() async {
    if (_polling || _reqId.isEmpty) return;
    _polling = true;
    try {
      final res = await http.get(
        Uri.parse('${ConfigService.baseUrl}/api/perpanjang-qris/status/$_reqId'),
      ).timeout(const Duration(seconds: 10));
      final d = jsonDecode(res.body);
      if (d['success'] == true) {
        final status = d['status'] ?? 'pending';
        if (status == 'approved') {
          _pollTimer?.cancel();
          final prefs = await SharedPreferences.getInstance();
          await prefs.remove('pending_req_id');
          await prefs.remove('pending_req_username');
          await prefs.remove('pending_req_type');
          setState(() {
            _newExpiredDate = d['expiredDate'] ?? '';
            _step = 'done';
          });
        } else if (status == 'rejected') {
          _pollTimer?.cancel();
          setState(() => _pollStatus = 'Ditolak oleh owner.');
          _snack('❌ Request perpanjang ditolak. Hubungi owner.');
        } else {
          setState(() => _pollStatus = 'Menunggu konfirmasi owner...');
        }
      }
    } catch (_) {}
    _polling = false;
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(color: Colors.white)),
      backgroundColor: _cPrimary,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: const BorderRadius.all(Radius.circular(12))),
      margin: const EdgeInsets.all(16),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: _cBg,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        border: Border.all(color: _cAccent.withOpacity(0.18)),
      ),
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(22, 20, 22, 32),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(child: Container(width: 40, height: 4,
              decoration: BoxDecoration(color: _cLine, borderRadius: const BorderRadius.all(Radius.circular(2))))),
          const SizedBox(height: 16),
          Row(children: [
            Container(
              width: 38, height: 38,
              decoration: BoxDecoration(
                color: _cAccent.withOpacity(0.12),
                borderRadius: const BorderRadius.all(Radius.circular(10)),
                border: Border.all(color: _cAccent.withOpacity(0.3)),
              ),
              child: const Center(child: Text('🔄', style: TextStyle(fontSize: 18))),
            ),
            const SizedBox(width: 12),
            const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('PERPANJANG AKUN',
                  style: TextStyle(fontFamily: 'Outfit',
                      fontSize: 15, fontWeight: FontWeight.w900,
                      color: _cText1, letterSpacing: 1.2)),
              Text('Bayar via QRIS · Konfirmasi owner',
                  style: TextStyle(fontFamily: 'Outfit', fontSize: 11, color: _cText3)),
            ]),
            const Spacer(),
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: const Icon(Icons.close_rounded, color: _cText3, size: 22),
            ),
          ]),
          const SizedBox(height: 16),
          Divider(color: _cLine, height: 1),
          const SizedBox(height: 18),

          if (_step == 'username') _buildUsernameStep(),
          if (_step == 'paket')   _buildPaketStep(),
          if (_step == 'qris')    _buildQrisStep(),
          if (_step == 'bukti')   _buildBuktiStep(),
          if (_step == 'tunggu')  _buildTungguStep(),
          if (_step == 'done')    _buildDoneStep(),
        ]),
      ),
    );
  }

  Widget _buildUsernameStep() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Text('Username Akun',
        style: TextStyle(fontFamily: 'Outfit', fontSize: 12, fontWeight: FontWeight.w700, color: _cText2)),
    const SizedBox(height: 8),
    TextField(
      controller: _usernameCtrl,
      style: const TextStyle(fontFamily: 'Outfit', color: _cText1, fontSize: 14),
      decoration: InputDecoration(
        hintText: 'Masukkan username kamu',
        hintStyle: const TextStyle(color: _cText3, fontFamily: 'Outfit', fontSize: 13),
        filled: true, fillColor: _cSurface1,
        prefixIcon: const Icon(Icons.person_outline_rounded, color: _cText3, size: 18),
        border: OutlineInputBorder(borderRadius: const BorderRadius.all(Radius.circular(12)), borderSide: BorderSide(color: _cLine)),
        focusedBorder: OutlineInputBorder(borderRadius: const BorderRadius.all(Radius.circular(12)), borderSide: BorderSide(color: _cAccent.withOpacity(0.6), width: 1.4)),
        enabledBorder: OutlineInputBorder(borderRadius: const BorderRadius.all(Radius.circular(12)), borderSide: BorderSide(color: _cLine)),
        contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 14),
      ),
    ),
    const SizedBox(height: 16),
    SizedBox(
      width: double.infinity, height: 48,
      child: ElevatedButton(
        onPressed: _loadingPaket ? null : _lanjutKePaket,
        style: ElevatedButton.styleFrom(
          backgroundColor: _cAccent, foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: const BorderRadius.all(Radius.circular(13))), elevation: 0,
        ),
        child: _loadingPaket
            ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
            : const Text('LANJUT → PILIH PAKET',
                style: TextStyle(fontFamily: 'Outfit', fontSize: 13, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
      ),
    ),
  ]);

  Widget _buildPaketStep() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [
      GestureDetector(onTap: () => setState(() => _step = 'username'),
          child: const Icon(Icons.arrow_back_rounded, color: _cText3, size: 20)),
      const SizedBox(width: 8),
      Expanded(child: Text('Perpanjang: ${_usernameCtrl.text.trim()}',
          style: const TextStyle(fontFamily: 'Outfit', fontSize: 12, fontWeight: FontWeight.w700, color: _cAccent))),
    ]),
    const SizedBox(height: 14),
    const Text('Pilih Paket',
        style: TextStyle(fontFamily: 'Outfit', fontSize: 14, fontWeight: FontWeight.w900, color: _cText1)),
    const SizedBox(height: 12),
    ..._pakets.map((p) => GestureDetector(
      onTap: () => _pilihPaket(p),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: _cSurface1,
          borderRadius: const BorderRadius.all(Radius.circular(14)),
          border: Border.all(color: p.isPopuler ? _cAccent.withOpacity(0.5) : _cLine, width: p.isPopuler ? 1.4 : 1),
        ),
        child: Row(children: [
          Text(p.emoji, style: const TextStyle(fontSize: 20)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Text(p.nama, style: const TextStyle(fontFamily: 'Outfit', fontSize: 13, fontWeight: FontWeight.w800, color: _cText1)),
              if (p.isPopuler) ...[
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(color: _cAccent.withOpacity(0.15), borderRadius: const BorderRadius.all(Radius.circular(6))),
                  child: const Text('POPULER', style: TextStyle(fontFamily: 'Outfit', fontSize: 9, fontWeight: FontWeight.w800, color: _cAccent)),
                ),
              ],
            ]),
            Text(p.durasi, style: const TextStyle(fontFamily: 'Outfit', fontSize: 11, color: _cText3)),
          ])),
          Text(p.hargaFmt, style: const TextStyle(fontFamily: 'Outfit', fontSize: 14, fontWeight: FontWeight.w900, color: _cAccent)),
        ]),
      ),
    )).toList(),
  ]);

  Widget _buildQrisStep() {
    final hargaFmt = _selectedPaket?.hargaFmt ?? '';
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        GestureDetector(onTap: () => setState(() => _step = 'paket'),
            child: const Icon(Icons.arrow_back_rounded, color: _cText3, size: 20)),
        const SizedBox(width: 8),
        Expanded(child: Text('${_selectedPaket?.nama ?? ''} · $hargaFmt',
            style: const TextStyle(fontFamily: 'Outfit', fontSize: 12, fontWeight: FontWeight.w700, color: _cAccent))),
      ]),
      const SizedBox(height: 16),
      Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: _cAccent.withOpacity(0.08),
          borderRadius: const BorderRadius.all(Radius.circular(12)),
          border: Border.all(color: _cAccent.withOpacity(0.25)),
        ),
        child: Column(children: [
          const Text('Transfer tepat nominal:',
              style: TextStyle(fontFamily: 'Outfit', fontSize: 11, color: _cText3)),
          const SizedBox(height: 4),
          Text(hargaFmt,
              style: const TextStyle(fontFamily: 'Outfit', fontSize: 22, fontWeight: FontWeight.w900, color: _cAccent)),
        ]),
      ),
      const SizedBox(height: 14),
      Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: const BorderRadius.all(Radius.circular(16)),
          border: Border.all(color: _cLine),
        ),
        padding: const EdgeInsets.all(12),
        child: Image.asset(
          'assets/qris.png', fit: BoxFit.contain, height: 240,
        ),
      ),
      const SizedBox(height: 8),
      const Center(child: Text('MARKET OMZILLXY, GROSIR · NMID: ID1025408222129',
          style: TextStyle(fontFamily: 'Outfit', fontSize: 10, color: _cText3, letterSpacing: 0.5))),
      const SizedBox(height: 16),
      SizedBox(
        width: double.infinity, height: 48,
        child: ElevatedButton.icon(
          onPressed: _pickBukti,
          icon: const Icon(Icons.upload_rounded, size: 18),
          label: const Text('UPLOAD BUKTI BAYAR',
              style: TextStyle(fontFamily: 'Outfit', fontSize: 13, fontWeight: FontWeight.w800, letterSpacing: 1.2)),
          style: ElevatedButton.styleFrom(
            backgroundColor: _cAccent, foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: const BorderRadius.all(Radius.circular(13))), elevation: 0,
          ),
        ),
      ),
    ]);
  }

  Widget _buildBuktiStep() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [
      GestureDetector(onTap: () => setState(() { _buktiFile = null; _step = 'qris'; }),
          child: const Icon(Icons.arrow_back_rounded, color: _cText3, size: 20)),
      const SizedBox(width: 8),
      const Text('Preview Bukti Bayar',
          style: TextStyle(fontFamily: 'Outfit', fontSize: 13, fontWeight: FontWeight.w800, color: _cText1)),
    ]),
    const SizedBox(height: 14),
    if (_buktiFile != null)
      ClipRRect(
        borderRadius: const BorderRadius.all(Radius.circular(14)),
        child: Image.file(_buktiFile!, width: double.infinity, height: 220, fit: BoxFit.cover),
      ),
    const SizedBox(height: 10),
    Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _cSurface1,
        borderRadius: const BorderRadius.all(Radius.circular(12)),
        border: Border.all(color: _cLine),
      ),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(_usernameCtrl.text.trim(),
              style: const TextStyle(fontFamily: 'Outfit', fontSize: 13, fontWeight: FontWeight.w900, color: _cText1)),
          Text('${_selectedPaket?.nama ?? ''} · ${_selectedPaket?.durasi ?? ''}',
              style: const TextStyle(fontFamily: 'Outfit', fontSize: 11, color: _cText3)),
        ]),
        Text(_selectedPaket?.hargaFmt ?? '',
            style: const TextStyle(fontFamily: 'Outfit', fontSize: 15, fontWeight: FontWeight.w900, color: _cAccent)),
      ]),
    ),
    const SizedBox(height: 14),
    Row(children: [
      Expanded(
        child: GestureDetector(
          onTap: () => setState(() { _buktiFile = null; _step = 'qris'; }),
          child: Container(
            height: 44,
            decoration: BoxDecoration(
              color: _cSurface1,
              borderRadius: const BorderRadius.all(Radius.circular(12)),
              border: Border.all(color: _cLine),
            ),
            child: const Center(child: Text('Ganti Foto',
                style: TextStyle(fontFamily: 'Outfit', fontSize: 13, fontWeight: FontWeight.w700, color: _cText2))),
          ),
        ),
      ),
      const SizedBox(width: 10),
      Expanded(
        flex: 2,
        child: SizedBox(
          height: 44,
          child: ElevatedButton(
            onPressed: _loadingUpload ? null : _kirimBukti,
            style: ElevatedButton.styleFrom(
              backgroundColor: _cAccent, foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: const BorderRadius.all(Radius.circular(12))), elevation: 0,
            ),
            child: _loadingUpload
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : const Text('KIRIM BUKTI', style: TextStyle(fontFamily: 'Outfit', fontSize: 13, fontWeight: FontWeight.w800)),
          ),
        ),
      ),
    ]),
  ]);

  Widget _buildTungguStep() => Column(children: [
    const SizedBox(height: 12),
    Center(child: Column(children: [
      Container(
        width: 60, height: 60,
        decoration: BoxDecoration(
          color: _cPrimary.withOpacity(0.12),
          shape: BoxShape.circle,
          border: Border.all(color: _cPrimary.withOpacity(0.3), width: 1.5),
        ),
        child: const Center(child: Text('⏳', style: TextStyle(fontSize: 28))),
      ),
      const SizedBox(height: 14),
      const Text('BUKTI TERKIRIM!',
          style: TextStyle(fontFamily: 'Outfit', fontSize: 15, fontWeight: FontWeight.w900, color: _cText1, letterSpacing: 1)),
      const SizedBox(height: 6),
      const Text('Menunggu konfirmasi owner...',
          style: TextStyle(fontFamily: 'Outfit', fontSize: 12, color: _cText3)),
    ])),
    const SizedBox(height: 20),
    Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _cSurface1,
        borderRadius: const BorderRadius.all(Radius.circular(12)),
        border: Border.all(color: _cLine),
      ),
      child: Row(children: [
        const SizedBox(width: 14, height: 14,
            child: CircularProgressIndicator(color: _cAccent, strokeWidth: 2)),
        const SizedBox(width: 10),
        Expanded(child: Text(_pollStatus,
            style: const TextStyle(fontFamily: 'Outfit', fontSize: 12, color: _cText2))),
      ]),
    ),
    const SizedBox(height: 12),
    const Text('Halaman ini otomatis update setelah owner konfirmasi',
        style: TextStyle(fontFamily: 'Outfit', fontSize: 10, color: _cText3),
        textAlign: TextAlign.center),
    const SizedBox(height: 16),
    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      OutlinedButton.icon(
        onPressed: () => launchUrl(Uri.parse('https://wa.me/6282221520070'), mode: LaunchMode.externalApplication),
        icon: Image.asset('assets/whatsapp.png', width: 16, height: 16),
        label: const Text('WhatsApp',
            style: TextStyle(fontFamily: 'Outfit', fontSize: 12,
                fontWeight: FontWeight.w600, color: Color(0xFF25D366))),
        style: OutlinedButton.styleFrom(
          side: const BorderSide(color: Color(0xFF25D366), width: 1),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          shape: RoundedRectangleBorder(borderRadius: const BorderRadius.all(Radius.circular(10))),
        ),
      ),
      const SizedBox(width: 10),
      OutlinedButton.icon(
        onPressed: () => launchUrl(Uri.parse('https://t.me/alwaysZilllxy'), mode: LaunchMode.externalApplication),
        icon: Image.asset('assets/telegram.png', width: 16, height: 16),
        label: const Text('Telegram',
            style: TextStyle(fontFamily: 'Outfit', fontSize: 12,
                fontWeight: FontWeight.w600, color: Color(0xFF229ED9))),
        style: OutlinedButton.styleFrom(
          side: const BorderSide(color: Color(0xFF229ED9), width: 1),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          shape: RoundedRectangleBorder(borderRadius: const BorderRadius.all(Radius.circular(10))),
        ),
      ),
    ]),
  ]);

  Widget _buildDoneStep() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Center(child: Column(children: [
      Container(
        width: 64, height: 64,
        decoration: BoxDecoration(
          color: _cGreen.withOpacity(0.15),
          shape: BoxShape.circle,
          border: Border.all(color: _cGreen.withOpacity(0.4), width: 1.5),
        ),
        child: const Center(child: Text('✅', style: TextStyle(fontSize: 30))),
      ),
      const SizedBox(height: 12),
      const Text('PERPANJANG BERHASIL!',
          style: TextStyle(fontFamily: 'Outfit', fontSize: 16, fontWeight: FontWeight.w900,
              color: _cGreen, letterSpacing: 1.2)),
      const SizedBox(height: 4),
      const Text('Akun kamu sudah diperpanjang oleh owner',
          style: TextStyle(fontFamily: 'Outfit', fontSize: 12, color: _cText3)),
    ])),
    const SizedBox(height: 20),
    Container(
      width: double.infinity, padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _cSurface1,
        borderRadius: const BorderRadius.all(Radius.circular(14)),
        border: Border.all(color: _cGreen.withOpacity(0.25)),
      ),
      child: Column(children: [
        _infoRow('👤', 'Username', _usernameCtrl.text.trim()),
        const SizedBox(height: 10),
        _infoRow('📦', 'Paket', _selectedPaket?.nama ?? '-'),
        const SizedBox(height: 10),
        _infoRow('📅', 'Expired Baru', _newExpiredDate.isNotEmpty ? _newExpiredDate : '-'),
      ]),
    ),
    const SizedBox(height: 20),
    SizedBox(
      width: double.infinity, height: 48,
      child: ElevatedButton(
        onPressed: () => Navigator.pop(context),
        style: ElevatedButton.styleFrom(
          backgroundColor: _cGreen, foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: const BorderRadius.all(Radius.circular(13))), elevation: 0,
        ),
        child: const Text('SELESAI',
            style: TextStyle(fontFamily: 'Outfit', fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
      ),
    ),
  ]);

  Widget _infoRow(String icon, String label, String value) => Row(children: [
    Text(icon, style: const TextStyle(fontSize: 14)),
    const SizedBox(width: 8),
    Text('$label : ', style: const TextStyle(fontFamily: 'Outfit', fontSize: 12, color: _cText3)),
    Expanded(child: Text(value,
        style: const TextStyle(fontFamily: 'Outfit', fontSize: 12, fontWeight: FontWeight.w800, color: _cText1),
        overflow: TextOverflow.ellipsis)),
  ]);
}

// ══════════════════════════════════════════════
// BACKGROUND PAINTER (orbit rings + dots)
// ══════════════════════════════════════════════
class _BgPainter extends CustomPainter {
  final double orbit;
  const _BgPainter({required this.orbit});

  @override
  void paint(Canvas canvas, Size size) {
    final g1 = Paint()
      ..shader = RadialGradient(
        colors: [_cPrimary.withOpacity(0.14), Colors.transparent],
        stops: const [0, 0.65],
      ).createShader(Rect.fromCircle(
          center: Offset(size.width + 60, -80), radius: 320));
    canvas.drawCircle(Offset(size.width + 60, -80), 320, g1);

    final g2 = Paint()
      ..shader = RadialGradient(
        colors: [_cAccent.withOpacity(0.09), Colors.transparent],
        stops: const [0, 0.65],
      ).createShader(Rect.fromCircle(
          center: Offset(-60, size.height + 40), radius: 260));
    canvas.drawCircle(Offset(-60, size.height + 40), 260, g2);

    final double cx = size.width - 40.0;
    const double cy = 70.0;

    canvas.drawCircle(
      Offset(cx, cy),
      70,
      Paint()
        ..color = _cPrimary.withOpacity(0.07)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1,
    );
    canvas.drawCircle(
      Offset(cx, cy),
      110,
      Paint()
        ..color = _cAccent.withOpacity(0.05)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1,
    );

    final ox1 = cx + 70 * math.cos(orbit);
    final oy1 = cy + 70 * math.sin(orbit);
    canvas.drawCircle(
      Offset(ox1, oy1), 5,
      Paint()
        ..shader = RadialGradient(
          colors: [_cPrimary2.withOpacity(0.9), _cPrimary.withOpacity(0)],
        ).createShader(Rect.fromCircle(center: Offset(ox1, oy1), radius: 5)),
    );

    final ox2 = cx + 110 * math.cos(-orbit * 0.65);
    final oy2 = cy + 110 * math.sin(-orbit * 0.65);
    canvas.drawCircle(
      Offset(ox2, oy2), 4,
      Paint()
        ..shader = RadialGradient(
          colors: [_cAccent.withOpacity(0.8), _cAccent.withOpacity(0)],
        ).createShader(Rect.fromCircle(center: Offset(ox2, oy2), radius: 4)),
    );
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.orbit != orbit;
}