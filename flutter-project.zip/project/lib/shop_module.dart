// ============================================================
// SHOP MODULE - TRICKSTER STORE
// Fully integrated with ThemeProvider
// ============================================================

import 'config_service.dart';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:provider/provider.dart';
import 'theme_provider.dart';

// ============================================================
// THEME HELPER EXTENSION
// ============================================================

extension ThemeColors on ThemeProvider {
  Color get bgBase => isDarkMode ? const Color(0xFF0A0A0F) : const Color(0xFFF5F5FA);
  Color get bgCard => isDarkMode
      ? Color.alphaBlend(primaryColor.withOpacity(0.08), const Color(0xFF1A1A2E))
      : Colors.white;
  Color get bgCard2 => isDarkMode
      ? Color.alphaBlend(primaryColor.withOpacity(0.12), const Color(0xFF16213E))
      : const Color(0xFFF0F0F8);
  Color get textPrimary => isDarkMode ? Colors.white : const Color(0xFF1A1A2E);
  Color get textSecondary => isDarkMode ? Colors.white70 : Colors.black54;
  Color get textMuted => isDarkMode ? Colors.white30 : Colors.black26;
  Color get glowColor => primaryColor.withOpacity(0.35);
  LinearGradient get primaryGrad => LinearGradient(
        colors: [primaryColor, accentColor],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );
  LinearGradient get cardGrad => LinearGradient(
        colors: [bgCard, bgCard2],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );
  LinearGradient get bgGrad => LinearGradient(
        colors: isDarkMode
            ? [const Color(0xFF0A0A0F), const Color(0xFF12101A), const Color(0xFF0A0A0F)]
            : [const Color(0xFFF5F5FA), const Color(0xFFEEEEF8), const Color(0xFFF5F5FA)],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      );
}

// ============================================================
// MODELS
// ============================================================

class Product {
  final String id, name, description, category, imageUrl;
  final int price, stock;
  final bool isActive;
  final double avgRating;
  final int totalRatings;

  Product({
    required this.id,
    required this.name,
    required this.description,
    required this.price,
    required this.category,
    required this.imageUrl,
    required this.stock,
    required this.isActive,
    this.avgRating = 0,
    this.totalRatings = 0,
  });

  factory Product.fromJson(Map<String, dynamic> json) => Product(
        id: json['id'],
        name: json['name'],
        description: json['description'] ?? '',
        price: json['price'],
        category: json['category'] ?? 'other',
        imageUrl: json['imageUrl'] ?? '',
        stock: json['stock'] ?? 0,
        isActive: json['isActive'] ?? true,
        avgRating: (json['avgRating'] ?? 0).toDouble(),
        totalRatings: json['totalRatings'] ?? 0,
      );
}

class CartItem {
  String productId, name, imageUrl;
  int price, quantity;

  CartItem({
    required this.productId,
    required this.name,
    required this.price,
    this.quantity = 1,
    this.imageUrl = '',
  });

  Map<String, dynamic> toJson() => {
        'productId': productId,
        'name': name,
        'price': price,
        'quantity': quantity,
        'imageUrl': imageUrl,
      };

  factory CartItem.fromJson(Map<String, dynamic> json) => CartItem(
        productId: json['productId'],
        name: json['name'],
        price: json['price'],
        quantity: json['quantity'],
        imageUrl: json['imageUrl'] ?? '',
      );
}

class BannerItem {
  final String id, imageUrl;
  BannerItem({required this.id, required this.imageUrl});
  factory BannerItem.fromJson(Map<String, dynamic> json) =>
      BannerItem(id: json['id'], imageUrl: json['imageUrl']);
}

// ============================================================
// MULTI ADMIN MODEL
// ============================================================

class AdminInfo {
  final String nama;
  final String whatsapp;
  final String telegram;

  AdminInfo({
    required this.nama,
    required this.whatsapp,
    required this.telegram,
  });

  factory AdminInfo.fromJson(Map<String, dynamic> json) => AdminInfo(
        nama: json['nama'] ?? 'Admin',
        whatsapp: json['whatsapp'] ?? '',
        telegram: json['telegram'] ?? '',
      );

  bool get hasWhatsapp => whatsapp.isNotEmpty;
  bool get hasTelegram => telegram.isNotEmpty;
}

class VoucherResult {
  final String code, description;
  final int discountAmount, percent;
  final List<String> productIds; // kosong = berlaku semua produk

  VoucherResult({
    required this.code,
    required this.description,
    required this.discountAmount,
    required this.percent,
    required this.productIds,
  });

  factory VoucherResult.fromJson(Map<String, dynamic> json) => VoucherResult(
        code: json['code'] ?? '',
        description: json['description'] ?? '',
        // support field baru & legacy
        discountAmount: json['discountAmount'] ?? json['value'] ?? 0,
        percent: json['percent'] ?? 0,
        productIds: json['productIds'] != null
            ? List<String>.from(json['productIds'])
            : [],
      );

  /// Hitung total potongan untuk cart items tertentu
  int getDiscount(int subtotal, {List<String> cartProductIds = const []}) {
    // Tentukan subtotal yang kena diskon
    // Jika productIds kosong → semua produk kena diskon
    // Jika ada productIds → hanya produk yang masuk list
    final eligibleSubtotal = productIds.isEmpty ? subtotal : _eligibleAmount(cartProductIds);

    if (eligibleSubtotal <= 0) return 0;

    // Flat dulu, lalu persen dari eligible
    int cut = discountAmount;
    if (percent > 0) cut += (eligibleSubtotal * percent / 100).round();
    // Jangan lebih dari subtotal total
    return cut.clamp(0, subtotal);
  }

  // Placeholder — ShopProvider akan inject amount per produk lewat getDiscountFromItems
  int _eligibleAmount(List<String> cartProductIds) => 0;
}

class RatingEntry {
  final String username;
  final int stars;
  final String comment, updatedAt;

  RatingEntry({
    required this.username,
    required this.stars,
    required this.comment,
    required this.updatedAt,
  });

  factory RatingEntry.fromJson(Map<String, dynamic> json) => RatingEntry(
        username: json['username'] ?? '',
        stars: json['stars'] ?? 0,
        comment: json['comment'] ?? '',
        updatedAt: json['updatedAt'] ?? '',
      );
}

// ============================================================
// SHOP PROVIDER
// ============================================================

class ShopProvider extends ChangeNotifier {
  List<Product> _products = [];
  List<Product> get products => _products;
  List<CartItem> _cart = [];
  List<CartItem> get cart => _cart;
  List<BannerItem> _banners = [];
  List<BannerItem> get banners => _banners;

  // Multi admin list
  List<AdminInfo> _admins = [];
  List<AdminInfo> get admins => _admins;

  VoucherResult? _appliedVoucher;
  VoucherResult? get appliedVoucher => _appliedVoucher;

  String _selectedCategory = 'all';
  String get selectedCategory => _selectedCategory;
  bool _isLoading = false;
  bool get isLoading => _isLoading;
  String? _sessionKey;

  

  List<Product> get filteredProducts {
    if (_selectedCategory == 'all') return _products;
    return _products.where((p) => p.category == _selectedCategory).toList();
  }

  int get totalCartItems => _cart.fold(0, (s, i) => s + i.quantity);
  int get subtotal => _cart.fold(0, (s, i) => s + (i.price * i.quantity));
  int get discountAmount {
    final v = _appliedVoucher;
    if (v == null) return 0;
    if (v.productIds.isEmpty) {
      // berlaku semua produk
      int cut = v.discountAmount;
      if (v.percent > 0) cut += (subtotal * v.percent / 100).round();
      return cut.clamp(0, subtotal);
    }
    // hitung eligible subtotal = hanya item yang productId-nya masuk list
    final eligibleSubtotal = _cart
        .where((i) => v.productIds.contains(i.productId))
        .fold(0, (s, i) => s + (i.price * i.quantity));
    if (eligibleSubtotal <= 0) return 0;
    int cut = v.discountAmount;
    if (v.percent > 0) cut += (eligibleSubtotal * v.percent / 100).round();
    return cut.clamp(0, subtotal);
  }
  int get totalPrice => subtotal - discountAmount;

  void setSessionKey(String key) {
    _sessionKey = key;
    loadCartFromLocal();
    loadProducts();
    loadBanners();
    loadAdmins();
  }

  void setCategory(String category) {
    _selectedCategory = category;
    notifyListeners();
  }

  Future<void> loadProducts() async {
    _isLoading = true;
    notifyListeners();
    try {
      final res = await http.get(Uri.parse('${ConfigService.baseUrl}/api/shop/products'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['success'] == true) {
          _products = (data['products'] as List).map((p) => Product.fromJson(p)).toList();
        }
      }
    } catch (e) {
      debugPrint('Load error: $e');
    }
    _isLoading = false;
    notifyListeners();
  }

  Future<void> loadBanners() async {
    try {
      final res = await http.get(Uri.parse('${ConfigService.baseUrl}/api/shop/banners'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['success'] == true) {
          _banners = (data['banners'] as List).map((b) => BannerItem.fromJson(b)).toList();
        }
      }
    } catch (e) {
      debugPrint('Banner error: $e');
    }
    notifyListeners();
  }

  Future<void> loadAdmins() async {
    try {
      final res = await http.get(Uri.parse('${ConfigService.baseUrl}/api/shop/contact'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['success'] == true) {
          _admins = (data['admins'] as List? ?? [])
              .map((a) => AdminInfo.fromJson(a))
              .toList();
        }
      }
    } catch (e) {
      debugPrint('Admins error: $e');
    }
    notifyListeners();
  }

  void addToCart(Product product, {int qty = 1}) {
    final idx = _cart.indexWhere((i) => i.productId == product.id);
    if (idx != -1) {
      _cart[idx].quantity += qty;
    } else {
      _cart.add(CartItem(
        productId: product.id,
        name: product.name,
        price: product.price,
        quantity: qty,
        imageUrl: product.imageUrl,
      ));
    }
    saveCartToLocal();
    notifyListeners();
  }

  void removeFromCart(String productId) {
    _cart.removeWhere((i) => i.productId == productId);
    saveCartToLocal();
    notifyListeners();
  }

  void updateQuantity(String productId, int qty) {
    final idx = _cart.indexWhere((i) => i.productId == productId);
    if (idx != -1) {
      qty <= 0 ? _cart.removeAt(idx) : (_cart[idx].quantity = qty);
      saveCartToLocal();
      notifyListeners();
    }
  }

  void clearCart() {
    _cart.clear();
    _appliedVoucher = null;
    saveCartToLocal();
    notifyListeners();
  }

  Future<Map<String, dynamic>> applyVoucher(String code) async {
    if (_sessionKey == null) return {'success': false, 'message': 'Session tidak valid'};
    try {
      final res = await http.post(
        Uri.parse('${ConfigService.baseUrl}/api/shop/voucher/check'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': _sessionKey, 'code': code}),
      );
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        final v = VoucherResult.fromJson(data['voucher']);
        // Cek apakah ada produk di cart yang eligible
        if (v.productIds.isNotEmpty) {
          final hasEligible = _cart.any((i) => v.productIds.contains(i.productId));
          if (!hasEligible) {
            return {'success': false, 'message': 'Voucher tidak berlaku untuk produk di cart kamu'};
          }
        }
        if (_cart.isEmpty) {
          return {'success': false, 'message': 'Cart masih kosong'};
        }
        _appliedVoucher = v;
        notifyListeners();
        return {'success': true, 'voucher': v};
      }
      return {'success': false, 'message': data['message'] ?? 'Gagal'};
    } catch (e) {
      return {'success': false, 'message': 'Error: $e'};
    }
  }

  void removeVoucher() {
    _appliedVoucher = null;
    notifyListeners();
  }

  Future<void> saveCartToLocal() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('shop_cart', jsonEncode(_cart.map((i) => i.toJson()).toList()));
  }

  Future<void> loadCartFromLocal() async {
    final prefs = await SharedPreferences.getInstance();
    final json = prefs.getString('shop_cart');
    if (json != null) {
      _cart = (jsonDecode(json) as List).map((i) => CartItem.fromJson(i)).toList();
    }
    notifyListeners();
  }

  // createOrder sekarang terima AdminInfo + channel (wa/tele)
  Future<Map<String, dynamic>> createOrder(
    AdminInfo admin,
    String channel, // 'whatsapp' atau 'telegram'
    String customerName,
    String customerContact,
  ) async {
    if (_sessionKey == null || _cart.isEmpty) return {'success': false, 'message': 'Keranjang kosong'};

    final items = _cart.map((i) => '• ${i.name} x${i.quantity} = Rp${_fmt(i.price * i.quantity)}').join('\n');
    String summary = items;
    if (_appliedVoucher != null) {
      summary += '\n\n🎟️ Voucher: ${_appliedVoucher!.code} (-Rp${_fmt(discountAmount)})';
    }
    final total = 'Rp${_fmt(totalPrice)}';
    String url = '';
    String message = '';

    if (channel == 'whatsapp') {
      message = 'Halo *${admin.nama}*, saya ingin order:\n\n$summary\n\nTotal: $total\n\nNama: $customerName\nNo WA: $customerContact';
      url = 'https://wa.me/${admin.whatsapp}?text=${Uri.encodeComponent(message)}';
    } else {
      message = 'Halo @${admin.telegram}, saya ingin order:\n\n$summary\n\nTotal: $total\n\nNama: $customerName';
      url = 'https://t.me/${admin.telegram}?text=${Uri.encodeComponent(message)}';
    }

    try {
      await http.post(
        Uri.parse('${ConfigService.baseUrl}/api/shop/order'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': _sessionKey,
          'items': _cart.map((i) => {'id': i.productId, 'name': i.name, 'quantity': i.quantity, 'price': i.price}).toList(),
          'totalAmount': subtotal,
          'discountAmount': discountAmount,
          'voucherCode': _appliedVoucher?.code,
          'customerName': customerName,
          'customerContact': customerContact,
          'channel': channel,
        }),
      );
      if (_appliedVoucher != null) {
        await http.post(
          Uri.parse('${ConfigService.baseUrl}/api/shop/voucher/use'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'key': _sessionKey, 'code': _appliedVoucher!.code}),
        );
      }
    } catch (e) {
      debugPrint('Order error: $e');
    }

    clearCart();
    return {'success': true, 'url': url, 'channel': channel, 'adminNama': admin.nama};
  }

  Future<Map<String, dynamic>> submitRating(String productId, int stars, String comment) async {
    if (_sessionKey == null) return {'success': false};
    try {
      final res = await http.post(
        Uri.parse('${ConfigService.baseUrl}/api/shop/rating'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'key': _sessionKey, 'productId': productId, 'stars': stars, 'comment': comment}),
      );
      return jsonDecode(res.body);
    } catch (e) {
      return {'success': false, 'message': '$e'};
    }
  }

  Future<Map<String, dynamic>> loadRatings(String productId) async {
    try {
      final res = await http.get(Uri.parse(
          '${ConfigService.baseUrl}/api/shop/rating?productId=$productId${_sessionKey != null ? "&key=$_sessionKey" : ""}'));
      return jsonDecode(res.body);
    } catch (e) {
      return {'success': false};
    }
  }

  String _fmt(int p) => p
      .toString()
      .replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.');
}

// ============================================================
// PARTICLE BACKGROUND
// ============================================================

class _Particle {
  final double x, y, speed, size;
  final Color color;
  _Particle({required this.x, required this.y, required this.speed, required this.size, required this.color});
}

class _ParticlePainter extends CustomPainter {
  final double progress;
  final List<_Particle> particles;
  _ParticlePainter(this.progress, this.particles);

  @override
  void paint(Canvas canvas, Size size) {
    for (final p in particles) {
      final dy = (1 - ((p.y + progress * p.speed) % 1.0)) * size.height;
      final opacity = (sin(progress * pi * 2 * p.speed + p.y * pi) * 0.25 + 0.25).clamp(0.0, 0.5);
      canvas.drawCircle(
        Offset(p.x * size.width, dy),
        p.size,
        Paint()..color = p.color.withOpacity(opacity),
      );
    }
  }

  @override
  bool shouldRepaint(_ParticlePainter old) => true;
}

class _ParticleBg extends StatefulWidget {
  final Color primary;
  final Color accent;
  const _ParticleBg({required this.primary, required this.accent});

  @override
  State<_ParticleBg> createState() => _ParticleBgState();
}

class _ParticleBgState extends State<_ParticleBg> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late List<_Particle> _particles;
  final _rnd = Random();

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 20))..repeat();
    _rebuildParticles();
  }

  void _rebuildParticles() {
    final colors = [widget.primary, widget.accent,
      widget.primary.withOpacity(0.6), widget.accent.withOpacity(0.6)];
    _particles = List.generate(20, (_) => _Particle(
      x: _rnd.nextDouble(), y: _rnd.nextDouble(),
      speed: _rnd.nextDouble() * 0.25 + 0.04,
      size: _rnd.nextDouble() * 2.5 + 1.5,
      color: colors[_rnd.nextInt(colors.length)],
    ));
  }

  @override
  void didUpdateWidget(_ParticleBg old) {
    super.didUpdateWidget(old);
    if (old.primary != widget.primary || old.accent != widget.accent) _rebuildParticles();
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _ctrl,
        builder: (_, __) => CustomPaint(
          painter: _ParticlePainter(_ctrl.value, _particles),
          size: Size.infinite,
        ),
      );
}

// ============================================================
// PULSING LOGO
// ============================================================

class _PulsingLogo extends StatefulWidget {
  final Color primary, accent;
  const _PulsingLogo({required this.primary, required this.accent});
  @override
  State<_PulsingLogo> createState() => _PulsingLogoState();
}

class _PulsingLogoState extends State<_PulsingLogo> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _anim = Tween<double>(begin: 0.3, end: 1.0).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _anim,
        builder: (_, __) => Container(
          width: 42, height: 42,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [widget.primary, widget.accent]),
            borderRadius: BorderRadius.circular(14),
            boxShadow: [BoxShadow(color: widget.primary.withOpacity(_anim.value * 0.7), blurRadius: 20, spreadRadius: 2)],
          ),
          child: const Center(child: Text('GJ', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16))),
        ),
      );
}

// ============================================================
// CART BUTTON
// ============================================================

class _CartButton extends StatelessWidget {
  final int count;
  const _CartButton({required this.count});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CartPage())),
      child: Stack(clipBehavior: Clip.none, children: [
        Container(
          width: 42, height: 42,
          decoration: BoxDecoration(
            color: theme.bgCard, borderRadius: BorderRadius.circular(13),
            border: Border.all(color: theme.primaryColor.withOpacity(0.2)),
          ),
          child: Icon(Icons.shopping_bag_outlined, size: 20, color: theme.primaryColor),
        ),
        if (count > 0)
          Positioned(top: -6, right: -6, child: _BounceBadge(count: count, color: theme.accentColor)),
      ]),
    );
  }
}

class _BounceBadge extends StatefulWidget {
  final int count;
  final Color color;
  const _BounceBadge({required this.count, required this.color});
  @override
  State<_BounceBadge> createState() => _BounceBadgeState();
}

class _BounceBadgeState extends State<_BounceBadge> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))..repeat(reverse: true);
    _scale = Tween<double>(begin: 1.0, end: 1.2).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _scale,
        builder: (_, __) => Transform.scale(
          scale: _scale.value,
          child: Container(
            width: 18, height: 18,
            decoration: BoxDecoration(
              color: widget.color, shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: widget.color.withOpacity(0.5), blurRadius: 6)],
            ),
            child: Center(child: Text('${widget.count}',
                style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w900))),
          ),
        ),
      );
}

// ============================================================
// BANNER CAROUSEL
// ============================================================

class _BannerCarousel extends StatefulWidget {
  final List<BannerItem> banners;
  const _BannerCarousel({required this.banners});
  @override
  State<_BannerCarousel> createState() => _BannerCarouselState();
}

class _BannerCarouselState extends State<_BannerCarousel> {
  late PageController _pc;
  int _page = 0;

  @override
  void initState() {
    super.initState();
    _pc = PageController(viewportFraction: 0.93);
    _pc.addListener(() {
      final p = _pc.page?.round() ?? 0;
      if (p != _page) setState(() => _page = p);
    });
    if (widget.banners.length > 1) Future.delayed(const Duration(seconds: 3), _autoScroll);
  }

  void _autoScroll() {
    if (!mounted) return;
    final next = (_page + 1) % widget.banners.length;
    _pc.animateToPage(next, duration: const Duration(milliseconds: 500), curve: Curves.easeInOut);
    Future.delayed(const Duration(seconds: 3), _autoScroll);
  }

  @override
  void dispose() { _pc.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final count = widget.banners.isEmpty ? 1 : widget.banners.length;
    return Column(children: [
      SizedBox(
        height: 180,
        child: PageView.builder(
          controller: _pc, itemCount: count,
          itemBuilder: (_, i) => Padding(
            padding: const EdgeInsets.symmetric(horizontal: 5),
            child: _BannerCard(item: widget.banners.isEmpty ? null : widget.banners[i], theme: theme, index: i),
          ),
        ),
      ),
      if (count > 1) ...[
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(count, (i) => GestureDetector(
            onTap: () => _pc.animateToPage(i, duration: const Duration(milliseconds: 400), curve: Curves.easeInOut),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: _page == i ? 22 : 6, height: 4,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(2),
                color: _page == i ? theme.primaryColor : Colors.white.withOpacity(0.2),
                boxShadow: _page == i ? [BoxShadow(color: theme.primaryColor.withOpacity(0.6), blurRadius: 6)] : null,
              ),
            ),
          )),
        ),
        const SizedBox(height: 4),
      ],
    ]);
  }
}

class _BannerCard extends StatelessWidget {
  final BannerItem? item;
  final ThemeProvider theme;
  final int index;
  const _BannerCard({this.item, required this.theme, required this.index});

  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          boxShadow: [BoxShadow(color: theme.primaryColor.withOpacity(0.3), blurRadius: 20, offset: const Offset(0, 8))],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: item != null && item!.imageUrl.isNotEmpty
              ? CachedNetworkImage(
                  imageUrl: item!.imageUrl, fit: BoxFit.cover,
                  width: double.infinity, height: 180,
                  placeholder: (_, __) => _BannerPlaceholder(theme: theme, index: index),
                  errorWidget: (_, __, ___) => _BannerPlaceholder(theme: theme, index: index),
                )
              : _BannerPlaceholder(theme: theme, index: index),
        ),
      );
}

class _BannerPlaceholder extends StatelessWidget {
  final ThemeProvider theme;
  final int index;
  const _BannerPlaceholder({required this.theme, required this.index});

  static const _texts = [
    ['MEMBER MIWA♡CHAN', '🌸 Dapatkan promo spesial!'],
    ['PREMIUM ACCESS', '👑 Upgrade sekarang!'],
    ['TOP UP MURAH', '💎 Harga terbaik dijamin!'],
  ];

  @override
  Widget build(BuildContext context) {
    final texts = _texts[index % _texts.length];
    return Container(
      height: 180, width: double.infinity,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [theme.primaryColor, Color.lerp(theme.primaryColor, theme.accentColor, 0.6)!, theme.accentColor],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
      ),
      child: Stack(children: [
        Positioned(top: -30, right: -20, child: Container(width: 130, height: 130,
            decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(0.1)))),
        Positioned(bottom: -20, left: 10, child: Container(width: 90, height: 90,
            decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(0.08)))),
        Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(texts[0], style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900,
              color: Colors.white, letterSpacing: 0.5, shadows: [Shadow(blurRadius: 12, color: Colors.black26)])),
          const SizedBox(height: 6),
          Text(texts[1], style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: Colors.white70)),
        ])),
      ]),
    );
  }
}

// ============================================================
// STAR RATING
// ============================================================

class _StarRating extends StatelessWidget {
  final double rating;
  final int total;
  final double size;
  const _StarRating({required this.rating, this.total = 0, this.size = 12});

  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
        ...List.generate(5, (i) {
          final filled = i < rating.floor();
          final half = !filled && i < rating;
          return Icon(filled ? Icons.star : half ? Icons.star_half : Icons.star_border,
              color: const Color(0xFFFBBF24), size: size);
        }),
        if (total > 0) ...[
          const SizedBox(width: 4),
          Text('${rating.toStringAsFixed(1)} ($total)',
              style: TextStyle(fontSize: size - 2, color: Colors.white.withOpacity(0.4))),
        ]
      ]);
}

// ============================================================
// SHOP PAGE
// ============================================================

class ShopPage extends StatefulWidget {
  const ShopPage({super.key});
  @override
  State<ShopPage> createState() => _ShopPageState();
}

class _ShopPageState extends State<ShopPage> with SingleTickerProviderStateMixin {
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  int _selectedIdx = 0;
  final List<String> _categories = ['all', 'premium', 'topup', 'addon'];
  final Map<String, String> _catLabel = {
    'all': 'Semua', 'premium': '👑 Premium', 'topup': '💎 Top Up', 'addon': '⚡ Addon',
  };

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final p = Provider.of<ShopProvider>(context, listen: false);
      p.loadProducts();
      p.loadBanners();
      p.loadAdmins();
    });
  }

  @override
  void dispose() { _fadeCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final shop = context.watch<ShopProvider>();
    final theme = context.watch<ThemeProvider>();

    return Scaffold(
      backgroundColor: theme.bgBase,
      body: Stack(children: [
        Container(decoration: BoxDecoration(gradient: theme.bgGrad)),
        Positioned(top: -100, right: -80, child: Container(width: 350, height: 350,
            decoration: BoxDecoration(shape: BoxShape.circle,
              gradient: RadialGradient(colors: [theme.primaryColor.withOpacity(0.14), Colors.transparent])))),
        Positioned(bottom: 200, left: -100, child: Container(width: 280, height: 280,
            decoration: BoxDecoration(shape: BoxShape.circle,
              gradient: RadialGradient(colors: [theme.accentColor.withOpacity(0.10), Colors.transparent])))),
        _ParticleBg(primary: theme.primaryColor, accent: theme.accentColor),
        SafeArea(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: Column(children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                child: Row(children: [
                  _PulsingLogo(primary: theme.primaryColor, accent: theme.accentColor),
                  const SizedBox(width: 10),
                  ShaderMask(
                    shaderCallback: (b) => LinearGradient(
                      colors: [theme.primaryColor.withOpacity(0.9), theme.accentColor],
                    ).createShader(b),
                    child: const Text('TRICKSTER STORE', style: TextStyle(
                        fontWeight: FontWeight.w900, fontSize: 18, letterSpacing: 2, color: Colors.white)),
                  ),
                  const Spacer(),
                  _CartButton(count: shop.totalCartItems),
                ]),
              ),
              Expanded(
                child: CustomScrollView(slivers: [
                  SliverToBoxAdapter(child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                    child: _BannerCarousel(banners: shop.banners),
                  )),
                  SliverToBoxAdapter(child: _buildTabs(shop, theme)),
                  SliverToBoxAdapter(child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
                    child: Container(height: 1, decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [
                        Colors.transparent, theme.primaryColor.withOpacity(0.4), Colors.transparent,
                      ]),
                    )),
                  )),
                  if (shop.isLoading)
                    SliverFillRemaining(child: Center(
                      child: CircularProgressIndicator(color: theme.primaryColor, strokeWidth: 2.5),
                    ))
                  else if (shop.filteredProducts.isEmpty)
                    SliverFillRemaining(child: Center(child: Column(
                      mainAxisAlignment: MainAxisAlignment.center, children: [
                        Container(width: 72, height: 72,
                          decoration: BoxDecoration(color: theme.bgCard, borderRadius: BorderRadius.circular(22),
                              border: Border.all(color: theme.primaryColor.withOpacity(0.2))),
                          child: const Center(child: Text('🛍️', style: TextStyle(fontSize: 32)))),
                        const SizedBox(height: 14),
                        Text('Belum ada produk', style: TextStyle(color: theme.textMuted, fontWeight: FontWeight.w600)),
                      ],
                    )))
                  else
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(12, 4, 12, 24),
                      sliver: SliverGrid(
                        delegate: SliverChildBuilderDelegate(
                          (ctx, i) => _AnimatedProductCard(product: shop.filteredProducts[i], index: i),
                          childCount: shop.filteredProducts.length,
                        ),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2, childAspectRatio: 0.68,
                          crossAxisSpacing: 12, mainAxisSpacing: 12,
                        ),
                      ),
                    ),
                ]),
              ),
            ]),
          ),
        ),
      ]),
    );
  }

  Widget _buildTabs(ShopProvider shop, ThemeProvider theme) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
        child: Container(
          padding: const EdgeInsets.all(5),
          decoration: BoxDecoration(color: theme.bgCard, borderRadius: BorderRadius.circular(18),
              border: Border.all(color: theme.primaryColor.withOpacity(0.12))),
          child: Row(
            children: List.generate(_categories.length, (i) {
              final active = _selectedIdx == i;
              return Expanded(
                child: GestureDetector(
                  onTap: () { setState(() => _selectedIdx = i); shop.setCategory(_categories[i]); },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 250), curve: Curves.easeOutBack,
                    padding: const EdgeInsets.symmetric(vertical: 9),
                    decoration: BoxDecoration(
                      gradient: active ? theme.primaryGrad : null,
                      borderRadius: BorderRadius.circular(13),
                      boxShadow: active ? [BoxShadow(color: theme.primaryColor.withOpacity(0.4), blurRadius: 12, offset: const Offset(0, 4))] : null,
                    ),
                    child: Text(_catLabel[_categories[i]]!, textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800,
                            color: active ? Colors.white : theme.textMuted)),
                  ),
                ),
              );
            }),
          ),
        ),
      );
}

// ============================================================
// ANIMATED PRODUCT CARD
// ============================================================

class _AnimatedProductCard extends StatefulWidget {
  final Product product;
  final int index;
  const _AnimatedProductCard({required this.product, required this.index});
  @override
  State<_AnimatedProductCard> createState() => _AnimatedProductCardState();
}

class _AnimatedProductCardState extends State<_AnimatedProductCard> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;
  bool _pressed = false;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 450));
    _fadeAnim = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(begin: const Offset(0, 0.3), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutBack));
    Future.delayed(Duration(milliseconds: 60 * widget.index), () { if (mounted) _ctrl.forward(); });
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    return FadeTransition(
      opacity: _fadeAnim,
      child: SlideTransition(
        position: _slideAnim,
        child: GestureDetector(
          onTapDown: (_) => setState(() => _pressed = true),
          onTapUp: (_) => setState(() => _pressed = false),
          onTapCancel: () => setState(() => _pressed = false),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductDetailPage(product: widget.product))),
          child: AnimatedScale(
            scale: _pressed ? 0.96 : 1.0, duration: const Duration(milliseconds: 120),
            child: _ProductCardInner(product: widget.product, theme: theme),
          ),
        ),
      ),
    );
  }
}

class _ProductCardInner extends StatelessWidget {
  final Product product;
  final ThemeProvider theme;
  const _ProductCardInner({required this.product, required this.theme});

  @override
  Widget build(BuildContext context) {
    final outOfStock = product.stock <= 0;
    return Container(
      decoration: BoxDecoration(
        gradient: theme.cardGrad, borderRadius: BorderRadius.circular(22),
        border: Border.all(color: theme.primaryColor.withOpacity(0.15)),
        boxShadow: [BoxShadow(color: theme.primaryColor.withOpacity(0.08), blurRadius: 16, offset: const Offset(0, 6))],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Stack(children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(22)),
            child: product.imageUrl.isNotEmpty
                ? CachedNetworkImage(imageUrl: product.imageUrl, height: 130, width: double.infinity, fit: BoxFit.cover,
                    placeholder: (_, __) => _imgPlaceholder(theme), errorWidget: (_, __, ___) => _imgPlaceholder(theme))
                : _imgPlaceholder(theme),
          ),
          Positioned(top: 8, left: 8, child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(color: Colors.black.withOpacity(0.55), borderRadius: BorderRadius.circular(20),
                border: Border.all(color: theme.primaryColor.withOpacity(0.4))),
            child: Text(product.category.toUpperCase(),
                style: TextStyle(fontSize: 8, fontWeight: FontWeight.w900, color: theme.primaryColor)),
          )),
          if (outOfStock)
            Positioned.fill(child: Container(
              decoration: BoxDecoration(color: Colors.black.withOpacity(0.72),
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(22))),
              child: const Center(child: Text('HABIS',
                  style: TextStyle(fontWeight: FontWeight.w900, fontSize: 14, color: Colors.white, letterSpacing: 2))),
            )),
        ]),
        Padding(
          padding: const EdgeInsets.all(10),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(product.name, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: theme.textPrimary),
                maxLines: 2, overflow: TextOverflow.ellipsis),
            if (product.totalRatings > 0) ...[
              const SizedBox(height: 4),
              _StarRating(rating: product.avgRating, total: product.totalRatings),
            ],
            const SizedBox(height: 6),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                ShaderMask(
                  shaderCallback: (b) => theme.primaryGrad.createShader(b),
                  child: Text('Rp${_fmt(product.price)}', style: const TextStyle(
                      fontWeight: FontWeight.w900, fontSize: 13, color: Colors.white)),
                ),
                if (product.stock > 0)
                  Text('Stok: ${product.stock}', style: TextStyle(fontSize: 9, color: theme.textMuted)),
              ]),
              if (!outOfStock) _AddCartBtn(product: product, theme: theme),
            ]),
          ]),
        ),
      ]),
    );
  }

  Widget _imgPlaceholder(ThemeProvider theme) => Container(
        height: 130,
        decoration: BoxDecoration(gradient: LinearGradient(
          colors: [theme.bgCard2, theme.bgCard], begin: Alignment.topLeft, end: Alignment.bottomRight)),
        child: Center(child: Icon(Icons.shopping_bag_outlined, color: theme.primaryColor.withOpacity(0.3), size: 36)));

  String _fmt(int p) => p.toString()
      .replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.');
}

// ============================================================
// ADD TO CART BUTTON
// ============================================================

class _AddCartBtn extends StatefulWidget {
  final Product product;
  final ThemeProvider theme;
  const _AddCartBtn({required this.product, required this.theme});
  @override
  State<_AddCartBtn> createState() => _AddCartBtnState();
}

class _AddCartBtnState extends State<_AddCartBtn> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 300));
    _scale = TweenSequence([
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 1.4), weight: 40),
      TweenSequenceItem(tween: Tween(begin: 1.4, end: 1.0), weight: 60),
    ]).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  void _onTap(BuildContext context) {
    _ctrl.forward(from: 0);
    Provider.of<ShopProvider>(context, listen: false).addToCart(widget.product);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('${widget.product.name} ditambahkan 🛒'),
      duration: const Duration(seconds: 1),
      backgroundColor: const Color(0xFF34D399),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
    ));
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _scale,
        builder: (_, __) => Transform.scale(
          scale: _scale.value,
          child: GestureDetector(
            onTap: () => _onTap(context),
            child: Container(
              width: 32, height: 32,
              decoration: BoxDecoration(
                gradient: widget.theme.primaryGrad, borderRadius: BorderRadius.circular(10),
                boxShadow: [BoxShadow(color: widget.theme.primaryColor.withOpacity(0.45), blurRadius: 10, offset: const Offset(0, 4))],
              ),
              child: const Icon(Icons.add, color: Colors.white, size: 18),
            ),
          ),
        ),
      );
}

// ============================================================
// PRODUCT DETAIL PAGE
// ============================================================

class ProductDetailPage extends StatefulWidget {
  final Product product;
  const ProductDetailPage({super.key, required this.product});
  @override
  State<ProductDetailPage> createState() => _ProductDetailPageState();
}

class _ProductDetailPageState extends State<ProductDetailPage> {
  int _quantity = 1;
  double _avgRating = 0;
  int _totalRatings = 0;
  List<RatingEntry> _ratings = [];
  int? _myRating;
  bool _loadingRatings = true;

  @override
  void initState() {
    super.initState();
    _avgRating = widget.product.avgRating;
    _totalRatings = widget.product.totalRatings;
    _loadRatings();
  }

  Future<void> _loadRatings() async {
    final data = await Provider.of<ShopProvider>(context, listen: false).loadRatings(widget.product.id);
    if (mounted && data['success'] == true) {
      setState(() {
        _avgRating = (data['avg'] ?? 0).toDouble();
        _totalRatings = data['total'] ?? 0;
        _ratings = (data['ratings'] as List? ?? []).map((r) => RatingEntry.fromJson(r)).toList();
        _myRating = data['myRating']?['stars'];
        _loadingRatings = false;
      });
    } else { setState(() => _loadingRatings = false); }
  }

  int get _total => widget.product.price * _quantity;

  void _showRatingDialog(ThemeProvider theme) {
    int stars = _myRating ?? 5;
    final ctrl = TextEditingController();
    showModalBottomSheet(
      context: context,
      backgroundColor: theme.bgCard,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(left: 24, right: 24, top: 24, bottom: MediaQuery.of(ctx).viewInsets.bottom + 24),
        child: StatefulBuilder(builder: (ctx, set) => Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 20),
          Text('⭐ Beri Rating', style: TextStyle(color: theme.textPrimary, fontWeight: FontWeight.w800, fontSize: 18)),
          const SizedBox(height: 16),
          Row(mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(5, (i) => GestureDetector(
              onTap: () => set(() => stars = i + 1),
              child: AnimatedScale(scale: i < stars ? 1.2 : 1.0, duration: const Duration(milliseconds: 150),
                child: Padding(padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: Icon(i < stars ? Icons.star : Icons.star_border, color: const Color(0xFFFBBF24), size: 36))),
            ))),
          const SizedBox(height: 16),
          TextField(controller: ctrl, style: TextStyle(color: theme.textPrimary), maxLines: 3, maxLength: 200,
            decoration: InputDecoration(hintText: 'Komentar (opsional)', hintStyle: TextStyle(color: theme.textMuted),
              filled: true, fillColor: theme.bgBase,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
              counterStyle: TextStyle(color: theme.textMuted))),
          const SizedBox(height: 12),
          SizedBox(width: double.infinity,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: theme.primaryColor,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
              onPressed: () async {
                Navigator.pop(ctx);
                final res = await Provider.of<ShopProvider>(context, listen: false)
                    .submitRating(widget.product.id, stars, ctrl.text);
                if (res['success'] == true) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                      content: Text('Rating tersimpan! ⭐'), backgroundColor: Color(0xFF34D399)));
                  _loadRatings();
                }
              },
              child: Text(_myRating != null ? '🔄 Update Rating' : '⭐ Kirim Rating',
                  style: const TextStyle(fontWeight: FontWeight.w800)),
            )),
        ])),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    final product = widget.product;

    return Scaffold(
      backgroundColor: theme.bgBase,
      body: Stack(children: [
        Container(decoration: BoxDecoration(gradient: theme.bgGrad)),
        _ParticleBg(primary: theme.primaryColor, accent: theme.accentColor),
        CustomScrollView(slivers: [
          SliverAppBar(
            expandedHeight: 300, backgroundColor: Colors.transparent,
            leading: GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Padding(padding: const EdgeInsets.all(8),
                child: Container(decoration: BoxDecoration(color: theme.bgCard, borderRadius: BorderRadius.circular(12)),
                  child: Icon(Icons.arrow_back, color: theme.textPrimary, size: 20))),
            ),
            actions: [
              GestureDetector(
                onTap: () => _showRatingDialog(theme),
                child: Padding(padding: const EdgeInsets.all(8),
                  child: Container(
                    decoration: BoxDecoration(color: theme.bgCard, borderRadius: BorderRadius.circular(12)),
                    padding: const EdgeInsets.all(8),
                    child: const Icon(Icons.star_outline, color: Color(0xFFFBBF24), size: 20))),
              ),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: product.imageUrl.isNotEmpty
                  ? CachedNetworkImage(imageUrl: product.imageUrl, fit: BoxFit.cover,
                      placeholder: (_, __) => Container(color: theme.bgCard),
                      errorWidget: (_, __, ___) => Container(color: theme.bgCard,
                          child: Icon(Icons.image_not_supported, color: theme.primaryColor.withOpacity(0.3), size: 60)))
                  : Container(decoration: BoxDecoration(gradient: theme.primaryGrad),
                      child: const Center(child: Icon(Icons.shopping_bag, size: 80, color: Colors.white54))),
            ),
          ),
          SliverToBoxAdapter(child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                  decoration: BoxDecoration(gradient: theme.primaryGrad, borderRadius: BorderRadius.circular(20),
                      boxShadow: [BoxShadow(color: theme.glowColor, blurRadius: 10)]),
                  child: Text(product.category.toUpperCase(),
                      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: Colors.white)),
                ),
                const Spacer(),
                if (_totalRatings > 0) _StarRating(rating: _avgRating, total: _totalRatings, size: 14),
              ]),
              const SizedBox(height: 14),
              Text(product.name, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: theme.textPrimary)),
              const SizedBox(height: 10),
              if (product.description.isNotEmpty)
                Text(product.description, style: TextStyle(fontSize: 14, color: theme.textSecondary, height: 1.5)),
              const SizedBox(height: 24),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(gradient: theme.cardGrad, borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: theme.primaryColor.withOpacity(0.15))),
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text('Total Harga', style: TextStyle(color: theme.textSecondary)),
                  Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                    ShaderMask(
                      shaderCallback: (b) => theme.primaryGrad.createShader(b),
                      child: Text('Rp${_fmt(_total)}', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: Colors.white)),
                    ),
                    if (_quantity > 1)
                      Text('${_fmt(product.price)} x $_quantity', style: TextStyle(fontSize: 12, color: theme.textMuted)),
                  ]),
                ]),
              ),
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(color: theme.bgCard, borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: theme.primaryColor.withOpacity(0.1))),
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text('Jumlah', style: TextStyle(color: theme.textSecondary, fontWeight: FontWeight.w700)),
                  Row(children: [
                    _QtyBtn(icon: Icons.remove, onTap: () { if (_quantity > 1) setState(() => _quantity--); }, theme: theme),
                    Padding(padding: const EdgeInsets.symmetric(horizontal: 18),
                      child: Text('$_quantity', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: theme.textPrimary))),
                    _QtyBtn(icon: Icons.add, onTap: () { if (_quantity < 99) setState(() => _quantity++); }, theme: theme, filled: true),
                  ]),
                ]),
              ),
              const SizedBox(height: 24),
              if (product.stock > 0)
                Row(children: [
                  Expanded(child: OutlinedButton(
                    style: OutlinedButton.styleFrom(side: BorderSide(color: theme.primaryColor),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                    onPressed: () {
                      Provider.of<ShopProvider>(context, listen: false).addToCart(product, qty: _quantity);
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text('${product.name} x$_quantity ditambahkan'),
                        duration: const Duration(seconds: 1),
                        backgroundColor: const Color(0xFF34D399),
                        behavior: SnackBarBehavior.floating,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                      ));
                    },
                    child: Text('🛒 KERANJANG', style: TextStyle(color: theme.primaryColor, fontWeight: FontWeight.w800)),
                  )),
                  const SizedBox(width: 12),
                  Expanded(child: Container(
                    decoration: BoxDecoration(gradient: theme.primaryGrad, borderRadius: BorderRadius.circular(14),
                        boxShadow: [BoxShadow(color: theme.glowColor, blurRadius: 14, offset: const Offset(0, 6))]),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, shadowColor: Colors.transparent,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                      onPressed: () {
                        Provider.of<ShopProvider>(context, listen: false).addToCart(product, qty: _quantity);
                        Navigator.push(context, MaterialPageRoute(builder: (_) => const CartPage()));
                      },
                      child: const Text('🛍️ BELI', style: TextStyle(fontWeight: FontWeight.w900, color: Colors.white)),
                    ),
                  )),
                ]),
              const SizedBox(height: 32),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text('⭐ Ulasan', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: theme.textPrimary)),
                TextButton(
                  onPressed: () => _showRatingDialog(theme),
                  child: Text(_myRating != null ? 'Edit Rating' : '+ Beri Rating',
                      style: TextStyle(color: theme.primaryColor, fontSize: 12)),
                ),
              ]),
              if (_loadingRatings)
                Center(child: Padding(padding: const EdgeInsets.all(16),
                  child: CircularProgressIndicator(color: theme.primaryColor, strokeWidth: 2)))
              else if (_ratings.isEmpty)
                Container(padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(color: theme.bgCard, borderRadius: BorderRadius.circular(16)),
                  child: Center(child: Text('Belum ada ulasan. Jadilah yang pertama!',
                      style: TextStyle(color: theme.textMuted))))
              else
                ..._ratings.take(5).map((r) => _ReviewCard(rating: r, theme: theme)),
            ]),
          )),
        ]),
      ]),
    );
  }

  String _fmt(int p) => p.toString()
      .replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.');
}

class _QtyBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final ThemeProvider theme;
  final bool filled;
  const _QtyBtn({required this.icon, required this.onTap, required this.theme, this.filled = false});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          width: 34, height: 34,
          decoration: BoxDecoration(
            gradient: filled ? theme.primaryGrad : null,
            color: filled ? null : theme.bgBase,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, size: 18, color: filled ? Colors.white : theme.textSecondary),
        ),
      );
}

class _ReviewCard extends StatelessWidget {
  final RatingEntry rating;
  final ThemeProvider theme;
  const _ReviewCard({required this.rating, required this.theme});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: theme.bgCard, borderRadius: BorderRadius.circular(16),
            border: Border.all(color: theme.primaryColor.withOpacity(0.1))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(width: 34, height: 34,
              decoration: BoxDecoration(gradient: theme.primaryGrad, shape: BoxShape.circle),
              child: Center(child: Text(
                rating.username.isNotEmpty ? rating.username[0].toUpperCase() : '?',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)))),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(rating.username, style: TextStyle(color: theme.textPrimary, fontWeight: FontWeight.w700, fontSize: 13)),
              _StarRating(rating: rating.stars.toDouble()),
            ])),
            Text(_timeAgo(rating.updatedAt), style: TextStyle(fontSize: 10, color: theme.textMuted)),
          ]),
          if (rating.comment.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(rating.comment, style: TextStyle(fontSize: 12, color: theme.textSecondary)),
          ]
        ]),
      );

  String _timeAgo(String iso) {
    try {
      final diff = DateTime.now().difference(DateTime.parse(iso));
      if (diff.inDays > 30) return '${(diff.inDays / 30).floor()} bln lalu';
      if (diff.inDays > 0) return '${diff.inDays} hr lalu';
      if (diff.inHours > 0) return '${diff.inHours} jam lalu';
      return '${diff.inMinutes} mnt lalu';
    } catch (_) { return ''; }
  }
}

// ============================================================
// CART PAGE
// ============================================================

class CartPage extends StatefulWidget {
  const CartPage({super.key});
  @override
  State<CartPage> createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  final _nameCtrl = TextEditingController();
  final _contactCtrl = TextEditingController();
  final _voucherCtrl = TextEditingController();
  bool _isProcessing = false, _isCheckingVoucher = false;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _contactCtrl.dispose();
    _voucherCtrl.dispose();
    super.dispose();
  }

  Future<void> _applyVoucher(ThemeProvider theme) async {
    final code = _voucherCtrl.text.trim();
    if (code.isEmpty) return;
    setState(() => _isCheckingVoucher = true);
    final res = await Provider.of<ShopProvider>(context, listen: false).applyVoucher(code);
    setState(() => _isCheckingVoucher = false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(res['success'] == true ? '🎟️ Voucher berhasil!' : res['message'] ?? 'Tidak valid'),
      backgroundColor: res['success'] == true ? const Color(0xFF34D399) : Colors.red,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
    ));
  }

  // ── Bottom sheet pilih admin ──────────────────────────────
  void _showPickAdminSheet(BuildContext context, ShopProvider shop, ThemeProvider theme) {
    if (_nameCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Masukkan nama Anda dulu')));
      return;
    }
    if (shop.admins.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Belum ada admin tersedia')));
      return;
    }

    showModalBottomSheet(
      context: context,
      backgroundColor: theme.bgCard,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 40, height: 4,
              decoration: BoxDecoration(color: theme.primaryColor.withOpacity(0.3), borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 16),
          Text('👥 Pilih Admin', style: TextStyle(
              color: theme.textPrimary, fontWeight: FontWeight.w800, fontSize: 18)),
          const SizedBox(height: 4),
          Text('Pilih admin yang ingin dihubungi', style: TextStyle(color: theme.textMuted, fontSize: 12)),
          const SizedBox(height: 16),
          ...shop.admins.map((admin) => Container(
            margin: const EdgeInsets.only(bottom: 10),
            decoration: BoxDecoration(
              color: theme.bgBase, borderRadius: BorderRadius.circular(16),
              border: Border.all(color: theme.primaryColor.withOpacity(0.15)),
            ),
            child: Column(children: [
              // Header admin
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                child: Row(children: [
                  Container(width: 38, height: 38,
                    decoration: BoxDecoration(gradient: theme.primaryGrad, shape: BoxShape.circle),
                    child: Center(child: Text(admin.nama[0].toUpperCase(),
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16)))),
                  const SizedBox(width: 12),
                  Text(admin.nama, style: TextStyle(
                      color: theme.textPrimary, fontWeight: FontWeight.w800, fontSize: 15)),
                ]),
              ),
              // Tombol WA & Tele
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                child: Row(children: [
                  if (admin.hasWhatsapp)
                    Expanded(child: Padding(
                      padding: const EdgeInsets.only(right: 6),
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF25D366),
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        icon: const Text('💬', style: TextStyle(fontSize: 14)),
                        label: const Text('WhatsApp', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12)),
                        onPressed: () {
                          Navigator.pop(ctx);
                          _checkout(context, shop, admin, 'whatsapp');
                        },
                      ),
                    )),
                  if (admin.hasTelegram)
                    Expanded(child: Padding(
                      padding: const EdgeInsets.only(left: 6),
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF26A5E4),
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        icon: const Text('✈️', style: TextStyle(fontSize: 14)),
                        label: const Text('Telegram', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12)),
                        onPressed: () {
                          Navigator.pop(ctx);
                          _checkout(context, shop, admin, 'telegram');
                        },
                      ),
                    )),
                ]),
              ),
            ]),
          )),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final shop = context.watch<ShopProvider>();
    final theme = context.watch<ThemeProvider>();

    return Scaffold(
      backgroundColor: theme.bgBase,
      body: Stack(children: [
        Container(decoration: BoxDecoration(gradient: theme.bgGrad)),
        _ParticleBg(primary: theme.primaryColor, accent: theme.accentColor),
        SafeArea(
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Row(children: [
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(width: 40, height: 40,
                    decoration: BoxDecoration(color: theme.bgCard, borderRadius: BorderRadius.circular(12)),
                    child: Icon(Icons.arrow_back, color: theme.textPrimary, size: 20)),
                ),
                const SizedBox(width: 12),
                ShaderMask(
                  shaderCallback: (b) => theme.primaryGrad.createShader(b),
                  child: const Text('🛒 KERANJANG', style: TextStyle(
                      fontWeight: FontWeight.w900, fontSize: 18, letterSpacing: 2, color: Colors.white)),
                ),
              ]),
            ),
            Expanded(
              child: shop.cart.isEmpty
                  ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Container(width: 80, height: 80,
                        decoration: BoxDecoration(color: theme.bgCard, borderRadius: BorderRadius.circular(24),
                            border: Border.all(color: theme.primaryColor.withOpacity(0.2))),
                        child: const Center(child: Text('🛒', style: TextStyle(fontSize: 36)))),
                      const SizedBox(height: 16),
                      Text('Keranjang Kosong', style: TextStyle(color: theme.textMuted, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 12),
                      Container(
                        decoration: BoxDecoration(gradient: theme.primaryGrad, borderRadius: BorderRadius.circular(30),
                            boxShadow: [BoxShadow(color: theme.glowColor, blurRadius: 12)]),
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, shadowColor: Colors.transparent,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30))),
                          onPressed: () => Navigator.pop(context),
                          child: const Text('LANJUT BELANJA', style: TextStyle(fontWeight: FontWeight.w800, color: Colors.white)),
                        ),
                      ),
                    ]))
                  : Column(children: [
                      Expanded(child: ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        itemCount: shop.cart.length,
                        itemBuilder: (_, i) => _CartItemCard(item: shop.cart[i], theme: theme),
                      )),
                      _buildCheckoutPanel(shop, theme),
                    ]),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _buildCheckoutPanel(ShopProvider shop, ThemeProvider theme) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
      decoration: BoxDecoration(
        color: theme.bgCard.withOpacity(0.95),
        border: Border(top: BorderSide(color: theme.primaryColor.withOpacity(0.1))),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        boxShadow: [BoxShadow(color: theme.primaryColor.withOpacity(0.1), blurRadius: 20, offset: const Offset(0, -8))],
      ),
      child: Column(children: [
        Center(child: Container(width: 40, height: 4,
            decoration: BoxDecoration(color: theme.primaryColor.withOpacity(0.3), borderRadius: BorderRadius.circular(2)))),
        const SizedBox(height: 14),

        // Voucher
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: theme.bgBase, borderRadius: BorderRadius.circular(14),
            border: Border.all(color: shop.appliedVoucher != null
                ? const Color(0xFF34D399).withOpacity(0.5) : theme.primaryColor.withOpacity(0.1))),
          child: shop.appliedVoucher != null
              ? Row(children: [
                  const Text('🎟️', style: TextStyle(fontSize: 18)),
                  const SizedBox(width: 10),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Voucher ${shop.appliedVoucher!.code}',
                        style: const TextStyle(color: Color(0xFF34D399), fontWeight: FontWeight.w700)),
                    Text('-Rp${_fmt(shop.discountAmount)}', style: const TextStyle(color: Color(0xFF34D399), fontSize: 12)),
                  ])),
                  GestureDetector(
                    onTap: () { shop.removeVoucher(); _voucherCtrl.clear(); },
                    child: Container(padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(color: Colors.red.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
                      child: const Icon(Icons.close, size: 16, color: Colors.redAccent)),
                  ),
                ])
              : Row(children: [
                  Expanded(child: TextField(
                    controller: _voucherCtrl,
                    style: TextStyle(color: theme.textPrimary, fontSize: 13),
                    textCapitalization: TextCapitalization.characters,
                    decoration: InputDecoration(hintText: '🎟️ Kode Voucher',
                      hintStyle: TextStyle(color: theme.textMuted, fontSize: 13),
                      border: InputBorder.none, isDense: true, contentPadding: EdgeInsets.zero),
                  )),
                  GestureDetector(
                    onTap: _isCheckingVoucher ? null : () => _applyVoucher(theme),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(gradient: theme.primaryGrad, borderRadius: BorderRadius.circular(10)),
                      child: _isCheckingVoucher
                          ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                          : const Text('PAKAI', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w800)),
                    ),
                  ),
                ]),
        ),
        const SizedBox(height: 12),

        // Price summary
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text('Subtotal (${shop.totalCartItems} item)', style: TextStyle(color: theme.textSecondary, fontSize: 13)),
          Text('Rp${_fmt(shop.subtotal)}', style: TextStyle(color: theme.textPrimary, fontSize: 13)),
        ]),
        if (shop.discountAmount > 0) ...[
          const SizedBox(height: 4),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text('Diskon Voucher', style: TextStyle(color: Color(0xFF34D399), fontSize: 13)),
            Text('-Rp${_fmt(shop.discountAmount)}', style: const TextStyle(color: Color(0xFF34D399), fontSize: 13)),
          ]),
        ],
        Divider(color: theme.primaryColor.withOpacity(0.15), height: 20),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text('TOTAL', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: theme.textPrimary)),
          ShaderMask(
            shaderCallback: (b) => theme.primaryGrad.createShader(b),
            child: Text('Rp${_fmt(shop.totalPrice)}',
                style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 22, color: Colors.white)),
          ),
        ]),
        const SizedBox(height: 14),

        // Input nama
        _inputField(controller: _nameCtrl, hint: 'Nama Lengkap',
            icon: Icons.person_outline, iconColor: theme.primaryColor, theme: theme),
        const SizedBox(height: 14),

        // Tombol ORDER → buka sheet pilih admin
        Container(
          width: double.infinity,
          decoration: BoxDecoration(
            gradient: theme.primaryGrad,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [BoxShadow(color: theme.glowColor, blurRadius: 16, offset: const Offset(0, 6))],
          ),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent, shadowColor: Colors.transparent,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            ),
            onPressed: _isProcessing ? null : () => _showPickAdminSheet(context, shop, theme),
            child: _isProcessing
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text('👥', style: TextStyle(fontSize: 18)),
                    SizedBox(width: 8),
                    Text('PILIH ADMIN & ORDER', style: TextStyle(fontWeight: FontWeight.w900, color: Colors.white)),
                  ]),
          ),
        ),
        const SizedBox(height: 6),
        Text('Pilih admin lalu hubungi via WA atau Telegram',
            style: TextStyle(fontSize: 10, color: theme.textMuted)),
      ]),
    );
  }

  Widget _inputField({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    required Color iconColor,
    required ThemeProvider theme,
  }) => TextField(
        controller: controller,
        style: TextStyle(color: theme.textPrimary),
        decoration: InputDecoration(
          hintText: hint, hintStyle: TextStyle(color: theme.textMuted),
          filled: true, fillColor: theme.bgBase,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
          prefixIcon: Icon(icon, color: iconColor, size: 20),
          contentPadding: const EdgeInsets.symmetric(vertical: 14),
        ),
      );

  Future<void> _checkout(BuildContext context, ShopProvider shop, AdminInfo admin, String channel) async {
    setState(() => _isProcessing = true);
    final result = await shop.createOrder(admin, channel, _nameCtrl.text.trim(), '');
    setState(() => _isProcessing = false);
    if (!mounted) return;

    if (result['success'] == true) {
      final uri = Uri.tryParse(result['url'] ?? '');
      if (uri != null && await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      }
      if (!mounted) return;
      final theme = context.read<ThemeProvider>();
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => AlertDialog(
          backgroundColor: theme.bgCard,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          title: Row(children: [
            Container(width: 40, height: 40,
              decoration: const BoxDecoration(color: Color(0xFF34D399), shape: BoxShape.circle),
              child: const Icon(Icons.check, color: Colors.white)),
            const SizedBox(width: 12),
            Text('Pesanan Dibuat!', style: TextStyle(color: theme.textPrimary, fontWeight: FontWeight.w800)),
          ]),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: theme.bgBase, borderRadius: BorderRadius.circular(12)),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text('Admin', style: TextStyle(color: theme.textMuted)),
                Text(result['adminNama'] ?? '-',
                    style: TextStyle(color: theme.primaryColor, fontWeight: FontWeight.w700)),
              ])),
            const SizedBox(height: 10),
            Container(padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: theme.bgBase, borderRadius: BorderRadius.circular(12)),
              child: Row(children: [
                Icon(Icons.info_outline, color: theme.accentColor, size: 18),
                const SizedBox(width: 10),
                Expanded(child: Text('Admin akan segera menghubungi Anda untuk konfirmasi',
                    style: TextStyle(color: theme.textSecondary, fontSize: 13))),
              ])),
          ]),
          actions: [
            TextButton(
              onPressed: () { Navigator.pop(context); Navigator.pop(context); },
              child: Text('KEMBALI KE TOKO', style: TextStyle(color: theme.primaryColor, fontWeight: FontWeight.w800)),
            ),
          ],
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(result['message'] ?? 'Gagal'), backgroundColor: Colors.red));
    }
  }

  String _fmt(int p) => p.toString()
      .replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.');
}

// ============================================================
// CART ITEM CARD
// ============================================================

class _CartItemCard extends StatelessWidget {
  final CartItem item;
  final ThemeProvider theme;
  const _CartItemCard({required this.item, required this.theme});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(gradient: theme.cardGrad, borderRadius: BorderRadius.circular(18),
            border: Border.all(color: theme.primaryColor.withOpacity(0.1))),
        child: Row(children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: item.imageUrl.isNotEmpty
                ? CachedNetworkImage(imageUrl: item.imageUrl, width: 60, height: 60, fit: BoxFit.cover,
                    placeholder: (_, __) => Container(width: 60, height: 60, color: theme.bgBase),
                    errorWidget: (_, __, ___) => Container(width: 60, height: 60, color: theme.bgBase,
                        child: Icon(Icons.image_not_supported, color: theme.primaryColor.withOpacity(0.3))))
                : Container(width: 60, height: 60, color: theme.bgBase,
                    child: Icon(Icons.shopping_bag_outlined, color: theme.primaryColor.withOpacity(0.3))),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(item.name, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: theme.textPrimary), maxLines: 2),
            const SizedBox(height: 4),
            ShaderMask(
              shaderCallback: (b) => theme.primaryGrad.createShader(b),
              child: Text('Rp${_fmt(item.price)}',
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12, color: Colors.white)),
            ),
          ])),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(color: theme.bgBase, borderRadius: BorderRadius.circular(30)),
            child: Row(children: [
              GestureDetector(
                onTap: () => Provider.of<ShopProvider>(context, listen: false)
                    .updateQuantity(item.productId, item.quantity - 1),
                child: Icon(Icons.remove, size: 18, color: theme.textMuted)),
              Padding(padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Text('${item.quantity}', style: TextStyle(color: theme.textPrimary, fontWeight: FontWeight.w700))),
              GestureDetector(
                onTap: () => Provider.of<ShopProvider>(context, listen: false)
                    .updateQuantity(item.productId, item.quantity + 1),
                child: Icon(Icons.add, size: 18, color: theme.primaryColor)),
            ]),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: () => Provider.of<ShopProvider>(context, listen: false).removeFromCart(item.productId),
            child: Container(padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: Colors.red.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.delete_outline, size: 18, color: Colors.redAccent)),
          ),
        ]),
      );

  String _fmt(int p) => p.toString()
      .replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.');
}
