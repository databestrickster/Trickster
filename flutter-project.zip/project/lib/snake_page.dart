import 'package:http/http.dart' as http;
import 'dart:convert';
import 'config_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:async';
import 'dart:math';

// ─────────────────────────────────────────────────────────────
// 🎨 PALETTE
// ─────────────────────────────────────────────────────────────
const _kDark      = Color(0xFF0A0A0A);
const _kDarkCard  = Color(0xFF151515);
const _kDarkPanel = Color(0xFF1A1A1A);
const _kGold      = Color(0xFFFFD700);
const _kGoldDark  = Color(0xFFB8860B);
const _kGreen     = Color(0xFF39FF14); // neon green snake
const _kGreenDark = Color(0xFF1A7A00);
const _kRed       = Color(0xFFFF2D55);
const _kNokia     = Color(0xFF4A7C59); // Nokia screen green tint

// ─────────────────────────────────────────────────────────────
// 🐍 DIRECTION
// ─────────────────────────────────────────────────────────────
enum Direction { up, down, left, right }

// ─────────────────────────────────────────────────────────────
// 🎮 SNAKE PAGE
// ─────────────────────────────────────────────────────────────
class SnakePage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const SnakePage({
    super.key,
    this.username = '',
    this.sessionKey = '',
  });

  @override
  State<SnakePage> createState() => _SnakePageState();
}

class _SnakePageState extends State<SnakePage> with TickerProviderStateMixin {
  static const int kCols = 20;
  static const int kRows = 20;

  List<Point<int>> _snake = [];
  Point<int> _food = const Point(10, 5);
  Point<int>? _bonusFood;
  Direction _dir = Direction.right;
  Direction _nextDir = Direction.right;
  Timer? _timer;
  bool _isRunning = false;
  bool _isDead = false;
  bool _isStarted = false;
  int _score = 0;
  int _highScore = 0;
  int _level = 1;
  int _foodEaten = 0;
  int _bonusFoodTimer = 0;
  Timer? _bonusTimer;

  late AnimationController _glowCtrl;
  late Animation<double> _glowAnim;
  late AnimationController _deathCtrl;
  late Animation<double> _deathAnim;
  late AnimationController _foodCtrl;
  late Animation<double> _foodAnim;

  // Swipe detection
  Offset? _dragStart;

  @override
  void initState() {
    super.initState();
    _glowCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1000))
      ..repeat(reverse: true);
    _glowAnim = Tween<double>(begin: 0.4, end: 1.0).animate(_glowCtrl);

    _deathCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _deathAnim = Tween<double>(begin: 0.0, end: 1.0).animate(_deathCtrl);

    _foodCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 700))
      ..repeat(reverse: true);
    _foodAnim = Tween<double>(begin: 0.8, end: 1.2).animate(
      CurvedAnimation(parent: _foodCtrl, curve: Curves.easeInOut));

    _initGame();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _bonusTimer?.cancel();
    _glowCtrl.dispose();
    _deathCtrl.dispose();
    _foodCtrl.dispose();
    super.dispose();
  }

  void _initGame() {
    _snake = [
      const Point(10, 10),
      const Point(9, 10),
      const Point(8, 10),
    ];
    _dir = Direction.right;
    _nextDir = Direction.right;
    _score = 0;
    _level = 1;
    _foodEaten = 0;
    _isDead = false;
    _isStarted = false;
    _isRunning = false;
    _bonusFood = null;
    _bonusFoodTimer = 0;
    _timer?.cancel();
    _bonusTimer?.cancel();
    _spawnFood();
    _deathCtrl.reset();
  }

  void _startGame() {
    setState(() {
      _isStarted = true;
      _isRunning = true;
    });
    _startTimer();
  }

  int get _speed {
    // Level 1 = 200ms, each level -15ms, min 60ms
    return max(60, 200 - (_level - 1) * 15);
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(Duration(milliseconds: _speed), (_) => _tick());
  }

  void _tick() {
    if (!_isRunning) return;
    setState(() {
      _dir = _nextDir;
      final head = _snake.first;
      Point<int> newHead;
      switch (_dir) {
        case Direction.up:    newHead = Point(head.x, head.y - 1); break;
        case Direction.down:  newHead = Point(head.x, head.y + 1); break;
        case Direction.left:  newHead = Point(head.x - 1, head.y); break;
        case Direction.right: newHead = Point(head.x + 1, head.y); break;
      }

      // Wall collision
      if (newHead.x < 0 || newHead.x >= kCols || newHead.y < 0 || newHead.y >= kRows) {
        _die(); return;
      }
      // Self collision
      if (_snake.contains(newHead)) { _die(); return; }

      _snake.insert(0, newHead);

      // Eat food
      if (newHead == _food) {
        _score += 10 * _level;
        _foodEaten++;
        HapticFeedback.lightImpact();
        _spawnFood();
        // Level up every 5 food
        if (_foodEaten % 5 == 0) {
          _level++;
          _startTimer(); // refresh speed
        }
        // Spawn bonus food randomly
        if (_foodEaten % 3 == 0 && _bonusFood == null) {
          _spawnBonusFood();
        }
      } else if (_bonusFood != null && newHead == _bonusFood) {
        _score += 50 * _level;
        HapticFeedback.mediumImpact();
        _bonusFood = null;
        _bonusTimer?.cancel();
      } else {
        _snake.removeLast();
      }

      if (_score > _highScore) _highScore = _score;
    });
  }

  void _die() {
    _isRunning = false;
    _isDead = true;
    _timer?.cancel();
    _bonusTimer?.cancel();
    HapticFeedback.heavyImpact();
    _deathCtrl.forward();
    _submitToLeaderboard();
  }

  Future<void> _submitToLeaderboard() async {
    if (widget.username.isEmpty || _score <= 0) return;
    try {
      await http.post(
        Uri.parse('${ConfigService.baseUrl}/api/games/leaderboard/submit'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': widget.username,
          'gameName': 'Snake',
          'score': _score,
          'win': false,
          'icon': '🐍',
        }),
      ).timeout(const Duration(seconds: 8));
    } catch (_) {}
  }

  void _spawnFood() {
    final rand = Random();
    Point<int> pos;
    do {
      pos = Point(rand.nextInt(kCols), rand.nextInt(kRows));
    } while (_snake.contains(pos));
    _food = pos;
  }

  void _spawnBonusFood() {
    final rand = Random();
    Point<int> pos;
    do {
      pos = Point(rand.nextInt(kCols), rand.nextInt(kRows));
    } while (_snake.contains(pos) || pos == _food);
    _bonusFood = pos;
    _bonusFoodTimer = 8;
    _bonusTimer?.cancel();
    _bonusTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() {
        _bonusFoodTimer--;
        if (_bonusFoodTimer <= 0) {
          _bonusFood = null;
          _bonusTimer?.cancel();
        }
      });
    });
  }

  void _togglePause() {
    setState(() => _isRunning = !_isRunning);
  }

  void _changeDir(Direction d) {
    // Prevent reverse
    if (d == Direction.up    && _dir == Direction.down)  return;
    if (d == Direction.down  && _dir == Direction.up)    return;
    if (d == Direction.left  && _dir == Direction.right) return;
    if (d == Direction.right && _dir == Direction.left)  return;
    _nextDir = d;
  }

  void _handleSwipe(Offset delta) {
    if (delta.dx.abs() > delta.dy.abs()) {
      _changeDir(delta.dx > 0 ? Direction.right : Direction.left);
    } else {
      _changeDir(delta.dy > 0 ? Direction.down : Direction.up);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kDark,
      appBar: AppBar(
        backgroundColor: _kDarkCard,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: _kGold),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('🐍 Snake',
          style: TextStyle(color: _kGold, fontWeight: FontWeight.bold,
              fontSize: 20, letterSpacing: 2)),
        centerTitle: true,
        actions: [
          if (_isStarted && !_isDead)
            IconButton(
              icon: Icon(_isRunning ? Icons.pause : Icons.play_arrow, color: _kGold),
              onPressed: _togglePause,
            ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 8),
            _buildScoreBar(),
            const SizedBox(height: 8),
            Expanded(child: _buildBoard()),
            const SizedBox(height: 8),
            _buildDpad(),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  Widget _buildScoreBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          _buildStatBox('SCORE', '$_score'),
          const SizedBox(width: 8),
          _buildStatBox('LEVEL', '$_level'),
          const SizedBox(width: 8),
          _buildStatBox('BEST', '$_highScore'),
        ],
      ),
    );
  }

  Widget _buildStatBox(String label, String value) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: _kDarkPanel,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: _kGold.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Text(label, style: const TextStyle(color: Colors.white38, fontSize: 10, letterSpacing: 1)),
            const SizedBox(height: 2),
            Text(value, style: const TextStyle(color: _kGold, fontWeight: FontWeight.bold, fontSize: 18)),
          ],
        ),
      ),
    );
  }

  Widget _buildBoard() {
    return GestureDetector(
      onPanStart: (d) => _dragStart = d.globalPosition,
      onPanEnd: (d) {
        if (_dragStart != null) {
          final delta = d.velocity.pixelsPerSecond;
          if (delta.distance > 100) _handleSwipe(delta);
          _dragStart = null;
        }
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: AspectRatio(
          aspectRatio: 1,
          child: Container(
            decoration: BoxDecoration(
              color: const Color(0xFF0D1F0D), // dark nokia green bg
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _kGold.withOpacity(0.5), width: 2),
              boxShadow: [
                BoxShadow(color: _kGreen.withOpacity(0.08), blurRadius: 20, spreadRadius: 2),
                BoxShadow(color: _kGold.withOpacity(0.1), blurRadius: 30),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: Stack(
                children: [
                  // Grid lines (subtle)
                  CustomPaint(
                    painter: _GridPainter(kCols, kRows),
                    child: Container(),
                  ),
                  // Game objects
                  LayoutBuilder(builder: (ctx, constraints) {
                    final cw = constraints.maxWidth / kCols;
                    final ch = constraints.maxHeight / kRows;
                    return AnimatedBuilder(
                      animation: Listenable.merge([_glowAnim, _foodAnim, _deathAnim]),
                      builder: (_, __) => CustomPaint(
                        painter: _SnakePainter(
                          snake: _snake,
                          food: _food,
                          bonusFood: _bonusFood,
                          cellW: cw,
                          cellH: ch,
                          glowAnim: _glowAnim.value,
                          foodAnim: _foodAnim.value,
                          isDead: _isDead,
                          deathAnim: _deathAnim.value,
                        ),
                        child: Container(),
                      ),
                    );
                  }),
                  // Overlay screens
                  if (!_isStarted) _buildStartOverlay(),
                  if (_isDead) _buildDeadOverlay(),
                  if (_isStarted && !_isRunning && !_isDead) _buildPauseOverlay(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStartOverlay() {
    return Container(
      color: Colors.black.withOpacity(0.75),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('🐍', style: TextStyle(fontSize: 60)),
            const SizedBox(height: 12),
            const Text('SNAKE', style: TextStyle(
              color: _kGreen, fontSize: 32, fontWeight: FontWeight.bold, letterSpacing: 6)),
            const SizedBox(height: 4),
            const Text('Nokia Edition', style: TextStyle(color: Colors.white38, fontSize: 12)),
            const SizedBox(height: 24),
            GestureDetector(
              onTap: _startGame,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                decoration: BoxDecoration(
                  color: _kGreen,
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: [BoxShadow(color: _kGreen.withOpacity(0.5), blurRadius: 20)],
                ),
                child: const Text('MAIN', style: TextStyle(
                  color: Colors.black, fontWeight: FontWeight.bold, fontSize: 16, letterSpacing: 3)),
              ),
            ),
            const SizedBox(height: 16),
            const Text('Swipe atau pakai tombol D-Pad',
              style: TextStyle(color: Colors.white30, fontSize: 11)),
          ],
        ),
      ),
    );
  }

  Widget _buildDeadOverlay() {
    return AnimatedBuilder(
      animation: _deathAnim,
      builder: (_, __) => Container(
        color: Colors.black.withOpacity(0.8 * _deathAnim.value),
        child: _deathAnim.value > 0.5 ? Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('💀', style: TextStyle(fontSize: 56)),
              const SizedBox(height: 10),
              const Text('GAME OVER', style: TextStyle(
                color: _kRed, fontSize: 28, fontWeight: FontWeight.bold, letterSpacing: 4)),
              const SizedBox(height: 8),
              Text('Score: $_score', style: const TextStyle(color: _kGold, fontSize: 18)),
              if (_score >= _highScore && _score > 0)
                const Text('🏆 NEW HIGH SCORE!',
                  style: TextStyle(color: _kGold, fontSize: 13, fontWeight: FontWeight.bold)),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _buildOverlayBtn('LAGI', _kGreen, Colors.black, () {
                    setState(() => _initGame());
                    _startGame();
                  }),
                  const SizedBox(width: 12),
                  _buildOverlayBtn('MENU', Colors.white12, Colors.white60, () {
                    setState(() => _initGame());
                  }),
                ],
              ),
            ],
          ),
        ) : const SizedBox(),
      ),
    );
  }

  Widget _buildPauseOverlay() {
    return Container(
      color: Colors.black.withOpacity(0.6),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.pause_circle_filled, color: _kGold, size: 64),
            const SizedBox(height: 12),
            const Text('PAUSED', style: TextStyle(
              color: _kGold, fontSize: 24, fontWeight: FontWeight.bold, letterSpacing: 4)),
            const SizedBox(height: 20),
            _buildOverlayBtn('LANJUT', _kGold, Colors.black, _togglePause),
          ],
        ),
      ),
    );
  }

  Widget _buildOverlayBtn(String label, Color bg, Color fg, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 10),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(24),
          boxShadow: [BoxShadow(color: bg.withOpacity(0.3), blurRadius: 12)],
        ),
        child: Text(label, style: TextStyle(
          color: fg, fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 2)),
      ),
    );
  }

  Widget _buildDpad() {
    return Column(
      children: [
        // Bonus food timer
        if (_bonusFood != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Text('⭐ Bonus +${50 * _level}! ($_bonusFoodTimer)',
              style: const TextStyle(color: _kGold, fontSize: 12, fontWeight: FontWeight.bold)),
          ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _dpadBtn(Icons.arrow_upward, Direction.up),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _dpadBtn(Icons.arrow_back, Direction.left),
            const SizedBox(width: 4),
            _dpadCenter(),
            const SizedBox(width: 4),
            _dpadBtn(Icons.arrow_forward, Direction.right),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _dpadBtn(Icons.arrow_downward, Direction.down),
          ],
        ),
      ],
    );
  }

  Widget _dpadBtn(IconData icon, Direction dir) {
    return GestureDetector(
      onTap: () {
        if (!_isStarted) _startGame();
        else if (_isRunning) _changeDir(dir);
      },
      child: Container(
        width: 64, height: 64,
        margin: const EdgeInsets.all(2),
        decoration: BoxDecoration(
          color: _kDarkPanel,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _kGold.withOpacity(0.3)),
          boxShadow: [BoxShadow(color: Colors.black54, blurRadius: 4, offset: const Offset(0, 2))],
        ),
        child: Icon(icon, color: _kGold, size: 28),
      ),
    );
  }

  Widget _dpadCenter() {
    return Container(
      width: 64, height: 64,
      margin: const EdgeInsets.all(2),
      decoration: BoxDecoration(
        color: _kDarkCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _kGold.withOpacity(0.15)),
      ),
      child: Icon(Icons.circle, color: _kGold.withOpacity(0.2), size: 20),
    );
  }
}

// ─────────────────────────────────────────────────────────────
// 🎨 PAINTERS
// ─────────────────────────────────────────────────────────────
class _GridPainter extends CustomPainter {
  final int cols, rows;
  _GridPainter(this.cols, this.rows);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.04)
      ..strokeWidth = 0.5;
    final cw = size.width / cols;
    final ch = size.height / rows;
    for (int i = 0; i <= cols; i++) {
      canvas.drawLine(Offset(i * cw, 0), Offset(i * cw, size.height), paint);
    }
    for (int i = 0; i <= rows; i++) {
      canvas.drawLine(Offset(0, i * ch), Offset(size.width, i * ch), paint);
    }
  }

  @override
  bool shouldRepaint(_) => false;
}

class _SnakePainter extends CustomPainter {
  final List<Point<int>> snake;
  final Point<int> food;
  final Point<int>? bonusFood;
  final double cellW, cellH;
  final double glowAnim, foodAnim;
  final bool isDead;
  final double deathAnim;

  _SnakePainter({
    required this.snake,
    required this.food,
    required this.bonusFood,
    required this.cellW,
    required this.cellH,
    required this.glowAnim,
    required this.foodAnim,
    required this.isDead,
    required this.deathAnim,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final snakeColor = isDead
        ? Color.lerp(const Color(0xFF39FF14), const Color(0xFFFF2D55), deathAnim)!
        : const Color(0xFF39FF14);

    // Draw food
    _drawFood(canvas, food, const Color(0xFFFF2D55), foodAnim);
    if (bonusFood != null) {
      _drawFood(canvas, bonusFood!, const Color(0xFFFFD700), foodAnim);
    }

    // Draw snake
    for (int i = 0; i < snake.length; i++) {
      final seg = snake[i];
      final isHead = i == 0;
      final rect = Rect.fromLTWH(
        seg.x * cellW + 1,
        seg.y * cellH + 1,
        cellW - 2,
        cellH - 2,
      );
      final rr = RRect.fromRectAndRadius(rect, Radius.circular(isHead ? 4 : 3));

      final alpha = isHead ? 1.0 : max(0.3, 1.0 - (i / snake.length) * 0.7);
      final paint = Paint()..color = snakeColor.withOpacity(alpha);
      canvas.drawRRect(rr, paint);

      // Head glow
      if (isHead && !isDead) {
        final glowPaint = Paint()
          ..color = snakeColor.withOpacity(0.4 * glowAnim)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6);
        canvas.drawRRect(rr.inflate(3), glowPaint);
        // Eyes
        _drawEyes(canvas, seg, cellW, cellH);
      }
    }
  }

  void _drawFood(Canvas canvas, Point<int> pos, Color color, double scale) {
    final cx = pos.x * cellW + cellW / 2;
    final cy = pos.y * cellH + cellH / 2;
    final r = (min(cellW, cellH) / 2 - 2) * scale;

    // Glow
    canvas.drawCircle(
      Offset(cx, cy), r + 3,
      Paint()..color = color.withOpacity(0.3)
             ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6));
    // Food dot
    canvas.drawCircle(Offset(cx, cy), r, Paint()..color = color);
  }

  void _drawEyes(Canvas canvas, Point<int> head, double cw, double ch) {
    // Simple eyes based on direction (just two dots)
    final cx = head.x * cw + cw / 2;
    final cy = head.y * ch + ch / 2;
    final eyePaint = Paint()..color = Colors.black;
    final r = cw * 0.1;
    canvas.drawCircle(Offset(cx - cw * 0.15, cy - ch * 0.1), r, eyePaint);
    canvas.drawCircle(Offset(cx + cw * 0.15, cy - ch * 0.1), r, eyePaint);
  }

  @override
  bool shouldRepaint(_SnakePainter old) => true;
}
