// lib/ular_tangga_bet.dart
// Sistem Taruhan Koin untuk Ular Tangga
// File ini TERPISAH  tidak mengubah logika game/pion sama sekali

import 'config_service.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;


const Color _kGold = Color(0xFFFFD700);
const Color _kDark = Color(0xFF0D1426);

// 
// MODEL
// 
class BetHistory {
  final String gameMode;
  final int betAmount;
  final int totalPot;
  final int players;
  final String result; // 'menang' | 'kalah'
  final int saldoChange;
  final DateTime time;

  BetHistory({
    required this.gameMode,
    required this.betAmount,
    required this.totalPot,
    required this.players,
    required this.result,
    required this.saldoChange,
    required this.time,
  });

  Map<String, dynamic> toJson() => {
    'gameMode': gameMode,
    'betAmount': betAmount,
    'totalPot': totalPot,
    'players': players,
    'result': result,
    'saldoChange': saldoChange,
    'time': time.toIso8601String(),
  };

  factory BetHistory.fromJson(Map<String, dynamic> j) => BetHistory(
    gameMode: j['gameMode'] ?? '',
    betAmount: j['betAmount'] ?? 0,
    totalPot: j['totalPot'] ?? 0,
    players: j['players'] ?? 0,
    result: j['result'] ?? '',
    saldoChange: j['saldoChange'] ?? 0,
    time: DateTime.tryParse(j['time'] ?? '') ?? DateTime.now(),
  );
}

// 
// API HELPER
// 
// Helper aman parse JSON  kalau server return HTML langsung return null
Map<String, dynamic>? _safeJson(String body) {
  try {
    final trimmed = body.trim();
    if (!trimmed.startsWith('{') && !trimmed.startsWith('[')) return null;
    return jsonDecode(trimmed);
  } catch (_) { return null; }
}

class BetApi {
  static Future<int> getSaldo(String sessionKey) async {
    try {
      final res = await http.get(Uri.parse('${ConfigService.baseUrl}/getSaldo?key=$sessionKey'))
          .timeout(const Duration(seconds: 8));
      final data = _safeJson(res.body);
      if (data != null && data['valid'] == true) return (data['saldo'] as num).toInt();
    } catch (_) {}
    return -1;
  }

  static Future<Map<String, dynamic>> placeBet(String sessionKey, int amount) async {
    try {
      final res = await http.get(Uri.parse('${ConfigService.baseUrl}/placeBet?key=$sessionKey&amount=$amount'))
          .timeout(const Duration(seconds: 8));
      return _safeJson(res.body) ?? {'valid': false, 'message': 'Server error'};
    } catch (e) {
      return {'valid': false, 'message': 'Koneksi error'};
    }
  }

  static Future<Map<String, dynamic>> claimWin(String sessionKey, int totalPot) async {
    try {
      final res = await http.get(Uri.parse('${ConfigService.baseUrl}/claimBetWin?key=$sessionKey&amount=$totalPot'))
          .timeout(const Duration(seconds: 8));
      return _safeJson(res.body) ?? {'valid': false, 'message': 'Server error'};
    } catch (e) {
      return {'valid': false, 'message': 'Koneksi error'};
    }
  }

  static Future<Map<String, dynamic>> checkDaily(String sessionKey) async {
    try {
      final res = await http.get(Uri.parse('${ConfigService.baseUrl}/checkDaily?key=$sessionKey'))
          .timeout(const Duration(seconds: 8));
      return _safeJson(res.body) ?? {'valid': false, 'canClaim': false};
    } catch (e) {
      return {'valid': false, 'canClaim': false};
    }
  }

  static Future<Map<String, dynamic>> claimDaily(String sessionKey) async {
    try {
      final res = await http.get(Uri.parse('${ConfigService.baseUrl}/claimDaily?key=$sessionKey'))
          .timeout(const Duration(seconds: 8));
      return _safeJson(res.body) ?? {'valid': false, 'message': 'Server error'};
    } catch (e) {
      return {'valid': false, 'message': 'Koneksi error'};
    }
  }

  static Future<Map<String, dynamic>> topUpUser(
      String ownerKey, String targetUsername, int amount) async {
    try {
      final res = await http.get(Uri.parse(
          '${ConfigService.baseUrl}/topUpSaldo?key=$ownerKey&username=$targetUsername&amount=$amount'))
          .timeout(const Duration(seconds: 8));
      return _safeJson(res.body) ?? {'valid': false, 'message': 'Server error'};
    } catch (e) {
      return {'valid': false, 'message': 'Koneksi error'};
    }
  }

  static Future<List<dynamic>> getUsers(String sessionKey) async {
    try {
      final res = await http.get(Uri.parse('${ConfigService.baseUrl}/listUsers?key=$sessionKey'))
          .timeout(const Duration(seconds: 8));
      final data = _safeJson(res.body);
      if (data != null && data['valid'] == true) return data['users'] ?? [];
    } catch (_) {}
    return [];
  }
}

// 
// WIDGET: SALDO BADGE (tampil di header)
// 
class SaldoBadge extends StatelessWidget {
  final int saldo;
  final bool isLoading;
  final VoidCallback? onTap;

  const SaldoBadge({
    super.key,
    required this.saldo,
    this.isLoading = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 400),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: _kGold.withValues(alpha: 0.12),
          border: Border.all(color: _kGold.withValues(alpha: 0.5), width: 1.5),
          boxShadow: [BoxShadow(color: _kGold.withValues(alpha: 0.2), blurRadius: 8)],
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          const Text('🪙', style: TextStyle(fontSize: 13)),
          const SizedBox(width: 4),
          isLoading
              ? const SizedBox(width: 40, height: 12,
                  child: LinearProgressIndicator(backgroundColor: Colors.transparent,
                      valueColor: AlwaysStoppedAnimation(_kGold)))
              : Text(
                  _fmtRp(saldo),
                  style: const TextStyle(
                    color: _kGold, fontFamily: 'Orbitron',
                    fontSize: 11, fontWeight: FontWeight.bold),
                ),
        ]),
      ),
    );
  }

  static String _fmtRp(int n) =>
      'Rp ${n.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.')}';
}

// 
// WIDGET: BET SETUP BOTTOM SHEET
// Dipanggil sebelum game dimulai di semua mode
// 
class BetSetupSheet extends StatefulWidget {
  final String sessionKey;
  final String gameMode;
  final int playerCount;
  final void Function(int betAmount) onConfirm; // 0 = tanpa taruhan

  const BetSetupSheet({
    super.key,
    required this.sessionKey,
    required this.gameMode,
    required this.playerCount,
    required this.onConfirm,
  });

  static Future<int?> show(BuildContext context, {
    required String sessionKey,
    required String gameMode,
    required int playerCount,
  }) async {
    int? result;
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => BetSetupSheet(
        sessionKey: sessionKey,
        gameMode: gameMode,
        playerCount: playerCount,
        onConfirm: (bet) { result = bet; Navigator.pop(context); },
      ),
    );
    return result;
  }

  @override
  State<BetSetupSheet> createState() => _BetSetupSheetState();
}

class _BetSetupSheetState extends State<BetSetupSheet> {
  int _saldo = 0;
  bool _loadingSaldo = true;
  int _betAmount = 0;
  final _ctrl = TextEditingController(text: '0');
  bool _enableBet = false;

  // Preset bets
  static const _presets = [1000, 5000, 10000, 25000, 50000, 100000];
  static const _minBet  = 1000;

  @override
  void initState() {
    super.initState();
    _fetchSaldo();
  }

  Future<void> _fetchSaldo() async {
    final s = await BetApi.getSaldo(widget.sessionKey);
    if (mounted) setState(() { _saldo = s; _loadingSaldo = false; });
  }

  void _setBet(int amount) {
    final clamped = amount.clamp(_minBet, _saldo > 0 ? _saldo : _minBet);
    setState(() { _betAmount = clamped; _ctrl.text = clamped.toString(); });
  }

  String _fmtRp(int n) =>
      'Rp ${n.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.')}';

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final totalPot = _betAmount * widget.playerCount;
    final canBet   = _saldo >= _minBet && _betAmount >= _minBet;

    return Container(
      padding: EdgeInsets.only(
        left: 20, right: 20, top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      decoration: BoxDecoration(
        color: _kDark,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        border: const Border(top: BorderSide(color: Color(0x33FFD700), width: 1.5)),
        boxShadow: [BoxShadow(color: _kGold.withValues(alpha: 0.08), blurRadius: 30)],
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [

        // Handle
        Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 18),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),

        // Title
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Text('🎲', style: TextStyle(fontSize: 24)),
          const SizedBox(width: 10),
          Text('TARUHAN KOIN', style: TextStyle(
            fontFamily: 'Orbitron', fontSize: 16, fontWeight: FontWeight.w900,
            color: Colors.white,
            shadows: [Shadow(color: _kGold.withValues(alpha: 0.8), blurRadius: 12)],
          )),
        ]),
        const SizedBox(height: 6),
        Text('Mode: ${widget.gameMode}  �  ${widget.playerCount} Pemain',
            style: const TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 10)),

        const SizedBox(height: 18),

        // Saldo display
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            color: Colors.white.withValues(alpha: 0.04),
            border: Border.all(color: Colors.white12),
          ),
          child: Row(children: [
            const Text('💰', style: TextStyle(fontSize: 20)),
            const SizedBox(width: 10),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('SALDO KAMU', style: TextStyle(
                  color: Colors.white38, fontFamily: 'Orbitron', fontSize: 9, letterSpacing: 2)),
              const SizedBox(height: 2),
              _loadingSaldo
                  ? const SizedBox(width: 80, height: 16,
                      child: LinearProgressIndicator(valueColor: AlwaysStoppedAnimation(_kGold)))
                  : Text(_fmtRp(_saldo), style: const TextStyle(
                      color: _kGold, fontFamily: 'Orbitron', fontSize: 16, fontWeight: FontWeight.w900)),
            ]),
            const Spacer(),
            GestureDetector(
              onTap: _fetchSaldo,
              child: Container(padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.05), borderRadius: BorderRadius.circular(8)),
                child: const Icon(Icons.refresh, color: Colors.white38, size: 16)),
            ),
          ]),
        ),

        const SizedBox(height: 16),

        // Toggle taruhan
        Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('AKTIFKAN TARUHAN', style: TextStyle(
                color: Colors.white70, fontFamily: 'Orbitron', fontSize: 11, fontWeight: FontWeight.bold)),
            const SizedBox(height: 2),
            Text(_saldo < _minBet ? 'Saldo min. ${_fmtRp(_minBet)}' : 'Pemenang ambil semua pot',
                style: const TextStyle(color: Colors.white30, fontFamily: 'ShareTechMono', fontSize: 9)),
          ])),
          Switch(
            value: _enableBet,
            onChanged: _saldo >= _minBet ? (v) => setState(() {
              _enableBet = v;
              if (v && _betAmount < _minBet) _setBet(_minBet);
              if (!v) _betAmount = 0;
            }) : null,
            activeColor: _kGold,
            inactiveThumbColor: Colors.white24,
          ),
        ]),

        if (_enableBet) ...[
          const SizedBox(height: 14),

          // Preset chips
          Wrap(spacing: 8, runSpacing: 8, children: _presets.map((p) {
            final isSel = _betAmount == p;
            final canAfford = _saldo >= p;
            return GestureDetector(
              onTap: canAfford ? () => _setBet(p) : null,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: isSel ? _kGold.withValues(alpha: 0.2) : (canAfford ? Colors.white.withValues(alpha: 0.06) : Colors.white.withValues(alpha: 0.02)),
                  border: Border.all(
                    color: isSel ? _kGold : (canAfford ? Colors.white24 : Colors.white12),
                    width: isSel ? 2 : 1),
                  boxShadow: isSel ? [BoxShadow(color: _kGold.withValues(alpha: 0.3), blurRadius: 10)] : [],
                ),
                child: Text(_fmtRp(p), style: TextStyle(
                  color: isSel ? _kGold : (canAfford ? Colors.white60 : Colors.white24),
                  fontFamily: 'Orbitron', fontSize: 10, fontWeight: FontWeight.bold)),
              ),
            );
          }).toList()),

          const SizedBox(height: 12),

          // Manual input
          Row(children: [
            Expanded(child: TextField(
              controller: _ctrl,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 15),
              onChanged: (v) {
                final parsed = int.tryParse(v) ?? 0;
                setState(() => _betAmount = parsed.clamp(0, _saldo));
              },
              decoration: InputDecoration(
                hintText: 'Nominal taruhan',
                hintStyle: const TextStyle(color: Colors.white24),
                prefixText: 'Rp ',
                prefixStyle: const TextStyle(color: _kGold, fontFamily: 'Orbitron', fontWeight: FontWeight.bold),
                filled: true,
                fillColor: Colors.white.withValues(alpha: 0.05),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Colors.white12)),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Colors.white12)),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: _kGold, width: 2)),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              ),
            )),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: () => _setBet(_saldo),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
                decoration: BoxDecoration(
                  color: _kGold.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _kGold.withValues(alpha: 0.4)),
                ),
                child: const Text('MAX', style: TextStyle(color: _kGold, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 10)),
              ),
            ),
          ]),

          const SizedBox(height: 14),

          // Total pot preview
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              gradient: LinearGradient(colors: [_kGold.withValues(alpha: 0.12), Colors.orange.withValues(alpha: 0.08)]),
              border: Border.all(color: _kGold.withValues(alpha: 0.35)),
            ),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('TARUHAN KAMU', style: TextStyle(color: Colors.white38, fontFamily: 'Orbitron', fontSize: 9, letterSpacing: 1)),
                Text(_fmtRp(_betAmount), style: const TextStyle(color: Colors.white70, fontFamily: 'Orbitron', fontSize: 13, fontWeight: FontWeight.bold)),
              ]),
              const Text('�  ${2}', style: TextStyle(color: Colors.white38, fontSize: 20)),
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                const Text('TOTAL POT 🏆', style: TextStyle(color: _kGold, fontFamily: 'Orbitron', fontSize: 9, letterSpacing: 1)),
                Text(_fmtRp(totalPot), style: const TextStyle(color: _kGold, fontFamily: 'Orbitron', fontSize: 16, fontWeight: FontWeight.w900)),
              ]),
            ]),
          ),

          const SizedBox(height: 4),
          Text(
            '️ Taruhan dikurangi saat game mulai. Pemenang dapat total pot.',
            style: const TextStyle(color: Colors.white24, fontFamily: 'ShareTechMono', fontSize: 9),
            textAlign: TextAlign.center,
          ),
        ],

        const SizedBox(height: 20),

        // Action buttons
        Row(children: [
          Expanded(child: OutlinedButton(
            onPressed: () => widget.onConfirm(0),
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: Colors.white24),
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            child: const Text('Tanpa Taruhan', style: TextStyle(color: Colors.white54, fontFamily: 'Orbitron', fontSize: 10)),
          )),
          const SizedBox(width: 12),
          Expanded(flex: 2, child: ElevatedButton(
            onPressed: _enableBet && canBet ? () => widget.onConfirm(_betAmount) : (!_enableBet ? () => widget.onConfirm(0) : null),
            style: ElevatedButton.styleFrom(
              backgroundColor: _enableBet && canBet ? _kGold : Colors.white12,
              foregroundColor: _enableBet && canBet ? Colors.black : Colors.white38,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              elevation: _enableBet && canBet ? 8 : 0,
              shadowColor: _kGold.withValues(alpha: 0.4),
            ),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(_enableBet ? '🎲 TARUHAN!' : '� MULAI', style: TextStyle(
                fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 12,
                color: _enableBet && canBet ? Colors.black : Colors.white38)),
            ]),
          )),
        ]),
      ]),
    );
  }
}

// 
// WIDGET: BET INFO BAR (tampil di dalam game)
// Ditempel di atas board/bawah header
// 
class BetInfoBar extends StatelessWidget {
  final int betAmount;
  final int playerCount;
  final bool isActive;

  const BetInfoBar({
    super.key,
    required this.betAmount,
    required this.playerCount,
    required this.isActive,
  });

  String _fmtRp(int n) =>
      'Rp ${n.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.')}';

  @override
  Widget build(BuildContext context) {
    if (!isActive || betAmount <= 0) return const SizedBox.shrink();
    final totalPot = betAmount * playerCount;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: LinearGradient(colors: [_kGold.withValues(alpha: 0.18), Colors.orange.withValues(alpha: 0.1)]),
        border: Border.all(color: _kGold.withValues(alpha: 0.4)),
        boxShadow: [BoxShadow(color: _kGold.withValues(alpha: 0.15), blurRadius: 12)],
      ),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Text('🏆', style: TextStyle(fontSize: 16)),
        const SizedBox(width: 8),
        Text('POT: ${_fmtRp(totalPot)}',
            style: const TextStyle(
              color: _kGold, fontFamily: 'Orbitron',
              fontSize: 13, fontWeight: FontWeight.w900,
              letterSpacing: 1,
            )),
        const SizedBox(width: 10),
        Text('(${_fmtRp(betAmount)} � $playerCount pemain)',
            style: const TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 9)),
      ]),
    );
  }
}

// 
// WIDGET: BET RESULT OVERLAY (muncul di result page)
// 
class BetResultCard extends StatelessWidget {
  final bool isWinner;
  final int betAmount;
  final int totalPot;
  final int playerCount;
  final bool isLoading;
  final String? errorMsg;

  const BetResultCard({
    super.key,
    required this.isWinner,
    required this.betAmount,
    required this.totalPot,
    required this.playerCount,
    this.isLoading = false,
    this.errorMsg,
  });

  String _fmtRp(int n) =>
      'Rp ${n.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.')}';

  @override
  Widget build(BuildContext context) {
    if (betAmount <= 0) return const SizedBox.shrink();

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: LinearGradient(
          colors: isWinner
              ? [_kGold.withValues(alpha: 0.2), Colors.orange.withValues(alpha: 0.1)]
              : [Colors.red.withValues(alpha: 0.15), Colors.red.withValues(alpha: 0.05)],
        ),
        border: Border.all(
          color: isWinner ? _kGold.withValues(alpha: 0.6) : Colors.red.withValues(alpha: 0.4),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: isWinner ? _kGold.withValues(alpha: 0.2) : Colors.red.withValues(alpha: 0.15),
            blurRadius: 20,
          )
        ],
      ),
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(isWinner ? '🏆' : '💸', style: const TextStyle(fontSize: 28)),
          const SizedBox(width: 10),
          Text(
            isWinner ? 'KAMU MENANG TARUHAN!' : 'TARUHAN KALAH',
            style: TextStyle(
              color: isWinner ? _kGold : Colors.red.shade300,
              fontFamily: 'Orbitron', fontSize: 14, fontWeight: FontWeight.w900,
            ),
          ),
        ]),
        const SizedBox(height: 12),

        if (isLoading) ...[
          const CircularProgressIndicator(color: _kGold, strokeWidth: 2),
          const SizedBox(height: 6),
          const Text('Memproses koin...', style: TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 10)),
        ] else if (errorMsg != null) ...[
          Text('️ $errorMsg', style: const TextStyle(color: Colors.orange, fontFamily: 'ShareTechMono', fontSize: 10), textAlign: TextAlign.center),
        ] else ...[
          Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
            _statCol('TARUHAN', _fmtRp(betAmount), Colors.white54),
            _statCol('PEMAIN', '�$playerCount', Colors.white54),
            _statCol(isWinner ? 'KAMU DAPAT' : 'KAMU KEHILANGAN',
                isWinner ? '+${_fmtRp(totalPot)}' : '-${_fmtRp(betAmount)}',
                isWinner ? _kGold : Colors.red.shade300),
          ]),
        ],
      ]),
    );
  }

  Widget _statCol(String label, String value, Color color) {
    return Column(children: [
      Text(label, style: const TextStyle(color: Colors.white30, fontFamily: 'Orbitron', fontSize: 8, letterSpacing: 1)),
      const SizedBox(height: 4),
      Text(value, style: TextStyle(color: color, fontFamily: 'Orbitron', fontSize: 12, fontWeight: FontWeight.bold)),
    ]);
  }
}

// 
// WIDGET: BET HISTORY PAGE
// 
class BetHistoryPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const BetHistoryPage({super.key, required this.username, required this.sessionKey});

  @override
  State<BetHistoryPage> createState() => _BetHistoryPageState();
}

class _BetHistoryPageState extends State<BetHistoryPage> {
  List<BetHistory> _history = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() {
    // Ambil dari shared_preferences atau local storage
    // Untuk sekarang pakai static list yang di-pass dari parent
    setState(() {});
  }

  String _fmtRp(int n) =>
      'Rp ${n.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.')}';

  String _fmtDate(DateTime dt) {
    return '${dt.day}/${dt.month}/${dt.year} ${dt.hour.toString().padLeft(2,'0')}:${dt.minute.toString().padLeft(2,'0')}';
  }

  @override
  Widget build(BuildContext context) {
    final accent = Theme.of(context).colorScheme.secondary;

    return Scaffold(
      backgroundColor: _kDark,
      body: SafeArea(child: Column(children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: accent.withValues(alpha: 0.2))),
                child: const Icon(Icons.arrow_back, color: Colors.white70, size: 20)),
            ),
            const Spacer(),
            Column(children: [
              Text('RIWAYAT TARUHAN', style: TextStyle(
                  fontFamily: 'Orbitron', fontSize: 14, fontWeight: FontWeight.w900,
                  color: Colors.white, shadows: [Shadow(color: _kGold, blurRadius: 8)])),
              const Text('Ular Tangga', style: TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono', fontSize: 10)),
            ]),
            const Spacer(),
            const SizedBox(width: 40),
          ]),
        ),

        if (_history.isEmpty)
          Expanded(child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('🎲', style: TextStyle(fontSize: 48)),
            const SizedBox(height: 16),
            const Text('Belum ada riwayat taruhan', style: TextStyle(color: Colors.white38, fontFamily: 'Orbitron', fontSize: 12)),
            const SizedBox(height: 6),
            const Text('Mainkan game dengan taruhan\nuntuk melihat riwayat di sini',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white24, fontFamily: 'ShareTechMono', fontSize: 10)),
          ])))
        else
          Expanded(child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: _history.length,
            itemBuilder: (_, i) {
              final h = _history[i];
              final isWin = h.result == 'menang';
              return Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: isWin ? _kGold.withValues(alpha: 0.4) : Colors.red.withValues(alpha: 0.3)),
                  color: isWin ? _kGold.withValues(alpha: 0.06) : Colors.red.withValues(alpha: 0.05),
                ),
                child: Row(children: [
                  Text(isWin ? '🏆' : '💸', style: const TextStyle(fontSize: 28)),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(h.gameMode, style: const TextStyle(color: Colors.white70, fontFamily: 'Orbitron', fontSize: 11, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 3),
                    Text('${h.players} pemain � Bet: ${_fmtRp(h.betAmount)} � Pot: ${_fmtRp(h.totalPot)}',
                        style: const TextStyle(color: Colors.white30, fontFamily: 'ShareTechMono', fontSize: 9)),
                    const SizedBox(height: 2),
                    Text(_fmtDate(h.time), style: const TextStyle(color: Colors.white24, fontFamily: 'ShareTechMono', fontSize: 8)),
                  ])),
                  Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                    Text(
                      isWin ? '+${_fmtRp(h.saldoChange)}' : '-${_fmtRp(h.betAmount)}',
                      style: TextStyle(
                        color: isWin ? _kGold : Colors.red.shade300,
                        fontFamily: 'Orbitron', fontSize: 13, fontWeight: FontWeight.w900,
                      ),
                    ),
                    Text(isWin ? 'MENANG' : 'KALAH', style: TextStyle(
                        color: isWin ? _kGold.withValues(alpha: 0.7) : Colors.red.withValues(alpha: 0.6),
                        fontFamily: 'Orbitron', fontSize: 9)),
                  ]),
                ]),
              );
            },
          )),
      ])),
    );
  }
}

// 
// WIDGET: OWNER TOP UP PAGE (khusus owner/admin)
// 
class OwnerTopUpPage extends StatefulWidget {
  final String ownerUsername;
  final String sessionKey;
  final String userRole;

  const OwnerTopUpPage({
    super.key,
    required this.ownerUsername,
    required this.sessionKey,
    required this.userRole,
  });

  @override
  State<OwnerTopUpPage> createState() => _OwnerTopUpPageState();
}

class _OwnerTopUpPageState extends State<OwnerTopUpPage> {
  List<dynamic> _users = [];
  bool _loadingUsers = true;
  String _search = '';
  final _searchCtrl = TextEditingController();
  final _amountCtrl = TextEditingController();
  String? _selectedUser;
  bool _processing = false;
  String? _lastMsg;
  bool _lastSuccess = false;

  static const _presets = [5000, 10000, 25000, 50000, 100000, 500000];

  bool get _isOwner => widget.userRole.toLowerCase() == 'owner';

  @override
  void initState() {
    super.initState();
    _fetchUsers();
  }

  Future<void> _fetchUsers() async {
    setState(() => _loadingUsers = true);
    final users = await BetApi.getUsers(widget.sessionKey);
    if (mounted) setState(() { _users = users; _loadingUsers = false; });
  }

  List<dynamic> get _filtered => _users.where((u) {
    final name = (u['username'] ?? '').toString().toLowerCase();
    return _search.isEmpty || name.contains(_search.toLowerCase());
  }).toList();

  String _fmtRp(int n) =>
      'Rp ${n.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.')}';

  Future<void> _doTopUp() async {
    if (_selectedUser == null) {
      _showMsg('Pilih user dulu!', false); return;
    }
    final amount = int.tryParse(_amountCtrl.text.replaceAll('.', '')) ?? 0;
    if (amount < 1000) {
      _showMsg('Minimal top up Rp 1.000', false); return;
    }

    setState(() => _processing = true);
    final res = await BetApi.topUpUser(widget.sessionKey, _selectedUser!, amount);
    if (mounted) {
      setState(() => _processing = false);
      if (res['valid'] == true) {
        _showMsg('�� Top up ${_fmtRp(amount)} ke @$_selectedUser berhasil!', true);
        _amountCtrl.clear();
      } else {
        _showMsg('� ${res['message'] ?? 'Gagal'}', false);
      }
    }
  }

  void _showMsg(String msg, bool success) {
    setState(() { _lastMsg = msg; _lastSuccess = success; });
    Future.delayed(const Duration(seconds: 4), () {
      if (mounted) setState(() => _lastMsg = null);
    });
  }

  @override
  void dispose() { _searchCtrl.dispose(); _amountCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final accent = Theme.of(context).colorScheme.secondary;

    if (!_isOwner) {
      return Scaffold(
        backgroundColor: _kDark,
        body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('�', style: TextStyle(fontSize: 48)),
          const SizedBox(height: 12),
          const Text('Akses hanya untuk OWNER', style: TextStyle(color: Colors.white38, fontFamily: 'Orbitron', fontSize: 12)),
        ])),
      );
    }

    return Scaffold(
      backgroundColor: _kDark,
      body: SafeArea(child: Column(children: [

        // Header
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: accent.withValues(alpha: 0.2))),
                child: const Icon(Icons.arrow_back, color: Colors.white70, size: 20)),
            ),
            const Spacer(),
            Column(children: [
              Text('💰 TOP UP KOIN', style: TextStyle(
                  fontFamily: 'Orbitron', fontSize: 15, fontWeight: FontWeight.w900,
                  color: Colors.white, shadows: [Shadow(color: _kGold, blurRadius: 10)])),
              Container(
                margin: const EdgeInsets.only(top: 3),
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(color: _kGold.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: _kGold.withValues(alpha: 0.4))),
                child: const Text('OWNER PANEL', style: TextStyle(color: _kGold, fontFamily: 'Orbitron', fontSize: 8, fontWeight: FontWeight.bold)),
              ),
            ]),
            const Spacer(),
            GestureDetector(
              onTap: _fetchUsers,
              child: Container(padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: accent.withValues(alpha: 0.2))),
                child: const Icon(Icons.refresh, color: Colors.white70, size: 20)),
            ),
          ]),
        ),

        Expanded(child: SingleChildScrollView(padding: const EdgeInsets.symmetric(horizontal: 16), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

          // Search user
          const Text('PILIH USER', style: TextStyle(color: Colors.white38, fontFamily: 'Orbitron', fontSize: 10, letterSpacing: 2)),
          const SizedBox(height: 8),
          TextField(
            controller: _searchCtrl,
            style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono'),
            onChanged: (v) => setState(() => _search = v),
            decoration: InputDecoration(
              hintText: '�  Cari username...',
              hintStyle: const TextStyle(color: Colors.white24),
              prefixIcon: const Icon(Icons.search, color: Colors.white30, size: 18),
              filled: true,
              fillColor: Colors.white.withValues(alpha: 0.05),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Colors.white12)),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Colors.white12)),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: _kGold, width: 1.5)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            ),
          ),
          const SizedBox(height: 10),

          // User list
          if (_loadingUsers)
            const Center(child: Padding(
              padding: EdgeInsets.all(20),
              child: CircularProgressIndicator(color: _kGold, strokeWidth: 2),
            ))
          else if (_filtered.isEmpty)
            const Center(child: Padding(
              padding: EdgeInsets.all(20),
              child: Text('Tidak ada user', style: TextStyle(color: Colors.white38, fontFamily: 'ShareTechMono')),
            ))
          else
            Container(
              height: 200,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.white12),
                color: Colors.white.withValues(alpha: 0.03),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: ListView.builder(
                  itemCount: _filtered.length,
                  itemBuilder: (_, i) {
                    final u = _filtered[i];
                    final name = u['username'] ?? '';
                    final role = u['role'] ?? 'guest';
                    final isSel = _selectedUser == name;
                    return GestureDetector(
                      onTap: () => setState(() => _selectedUser = name),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 150),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                        decoration: BoxDecoration(
                          color: isSel ? _kGold.withValues(alpha: 0.12) : Colors.transparent,
                          border: Border(bottom: BorderSide(color: Colors.white.withValues(alpha: 0.05))),
                        ),
                        child: Row(children: [
                          Container(width: 8, height: 8,
                              decoration: BoxDecoration(shape: BoxShape.circle,
                                  color: isSel ? _kGold : Colors.white24)),
                          const SizedBox(width: 10),
                          Text('@$name', style: TextStyle(
                              color: isSel ? Colors.white : Colors.white70,
                              fontFamily: 'Orbitron', fontSize: 11,
                              fontWeight: isSel ? FontWeight.bold : FontWeight.normal)),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              color: _roleColor(role).withValues(alpha: 0.15),
                              border: Border.all(color: _roleColor(role).withValues(alpha: 0.4)),
                            ),
                            child: Text(role.toUpperCase(), style: TextStyle(
                                color: _roleColor(role), fontSize: 7, fontWeight: FontWeight.bold)),
                          ),
                          if (isSel) ...[const Spacer(), const Icon(Icons.check_circle, color: _kGold, size: 16)],
                        ]),
                      ),
                    );
                  },
                ),
              ),
            ),

          const SizedBox(height: 20),

          // Nominal
          const Text('NOMINAL TOP UP', style: TextStyle(color: Colors.white38, fontFamily: 'Orbitron', fontSize: 10, letterSpacing: 2)),
          const SizedBox(height: 10),

          // Preset chips
          Wrap(spacing: 8, runSpacing: 8, children: _presets.map((p) {
            return GestureDetector(
              onTap: () => setState(() => _amountCtrl.text = p.toString()),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Colors.white.withValues(alpha: 0.06),
                  border: Border.all(color: Colors.white24),
                ),
                child: Text(_fmtRp(p), style: const TextStyle(
                    color: Colors.white70, fontFamily: 'Orbitron', fontSize: 10, fontWeight: FontWeight.bold)),
              ),
            );
          }).toList()),
          const SizedBox(height: 12),

          TextField(
            controller: _amountCtrl,
            keyboardType: TextInputType.number,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 16),
            decoration: InputDecoration(
              hintText: '0',
              hintStyle: const TextStyle(color: Colors.white24),
              prefixText: 'Rp ',
              prefixStyle: const TextStyle(color: _kGold, fontFamily: 'Orbitron', fontWeight: FontWeight.bold),
              filled: true,
              fillColor: Colors.white.withValues(alpha: 0.05),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Colors.white12)),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Colors.white12)),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: _kGold, width: 2)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            ),
          ),

          const SizedBox(height: 20),

          // Selected user preview
          if (_selectedUser != null)
            Container(
              padding: const EdgeInsets.all(14),
              margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                gradient: LinearGradient(colors: [_kGold.withValues(alpha: 0.1), Colors.orange.withValues(alpha: 0.06)]),
                border: Border.all(color: _kGold.withValues(alpha: 0.3)),
              ),
              child: Row(children: [
                const Text('�', style: TextStyle(fontSize: 22)),
                const SizedBox(width: 10),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('TOP UP KE', style: TextStyle(color: Colors.white30, fontFamily: 'Orbitron', fontSize: 9, letterSpacing: 2)),
                  Text('@$_selectedUser', style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 14, fontWeight: FontWeight.bold)),
                ])),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  const Text('JUMLAH', style: TextStyle(color: Colors.white30, fontFamily: 'Orbitron', fontSize: 9, letterSpacing: 2)),
                  Text(
                    int.tryParse(_amountCtrl.text) != null && int.parse(_amountCtrl.text) > 0
                        ? _fmtRp(int.parse(_amountCtrl.text))
                        : '',
                    style: const TextStyle(color: _kGold, fontFamily: 'Orbitron', fontSize: 14, fontWeight: FontWeight.bold),
                  ),
                ]),
              ]),
            ),

          // Status message
          if (_lastMsg != null)
            AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: _lastSuccess ? Colors.green.withValues(alpha: 0.12) : Colors.red.withValues(alpha: 0.12),
                border: Border.all(color: _lastSuccess ? Colors.green.withValues(alpha: 0.4) : Colors.red.withValues(alpha: 0.4)),
              ),
              child: Text(_lastMsg!, style: TextStyle(
                  color: _lastSuccess ? Colors.green.shade300 : Colors.red.shade300,
                  fontFamily: 'ShareTechMono', fontSize: 11),
                textAlign: TextAlign.center),
            ),

          // Top up button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _processing ? null : _doTopUp,
              style: ElevatedButton.styleFrom(
                backgroundColor: _kGold,
                foregroundColor: Colors.black,
                disabledBackgroundColor: Colors.white12,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                elevation: 8,
                shadowColor: _kGold.withValues(alpha: 0.4),
              ),
              child: _processing
                  ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2))
                  : const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Text('💰', style: TextStyle(fontSize: 18)),
                      SizedBox(width: 8),
                      Text('TOP UP SEKARANG',
                          style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 1)),
                    ]),
            ),
          ),

          const SizedBox(height: 20),
        ]))),
      ])),
    );
  }

  Color _roleColor(String role) {
    switch (role.toLowerCase()) {
      case 'owner':  return _kGold;
      case 'admin':  return const Color(0xFFFF6B35);
      case 'vip':    return const Color(0xFF9B59B6);
      case 'member': return const Color(0xFF3498DB);
      default:       return const Color(0xFF95A5A6);
    }
  }
}
