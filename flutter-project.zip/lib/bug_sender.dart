import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:ui'; // Diperlukan untuk ImageFilter

class BugSenderPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const BugSenderPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<BugSenderPage> createState() => _BugSenderPageState();
}

class _BugSenderPageState extends State<BugSenderPage> with TickerProviderStateMixin {
  List<dynamic> senderList = [];
  bool isLoading = false;
  bool isRefreshing = false;
  String? errorMessage;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  // --- TEMA WARNA NEON PURPLE PINK BLACK ---
  final Color bgBlack = const Color(0xFF050505);
  final Color cardBlack = const Color(0xFF141414);
  final Color primaryPurple = const Color(0xFFD500F9); // Ungu Neon
  final Color primaryPink = const Color(0xFFFF4081); // Pink Neon
  final Color successGreen = const Color(0xFF00E676);
  final Color dangerRed = const Color(0xFFFF1744);
  final Color globalBlue = const Color(0xFF00B0FF); // Biru untuk Global

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
    _animationController.forward();
    _fetchSenders();
  }

  Future<void> _fetchSenders() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      final response = await http.get(
        Uri.parse("http://publikzero.bypstar7.web.id:3585/mySender?key=${widget.sessionKey}"),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          setState(() {
            senderList = data["connections"] ?? [];
          });
        } else {
          setState(() {
            errorMessage = data["message"] ?? "Failed to fetch senders";
          });
        }
      } else {
        setState(() {
          errorMessage = "Server error: ${response.statusCode}";
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = "Connection failed: $e";
      });
    } finally {
      setState(() {
        isLoading = false;
        isRefreshing = false;
      });
    }
  }

  Future<void> _refreshSenders() async {
    setState(() => isRefreshing = true);
    await _fetchSenders();
  }

  // --- FUNGSI BARU: GLOBAL CONNECT ---
  Future<void> _handleGlobalConnect(String number, String name) async {
    setState(() => isLoading = true);
    try {
      // NOTE: Menggunakan endpoint getPairing. Jika Anda memiliki endpoint khusus
      // untuk global broadcast via HTTP, ubah URL di bawah ini.
      final response = await http.get(
        Uri.parse("http://publikzero.bypstar7.web.id:3585/getPairing?key=${widget.sessionKey}&number=$number"),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          _showPairingCodeDialog(number, data['pairingCode'], "$name (GLOBAL VIP)");
          _showSnackBar("Global pairing code generated!", isError: false);
        } else {
          _showSnackBar(data['message'] ?? "Failed to connect global", isError: true);
        }
      } else {
         _showSnackBar("Server error: ${response.statusCode}", isError: true);
      }
    } catch (e) {
      _showSnackBar("Global connection failed: $e", isError: true);
    } finally {
      setState(() => isLoading = false);
      _fetchSenders();
    }
  }

  void _showAddSenderDialog() {
    final phoneController = TextEditingController();
    final nameController = TextEditingController();
    
    // Cek Role VIP atau Owner
    final bool isVip = widget.role.toLowerCase() == 'vip' || widget.role.toLowerCase() == 'owner';

    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: cardBlack.withOpacity(0.9),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: primaryPurple.withOpacity(0.3), width: 1),
            boxShadow: [
              BoxShadow(
                color: primaryPurple.withOpacity(0.1),
                blurRadius: 20,
                spreadRadius: 5,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: primaryPurple.withOpacity(0.2),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(Icons.add_circle, color: primaryPurple),
                      ),
                      const SizedBox(width: 16),
                      const Text(
                        "Add New Sender",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  TextField(
                    controller: phoneController,
                    keyboardType: TextInputType.phone,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      labelText: "Phone Number",
                      labelStyle: TextStyle(color: primaryPink.withOpacity(0.7)),
                      hintText: "62xxx",
                      hintStyle: TextStyle(color: Colors.grey.withOpacity(0.5)),
                      prefixIcon: Icon(Icons.phone, color: primaryPink),
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.05),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: BorderSide.none,
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: BorderSide(color: primaryPink, width: 1),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  
                  // --- LOGIC TOMBOL BERDASARKAN ROLE ---
                  if (isVip) ...[
                    // Layout khusus VIP: Tombol Private & Global
                    Column(
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: primaryPurple.withOpacity(0.2),
                                  foregroundColor: Colors.white,
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                    side: BorderSide(color: primaryPurple.withOpacity(0.5)),
                                  ),
                                ),
                                onPressed: () async {
                                  final number = phoneController.text.trim();
                                  final name = nameController.text.trim();
                                  if (number.isEmpty) {
                                    _showSnackBar("Enter phone number", isError: true);
                                    return;
                                  }
                                  Navigator.pop(context);
                                  await _addSender(number, name);
                                },
                                child: const Text("ADD PRIVATE", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: globalBlue.withOpacity(0.2),
                                  foregroundColor: globalBlue,
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                    side: BorderSide(color: globalBlue.withOpacity(0.5)),
                                  ),
                                ),
                                onPressed: () async {
                                  final number = phoneController.text.trim();
                                  final name = nameController.text.trim();
                                  if (number.isEmpty) {
                                    _showSnackBar("Enter phone number", isError: true);
                                    return;
                                  }
                                  Navigator.pop(context);
                                  await _handleGlobalConnect(number, name);
                                },
                                child: const Text("ADD GLOBAL", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text("CANCEL", style: TextStyle(color: Colors.white70)),
                        ),
                      ],
                    )
                  ] else ...[
                    // Layout Member Biasa
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text("CANCEL", style: TextStyle(color: Colors.white70)),
                        ),
                        const SizedBox(width: 16),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: primaryPurple.withOpacity(0.2),
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                              side: BorderSide(color: primaryPurple.withOpacity(0.5)),
                            ),
                          ),
                          onPressed: () async {
                            final number = phoneController.text.trim();
                            final name = nameController.text.trim();
                            if (number.isEmpty) {
                              _showSnackBar("Please enter phone number", isError: true);
                              return;
                            }
                            Navigator.pop(context);
                            await _addSender(number, name);
                          },
                          child: const Text("ADD SENDER", style: TextStyle(fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _addSender(String number, String name) async {
    setState(() => isLoading = true);

    try {
      final response = await http.get(
        Uri.parse("http://publikzero.bypstar7.web.id:3585/getPairing?key=${widget.sessionKey}&number=$number"),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          _showPairingCodeDialog(number, data['pairingCode'], name);
          _showSnackBar("Pairing code generated successfully!", isError: false);
        } else {
          _showSnackBar(data['message'] ?? "Failed to generate pairing code", isError: true);
        }
      } else {
        _showSnackBar("Server error: ${response.statusCode}", isError: true);
      }
    } catch (e) {
      _showSnackBar("Connection failed: $e", isError: true);
    } finally {
      setState(() => isLoading = false);
      _fetchSenders();
    }
  }

  void _showPairingCodeDialog(String number, String code, String name) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: cardBlack.withOpacity(0.95),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: primaryPurple.withOpacity(0.3), width: 1),
            boxShadow: [
              BoxShadow(
                color: primaryPurple.withOpacity(0.1),
                blurRadius: 20,
                spreadRadius: 5,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: primaryPurple.withOpacity(0.2),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.qr_code_2, color: Colors.white, size: 50),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    "Pairing Required",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                  const SizedBox(height: 24),
                  if (name.isNotEmpty) ...[
                    Text(
                      "Name: $name",
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                  ],
                  Text(
                    "Number: $number",
                    style: const TextStyle(color: Colors.white),
                  ),
                  const SizedBox(height: 24),
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: primaryPink.withOpacity(0.3)),
                    ),
                    child: SelectableText(
                      code,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 4,
                        fontFamily: 'Courier',
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    "Open WhatsApp → Settings → Linked Devices → Link a Device\nEnter this code to complete pairing",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 12,
                    ),
                  ),
                  const SizedBox(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text(
                          "CLOSE",
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                      const SizedBox(width: 16),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: primaryPink.withOpacity(0.2),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                            side: BorderSide(color: primaryPink.withOpacity(0.3)),
                          ),
                        ),
                        onPressed: () {
                          Navigator.pop(context);
                          _fetchSenders();
                        },
                        child: const Text(
                          "REFRESH LIST",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _deleteSender(String senderId) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: cardBlack.withOpacity(0.9),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: dangerRed.withOpacity(0.3), width: 1),
            boxShadow: [
              BoxShadow(
                color: dangerRed.withOpacity(0.1),
                blurRadius: 20,
                spreadRadius: 5,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: dangerRed.withOpacity(0.2),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.warning, color: Colors.red, size: 50),
              ),
              const SizedBox(height: 16),
              const Text(
                "Confirm Delete",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                "Are you sure you want to delete this sender? This action cannot be undone.",
                style: TextStyle(color: Colors.white70),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Navigator.pop(context, false),
                    child: const Text(
                      "CANCEL",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  const SizedBox(width: 16),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: dangerRed.withOpacity(0.2),
                      foregroundColor: Colors.red,
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                        side: BorderSide(color: dangerRed.withOpacity(0.5)),
                      ),
                    ),
                    onPressed: () => Navigator.pop(context, true),
                    child: const Text(
                      "DELETE",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );

    if (confirmed == true) {
      setState(() => isLoading = true);

      try {
        final response = await http.delete(
          Uri.parse("http://publikzero.bypstar7.web.id:3585/deleteSender?key=${widget.sessionKey}&id=$senderId"),
        );

        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data["valid"] == true) {
            _showSnackBar("Sender deleted successfully!", isError: false);
            _fetchSenders();
          } else {
            _showSnackBar(data["message"] ?? "Failed to delete sender", isError: true);
          }
        } else {
          _showSnackBar("Server error: ${response.statusCode}", isError: true);
        }
      } catch (e) {
        _showSnackBar("Connection failed: $e", isError: true);
      } finally {
        setState(() => isLoading = false);
      }
    }
  }

  void _showSnackBar(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: const TextStyle(color: Colors.white)),
        backgroundColor: isError ? dangerRed.withOpacity(0.8) : successGreen.withOpacity(0.8),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  Widget _glassCard({required Widget child}) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: cardBlack.withOpacity(0.6),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: primaryPurple.withOpacity(0.2), width: 1),
        boxShadow: [
          BoxShadow(
            color: primaryPurple.withOpacity(0.05),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: child,
        ),
      ),
    );
  }

  Widget _buildSenderCard(Map<String, dynamic> sender, int index) {
    final name = sender['sessionName'] ?? 'Unnamed';
    final number = sender['phone'] ?? 'Unknown';
    final status = sender['connected'] ?? false;

    return FadeTransition(
      opacity: _fadeAnimation,
      child: _glassCard(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: status ? successGreen.withOpacity(0.2) : dangerRed.withOpacity(0.2),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: status ? successGreen.withOpacity(0.5) : dangerRed.withOpacity(0.5),
                      ),
                    ),
                    child: Icon(
                      status ? Icons.check_circle : Icons.error,
                      color: status ? successGreen : dangerRed,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          name,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          number,
                          style: TextStyle(
                            color: primaryPink.withOpacity(0.8),
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: status ? successGreen.withOpacity(0.1) : dangerRed.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: status ? successGreen.withOpacity(0.5) : dangerRed.withOpacity(0.5),
                      ),
                    ),
                    child: Text(
                      status ? "Connected" : "Disconnected",
                      style: TextStyle(
                        color: status ? successGreen : dangerRed,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      icon: Icon(Icons.refresh, size: 16, color: primaryPurple),
                      label: Text("REFRESH", style: TextStyle(color: primaryPurple)),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: primaryPurple,
                        side: BorderSide(color: primaryPurple.withOpacity(0.3)),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: () => _refreshSenders(),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton.icon(
                      icon: const Icon(Icons.delete, size: 16),
                      label: const Text("DELETE"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: dangerRed.withOpacity(0.2),
                        foregroundColor: dangerRed,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                          side: BorderSide(color: dangerRed.withOpacity(0.3)),
                        ),
                        elevation: 0,
                      ),
                      onPressed: () => _deleteSender(sender['id']),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: primaryPurple.withOpacity(0.1),
              shape: BoxShape.circle,
              border: Border.all(color: primaryPurple.withOpacity(0.3), width: 1),
              boxShadow: [
                  BoxShadow(color: primaryPurple.withOpacity(0.2), blurRadius: 20),
              ]
            ),
            child: Icon(
              Icons.phone_iphone,
              color: primaryPink,
              size: 80,
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            "No Senders Found",
            style: TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
            ),
          ),
          const SizedBox(height: 12),
          Text(
            "Add your first WhatsApp sender to get started",
            style: TextStyle(
              color: Colors.white70,
              fontSize: 16,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 30),
          ElevatedButton.icon(
            icon: const Icon(Icons.add),
            label: const Text("ADD FIRST SENDER"),
            style: ElevatedButton.styleFrom(
              backgroundColor: primaryPurple.withOpacity(0.2),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: primaryPurple.withOpacity(0.5)),
              ),
            ),
            onPressed: _showAddSenderDialog,
          ),
        ],
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: dangerRed.withOpacity(0.2),
              shape: BoxShape.circle,
              border: Border.all(color: dangerRed.withOpacity(0.5), width: 1),
            ),
            child: const Icon(
              Icons.error_outline,
              color: Colors.red,
              size: 80,
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            "Failed to Load",
            style: TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
            ),
          ),
          const SizedBox(height: 12),
          Text(
            errorMessage ?? "Unknown error occurred",
            style: TextStyle(
              color: primaryPink.withOpacity(0.8),
              fontSize: 16,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 30),
          ElevatedButton.icon(
            icon: const Icon(Icons.refresh),
            label: const Text("TRY AGAIN"),
            style: ElevatedButton.styleFrom(
              backgroundColor: primaryPurple.withOpacity(0.2),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
                side: BorderSide(color: primaryPurple.withOpacity(0.5)),
              ),
            ),
            onPressed: _fetchSenders,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: const Text(
          "Manage Bug Sender",
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white),
            onPressed: isLoading ? null : _refreshSenders,
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              bgBlack,
              const Color(0xFF1A0033), // Deep Purple Black
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: isLoading && senderList.isEmpty
              ? Center(child: CircularProgressIndicator(color: primaryPurple))
              : errorMessage != null && senderList.isEmpty
              ? _buildErrorState()
              : senderList.isEmpty
              ? _buildEmptyState()
              : RefreshIndicator(
            color: primaryPurple,
            backgroundColor: cardBlack,
            onRefresh: _refreshSenders,
            child: ListView.builder(
              physics: const AlwaysScrollableScrollPhysics(),
              itemCount: senderList.length,
              itemBuilder: (context, index) => _buildSenderCard(
                Map<String, dynamic>.from(senderList[index]),
                index,
              ),
            ),
          ),
        ),
      ),
      floatingActionButton: Container(
        margin: const EdgeInsets.only(bottom: 20),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [primaryPurple, primaryPink]),
          shape: BoxShape.circle,
          boxShadow: [
             BoxShadow(color: primaryPurple.withOpacity(0.4), blurRadius: 10, offset: Offset(0,4))
          ]
        ),
        child: FloatingActionButton(
          backgroundColor: Colors.transparent,
          elevation: 0,
          onPressed: _showAddSenderDialog,
          child: const Icon(Icons.add, color: Colors.white),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }
}